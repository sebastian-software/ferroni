# Production regex comparison

Host: Linux-6.6.141-x86_64-with-glibc2.39; x86_64.

Publication candidate: review host stability, raw samples, coverage and run intervals before publishing.

Ratios are comparator / Ferroni. Compile and first-use times concern one pattern; steady times concern the complete fixture batch.

Each comparison below uses only its explicitly listed common tasks. Families have equal aggregate weight; architectures are never combined.

## Eligibility

| Case | Engine | Status |
| --- | --- | --- |
| `uuid_shape` | rust | eligible |
| `uuid_shape` | regexr | eligible |
| `uuid_shape` | regexr_jit | eligible |
| `uuid_v4` | rust | eligible |
| `uuid_v4` | regexr | eligible |
| `uuid_v4` | regexr_jit | eligible |
| `ipv4_validation` | rust | eligible |
| `ipv4_validation` | regexr | eligible |
| `ipv4_validation` | regexr_jit | eligible |
| `ipv6_validation` | rust | eligible |
| `ipv6_validation` | regexr | eligible |
| `ipv6_validation` | regexr_jit | eligible |
| `semver_version_parse` | rust | eligible |
| `semver_version_parse` | regexr | syntax_rejected |
| `semver_version_parse` | regexr_jit | syntax_rejected |
| `semver_hyphen_range_captures` | rust | eligible |
| `semver_hyphen_range_captures` | regexr | syntax_rejected |
| `semver_hyphen_range_captures` | regexr_jit | syntax_rejected |
| `jinja_string_token` | rust | eligible |
| `jinja_string_token` | regexr | eligible |
| `jinja_string_token` | regexr_jit | eligible |
| `jinja_integer_token` | rust | eligible |
| `jinja_integer_token` | regexr | eligible |
| `jinja_integer_token` | regexr_jit | eligible |
| `jinja_float_token` | rust | eligible |
| `jinja_float_token` | regexr | api_unsupported |
| `jinja_float_token` | regexr_jit | api_unsupported |
| `django_email_local_part` | rust | eligible |
| `django_email_local_part` | regexr | syntax_rejected |
| `django_email_local_part` | regexr_jit | syntax_rejected |
| `django_email_domain` | rust | eligible |
| `django_email_domain` | regexr | syntax_rejected |
| `django_email_domain` | regexr_jit | syntax_rejected |
| `django_url_regex` | rust | eligible |
| `django_url_regex` | regexr | syntax_rejected |
| `django_url_regex` | regexr_jit | syntax_rejected |
| `fluent_bit_apache` | rust | eligible |
| `fluent_bit_apache` | regexr | eligible |
| `fluent_bit_apache` | regexr_jit | eligible |
| `fluent_bit_nginx` | rust | eligible |
| `fluent_bit_nginx` | regexr | eligible |
| `fluent_bit_nginx` | regexr_jit | eligible |
| `rails_underscore_regex_step` | rust | eligible |
| `rails_underscore_regex_step` | regexr | eligible |
| `rails_underscore_regex_step` | regexr_jit | eligible |
| `mastodon_hashtag_regex_step` | rust | eligible |
| `mastodon_hashtag_regex_step` | regexr | semantic_difference |
| `mastodon_hashtag_regex_step` | regexr_jit | semantic_difference |
| `python_markdown_smart_emphasis_re` | rust | eligible |
| `python_markdown_smart_emphasis_re` | regexr | api_unsupported |
| `python_markdown_smart_emphasis_re` | regexr_jit | api_unsupported |
| `python_markdown_smart_strong_em_re` | rust | eligible |
| `python_markdown_smart_strong_em_re` | regexr | api_unsupported |
| `python_markdown_smart_strong_em_re` | regexr_jit | api_unsupported |
| `wordpress_shortcode_captures` | rust | eligible |
| `wordpress_shortcode_captures` | regexr | syntax_rejected |
| `wordpress_shortcode_captures` | regexr_jit | syntax_rejected |
| `symfony_grapheme_chunks_1` | rust | eligible |
| `symfony_grapheme_chunks_1` | regexr | semantic_difference |
| `symfony_grapheme_chunks_1` | regexr_jit | semantic_difference |
| `symfony_grapheme_chunks_2` | rust | eligible |
| `symfony_grapheme_chunks_2` | regexr | eligible |
| `symfony_grapheme_chunks_2` | regexr_jit | eligible |
| `literal_first` | rust | eligible |
| `literal_first` | regexr | eligible |
| `literal_first` | regexr_jit | eligible |
| `literal_middle` | rust | eligible |
| `literal_middle` | regexr | eligible |
| `literal_middle` | regexr_jit | eligible |
| `literal_end` | rust | eligible |
| `literal_end` | regexr | eligible |
| `literal_end` | regexr_jit | eligible |
| `literal_absent` | rust | eligible |
| `literal_absent` | regexr | eligible |
| `literal_absent` | regexr_jit | eligible |
| `linkify_http_tail` | rust | pending |
| `linkify_http_tail` | regexr | pending |
| `linkify_http_tail` | regexr_jit | pending |
| `php_cs_fixer_recursive_types` | rust | pending |
| `php_cs_fixer_recursive_types` | regexr | pending |
| `php_cs_fixer_recursive_types` | regexr_jit | pending |

## regexr / steady

Common cases: 14; families: 7. Pair-specific family-weighted ratio: 5.696.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.066 | 1.066–1.110 | Ferroni faster in every run interval |
| `uuid_v4` | 0.841 | 0.806–0.875 | comparator faster in every run interval |
| `ipv4_validation` | 12.482 | 11.692–13.141 | Ferroni faster in every run interval |
| `ipv6_validation` | 33.006 | 32.371–36.025 | Ferroni faster in every run interval |
| `jinja_string_token` | 0.603 | 0.587–0.616 | comparator faster in every run interval |
| `jinja_integer_token` | 8.029 | 8.008–8.634 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 15.081 | 14.488–15.189 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 30.934 | 28.782–31.417 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 30.879 | 30.203–32.181 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_2` | 5.996 | 4.553–6.375 | Ferroni faster in every run interval |
| `literal_first` | 0.580 | 0.568–0.623 | comparator faster in every run interval |
| `literal_middle` | 1.983 | 1.874–2.198 | Ferroni faster in every run interval |
| `literal_end` | 3.817 | 2.606–3.880 | Ferroni faster in every run interval |
| `literal_absent` | 0.400 | 0.388–0.454 | comparator faster in every run interval |

## regexr / compile

Common cases: 14; families: 7. Pair-specific family-weighted ratio: 3.777.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 2.851 | 2.830–3.001 | Ferroni faster in every run interval |
| `uuid_v4` | 2.665 | 2.630–3.046 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.834 | 0.781–0.961 | comparator faster in every run interval |
| `ipv6_validation` | 1.184 | 1.130–1.215 | Ferroni faster in every run interval |
| `jinja_string_token` | 10.646 | 10.455–10.831 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.479 | 1.420–1.495 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.947 | 1.770–1.977 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 2.188 | 1.886–2.397 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 2.924 | 2.731–2.928 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_2` | 47.620 | 44.870–48.920 | Ferroni faster in every run interval |
| `literal_first` | 3.371 | 3.248–3.620 | Ferroni faster in every run interval |
| `literal_middle` | 3.281 | 3.029–3.372 | Ferroni faster in every run interval |
| `literal_end` | 3.527 | 3.387–3.724 | Ferroni faster in every run interval |
| `literal_absent` | 3.900 | 2.578–4.048 | Ferroni faster in every run interval |

## regexr / first_use

Common cases: 14; families: 7. Pair-specific family-weighted ratio: 4.323.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 2.820 | 2.801–3.171 | Ferroni faster in every run interval |
| `uuid_v4` | 2.673 | 2.474–2.716 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.998 | 0.917–1.018 | inconclusive |
| `ipv6_validation` | 1.133 | 1.106–1.146 | Ferroni faster in every run interval |
| `jinja_string_token` | 20.160 | 19.138–22.649 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.464 | 1.455–1.480 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 2.519 | 2.248–2.579 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 3.668 | 3.325–3.714 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 4.693 | 4.425–4.695 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_2` | 40.386 | 38.640–41.288 | Ferroni faster in every run interval |
| `literal_first` | 2.884 | 2.510–3.218 | Ferroni faster in every run interval |
| `literal_middle` | 2.995 | 2.621–3.420 | Ferroni faster in every run interval |
| `literal_end` | 3.236 | 2.550–3.519 | Ferroni faster in every run interval |
| `literal_absent` | 3.248 | 3.121–3.904 | Ferroni faster in every run interval |

## regexr_jit / steady

Common cases: 14; families: 7. Pair-specific family-weighted ratio: 5.383.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.971 | 0.921–0.987 | inconclusive |
| `uuid_v4` | 0.735 | 0.733–0.790 | comparator faster in every run interval |
| `ipv4_validation` | 12.857 | 12.341–12.907 | Ferroni faster in every run interval |
| `ipv6_validation` | 32.127 | 31.682–36.017 | Ferroni faster in every run interval |
| `jinja_string_token` | 0.618 | 0.591–0.628 | comparator faster in every run interval |
| `jinja_integer_token` | 8.036 | 8.033–8.986 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 14.999 | 13.657–15.503 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 30.764 | 26.615–32.285 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 30.098 | 28.885–32.553 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_2` | 6.430 | 5.486–6.946 | Ferroni faster in every run interval |
| `literal_first` | 0.548 | 0.519–0.587 | comparator faster in every run interval |
| `literal_middle` | 1.126 | 1.089–1.153 | Ferroni faster in every run interval |
| `literal_end` | 1.736 | 1.168–1.939 | Ferroni faster in every run interval |
| `literal_absent` | 0.429 | 0.392–0.496 | comparator faster in every run interval |

## regexr_jit / compile

Common cases: 14; families: 7. Pair-specific family-weighted ratio: 4.378.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 3.259 | 3.176–3.487 | Ferroni faster in every run interval |
| `uuid_v4` | 3.110 | 2.914–3.564 | Ferroni faster in every run interval |
| `ipv4_validation` | 1.000 | 0.783–1.103 | inconclusive |
| `ipv6_validation` | 1.169 | 1.084–1.185 | Ferroni faster in every run interval |
| `jinja_string_token` | 15.874 | 15.834–16.372 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.431 | 1.425–1.596 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.841 | 1.742–1.947 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.882 | 1.576–2.007 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 2.984 | 2.653–3.160 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_2` | 35.210 | 33.203–47.349 | Ferroni faster in every run interval |
| `literal_first` | 9.030 | 8.202–11.155 | Ferroni faster in every run interval |
| `literal_middle` | 9.301 | 8.766–9.668 | Ferroni faster in every run interval |
| `literal_end` | 10.238 | 6.149–10.615 | Ferroni faster in every run interval |
| `literal_absent` | 9.931 | 9.591–11.341 | Ferroni faster in every run interval |

## regexr_jit / first_use

Common cases: 14; families: 7. Pair-specific family-weighted ratio: 4.949.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 3.111 | 3.099–3.361 | Ferroni faster in every run interval |
| `uuid_v4` | 3.107 | 2.739–3.383 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.999 | 0.962–1.085 | inconclusive |
| `ipv6_validation` | 1.168 | 1.118–1.260 | Ferroni faster in every run interval |
| `jinja_string_token` | 26.585 | 25.264–28.896 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.486 | 1.461–1.573 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 2.386 | 2.341–2.675 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 3.186 | 2.901–3.606 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 4.638 | 4.078–4.717 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_2` | 31.130 | 28.543–31.670 | Ferroni faster in every run interval |
| `literal_first` | 8.684 | 7.310–9.276 | Ferroni faster in every run interval |
| `literal_middle` | 8.033 | 7.996–8.853 | Ferroni faster in every run interval |
| `literal_end` | 8.495 | 4.772–10.060 | Ferroni faster in every run interval |
| `literal_absent` | 9.465 | 9.285–9.883 | Ferroni faster in every run interval |

Raw samples, estimates, confidence intervals, failures, eligibility reasons, corpus snapshot and execution order are retained beside this report.

Memory, where requested, is fresh-process peak RSS including the binary, runtime, parsed catalog, compilation, input/output and allocator. It is not isolated compiled-pattern memory.
