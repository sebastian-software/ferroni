# Production regex comparison

Host: macOS-26.3-arm64-arm-64bit-Mach-O; arm64.

Publication candidate: review host stability, raw samples, coverage and run intervals before publishing.

Ratios are comparator / Ferroni. Compile and first-use times concern one pattern; steady times concern the complete fixture batch.

Each comparison below uses only its explicitly listed common tasks. Families have equal aggregate weight; architectures are never combined.

## Eligibility

| Case | Engine | Status |
| --- | --- | --- |
| `uuid_shape` | rust | eligible |
| `uuid_shape` | regexr | eligible |
| `uuid_shape` | regexr_jit | eligible |
| `uuid_v4` | rust | eligible |
| `uuid_v4` | regexr | eligible |
| `uuid_v4` | regexr_jit | eligible |
| `ipv4_validation` | rust | eligible |
| `ipv4_validation` | regexr | eligible |
| `ipv4_validation` | regexr_jit | eligible |
| `ipv6_validation` | rust | eligible |
| `ipv6_validation` | regexr | eligible |
| `ipv6_validation` | regexr_jit | eligible |
| `semver_version_parse` | rust | eligible |
| `semver_version_parse` | regexr | syntax_rejected |
| `semver_version_parse` | regexr_jit | syntax_rejected |
| `semver_hyphen_range_captures` | rust | eligible |
| `semver_hyphen_range_captures` | regexr | syntax_rejected |
| `semver_hyphen_range_captures` | regexr_jit | syntax_rejected |
| `jinja_string_token` | rust | eligible |
| `jinja_string_token` | regexr | eligible |
| `jinja_string_token` | regexr_jit | eligible |
| `jinja_integer_token` | rust | eligible |
| `jinja_integer_token` | regexr | eligible |
| `jinja_integer_token` | regexr_jit | eligible |
| `jinja_float_token` | rust | eligible |
| `jinja_float_token` | regexr | api_unsupported |
| `jinja_float_token` | regexr_jit | api_unsupported |
| `django_email_local_part` | rust | eligible |
| `django_email_local_part` | regexr | syntax_rejected |
| `django_email_local_part` | regexr_jit | syntax_rejected |
| `django_email_domain` | rust | eligible |
| `django_email_domain` | regexr | syntax_rejected |
| `django_email_domain` | regexr_jit | syntax_rejected |
| `django_url_regex` | rust | eligible |
| `django_url_regex` | regexr | syntax_rejected |
| `django_url_regex` | regexr_jit | syntax_rejected |
| `fluent_bit_apache` | rust | eligible |
| `fluent_bit_apache` | regexr | eligible |
| `fluent_bit_apache` | regexr_jit | eligible |
| `fluent_bit_nginx` | rust | eligible |
| `fluent_bit_nginx` | regexr | eligible |
| `fluent_bit_nginx` | regexr_jit | eligible |
| `rails_underscore_regex_step` | rust | eligible |
| `rails_underscore_regex_step` | regexr | eligible |
| `rails_underscore_regex_step` | regexr_jit | eligible |
| `mastodon_hashtag_regex_step` | rust | eligible |
| `mastodon_hashtag_regex_step` | regexr | semantic_difference |
| `mastodon_hashtag_regex_step` | regexr_jit | semantic_difference |
| `python_markdown_smart_emphasis_re` | rust | eligible |
| `python_markdown_smart_emphasis_re` | regexr | api_unsupported |
| `python_markdown_smart_emphasis_re` | regexr_jit | api_unsupported |
| `python_markdown_smart_strong_em_re` | rust | eligible |
| `python_markdown_smart_strong_em_re` | regexr | api_unsupported |
| `python_markdown_smart_strong_em_re` | regexr_jit | api_unsupported |
| `wordpress_shortcode_captures` | rust | eligible |
| `wordpress_shortcode_captures` | regexr | syntax_rejected |
| `wordpress_shortcode_captures` | regexr_jit | syntax_rejected |
| `symfony_grapheme_chunks_1` | rust | eligible |
| `symfony_grapheme_chunks_1` | regexr | semantic_difference |
| `symfony_grapheme_chunks_1` | regexr_jit | semantic_difference |
| `symfony_grapheme_chunks_2` | rust | eligible |
| `symfony_grapheme_chunks_2` | regexr | eligible |
| `symfony_grapheme_chunks_2` | regexr_jit | eligible |
| `literal_first` | rust | eligible |
| `literal_first` | regexr | eligible |
| `literal_first` | regexr_jit | eligible |
| `literal_middle` | rust | eligible |
| `literal_middle` | regexr | eligible |
| `literal_middle` | regexr_jit | eligible |
| `literal_end` | rust | eligible |
| `literal_end` | regexr | eligible |
| `literal_end` | regexr_jit | eligible |
| `literal_absent` | rust | eligible |
| `literal_absent` | regexr | eligible |
| `literal_absent` | regexr_jit | eligible |
| `linkify_http_tail` | rust | pending |
| `linkify_http_tail` | regexr | pending |
| `linkify_http_tail` | regexr_jit | pending |
| `php_cs_fixer_recursive_types` | rust | pending |
| `php_cs_fixer_recursive_types` | regexr | pending |
| `php_cs_fixer_recursive_types` | regexr_jit | pending |

## regexr / steady

Common cases: 14; families: 7. Pair-specific family-weighted ratio: 5.337.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.256 | 1.236–1.264 | Ferroni faster in every run interval |
| `uuid_v4` | 0.888 | 0.859–0.922 | comparator faster in every run interval |
| `ipv4_validation` | 11.098 | 9.816–11.922 | Ferroni faster in every run interval |
| `ipv6_validation` | 27.367 | 27.222–27.854 | Ferroni faster in every run interval |
| `jinja_string_token` | 0.720 | 0.701–0.765 | comparator faster in every run interval |
| `jinja_integer_token` | 6.185 | 6.098–6.274 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 13.195 | 13.180–14.249 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 23.979 | 23.340–24.129 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 30.031 | 29.977–35.209 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_2` | 5.455 | 5.454–5.496 | Ferroni faster in every run interval |
| `literal_first` | 0.446 | 0.444–0.453 | comparator faster in every run interval |
| `literal_middle` | 2.077 | 2.071–2.083 | Ferroni faster in every run interval |
| `literal_end` | 4.392 | 4.153–4.576 | Ferroni faster in every run interval |
| `literal_absent` | 0.347 | 0.347–0.360 | comparator faster in every run interval |

## regexr / compile

Common cases: 14; families: 7. Pair-specific family-weighted ratio: 4.064.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 3.014 | 3.001–3.101 | Ferroni faster in every run interval |
| `uuid_v4` | 2.927 | 2.861–2.952 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.957 | 0.937–1.104 | inconclusive |
| `ipv6_validation` | 0.936 | 0.902–0.966 | comparator faster in every run interval |
| `jinja_string_token` | 10.341 | 9.942–12.214 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.778 | 1.720–1.863 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.769 | 1.708–1.820 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.851 | 1.843–1.942 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 3.370 | 3.251–3.699 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_2` | 44.813 | 44.570–45.159 | Ferroni faster in every run interval |
| `literal_first` | 5.635 | 5.304–5.999 | Ferroni faster in every run interval |
| `literal_middle` | 5.568 | 5.468–5.674 | Ferroni faster in every run interval |
| `literal_end` | 5.478 | 5.463–5.609 | Ferroni faster in every run interval |
| `literal_absent` | 5.569 | 5.300–5.660 | Ferroni faster in every run interval |

## regexr / first_use

Common cases: 14; families: 7. Pair-specific family-weighted ratio: 4.622.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 3.023 | 3.015–3.208 | Ferroni faster in every run interval |
| `uuid_v4` | 2.885 | 2.882–3.074 | Ferroni faster in every run interval |
| `ipv4_validation` | 1.120 | 1.077–1.193 | Ferroni faster in every run interval |
| `ipv6_validation` | 0.956 | 0.938–1.028 | inconclusive |
| `jinja_string_token` | 19.762 | 19.337–23.362 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.824 | 1.691–1.899 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 2.438 | 2.381–2.560 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 3.249 | 3.205–3.376 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 4.605 | 4.601–4.970 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_2` | 37.467 | 36.209–38.095 | Ferroni faster in every run interval |
| `literal_first` | 4.929 | 4.698–4.962 | Ferroni faster in every run interval |
| `literal_middle` | 5.232 | 5.103–5.456 | Ferroni faster in every run interval |
| `literal_end` | 5.134 | 5.105–5.200 | Ferroni faster in every run interval |
| `literal_absent` | 4.958 | 4.894–5.097 | Ferroni faster in every run interval |

## regexr_jit / steady

Common cases: 14; families: 7. Pair-specific family-weighted ratio: 5.323.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.304 | 1.280–1.342 | Ferroni faster in every run interval |
| `uuid_v4` | 0.972 | 0.923–1.091 | inconclusive |
| `ipv4_validation` | 10.997 | 9.887–12.271 | Ferroni faster in every run interval |
| `ipv6_validation` | 27.671 | 27.213–27.859 | Ferroni faster in every run interval |
| `jinja_string_token` | 0.715 | 0.687–0.812 | comparator faster in every run interval |
| `jinja_integer_token` | 6.137 | 5.861–6.320 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 12.891 | 11.824–12.938 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 25.393 | 24.209–25.794 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 30.177 | 29.961–34.671 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_2` | 6.369 | 6.325–6.387 | Ferroni faster in every run interval |
| `literal_first` | 0.417 | 0.410–0.427 | comparator faster in every run interval |
| `literal_middle` | 1.451 | 1.378–1.517 | Ferroni faster in every run interval |
| `literal_end` | 2.413 | 2.348–2.435 | Ferroni faster in every run interval |
| `literal_absent` | 0.353 | 0.341–0.367 | comparator faster in every run interval |

## regexr_jit / compile

Common cases: 14; families: 7. Pair-specific family-weighted ratio: 4.731.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 3.320 | 3.228–3.322 | Ferroni faster in every run interval |
| `uuid_v4` | 3.309 | 3.190–3.400 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.984 | 0.919–1.084 | inconclusive |
| `ipv6_validation` | 0.927 | 0.900–0.956 | comparator faster in every run interval |
| `jinja_string_token` | 15.532 | 14.891–16.015 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.792 | 1.748–1.894 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.702 | 1.695–1.960 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.955 | 1.920–2.092 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 3.454 | 3.318–4.064 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_2` | 36.377 | 35.568–37.270 | Ferroni faster in every run interval |
| `literal_first` | 13.694 | 13.516–15.004 | Ferroni faster in every run interval |
| `literal_middle` | 13.770 | 13.221–14.971 | Ferroni faster in every run interval |
| `literal_end` | 13.814 | 13.145–15.479 | Ferroni faster in every run interval |
| `literal_absent` | 14.188 | 13.758–20.644 | Ferroni faster in every run interval |

## regexr_jit / first_use

Common cases: 14; families: 7. Pair-specific family-weighted ratio: 5.427.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 3.406 | 3.260–3.536 | Ferroni faster in every run interval |
| `uuid_v4` | 3.222 | 3.172–3.269 | Ferroni faster in every run interval |
| `ipv4_validation` | 1.114 | 1.075–1.186 | Ferroni faster in every run interval |
| `ipv6_validation` | 0.924 | 0.923–0.960 | comparator faster in every run interval |
| `jinja_string_token` | 24.753 | 24.740–26.743 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.864 | 1.824–1.892 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 2.465 | 2.297–2.620 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 3.202 | 3.153–3.949 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 4.703 | 4.389–5.041 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_2` | 31.897 | 30.493–32.258 | Ferroni faster in every run interval |
| `literal_first` | 14.646 | 14.392–15.836 | Ferroni faster in every run interval |
| `literal_middle` | 15.224 | 14.415–15.977 | Ferroni faster in every run interval |
| `literal_end` | 14.736 | 14.421–15.097 | Ferroni faster in every run interval |
| `literal_absent` | 13.086 | 12.961–15.168 | Ferroni faster in every run interval |

Raw samples, estimates, confidence intervals, failures, eligibility reasons, corpus snapshot and execution order are retained beside this report.

Memory, where requested, is fresh-process peak RSS including the binary, runtime, parsed catalog, compilation, input/output and allocator. It is not isolated compiled-pattern memory.
