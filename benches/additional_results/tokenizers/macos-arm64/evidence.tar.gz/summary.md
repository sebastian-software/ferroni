# Production regex comparison

Host: macOS-26.3-arm64-arm-64bit-Mach-O; arm64.

Publication candidate: review host stability, raw samples, coverage and run intervals before publishing.

Ratios are comparator / Ferroni. Compile and first-use times concern one pattern; steady times concern the complete fixture batch.

Each comparison below uses only its explicitly listed common tasks. Families have equal aggregate weight; architectures are never combined.

## Eligibility

| Case | Engine | Status |
| --- | --- | --- |
| `tiktoken_cl100k_base` | rust | eligible |
| `tiktoken_cl100k_base` | rust_erroraware | eligible |
| `tiktoken_cl100k_base` | c | eligible |
| `tiktoken_cl100k_base` | onigmo | eligible |
| `tiktoken_cl100k_base` | pcre2_jit | eligible |
| `tiktoken_cl100k_base` | pcre2 | eligible |
| `tiktoken_cl100k_base` | fancy_regex | eligible |
| `tiktoken_cl100k_base` | fancy_regex_seek | eligible |
| `tiktoken_cl100k_base` | regex | syntax_rejected |
| `tiktoken_o200k_base` | rust | eligible |
| `tiktoken_o200k_base` | rust_erroraware | eligible |
| `tiktoken_o200k_base` | c | eligible |
| `tiktoken_o200k_base` | onigmo | eligible |
| `tiktoken_o200k_base` | pcre2_jit | eligible |
| `tiktoken_o200k_base` | pcre2 | eligible |
| `tiktoken_o200k_base` | fancy_regex | eligible |
| `tiktoken_o200k_base` | fancy_regex_seek | eligible |
| `tiktoken_o200k_base` | regex | syntax_rejected |

## rust_erroraware / steady

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.043.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 1.056 | 1.039–1.067 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 1.030 | 1.022–1.152 | inconclusive |

## rust_erroraware / compile

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.035.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 1.013 | 0.890–1.038 | inconclusive |
| `tiktoken_o200k_base` | 1.058 | 1.024–1.080 | inconclusive |

## rust_erroraware / first_use

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 0.987.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 1.005 | 0.928–1.020 | inconclusive |
| `tiktoken_o200k_base` | 0.969 | 0.925–0.983 | inconclusive |

## c / steady

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 2.782.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 2.583 | 2.228–2.779 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 2.997 | 2.968–3.100 | Ferroni faster in every run interval |

## c / compile

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.640.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 1.339 | 1.329–1.482 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 2.009 | 1.959–2.046 | Ferroni faster in every run interval |

## c / first_use

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.697.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 1.448 | 1.357–1.479 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 1.989 | 1.955–2.107 | Ferroni faster in every run interval |

## onigmo / steady

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.578.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 1.331 | 1.178–1.336 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 1.870 | 1.865–1.898 | Ferroni faster in every run interval |

## onigmo / compile

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.622.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 1.308 | 1.251–1.380 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 2.011 | 1.955–2.047 | Ferroni faster in every run interval |

## onigmo / first_use

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.592.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 1.285 | 1.276–1.399 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 1.972 | 1.924–2.030 | Ferroni faster in every run interval |

## pcre2_jit / steady

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 0.427.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 0.370 | 0.350–0.374 | comparator faster in every run interval |
| `tiktoken_o200k_base` | 0.492 | 0.482–0.512 | comparator faster in every run interval |

## pcre2_jit / compile

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 0.185.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 0.216 | 0.213–0.225 | comparator faster in every run interval |
| `tiktoken_o200k_base` | 0.158 | 0.155–0.160 | comparator faster in every run interval |

## pcre2_jit / first_use

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 0.207.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 0.249 | 0.233–0.250 | comparator faster in every run interval |
| `tiktoken_o200k_base` | 0.172 | 0.157–0.175 | comparator faster in every run interval |

## pcre2 / steady

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.971.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 1.327 | 1.241–1.416 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 2.927 | 2.875–2.940 | Ferroni faster in every run interval |

## pcre2 / compile

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 0.086.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 0.083 | 0.079–0.085 | comparator faster in every run interval |
| `tiktoken_o200k_base` | 0.089 | 0.089–0.093 | comparator faster in every run interval |

## pcre2 / first_use

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 0.089.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 0.084 | 0.084–0.090 | comparator faster in every run interval |
| `tiktoken_o200k_base` | 0.093 | 0.092–0.095 | comparator faster in every run interval |

## fancy_regex / steady

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.552.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 2.044 | 1.998–2.239 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 1.178 | 1.170–1.180 | Ferroni faster in every run interval |

## fancy_regex / compile

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 8.928.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 10.203 | 9.741–10.439 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 7.813 | 7.649–8.111 | Ferroni faster in every run interval |

## fancy_regex / first_use

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 8.959.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 10.115 | 9.554–10.895 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 7.935 | 7.573–8.148 | Ferroni faster in every run interval |

## fancy_regex_seek / steady

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 2.129.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 2.702 | 2.611–2.754 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 1.677 | 1.677–1.697 | Ferroni faster in every run interval |

## fancy_regex_seek / compile

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 17.687.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 19.809 | 17.662–20.204 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 15.792 | 15.133–16.358 | Ferroni faster in every run interval |

## fancy_regex_seek / first_use

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 20.312.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 22.399 | 22.386–22.411 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 18.420 | 16.349–18.460 | Ferroni faster in every run interval |

Raw samples, estimates, confidence intervals, failures, eligibility reasons, corpus snapshot and execution order are retained beside this report.

Memory, where requested, is fresh-process peak RSS including the binary, runtime, parsed catalog, compilation, input/output and allocator. It is not isolated compiled-pattern memory.
