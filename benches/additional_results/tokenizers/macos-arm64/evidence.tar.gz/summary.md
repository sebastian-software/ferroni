# Production regex comparison

Host: macOS-26.3-arm64-arm-64bit-Mach-O; arm64.

Publication candidate: review host stability, raw samples, coverage and run intervals before publishing.

Ratios are comparator / Ferroni. Compile and first-use times concern one pattern; steady times concern the complete fixture batch.

Each comparison below uses only its explicitly listed common tasks. Families have equal aggregate weight; architectures are never combined.

## Eligibility

| Case | Engine | Status |
| --- | --- | --- |
| `tiktoken_cl100k_base` | rust | eligible |
| `tiktoken_cl100k_base` | rust_erroraware | eligible |
| `tiktoken_cl100k_base` | c | eligible |
| `tiktoken_cl100k_base` | onigmo | eligible |
| `tiktoken_cl100k_base` | pcre2_jit | eligible |
| `tiktoken_cl100k_base` | pcre2 | eligible |
| `tiktoken_cl100k_base` | fancy_regex | eligible |
| `tiktoken_cl100k_base` | fancy_regex_seek | eligible |
| `tiktoken_cl100k_base` | regex | syntax_rejected |
| `tiktoken_o200k_base` | rust | eligible |
| `tiktoken_o200k_base` | rust_erroraware | eligible |
| `tiktoken_o200k_base` | c | eligible |
| `tiktoken_o200k_base` | onigmo | eligible |
| `tiktoken_o200k_base` | pcre2_jit | eligible |
| `tiktoken_o200k_base` | pcre2 | eligible |
| `tiktoken_o200k_base` | fancy_regex | eligible |
| `tiktoken_o200k_base` | fancy_regex_seek | eligible |
| `tiktoken_o200k_base` | regex | syntax_rejected |

## rust_erroraware / steady

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.034.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 1.041 | 1.036–1.154 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 1.028 | 0.974–1.062 | inconclusive |

## rust_erroraware / compile

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.010.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 0.987 | 0.879–1.001 | inconclusive |
| `tiktoken_o200k_base` | 1.034 | 1.001–1.073 | inconclusive |

## rust_erroraware / first_use

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.003.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 0.998 | 0.875–0.999 | inconclusive |
| `tiktoken_o200k_base` | 1.007 | 0.991–1.050 | inconclusive |

## c / steady

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 2.767.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 2.577 | 2.352–2.860 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 2.971 | 2.758–3.055 | Ferroni faster in every run interval |

## c / compile

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.669.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 1.390 | 1.337–1.393 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 2.003 | 1.985–2.013 | Ferroni faster in every run interval |

## c / first_use

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.671.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 1.392 | 1.371–1.441 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 2.007 | 1.994–2.105 | Ferroni faster in every run interval |

## onigmo / steady

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.620.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 1.383 | 1.369–1.394 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 1.897 | 1.803–2.043 | Ferroni faster in every run interval |

## onigmo / compile

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.655.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 1.378 | 1.260–1.393 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 1.988 | 1.957–2.192 | Ferroni faster in every run interval |

## onigmo / first_use

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.661.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 1.369 | 1.185–1.429 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 2.014 | 1.943–2.278 | Ferroni faster in every run interval |

## pcre2_jit / steady

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 0.435.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 0.383 | 0.375–0.388 | comparator faster in every run interval |
| `tiktoken_o200k_base` | 0.493 | 0.469–0.552 | comparator faster in every run interval |

## pcre2_jit / compile

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 0.191.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 0.226 | 0.190–0.227 | comparator faster in every run interval |
| `tiktoken_o200k_base` | 0.161 | 0.159–0.175 | comparator faster in every run interval |

## pcre2_jit / first_use

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 0.207.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 0.252 | 0.220–0.255 | comparator faster in every run interval |
| `tiktoken_o200k_base` | 0.171 | 0.169–0.188 | comparator faster in every run interval |

## pcre2 / steady

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.996.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 1.354 | 1.354–1.379 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 2.943 | 2.789–3.288 | Ferroni faster in every run interval |

## pcre2 / compile

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 0.085.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 0.081 | 0.073–0.082 | comparator faster in every run interval |
| `tiktoken_o200k_base` | 0.089 | 0.088–0.097 | comparator faster in every run interval |

## pcre2 / first_use

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 0.091.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 0.089 | 0.078–0.089 | comparator faster in every run interval |
| `tiktoken_o200k_base` | 0.094 | 0.092–0.102 | comparator faster in every run interval |

## fancy_regex / steady

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.572.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 2.129 | 2.088–2.175 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 1.161 | 1.094–1.168 | Ferroni faster in every run interval |

## fancy_regex / compile

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 8.667.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 9.675 | 8.128–9.941 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 7.764 | 7.568–7.849 | Ferroni faster in every run interval |

## fancy_regex / first_use

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 8.815.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 9.990 | 8.201–10.142 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 7.779 | 7.644–7.854 | Ferroni faster in every run interval |

## fancy_regex_seek / steady

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 2.150.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 2.779 | 2.589–2.783 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 1.663 | 1.567–1.743 | Ferroni faster in every run interval |

## fancy_regex_seek / compile

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 16.831.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 18.809 | 15.790–18.896 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 15.061 | 14.781–16.428 | Ferroni faster in every run interval |

## fancy_regex_seek / first_use

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 19.064.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 20.892 | 18.283–21.663 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 17.396 | 16.862–18.708 | Ferroni faster in every run interval |

Raw samples, estimates, confidence intervals, failures, eligibility reasons, corpus snapshot and execution order are retained beside this report.

Memory, where requested, is fresh-process peak RSS including the binary, runtime, parsed catalog, compilation, input/output and allocator. It is not isolated compiled-pattern memory.
