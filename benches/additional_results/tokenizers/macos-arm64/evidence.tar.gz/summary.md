# Production regex comparison

Host: macOS-26.3-arm64-arm-64bit-Mach-O; arm64.

Publication candidate: review host stability, raw samples, coverage and run intervals before publishing.

Ratios are comparator / Ferroni. Compile and first-use times concern one pattern; steady times concern the complete fixture batch.

Each comparison below uses only its explicitly listed common tasks. Families have equal aggregate weight; architectures are never combined.

## Eligibility

| Case | Engine | Status |
| --- | --- | --- |
| `tiktoken_cl100k_base` | rust | eligible |
| `tiktoken_cl100k_base` | rust_erroraware | eligible |
| `tiktoken_cl100k_base` | c | eligible |
| `tiktoken_cl100k_base` | onigmo | eligible |
| `tiktoken_cl100k_base` | pcre2_jit | eligible |
| `tiktoken_cl100k_base` | pcre2 | eligible |
| `tiktoken_cl100k_base` | fancy_regex | eligible |
| `tiktoken_cl100k_base` | fancy_regex_seek | eligible |
| `tiktoken_cl100k_base` | regex | syntax_rejected |
| `tiktoken_o200k_base` | rust | eligible |
| `tiktoken_o200k_base` | rust_erroraware | eligible |
| `tiktoken_o200k_base` | c | eligible |
| `tiktoken_o200k_base` | onigmo | eligible |
| `tiktoken_o200k_base` | pcre2_jit | eligible |
| `tiktoken_o200k_base` | pcre2 | eligible |
| `tiktoken_o200k_base` | fancy_regex | eligible |
| `tiktoken_o200k_base` | fancy_regex_seek | eligible |
| `tiktoken_o200k_base` | regex | syntax_rejected |

## rust_erroraware / steady

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.067.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 1.062 | 1.003–1.171 | inconclusive |
| `tiktoken_o200k_base` | 1.072 | 1.014–1.131 | inconclusive |

## rust_erroraware / compile

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.005.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 0.984 | 0.927–1.082 | inconclusive |
| `tiktoken_o200k_base` | 1.026 | 0.921–1.091 | inconclusive |

## rust_erroraware / first_use

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.040.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 1.016 | 0.959–1.018 | inconclusive |
| `tiktoken_o200k_base` | 1.064 | 0.960–1.078 | inconclusive |

## c / steady

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 2.917.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 2.792 | 2.674–3.060 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 3.048 | 2.818–3.299 | Ferroni faster in every run interval |

## c / compile

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.657.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 1.357 | 1.273–1.502 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 2.022 | 1.680–2.320 | Ferroni faster in every run interval |

## c / first_use

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.647.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 1.310 | 1.266–1.459 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 2.069 | 1.872–2.213 | Ferroni faster in every run interval |

## onigmo / steady

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.589.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 1.321 | 1.277–1.356 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 1.912 | 1.684–1.950 | Ferroni faster in every run interval |

## onigmo / compile

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.580.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 1.317 | 1.298–1.365 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 1.897 | 1.766–2.066 | Ferroni faster in every run interval |

## onigmo / first_use

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.604.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 1.310 | 1.240–1.355 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 1.966 | 1.878–2.022 | Ferroni faster in every run interval |

## pcre2_jit / steady

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 0.423.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 0.361 | 0.346–0.410 | comparator faster in every run interval |
| `tiktoken_o200k_base` | 0.495 | 0.470–0.503 | comparator faster in every run interval |

## pcre2_jit / compile

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 0.181.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 0.214 | 0.203–0.229 | comparator faster in every run interval |
| `tiktoken_o200k_base` | 0.153 | 0.138–0.161 | comparator faster in every run interval |

## pcre2_jit / first_use

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 0.207.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 0.240 | 0.224–0.247 | comparator faster in every run interval |
| `tiktoken_o200k_base` | 0.179 | 0.155–0.184 | comparator faster in every run interval |

## pcre2 / steady

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.986.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 1.285 | 1.259–1.451 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 3.068 | 2.741–3.181 | Ferroni faster in every run interval |

## pcre2 / compile

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 0.083.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 0.077 | 0.073–0.086 | comparator faster in every run interval |
| `tiktoken_o200k_base` | 0.090 | 0.086–0.092 | comparator faster in every run interval |

## pcre2 / first_use

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 0.088.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 0.082 | 0.081–0.088 | comparator faster in every run interval |
| `tiktoken_o200k_base` | 0.094 | 0.090–0.097 | comparator faster in every run interval |

## fancy_regex / steady

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.547.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 2.023 | 1.915–2.202 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 1.183 | 1.042–1.261 | Ferroni faster in every run interval |

## fancy_regex / compile

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 8.398.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 9.126 | 9.126–10.650 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 7.729 | 7.678–8.138 | Ferroni faster in every run interval |

## fancy_regex / first_use

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 8.450.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 9.289 | 9.033–10.491 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 7.688 | 7.504–8.231 | Ferroni faster in every run interval |

## fancy_regex_seek / steady

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 2.102.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 2.653 | 2.517–2.690 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 1.665 | 1.545–1.686 | Ferroni faster in every run interval |

## fancy_regex_seek / compile

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 15.933.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 17.890 | 17.225–20.055 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 14.190 | 13.798–15.642 | Ferroni faster in every run interval |

## fancy_regex_seek / first_use

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 18.516.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 20.600 | 18.607–21.933 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 16.643 | 16.570–18.040 | Ferroni faster in every run interval |

Raw samples, estimates, confidence intervals, failures, eligibility reasons, corpus snapshot and execution order are retained beside this report.

Memory, where requested, is fresh-process peak RSS including the binary, runtime, parsed catalog, compilation, input/output and allocator. It is not isolated compiled-pattern memory.
