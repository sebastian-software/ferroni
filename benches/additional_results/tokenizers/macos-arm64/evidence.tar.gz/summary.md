# Production regex comparison

Host: macOS-26.3-arm64-arm-64bit-Mach-O; arm64.

Publication candidate: review host stability, raw samples, coverage and run intervals before publishing.

Ratios are comparator / Ferroni. Compile and first-use times concern one pattern; steady times concern the complete fixture batch.

Each comparison below uses only its explicitly listed common tasks. Families have equal aggregate weight; architectures are never combined.

## Eligibility

| Case | Engine | Status |
| --- | --- | --- |
| `tiktoken_cl100k_base` | rust | eligible |
| `tiktoken_cl100k_base` | rust_erroraware | eligible |
| `tiktoken_cl100k_base` | c | eligible |
| `tiktoken_cl100k_base` | onigmo | eligible |
| `tiktoken_cl100k_base` | pcre2_jit | eligible |
| `tiktoken_cl100k_base` | pcre2 | eligible |
| `tiktoken_cl100k_base` | fancy_regex | eligible |
| `tiktoken_cl100k_base` | fancy_regex_seek | eligible |
| `tiktoken_cl100k_base` | regex | syntax_rejected |
| `tiktoken_cl100k_base` | regexr | syntax_rejected |
| `tiktoken_cl100k_base` | regexr_jit | syntax_rejected |
| `tiktoken_o200k_base` | rust | eligible |
| `tiktoken_o200k_base` | rust_erroraware | eligible |
| `tiktoken_o200k_base` | c | eligible |
| `tiktoken_o200k_base` | onigmo | eligible |
| `tiktoken_o200k_base` | pcre2_jit | eligible |
| `tiktoken_o200k_base` | pcre2 | eligible |
| `tiktoken_o200k_base` | fancy_regex | eligible |
| `tiktoken_o200k_base` | fancy_regex_seek | eligible |
| `tiktoken_o200k_base` | regex | syntax_rejected |
| `tiktoken_o200k_base` | regexr | eligible |
| `tiktoken_o200k_base` | regexr_jit | eligible |

## rust_erroraware / steady

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.728.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 1.723 | 1.671–1.768 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 1.732 | 1.677–1.891 | Ferroni faster in every run interval |

## rust_erroraware / compile

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.000.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 1.002 | 0.999–1.031 | inconclusive |
| `tiktoken_o200k_base` | 0.998 | 0.978–1.014 | inconclusive |

## rust_erroraware / first_use

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 0.999.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 1.013 | 0.995–1.204 | inconclusive |
| `tiktoken_o200k_base` | 0.986 | 0.948–0.993 | inconclusive |

## c / steady

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 2.725.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 2.625 | 2.506–3.140 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 2.828 | 2.826–2.901 | Ferroni faster in every run interval |

## c / compile

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 3.781.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 3.978 | 3.609–4.291 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 3.593 | 3.449–3.856 | Ferroni faster in every run interval |

## c / first_use

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 3.745.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 3.980 | 3.572–4.294 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 3.523 | 3.495–3.878 | Ferroni faster in every run interval |

## onigmo / steady

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.434.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 1.187 | 1.115–1.393 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 1.732 | 1.692–1.841 | Ferroni faster in every run interval |

## onigmo / compile

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 3.649.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 3.615 | 3.593–4.508 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 3.683 | 3.378–3.749 | Ferroni faster in every run interval |

## onigmo / first_use

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 3.676.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 4.006 | 3.563–4.375 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 3.373 | 3.344–3.500 | Ferroni faster in every run interval |

## pcre2_jit / steady

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 0.394.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 0.346 | 0.320–0.371 | comparator faster in every run interval |
| `tiktoken_o200k_base` | 0.448 | 0.426–0.452 | comparator faster in every run interval |

## pcre2_jit / compile

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 0.407.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 0.591 | 0.591–0.679 | comparator faster in every run interval |
| `tiktoken_o200k_base` | 0.280 | 0.263–0.292 | comparator faster in every run interval |

## pcre2_jit / first_use

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 0.443.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 0.665 | 0.658–0.753 | comparator faster in every run interval |
| `tiktoken_o200k_base` | 0.295 | 0.282–0.308 | comparator faster in every run interval |

## pcre2 / steady

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.768.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 1.163 | 1.159–1.381 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 2.689 | 2.487–2.693 | Ferroni faster in every run interval |

## pcre2 / compile

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 0.195.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 0.233 | 0.218–0.240 | comparator faster in every run interval |
| `tiktoken_o200k_base` | 0.164 | 0.160–0.165 | comparator faster in every run interval |

## pcre2 / first_use

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 0.206.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 0.239 | 0.236–0.252 | comparator faster in every run interval |
| `tiktoken_o200k_base` | 0.178 | 0.163–0.183 | comparator faster in every run interval |

## fancy_regex / steady

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.450.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 1.886 | 1.861–2.226 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 1.115 | 1.045–1.179 | Ferroni faster in every run interval |

## fancy_regex / compile

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 19.309.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 26.665 | 26.467–32.438 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 13.982 | 13.677–14.616 | Ferroni faster in every run interval |

## fancy_regex / first_use

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 19.644.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 27.635 | 26.924–32.702 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 13.964 | 13.119–14.885 | Ferroni faster in every run interval |

## fancy_regex_seek / steady

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.936.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 2.434 | 2.404–2.858 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 1.541 | 1.487–1.595 | Ferroni faster in every run interval |

## fancy_regex_seek / compile

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 37.329.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 50.965 | 49.964–61.617 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 27.341 | 27.005–27.415 | Ferroni faster in every run interval |

## fancy_regex_seek / first_use

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 42.135.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 57.292 | 55.905–65.989 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 30.988 | 30.725–31.246 | Ferroni faster in every run interval |

## regexr / steady

Common cases: 1; families: 1. Pair-specific family-weighted ratio: 0.831.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_o200k_base` | 0.831 | 0.827–0.834 | comparator faster in every run interval |

## regexr / compile

Common cases: 1; families: 1. Pair-specific family-weighted ratio: 6.739.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_o200k_base` | 6.739 | 6.690–6.854 | Ferroni faster in every run interval |

## regexr / first_use

Common cases: 1; families: 1. Pair-specific family-weighted ratio: 6.613.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_o200k_base` | 6.613 | 6.576–6.672 | Ferroni faster in every run interval |

## regexr_jit / steady

Common cases: 1; families: 1. Pair-specific family-weighted ratio: 0.832.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_o200k_base` | 0.832 | 0.824–0.849 | comparator faster in every run interval |

## regexr_jit / compile

Common cases: 1; families: 1. Pair-specific family-weighted ratio: 7.001.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_o200k_base` | 7.001 | 6.997–7.050 | Ferroni faster in every run interval |

## regexr_jit / first_use

Common cases: 1; families: 1. Pair-specific family-weighted ratio: 6.823.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_o200k_base` | 6.823 | 6.810–6.974 | Ferroni faster in every run interval |

Raw samples, estimates, confidence intervals, failures, eligibility reasons, corpus snapshot and execution order are retained beside this report.

Memory, where requested, is fresh-process peak RSS including the binary, runtime, parsed catalog, compilation, input/output and allocator. It is not isolated compiled-pattern memory.
