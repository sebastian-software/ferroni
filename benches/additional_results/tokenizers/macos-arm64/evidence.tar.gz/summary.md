# Production regex comparison

Host: macOS-26.3-arm64-arm-64bit-Mach-O; arm64.

Publication candidate: review host stability, raw samples, coverage and run intervals before publishing.

Ratios are comparator / Ferroni. Compile and first-use times concern one pattern; steady times concern the complete fixture batch.

Each comparison below uses only its explicitly listed common tasks. Families have equal aggregate weight; architectures are never combined.

## Eligibility

| Case | Engine | Status |
| --- | --- | --- |
| `tiktoken_cl100k_base` | rust | eligible |
| `tiktoken_cl100k_base` | rust_erroraware | eligible |
| `tiktoken_cl100k_base` | c | eligible |
| `tiktoken_cl100k_base` | onigmo | eligible |
| `tiktoken_cl100k_base` | pcre2_jit | eligible |
| `tiktoken_cl100k_base` | pcre2 | eligible |
| `tiktoken_cl100k_base` | fancy_regex | eligible |
| `tiktoken_cl100k_base` | fancy_regex_seek | eligible |
| `tiktoken_cl100k_base` | regex | syntax_rejected |
| `tiktoken_o200k_base` | rust | eligible |
| `tiktoken_o200k_base` | rust_erroraware | eligible |
| `tiktoken_o200k_base` | c | eligible |
| `tiktoken_o200k_base` | onigmo | eligible |
| `tiktoken_o200k_base` | pcre2_jit | eligible |
| `tiktoken_o200k_base` | pcre2 | eligible |
| `tiktoken_o200k_base` | fancy_regex | eligible |
| `tiktoken_o200k_base` | fancy_regex_seek | eligible |
| `tiktoken_o200k_base` | regex | syntax_rejected |

## rust_erroraware / steady

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.073.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 1.047 | 1.028–1.128 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 1.099 | 1.056–1.118 | Ferroni faster in every run interval |

## rust_erroraware / compile

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 0.974.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 0.985 | 0.920–1.115 | inconclusive |
| `tiktoken_o200k_base` | 0.964 | 0.963–0.992 | inconclusive |

## rust_erroraware / first_use

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 0.970.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 0.981 | 0.934–0.990 | inconclusive |
| `tiktoken_o200k_base` | 0.959 | 0.920–0.992 | inconclusive |

## c / steady

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 2.751.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 2.529 | 2.447–2.583 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 2.993 | 2.753–3.031 | Ferroni faster in every run interval |

## c / compile

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.984.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 1.644 | 1.571–1.654 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 2.394 | 2.373–2.521 | Ferroni faster in every run interval |

## c / first_use

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.989.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 1.627 | 1.504–1.639 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 2.432 | 2.179–2.438 | Ferroni faster in every run interval |

## onigmo / steady

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.590.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 1.323 | 1.307–1.360 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 1.911 | 1.856–1.938 | Ferroni faster in every run interval |

## onigmo / compile

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.974.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 1.639 | 1.599–1.659 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 2.378 | 2.291–2.536 | Ferroni faster in every run interval |

## onigmo / first_use

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.963.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 1.627 | 1.571–1.634 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 2.367 | 2.213–2.375 | Ferroni faster in every run interval |

## pcre2_jit / steady

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 0.429.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 0.373 | 0.351–0.391 | comparator faster in every run interval |
| `tiktoken_o200k_base` | 0.494 | 0.488–0.517 | comparator faster in every run interval |

## pcre2_jit / compile

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 0.232.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 0.266 | 0.247–0.271 | comparator faster in every run interval |
| `tiktoken_o200k_base` | 0.203 | 0.189–0.209 | comparator faster in every run interval |

## pcre2_jit / first_use

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 0.240.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 0.287 | 0.267–0.304 | comparator faster in every run interval |
| `tiktoken_o200k_base` | 0.201 | 0.201–0.206 | comparator faster in every run interval |

## pcre2 / steady

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.942.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 1.298 | 1.171–1.325 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 2.905 | 2.871–3.310 | Ferroni faster in every run interval |

## pcre2 / compile

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 0.102.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 0.097 | 0.087–0.099 | comparator faster in every run interval |
| `tiktoken_o200k_base` | 0.107 | 0.104–0.121 | comparator faster in every run interval |

## pcre2 / first_use

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 0.109.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 0.105 | 0.093–0.106 | comparator faster in every run interval |
| `tiktoken_o200k_base` | 0.113 | 0.107–0.113 | comparator faster in every run interval |

## fancy_regex / steady

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.549.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 2.024 | 1.894–2.162 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 1.185 | 1.148–1.315 | Ferroni faster in every run interval |

## fancy_regex / compile

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 10.347.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 11.484 | 10.842–11.791 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 9.323 | 9.298–9.471 | Ferroni faster in every run interval |

## fancy_regex / first_use

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 10.426.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 11.668 | 10.781–11.925 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 9.317 | 8.590–9.353 | Ferroni faster in every run interval |

## fancy_regex_seek / steady

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 2.096.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 2.624 | 2.600–2.659 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 1.674 | 1.640–1.675 | Ferroni faster in every run interval |

## fancy_regex_seek / compile

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 19.941.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 22.016 | 20.849–22.581 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 18.061 | 17.578–18.462 | Ferroni faster in every run interval |

## fancy_regex_seek / first_use

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 22.330.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 24.461 | 23.712–24.707 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 20.384 | 18.171–20.736 | Ferroni faster in every run interval |

Raw samples, estimates, confidence intervals, failures, eligibility reasons, corpus snapshot and execution order are retained beside this report.

Memory, where requested, is fresh-process peak RSS including the binary, runtime, parsed catalog, compilation, input/output and allocator. It is not isolated compiled-pattern memory.
