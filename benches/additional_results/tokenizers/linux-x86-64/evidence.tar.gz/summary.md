# Production regex comparison

Host: Linux-6.6.141-x86_64-with-glibc2.39; x86_64.

Publication candidate: review host stability, raw samples, coverage and run intervals before publishing.

Ratios are comparator / Ferroni. Compile and first-use times concern one pattern; steady times concern the complete fixture batch.

Each comparison below uses only its explicitly listed common tasks. Families have equal aggregate weight; architectures are never combined.

## Eligibility

| Case | Engine | Status |
| --- | --- | --- |
| `tiktoken_cl100k_base` | rust | eligible |
| `tiktoken_cl100k_base` | rust_erroraware | eligible |
| `tiktoken_cl100k_base` | c | eligible |
| `tiktoken_cl100k_base` | onigmo | eligible |
| `tiktoken_cl100k_base` | pcre2_jit | eligible |
| `tiktoken_cl100k_base` | pcre2 | eligible |
| `tiktoken_cl100k_base` | fancy_regex | eligible |
| `tiktoken_cl100k_base` | fancy_regex_seek | eligible |
| `tiktoken_cl100k_base` | regex | syntax_rejected |
| `tiktoken_cl100k_base` | regexr | syntax_rejected |
| `tiktoken_cl100k_base` | regexr_jit | syntax_rejected |
| `tiktoken_o200k_base` | rust | eligible |
| `tiktoken_o200k_base` | rust_erroraware | eligible |
| `tiktoken_o200k_base` | c | eligible |
| `tiktoken_o200k_base` | onigmo | eligible |
| `tiktoken_o200k_base` | pcre2_jit | eligible |
| `tiktoken_o200k_base` | pcre2 | eligible |
| `tiktoken_o200k_base` | fancy_regex | eligible |
| `tiktoken_o200k_base` | fancy_regex_seek | eligible |
| `tiktoken_o200k_base` | regex | syntax_rejected |
| `tiktoken_o200k_base` | regexr | eligible |
| `tiktoken_o200k_base` | regexr_jit | eligible |

## rust_erroraware / steady

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.783.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 1.700 | 1.608–1.793 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 1.870 | 1.603–1.881 | Ferroni faster in every run interval |

## rust_erroraware / compile

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 0.945.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 0.953 | 0.944–1.043 | inconclusive |
| `tiktoken_o200k_base` | 0.937 | 0.903–1.064 | inconclusive |

## rust_erroraware / first_use

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 0.968.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 0.942 | 0.938–0.978 | inconclusive |
| `tiktoken_o200k_base` | 0.995 | 0.806–1.069 | inconclusive |

## c / steady

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.566.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 1.407 | 1.274–1.538 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 1.743 | 1.531–1.810 | Ferroni faster in every run interval |

## c / compile

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.552.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 2.067 | 1.945–2.409 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 1.165 | 1.162–1.329 | Ferroni faster in every run interval |

## c / first_use

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.611.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 2.151 | 1.892–2.172 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 1.207 | 0.983–1.518 | inconclusive |

## onigmo / steady

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.323.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 1.094 | 0.835–1.162 | inconclusive |
| `tiktoken_o200k_base` | 1.601 | 1.441–1.723 | Ferroni faster in every run interval |

## onigmo / compile

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.406.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 1.780 | 1.420–2.113 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 1.111 | 0.992–1.141 | inconclusive |

## onigmo / first_use

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.397.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 1.800 | 1.781–2.095 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 1.084 | 0.906–1.185 | inconclusive |

## pcre2_jit / steady

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 0.386.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 0.339 | 0.274–0.425 | comparator faster in every run interval |
| `tiktoken_o200k_base` | 0.439 | 0.411–0.447 | comparator faster in every run interval |

## pcre2_jit / compile

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 0.422.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 0.613 | 0.538–0.665 | comparator faster in every run interval |
| `tiktoken_o200k_base` | 0.291 | 0.280–0.326 | comparator faster in every run interval |

## pcre2_jit / first_use

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 0.498.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 0.727 | 0.621–0.824 | comparator faster in every run interval |
| `tiktoken_o200k_base` | 0.341 | 0.247–0.346 | comparator faster in every run interval |

## pcre2 / steady

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.520.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 0.969 | 0.804–1.139 | inconclusive |
| `tiktoken_o200k_base` | 2.385 | 1.859–2.458 | Ferroni faster in every run interval |

## pcre2 / compile

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 0.194.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 0.212 | 0.192–0.214 | comparator faster in every run interval |
| `tiktoken_o200k_base` | 0.178 | 0.162–0.188 | comparator faster in every run interval |

## pcre2 / first_use

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 0.221.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 0.264 | 0.242–0.303 | comparator faster in every run interval |
| `tiktoken_o200k_base` | 0.185 | 0.152–0.190 | comparator faster in every run interval |

## fancy_regex / steady

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.322.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 1.723 | 1.647–1.763 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 1.014 | 0.833–1.067 | inconclusive |

## fancy_regex / compile

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 18.185.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 24.982 | 21.337–26.351 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 13.238 | 12.300–13.886 | Ferroni faster in every run interval |

## fancy_regex / first_use

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 18.523.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 26.089 | 25.358–27.848 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 13.151 | 10.756–14.442 | Ferroni faster in every run interval |

## fancy_regex_seek / steady

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.790.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 2.294 | 2.275–2.570 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 1.397 | 1.282–1.720 | Ferroni faster in every run interval |

## fancy_regex_seek / compile

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 35.261.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 48.627 | 43.627–49.661 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 25.568 | 24.727–27.785 | Ferroni faster in every run interval |

## fancy_regex_seek / first_use

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 41.059.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 58.737 | 54.784–61.883 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 28.702 | 24.667–32.831 | Ferroni faster in every run interval |

## regexr / steady

Common cases: 1; families: 1. Pair-specific family-weighted ratio: 0.828.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_o200k_base` | 0.828 | 0.750–0.883 | comparator faster in every run interval |

## regexr / compile

Common cases: 1; families: 1. Pair-specific family-weighted ratio: 4.674.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_o200k_base` | 4.674 | 4.615–4.711 | Ferroni faster in every run interval |

## regexr / first_use

Common cases: 1; families: 1. Pair-specific family-weighted ratio: 4.746.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_o200k_base` | 4.746 | 3.959–5.389 | Ferroni faster in every run interval |

## regexr_jit / steady

Common cases: 1; families: 1. Pair-specific family-weighted ratio: 0.792.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_o200k_base` | 0.792 | 0.756–0.993 | inconclusive |

## regexr_jit / compile

Common cases: 1; families: 1. Pair-specific family-weighted ratio: 5.019.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_o200k_base` | 5.019 | 4.776–5.840 | Ferroni faster in every run interval |

## regexr_jit / first_use

Common cases: 1; families: 1. Pair-specific family-weighted ratio: 5.046.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_o200k_base` | 5.046 | 4.517–6.160 | Ferroni faster in every run interval |

Raw samples, estimates, confidence intervals, failures, eligibility reasons, corpus snapshot and execution order are retained beside this report.

Memory, where requested, is fresh-process peak RSS including the binary, runtime, parsed catalog, compilation, input/output and allocator. It is not isolated compiled-pattern memory.
