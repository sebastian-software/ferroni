# Production regex comparison

Host: Linux-6.6.141-x86_64-with-glibc2.39; x86_64.

Publication candidate: review host stability, raw samples, coverage and run intervals before publishing.

Ratios are comparator / Ferroni. Compile and first-use times concern one pattern; steady times concern the complete fixture batch.

Each comparison below uses only its explicitly listed common tasks. Families have equal aggregate weight; architectures are never combined.

## Eligibility

| Case | Engine | Status |
| --- | --- | --- |
| `tiktoken_cl100k_base` | rust | eligible |
| `tiktoken_cl100k_base` | rust_erroraware | eligible |
| `tiktoken_cl100k_base` | c | eligible |
| `tiktoken_cl100k_base` | onigmo | eligible |
| `tiktoken_cl100k_base` | pcre2_jit | eligible |
| `tiktoken_cl100k_base` | pcre2 | eligible |
| `tiktoken_cl100k_base` | fancy_regex | eligible |
| `tiktoken_cl100k_base` | fancy_regex_seek | eligible |
| `tiktoken_cl100k_base` | regex | syntax_rejected |
| `tiktoken_o200k_base` | rust | eligible |
| `tiktoken_o200k_base` | rust_erroraware | eligible |
| `tiktoken_o200k_base` | c | eligible |
| `tiktoken_o200k_base` | onigmo | eligible |
| `tiktoken_o200k_base` | pcre2_jit | eligible |
| `tiktoken_o200k_base` | pcre2 | eligible |
| `tiktoken_o200k_base` | fancy_regex | eligible |
| `tiktoken_o200k_base` | fancy_regex_seek | eligible |
| `tiktoken_o200k_base` | regex | syntax_rejected |

## rust_erroraware / steady

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.106.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 1.072 | 1.035–1.105 | inconclusive |
| `tiktoken_o200k_base` | 1.141 | 1.021–1.652 | inconclusive |

## rust_erroraware / compile

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.027.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 1.048 | 0.984–1.050 | inconclusive |
| `tiktoken_o200k_base` | 1.007 | 0.847–1.279 | inconclusive |

## rust_erroraware / first_use

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.038.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 0.998 | 0.973–1.024 | inconclusive |
| `tiktoken_o200k_base` | 1.080 | 0.860–1.096 | inconclusive |

## c / steady

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.873.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 1.700 | 1.603–1.755 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 2.064 | 2.021–2.298 | Ferroni faster in every run interval |

## c / compile

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 0.658.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 0.777 | 0.654–0.843 | comparator faster in every run interval |
| `tiktoken_o200k_base` | 0.558 | 0.406–0.581 | comparator faster in every run interval |

## c / first_use

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 0.593.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 0.710 | 0.641–0.734 | comparator faster in every run interval |
| `tiktoken_o200k_base` | 0.495 | 0.415–0.582 | comparator faster in every run interval |

## onigmo / steady

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.597.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 1.404 | 1.170–1.448 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 1.816 | 1.685–2.122 | Ferroni faster in every run interval |

## onigmo / compile

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 0.574.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 0.590 | 0.578–0.751 | comparator faster in every run interval |
| `tiktoken_o200k_base` | 0.559 | 0.411–0.765 | comparator faster in every run interval |

## onigmo / first_use

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 0.591.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 0.600 | 0.590–0.673 | comparator faster in every run interval |
| `tiktoken_o200k_base` | 0.582 | 0.409–0.603 | comparator faster in every run interval |

## pcre2_jit / steady

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 0.469.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 0.421 | 0.348–0.436 | comparator faster in every run interval |
| `tiktoken_o200k_base` | 0.523 | 0.459–0.538 | comparator faster in every run interval |

## pcre2_jit / compile

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 0.174.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 0.201 | 0.191–0.216 | comparator faster in every run interval |
| `tiktoken_o200k_base` | 0.151 | 0.110–0.163 | comparator faster in every run interval |

## pcre2_jit / first_use

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 0.183.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 0.217 | 0.208–0.246 | comparator faster in every run interval |
| `tiktoken_o200k_base` | 0.154 | 0.119–0.164 | comparator faster in every run interval |

## pcre2 / steady

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.822.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 1.260 | 1.091–1.365 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 2.636 | 2.240–2.706 | Ferroni faster in every run interval |

## pcre2 / compile

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 0.079.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 0.072 | 0.071–0.072 | comparator faster in every run interval |
| `tiktoken_o200k_base` | 0.087 | 0.062–0.098 | comparator faster in every run interval |

## pcre2 / first_use

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 0.083.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 0.083 | 0.083–0.085 | comparator faster in every run interval |
| `tiktoken_o200k_base` | 0.083 | 0.065–0.091 | comparator faster in every run interval |

## fancy_regex / steady

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.604.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 2.176 | 1.833–2.217 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 1.182 | 1.071–1.204 | Ferroni faster in every run interval |

## fancy_regex / compile

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 7.483.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 8.805 | 8.538–8.977 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 6.360 | 4.962–6.526 | Ferroni faster in every run interval |

## fancy_regex / first_use

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 7.053.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 8.337 | 7.810–8.636 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 5.967 | 5.298–6.644 | Ferroni faster in every run interval |

## fancy_regex_seek / steady

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 2.216.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 2.807 | 2.555–2.848 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 1.749 | 1.705–2.116 | Ferroni faster in every run interval |

## fancy_regex_seek / compile

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 14.241.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 15.337 | 15.256–16.007 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 13.223 | 11.382–16.148 | Ferroni faster in every run interval |

## fancy_regex_seek / first_use

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 15.046.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 17.108 | 15.547–17.488 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 13.231 | 13.059–14.855 | Ferroni faster in every run interval |

Raw samples, estimates, confidence intervals, failures, eligibility reasons, corpus snapshot and execution order are retained beside this report.

Memory, where requested, is fresh-process peak RSS including the binary, runtime, parsed catalog, compilation, input/output and allocator. It is not isolated compiled-pattern memory.
