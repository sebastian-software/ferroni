# Production regex comparison

Host: Linux-6.6.141-x86_64-with-glibc2.39; x86_64.

Publication candidate: review host stability, raw samples, coverage and run intervals before publishing.

Ratios are comparator / Ferroni. Compile and first-use times concern one pattern; steady times concern the complete fixture batch.

Each comparison below uses only its explicitly listed common tasks. Families have equal aggregate weight; architectures are never combined.

## Eligibility

| Case | Engine | Status |
| --- | --- | --- |
| `tiktoken_cl100k_base` | rust | eligible |
| `tiktoken_cl100k_base` | rust_erroraware | eligible |
| `tiktoken_cl100k_base` | c | eligible |
| `tiktoken_cl100k_base` | onigmo | eligible |
| `tiktoken_cl100k_base` | pcre2_jit | eligible |
| `tiktoken_cl100k_base` | pcre2 | eligible |
| `tiktoken_cl100k_base` | fancy_regex | eligible |
| `tiktoken_cl100k_base` | fancy_regex_seek | eligible |
| `tiktoken_cl100k_base` | regex | syntax_rejected |
| `tiktoken_o200k_base` | rust | eligible |
| `tiktoken_o200k_base` | rust_erroraware | eligible |
| `tiktoken_o200k_base` | c | eligible |
| `tiktoken_o200k_base` | onigmo | eligible |
| `tiktoken_o200k_base` | pcre2_jit | eligible |
| `tiktoken_o200k_base` | pcre2 | eligible |
| `tiktoken_o200k_base` | fancy_regex | eligible |
| `tiktoken_o200k_base` | fancy_regex_seek | eligible |
| `tiktoken_o200k_base` | regex | syntax_rejected |

## rust_erroraware / steady

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.001.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 1.027 | 1.016–1.037 | inconclusive |
| `tiktoken_o200k_base` | 0.975 | 0.757–1.073 | inconclusive |

## rust_erroraware / compile

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 0.984.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 1.015 | 0.939–1.035 | inconclusive |
| `tiktoken_o200k_base` | 0.955 | 0.760–1.010 | inconclusive |

## rust_erroraware / first_use

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.048.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 0.999 | 0.954–1.053 | inconclusive |
| `tiktoken_o200k_base` | 1.099 | 1.019–1.149 | inconclusive |

## c / steady

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.660.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 1.627 | 1.570–2.013 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 1.693 | 1.395–1.922 | Ferroni faster in every run interval |

## c / compile

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 0.616.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 0.660 | 0.638–0.661 | comparator faster in every run interval |
| `tiktoken_o200k_base` | 0.575 | 0.475–0.597 | comparator faster in every run interval |

## c / first_use

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 0.598.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 0.701 | 0.590–0.809 | comparator faster in every run interval |
| `tiktoken_o200k_base` | 0.510 | 0.498–0.766 | comparator faster in every run interval |

## onigmo / steady

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.551.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 1.317 | 1.198–1.845 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 1.827 | 1.486–1.960 | Ferroni faster in every run interval |

## onigmo / compile

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 0.627.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 0.699 | 0.542–0.977 | inconclusive |
| `tiktoken_o200k_base` | 0.563 | 0.532–0.710 | comparator faster in every run interval |

## onigmo / first_use

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 0.726.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 0.725 | 0.678–0.953 | inconclusive |
| `tiktoken_o200k_base` | 0.728 | 0.512–0.844 | comparator faster in every run interval |

## pcre2_jit / steady

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 0.516.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 0.483 | 0.416–0.503 | comparator faster in every run interval |
| `tiktoken_o200k_base` | 0.551 | 0.450–0.552 | comparator faster in every run interval |

## pcre2_jit / compile

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 0.190.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 0.229 | 0.198–0.244 | comparator faster in every run interval |
| `tiktoken_o200k_base` | 0.157 | 0.106–0.167 | comparator faster in every run interval |

## pcre2_jit / first_use

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 0.197.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 0.214 | 0.207–0.274 | comparator faster in every run interval |
| `tiktoken_o200k_base` | 0.182 | 0.141–0.221 | comparator faster in every run interval |

## pcre2 / steady

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.792.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 1.360 | 1.268–1.374 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 2.361 | 1.995–2.379 | Ferroni faster in every run interval |

## pcre2 / compile

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 0.076.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 0.076 | 0.073–0.079 | comparator faster in every run interval |
| `tiktoken_o200k_base` | 0.076 | 0.066–0.077 | comparator faster in every run interval |

## pcre2 / first_use

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 0.091.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 0.086 | 0.080–0.113 | comparator faster in every run interval |
| `tiktoken_o200k_base` | 0.096 | 0.094–0.106 | comparator faster in every run interval |

## fancy_regex / steady

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.456.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 1.977 | 1.952–2.085 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 1.073 | 0.982–1.138 | inconclusive |

## fancy_regex / compile

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 6.951.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 8.171 | 7.432–8.906 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 5.913 | 5.424–7.051 | Ferroni faster in every run interval |

## fancy_regex / first_use

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 7.445.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 8.240 | 7.577–11.818 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 6.727 | 5.864–7.256 | Ferroni faster in every run interval |

## fancy_regex_seek / steady

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 2.321.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 3.374 | 3.192–3.381 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 1.596 | 1.432–1.721 | Ferroni faster in every run interval |

## fancy_regex_seek / compile

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 14.189.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 16.572 | 14.939–19.209 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 12.148 | 11.610–12.419 | Ferroni faster in every run interval |

## fancy_regex_seek / first_use

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 16.819.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 18.665 | 15.333–21.342 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 15.155 | 15.002–15.368 | Ferroni faster in every run interval |

Raw samples, estimates, confidence intervals, failures, eligibility reasons, corpus snapshot and execution order are retained beside this report.

Memory, where requested, is fresh-process peak RSS including the binary, runtime, parsed catalog, compilation, input/output and allocator. It is not isolated compiled-pattern memory.
