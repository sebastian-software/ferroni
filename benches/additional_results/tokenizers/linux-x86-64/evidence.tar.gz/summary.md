# Production regex comparison

Host: Linux-6.6.141-x86_64-with-glibc2.39; x86_64.

Publication candidate: review host stability, raw samples, coverage and run intervals before publishing.

Ratios are comparator / Ferroni. Compile and first-use times concern one pattern; steady times concern the complete fixture batch.

Each comparison below uses only its explicitly listed common tasks. Families have equal aggregate weight; architectures are never combined.

## Eligibility

| Case | Engine | Status |
| --- | --- | --- |
| `tiktoken_cl100k_base` | rust | eligible |
| `tiktoken_cl100k_base` | rust_erroraware | eligible |
| `tiktoken_cl100k_base` | c | eligible |
| `tiktoken_cl100k_base` | onigmo | eligible |
| `tiktoken_cl100k_base` | pcre2_jit | eligible |
| `tiktoken_cl100k_base` | pcre2 | eligible |
| `tiktoken_cl100k_base` | fancy_regex | eligible |
| `tiktoken_cl100k_base` | fancy_regex_seek | eligible |
| `tiktoken_cl100k_base` | regex | syntax_rejected |
| `tiktoken_o200k_base` | rust | eligible |
| `tiktoken_o200k_base` | rust_erroraware | eligible |
| `tiktoken_o200k_base` | c | eligible |
| `tiktoken_o200k_base` | onigmo | eligible |
| `tiktoken_o200k_base` | pcre2_jit | eligible |
| `tiktoken_o200k_base` | pcre2 | eligible |
| `tiktoken_o200k_base` | fancy_regex | eligible |
| `tiktoken_o200k_base` | fancy_regex_seek | eligible |
| `tiktoken_o200k_base` | regex | syntax_rejected |

## rust_erroraware / steady

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.092.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 1.114 | 1.092–1.127 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 1.071 | 0.984–1.125 | inconclusive |

## rust_erroraware / compile

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.021.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 1.006 | 0.980–1.083 | inconclusive |
| `tiktoken_o200k_base` | 1.035 | 0.932–1.038 | inconclusive |

## rust_erroraware / first_use

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.016.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 1.020 | 0.980–1.063 | inconclusive |
| `tiktoken_o200k_base` | 1.012 | 0.933–1.111 | inconclusive |

## c / steady

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.862.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 1.661 | 1.585–1.849 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 2.088 | 1.917–2.154 | Ferroni faster in every run interval |

## c / compile

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 0.596.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 0.651 | 0.641–0.654 | comparator faster in every run interval |
| `tiktoken_o200k_base` | 0.546 | 0.528–0.574 | comparator faster in every run interval |

## c / first_use

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 0.577.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 0.623 | 0.616–0.626 | comparator faster in every run interval |
| `tiktoken_o200k_base` | 0.535 | 0.528–0.560 | comparator faster in every run interval |

## onigmo / steady

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.565.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 1.272 | 1.262–1.286 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 1.925 | 1.584–1.952 | Ferroni faster in every run interval |

## onigmo / compile

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 0.599.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 0.619 | 0.594–0.640 | comparator faster in every run interval |
| `tiktoken_o200k_base` | 0.579 | 0.549–0.582 | comparator faster in every run interval |

## onigmo / first_use

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 0.606.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 0.610 | 0.610–0.655 | comparator faster in every run interval |
| `tiktoken_o200k_base` | 0.601 | 0.561–0.652 | comparator faster in every run interval |

## pcre2_jit / steady

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 0.472.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 0.431 | 0.417–0.433 | comparator faster in every run interval |
| `tiktoken_o200k_base` | 0.518 | 0.455–0.520 | comparator faster in every run interval |

## pcre2_jit / compile

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 0.184.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 0.206 | 0.183–0.213 | comparator faster in every run interval |
| `tiktoken_o200k_base` | 0.163 | 0.151–0.164 | comparator faster in every run interval |

## pcre2_jit / first_use

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 0.197.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 0.230 | 0.200–0.255 | comparator faster in every run interval |
| `tiktoken_o200k_base` | 0.169 | 0.157–0.169 | comparator faster in every run interval |

## pcre2 / steady

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.733.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 1.186 | 1.182–1.200 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 2.530 | 2.329–2.653 | Ferroni faster in every run interval |

## pcre2 / compile

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 0.079.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 0.071 | 0.065–0.083 | comparator faster in every run interval |
| `tiktoken_o200k_base` | 0.087 | 0.082–0.093 | comparator faster in every run interval |

## pcre2 / first_use

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 0.089.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 0.086 | 0.077–0.095 | comparator faster in every run interval |
| `tiktoken_o200k_base` | 0.092 | 0.087–0.103 | comparator faster in every run interval |

## fancy_regex / steady

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 1.501.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 1.965 | 1.963–2.058 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 1.146 | 1.025–1.214 | inconclusive |

## fancy_regex / compile

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 7.159.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 8.036 | 7.417–8.413 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 6.378 | 6.134–6.842 | Ferroni faster in every run interval |

## fancy_regex / first_use

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 7.428.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 8.451 | 7.729–8.623 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 6.528 | 6.357–6.818 | Ferroni faster in every run interval |

## fancy_regex_seek / steady

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 2.146.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 2.680 | 2.561–2.757 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 1.719 | 1.613–1.753 | Ferroni faster in every run interval |

## fancy_regex_seek / compile

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 14.263.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 15.849 | 14.265–16.227 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 12.836 | 12.706–12.876 | Ferroni faster in every run interval |

## fancy_regex_seek / first_use

Common cases: 2; families: 1. Pair-specific family-weighted ratio: 16.069.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `tiktoken_cl100k_base` | 17.588 | 16.420–17.966 | Ferroni faster in every run interval |
| `tiktoken_o200k_base` | 14.681 | 14.408–15.072 | Ferroni faster in every run interval |

Raw samples, estimates, confidence intervals, failures, eligibility reasons, corpus snapshot and execution order are retained beside this report.

Memory, where requested, is fresh-process peak RSS including the binary, runtime, parsed catalog, compilation, input/output and allocator. It is not isolated compiled-pattern memory.
