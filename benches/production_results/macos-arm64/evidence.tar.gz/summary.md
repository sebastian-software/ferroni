# Production regex comparison

Host: macOS-26.3-arm64-arm-64bit-Mach-O; arm64.

Publication candidate: review host stability, raw samples, coverage and run intervals before publishing.

Ratios are comparator / Ferroni. Compile and first-use times concern one pattern; steady times concern the complete fixture batch.

Each comparison below uses only its explicitly listed common tasks. Families have equal aggregate weight; architectures are never combined.

## Eligibility

| Case | Engine | Status |
| --- | --- | --- |
| `uuid_shape` | rust | eligible |
| `uuid_shape` | rust_erroraware | eligible |
| `uuid_shape` | c | eligible |
| `uuid_shape` | onigmo | eligible |
| `uuid_shape` | pcre2_jit | eligible |
| `uuid_shape` | pcre2 | eligible |
| `uuid_shape` | fancy_regex | eligible |
| `uuid_shape` | fancy_regex_seek | eligible |
| `uuid_shape` | regex | eligible |
| `uuid_v4` | rust | eligible |
| `uuid_v4` | rust_erroraware | eligible |
| `uuid_v4` | c | eligible |
| `uuid_v4` | onigmo | eligible |
| `uuid_v4` | pcre2_jit | eligible |
| `uuid_v4` | pcre2 | eligible |
| `uuid_v4` | fancy_regex | eligible |
| `uuid_v4` | fancy_regex_seek | eligible |
| `uuid_v4` | regex | eligible |
| `ipv4_validation` | rust | eligible |
| `ipv4_validation` | rust_erroraware | eligible |
| `ipv4_validation` | c | eligible |
| `ipv4_validation` | onigmo | eligible |
| `ipv4_validation` | pcre2_jit | eligible |
| `ipv4_validation` | pcre2 | eligible |
| `ipv4_validation` | fancy_regex | eligible |
| `ipv4_validation` | fancy_regex_seek | eligible |
| `ipv4_validation` | regex | eligible |
| `ipv6_validation` | rust | eligible |
| `ipv6_validation` | rust_erroraware | eligible |
| `ipv6_validation` | c | eligible |
| `ipv6_validation` | onigmo | eligible |
| `ipv6_validation` | pcre2_jit | eligible |
| `ipv6_validation` | pcre2 | eligible |
| `ipv6_validation` | fancy_regex | eligible |
| `ipv6_validation` | fancy_regex_seek | eligible |
| `ipv6_validation` | regex | eligible |
| `semver_version_parse` | rust | eligible |
| `semver_version_parse` | rust_erroraware | eligible |
| `semver_version_parse` | c | eligible |
| `semver_version_parse` | onigmo | eligible |
| `semver_version_parse` | pcre2_jit | eligible |
| `semver_version_parse` | pcre2 | eligible |
| `semver_version_parse` | fancy_regex | eligible |
| `semver_version_parse` | fancy_regex_seek | eligible |
| `semver_version_parse` | regex | eligible |
| `semver_hyphen_range_captures` | rust | eligible |
| `semver_hyphen_range_captures` | rust_erroraware | eligible |
| `semver_hyphen_range_captures` | c | eligible |
| `semver_hyphen_range_captures` | onigmo | eligible |
| `semver_hyphen_range_captures` | pcre2_jit | eligible |
| `semver_hyphen_range_captures` | pcre2 | eligible |
| `semver_hyphen_range_captures` | fancy_regex | eligible |
| `semver_hyphen_range_captures` | fancy_regex_seek | eligible |
| `semver_hyphen_range_captures` | regex | eligible |
| `jinja_string_token` | rust | eligible |
| `jinja_string_token` | rust_erroraware | eligible |
| `jinja_string_token` | c | eligible |
| `jinja_string_token` | onigmo | eligible |
| `jinja_string_token` | pcre2_jit | eligible |
| `jinja_string_token` | pcre2 | eligible |
| `jinja_string_token` | fancy_regex | eligible |
| `jinja_string_token` | fancy_regex_seek | eligible |
| `jinja_string_token` | regex | eligible |
| `jinja_integer_token` | rust | eligible |
| `jinja_integer_token` | rust_erroraware | eligible |
| `jinja_integer_token` | c | eligible |
| `jinja_integer_token` | onigmo | eligible |
| `jinja_integer_token` | pcre2_jit | eligible |
| `jinja_integer_token` | pcre2 | eligible |
| `jinja_integer_token` | fancy_regex | eligible |
| `jinja_integer_token` | fancy_regex_seek | eligible |
| `jinja_integer_token` | regex | eligible |
| `jinja_float_token` | rust | eligible |
| `jinja_float_token` | rust_erroraware | eligible |
| `jinja_float_token` | c | eligible |
| `jinja_float_token` | onigmo | eligible |
| `jinja_float_token` | pcre2_jit | eligible |
| `jinja_float_token` | pcre2 | eligible |
| `jinja_float_token` | fancy_regex | eligible |
| `jinja_float_token` | fancy_regex_seek | eligible |
| `jinja_float_token` | regex | syntax_rejected |
| `django_email_local_part` | rust | eligible |
| `django_email_local_part` | rust_erroraware | eligible |
| `django_email_local_part` | c | eligible |
| `django_email_local_part` | onigmo | eligible |
| `django_email_local_part` | pcre2_jit | eligible |
| `django_email_local_part` | pcre2 | eligible |
| `django_email_local_part` | fancy_regex | syntax_rejected |
| `django_email_local_part` | fancy_regex_seek | syntax_rejected |
| `django_email_local_part` | regex | syntax_rejected |
| `django_email_domain` | rust | eligible |
| `django_email_domain` | rust_erroraware | eligible |
| `django_email_domain` | c | eligible |
| `django_email_domain` | onigmo | eligible |
| `django_email_domain` | pcre2_jit | eligible |
| `django_email_domain` | pcre2 | eligible |
| `django_email_domain` | fancy_regex | eligible |
| `django_email_domain` | fancy_regex_seek | eligible |
| `django_email_domain` | regex | syntax_rejected |
| `django_url_regex` | rust | eligible |
| `django_url_regex` | rust_erroraware | eligible |
| `django_url_regex` | c | eligible |
| `django_url_regex` | onigmo | eligible |
| `django_url_regex` | pcre2_jit | eligible |
| `django_url_regex` | pcre2 | eligible |
| `django_url_regex` | fancy_regex | eligible |
| `django_url_regex` | fancy_regex_seek | eligible |
| `django_url_regex` | regex | syntax_rejected |
| `fluent_bit_apache` | rust | eligible |
| `fluent_bit_apache` | rust_erroraware | eligible |
| `fluent_bit_apache` | c | eligible |
| `fluent_bit_apache` | onigmo | eligible |
| `fluent_bit_apache` | pcre2_jit | eligible |
| `fluent_bit_apache` | pcre2 | eligible |
| `fluent_bit_apache` | fancy_regex | eligible |
| `fluent_bit_apache` | fancy_regex_seek | eligible |
| `fluent_bit_apache` | regex | eligible |
| `fluent_bit_nginx` | rust | eligible |
| `fluent_bit_nginx` | rust_erroraware | eligible |
| `fluent_bit_nginx` | c | eligible |
| `fluent_bit_nginx` | onigmo | eligible |
| `fluent_bit_nginx` | pcre2_jit | eligible |
| `fluent_bit_nginx` | pcre2 | eligible |
| `fluent_bit_nginx` | fancy_regex | eligible |
| `fluent_bit_nginx` | fancy_regex_seek | eligible |
| `fluent_bit_nginx` | regex | eligible |
| `rails_underscore_regex_step` | rust | eligible |
| `rails_underscore_regex_step` | rust_erroraware | eligible |
| `rails_underscore_regex_step` | c | eligible |
| `rails_underscore_regex_step` | onigmo | eligible |
| `rails_underscore_regex_step` | pcre2_jit | eligible |
| `rails_underscore_regex_step` | pcre2 | eligible |
| `rails_underscore_regex_step` | fancy_regex | eligible |
| `rails_underscore_regex_step` | fancy_regex_seek | eligible |
| `rails_underscore_regex_step` | regex | syntax_rejected |
| `mastodon_hashtag_regex_step` | rust | eligible |
| `mastodon_hashtag_regex_step` | rust_erroraware | eligible |
| `mastodon_hashtag_regex_step` | c | eligible |
| `mastodon_hashtag_regex_step` | onigmo | eligible |
| `mastodon_hashtag_regex_step` | pcre2_jit | eligible |
| `mastodon_hashtag_regex_step` | pcre2 | eligible |
| `mastodon_hashtag_regex_step` | fancy_regex | semantic_difference |
| `mastodon_hashtag_regex_step` | fancy_regex_seek | semantic_difference |
| `mastodon_hashtag_regex_step` | regex | syntax_rejected |
| `python_markdown_smart_emphasis_re` | rust | eligible |
| `python_markdown_smart_emphasis_re` | rust_erroraware | eligible |
| `python_markdown_smart_emphasis_re` | c | eligible |
| `python_markdown_smart_emphasis_re` | onigmo | eligible |
| `python_markdown_smart_emphasis_re` | pcre2_jit | eligible |
| `python_markdown_smart_emphasis_re` | pcre2 | eligible |
| `python_markdown_smart_emphasis_re` | fancy_regex | eligible |
| `python_markdown_smart_emphasis_re` | fancy_regex_seek | eligible |
| `python_markdown_smart_emphasis_re` | regex | syntax_rejected |
| `python_markdown_smart_strong_em_re` | rust | eligible |
| `python_markdown_smart_strong_em_re` | rust_erroraware | eligible |
| `python_markdown_smart_strong_em_re` | c | eligible |
| `python_markdown_smart_strong_em_re` | onigmo | eligible |
| `python_markdown_smart_strong_em_re` | pcre2_jit | eligible |
| `python_markdown_smart_strong_em_re` | pcre2 | eligible |
| `python_markdown_smart_strong_em_re` | fancy_regex | eligible |
| `python_markdown_smart_strong_em_re` | fancy_regex_seek | eligible |
| `python_markdown_smart_strong_em_re` | regex | syntax_rejected |
| `wordpress_shortcode_captures` | rust | eligible |
| `wordpress_shortcode_captures` | rust_erroraware | eligible |
| `wordpress_shortcode_captures` | c | eligible |
| `wordpress_shortcode_captures` | onigmo | eligible |
| `wordpress_shortcode_captures` | pcre2_jit | eligible |
| `wordpress_shortcode_captures` | pcre2 | eligible |
| `wordpress_shortcode_captures` | fancy_regex | eligible |
| `wordpress_shortcode_captures` | fancy_regex_seek | eligible |
| `wordpress_shortcode_captures` | regex | syntax_rejected |
| `symfony_grapheme_chunks_1` | rust | eligible |
| `symfony_grapheme_chunks_1` | rust_erroraware | eligible |
| `symfony_grapheme_chunks_1` | c | eligible |
| `symfony_grapheme_chunks_1` | onigmo | semantic_difference |
| `symfony_grapheme_chunks_1` | pcre2_jit | eligible |
| `symfony_grapheme_chunks_1` | pcre2 | eligible |
| `symfony_grapheme_chunks_1` | fancy_regex | syntax_rejected |
| `symfony_grapheme_chunks_1` | fancy_regex_seek | syntax_rejected |
| `symfony_grapheme_chunks_1` | regex | syntax_rejected |
| `symfony_grapheme_chunks_2` | rust | eligible |
| `symfony_grapheme_chunks_2` | rust_erroraware | eligible |
| `symfony_grapheme_chunks_2` | c | eligible |
| `symfony_grapheme_chunks_2` | onigmo | eligible |
| `symfony_grapheme_chunks_2` | pcre2_jit | eligible |
| `symfony_grapheme_chunks_2` | pcre2 | eligible |
| `symfony_grapheme_chunks_2` | fancy_regex | syntax_rejected |
| `symfony_grapheme_chunks_2` | fancy_regex_seek | syntax_rejected |
| `symfony_grapheme_chunks_2` | regex | syntax_rejected |
| `literal_first` | rust | eligible |
| `literal_first` | rust_erroraware | eligible |
| `literal_first` | c | eligible |
| `literal_first` | onigmo | eligible |
| `literal_first` | pcre2_jit | eligible |
| `literal_first` | pcre2 | eligible |
| `literal_first` | fancy_regex | eligible |
| `literal_first` | fancy_regex_seek | eligible |
| `literal_first` | regex | eligible |
| `literal_middle` | rust | eligible |
| `literal_middle` | rust_erroraware | eligible |
| `literal_middle` | c | eligible |
| `literal_middle` | onigmo | eligible |
| `literal_middle` | pcre2_jit | eligible |
| `literal_middle` | pcre2 | eligible |
| `literal_middle` | fancy_regex | eligible |
| `literal_middle` | fancy_regex_seek | eligible |
| `literal_middle` | regex | eligible |
| `literal_end` | rust | eligible |
| `literal_end` | rust_erroraware | eligible |
| `literal_end` | c | eligible |
| `literal_end` | onigmo | eligible |
| `literal_end` | pcre2_jit | eligible |
| `literal_end` | pcre2 | eligible |
| `literal_end` | fancy_regex | eligible |
| `literal_end` | fancy_regex_seek | eligible |
| `literal_end` | regex | eligible |
| `literal_absent` | rust | eligible |
| `literal_absent` | rust_erroraware | eligible |
| `literal_absent` | c | eligible |
| `literal_absent` | onigmo | eligible |
| `literal_absent` | pcre2_jit | eligible |
| `literal_absent` | pcre2 | eligible |
| `literal_absent` | fancy_regex | eligible |
| `literal_absent` | fancy_regex_seek | eligible |
| `literal_absent` | regex | eligible |
| `linkify_http_tail` | rust | pending |
| `linkify_http_tail` | rust_erroraware | pending |
| `linkify_http_tail` | c | pending |
| `linkify_http_tail` | onigmo | pending |
| `linkify_http_tail` | pcre2_jit | pending |
| `linkify_http_tail` | pcre2 | pending |
| `linkify_http_tail` | fancy_regex | pending |
| `linkify_http_tail` | fancy_regex_seek | pending |
| `linkify_http_tail` | regex | pending |
| `php_cs_fixer_recursive_types` | rust | pending |
| `php_cs_fixer_recursive_types` | rust_erroraware | pending |
| `php_cs_fixer_recursive_types` | c | pending |
| `php_cs_fixer_recursive_types` | onigmo | pending |
| `php_cs_fixer_recursive_types` | pcre2_jit | pending |
| `php_cs_fixer_recursive_types` | pcre2 | pending |
| `php_cs_fixer_recursive_types` | fancy_regex | pending |
| `php_cs_fixer_recursive_types` | fancy_regex_seek | pending |
| `php_cs_fixer_recursive_types` | regex | pending |
| `ferrolink_markup_scan` | rust | eligible |
| `ferrolink_markup_scan` | rust_erroraware | eligible |
| `ferrolink_markup_scan` | c | eligible |
| `ferrolink_markup_scan` | onigmo | eligible |
| `ferrolink_markup_scan` | pcre2_jit | eligible |
| `ferrolink_markup_scan` | pcre2 | eligible |
| `ferrolink_markup_scan` | fancy_regex | eligible |
| `ferrolink_markup_scan` | fancy_regex_seek | eligible |
| `ferrolink_markup_scan` | regex | syntax_rejected |
| `ferrolink_attribute_split` | rust | eligible |
| `ferrolink_attribute_split` | rust_erroraware | eligible |
| `ferrolink_attribute_split` | c | eligible |
| `ferrolink_attribute_split` | onigmo | eligible |
| `ferrolink_attribute_split` | pcre2_jit | eligible |
| `ferrolink_attribute_split` | pcre2 | eligible |
| `ferrolink_attribute_split` | fancy_regex | eligible |
| `ferrolink_attribute_split` | fancy_regex_seek | eligible |
| `ferrolink_attribute_split` | regex | eligible |

## rust_erroraware / steady

Common cases: 27; families: 14. Pair-specific family-weighted ratio: 1.734.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.837 | 1.803–1.860 | Ferroni faster in every run interval |
| `uuid_v4` | 1.838 | 1.764–1.925 | Ferroni faster in every run interval |
| `ipv4_validation` | 5.567 | 5.502–5.747 | Ferroni faster in every run interval |
| `ipv6_validation` | 12.595 | 12.422–12.930 | Ferroni faster in every run interval |
| `semver_version_parse` | 1.086 | 1.074–1.110 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.093 | 1.064–1.108 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.086 | 1.075–1.248 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.206 | 1.163–1.281 | Ferroni faster in every run interval |
| `jinja_float_token` | 1.241 | 1.110–1.288 | Ferroni faster in every run interval |
| `django_email_local_part` | 3.183 | 3.177–3.345 | Ferroni faster in every run interval |
| `django_email_domain` | 7.433 | 7.297–7.447 | Ferroni faster in every run interval |
| `django_url_regex` | 10.674 | 9.735–10.832 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.201 | 1.153–1.228 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.370 | 1.331–1.419 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 0.933 | 0.919–0.998 | inconclusive |
| `mastodon_hashtag_regex_step` | 1.106 | 0.993–1.154 | inconclusive |
| `python_markdown_smart_emphasis_re` | 1.172 | 1.119–1.192 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 1.079 | 1.076–1.155 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 1.041 | 0.995–1.061 | inconclusive |
| `symfony_grapheme_chunks_1` | 1.013 | 1.002–1.043 | inconclusive |
| `symfony_grapheme_chunks_2` | 1.026 | 0.970–1.032 | inconclusive |
| `literal_first` | 1.398 | 1.396–1.420 | Ferroni faster in every run interval |
| `literal_middle` | 1.546 | 1.491–1.575 | Ferroni faster in every run interval |
| `literal_end` | 1.320 | 1.238–1.363 | Ferroni faster in every run interval |
| `literal_absent` | 1.195 | 1.181–1.241 | Ferroni faster in every run interval |
| `ferrolink_markup_scan` | 0.996 | 0.935–1.108 | inconclusive |
| `ferrolink_attribute_split` | 1.025 | 1.018–1.175 | inconclusive |

## rust_erroraware / compile

Common cases: 27; families: 14. Pair-specific family-weighted ratio: 1.000.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.022 | 1.010–1.031 | inconclusive |
| `uuid_v4` | 1.015 | 0.989–1.045 | inconclusive |
| `ipv4_validation` | 1.010 | 0.997–1.012 | inconclusive |
| `ipv6_validation` | 1.031 | 0.938–1.086 | inconclusive |
| `semver_version_parse` | 1.011 | 0.976–1.016 | inconclusive |
| `semver_hyphen_range_captures` | 0.985 | 0.984–1.054 | inconclusive |
| `jinja_string_token` | 0.974 | 0.969–1.015 | inconclusive |
| `jinja_integer_token` | 1.028 | 1.008–1.099 | inconclusive |
| `jinja_float_token` | 0.931 | 0.869–0.971 | inconclusive |
| `django_email_local_part` | 1.005 | 1.002–1.057 | inconclusive |
| `django_email_domain` | 1.008 | 0.984–1.094 | inconclusive |
| `django_url_regex` | 0.914 | 0.836–1.003 | inconclusive |
| `fluent_bit_apache` | 1.014 | 0.940–1.021 | inconclusive |
| `fluent_bit_nginx` | 1.057 | 0.950–1.124 | inconclusive |
| `rails_underscore_regex_step` | 0.982 | 0.941–1.038 | inconclusive |
| `mastodon_hashtag_regex_step` | 1.072 | 0.932–1.075 | inconclusive |
| `python_markdown_smart_emphasis_re` | 0.996 | 0.954–1.047 | inconclusive |
| `python_markdown_smart_strong_em_re` | 1.009 | 0.997–1.055 | inconclusive |
| `wordpress_shortcode_captures` | 0.993 | 0.957–1.068 | inconclusive |
| `symfony_grapheme_chunks_1` | 0.970 | 0.834–0.985 | inconclusive |
| `symfony_grapheme_chunks_2` | 1.007 | 0.985–1.050 | inconclusive |
| `literal_first` | 1.011 | 0.972–1.024 | inconclusive |
| `literal_middle` | 0.990 | 0.848–1.029 | inconclusive |
| `literal_end` | 0.974 | 0.959–1.018 | inconclusive |
| `literal_absent` | 0.982 | 0.973–1.018 | inconclusive |
| `ferrolink_markup_scan` | 1.029 | 0.986–1.078 | inconclusive |
| `ferrolink_attribute_split` | 0.992 | 0.977–1.066 | inconclusive |

## rust_erroraware / first_use

Common cases: 27; families: 14. Pair-specific family-weighted ratio: 0.945.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.794 | 0.773–0.811 | comparator faster in every run interval |
| `uuid_v4` | 0.784 | 0.725–0.786 | comparator faster in every run interval |
| `ipv4_validation` | 0.944 | 0.822–0.949 | comparator faster in every run interval |
| `ipv6_validation` | 1.001 | 0.993–1.035 | inconclusive |
| `semver_version_parse` | 0.968 | 0.947–0.974 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.988 | 0.976–1.035 | inconclusive |
| `jinja_string_token` | 0.923 | 0.876–0.940 | comparator faster in every run interval |
| `jinja_integer_token` | 1.010 | 1.007–1.045 | inconclusive |
| `jinja_float_token` | 0.902 | 0.892–0.971 | inconclusive |
| `django_email_local_part` | 0.929 | 0.924–0.999 | inconclusive |
| `django_email_domain` | 0.992 | 0.979–1.018 | inconclusive |
| `django_url_regex` | 0.946 | 0.899–0.975 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.887 | 0.811–0.910 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.882 | 0.859–0.895 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.997 | 0.901–1.047 | inconclusive |
| `mastodon_hashtag_regex_step` | 0.963 | 0.907–1.035 | inconclusive |
| `python_markdown_smart_emphasis_re` | 0.873 | 0.723–0.917 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.876 | 0.837–0.905 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.977 | 0.970–1.012 | inconclusive |
| `symfony_grapheme_chunks_1` | 0.996 | 0.806–1.061 | inconclusive |
| `symfony_grapheme_chunks_2` | 0.950 | 0.926–1.006 | inconclusive |
| `literal_first` | 1.018 | 0.979–1.065 | inconclusive |
| `literal_middle` | 1.018 | 0.864–1.022 | inconclusive |
| `literal_end` | 0.979 | 0.903–0.991 | inconclusive |
| `literal_absent` | 0.992 | 0.950–1.084 | inconclusive |
| `ferrolink_markup_scan` | 1.001 | 0.988–1.045 | inconclusive |
| `ferrolink_attribute_split` | 0.991 | 0.928–1.083 | inconclusive |

## c / steady

Common cases: 27; families: 14. Pair-specific family-weighted ratio: 3.458.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 5.215 | 5.179–5.323 | Ferroni faster in every run interval |
| `uuid_v4` | 3.853 | 3.788–4.311 | Ferroni faster in every run interval |
| `ipv4_validation` | 8.505 | 8.388–8.556 | Ferroni faster in every run interval |
| `ipv6_validation` | 14.805 | 14.654–15.511 | Ferroni faster in every run interval |
| `semver_version_parse` | 1.874 | 1.865–1.888 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.334 | 1.308–1.384 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.741 | 1.536–1.848 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.413 | 1.413–1.626 | Ferroni faster in every run interval |
| `jinja_float_token` | 1.149 | 1.085–1.284 | Ferroni faster in every run interval |
| `django_email_local_part` | 9.592 | 8.986–9.814 | Ferroni faster in every run interval |
| `django_email_domain` | 38.129 | 37.970–38.543 | Ferroni faster in every run interval |
| `django_url_regex` | 19.670 | 19.306–21.248 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 2.288 | 2.180–2.328 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 2.516 | 2.363–2.518 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.350 | 1.208–1.461 | Ferroni faster in every run interval |
| `mastodon_hashtag_regex_step` | 2.371 | 2.163–2.413 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 2.816 | 2.774–2.978 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 2.703 | 2.658–2.760 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 1.496 | 1.480–1.497 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_1` | 1.751 | 1.580–1.872 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_2` | 1.898 | 1.770–1.984 | Ferroni faster in every run interval |
| `literal_first` | 10.636 | 10.073–11.906 | Ferroni faster in every run interval |
| `literal_middle` | 12.262 | 10.820–13.232 | Ferroni faster in every run interval |
| `literal_end` | 12.166 | 11.287–12.296 | Ferroni faster in every run interval |
| `literal_absent` | 1.862 | 1.813–2.236 | Ferroni faster in every run interval |
| `ferrolink_markup_scan` | 2.048 | 2.039–2.118 | Ferroni faster in every run interval |
| `ferrolink_attribute_split` | 1.836 | 1.735–2.219 | Ferroni faster in every run interval |

## c / compile

Common cases: 27; families: 14. Pair-specific family-weighted ratio: 0.351.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 4.475 | 3.952–4.550 | Ferroni faster in every run interval |
| `uuid_v4` | 4.755 | 4.523–5.055 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.268 | 0.260–0.296 | comparator faster in every run interval |
| `ipv6_validation` | 0.273 | 0.269–0.313 | comparator faster in every run interval |
| `semver_version_parse` | 0.262 | 0.258–0.277 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.264 | 0.258–0.265 | comparator faster in every run interval |
| `jinja_string_token` | 0.125 | 0.117–0.132 | comparator faster in every run interval |
| `jinja_integer_token` | 2.439 | 2.276–2.551 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.566 | 0.556–0.630 | comparator faster in every run interval |
| `django_email_local_part` | 2.292 | 2.289–2.339 | Ferroni faster in every run interval |
| `django_email_domain` | 0.211 | 0.197–0.225 | comparator faster in every run interval |
| `django_url_regex` | 0.321 | 0.310–0.371 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.144 | 0.139–0.150 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.157 | 0.145–0.164 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.401 | 0.368–0.420 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 1.466 | 1.452–1.593 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.142 | 0.142–0.151 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.125 | 0.120–0.131 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.233 | 0.211–0.239 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.080 | 0.069–0.082 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.078 | 0.074–0.086 | comparator faster in every run interval |
| `literal_first` | 0.325 | 0.294–0.366 | comparator faster in every run interval |
| `literal_middle` | 0.338 | 0.296–0.398 | comparator faster in every run interval |
| `literal_end` | 0.323 | 0.321–0.324 | comparator faster in every run interval |
| `literal_absent` | 0.323 | 0.317–0.399 | comparator faster in every run interval |
| `ferrolink_markup_scan` | 0.164 | 0.160–0.168 | comparator faster in every run interval |
| `ferrolink_attribute_split` | 0.134 | 0.130–0.150 | comparator faster in every run interval |

## c / first_use

Common cases: 27; families: 14. Pair-specific family-weighted ratio: 0.386.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 3.271 | 2.983–3.701 | Ferroni faster in every run interval |
| `uuid_v4` | 3.567 | 3.419–3.724 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.258 | 0.238–0.281 | comparator faster in every run interval |
| `ipv6_validation` | 0.284 | 0.273–0.331 | comparator faster in every run interval |
| `semver_version_parse` | 0.264 | 0.263–0.264 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.254 | 0.227–0.267 | comparator faster in every run interval |
| `jinja_string_token` | 0.126 | 0.118–0.128 | comparator faster in every run interval |
| `jinja_integer_token` | 2.375 | 2.221–2.379 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.572 | 0.555–0.591 | comparator faster in every run interval |
| `django_email_local_part` | 2.126 | 2.071–2.209 | Ferroni faster in every run interval |
| `django_email_domain` | 0.212 | 0.195–0.215 | comparator faster in every run interval |
| `django_url_regex` | 0.351 | 0.334–0.366 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.146 | 0.141–0.150 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.170 | 0.145–0.170 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.421 | 0.380–0.463 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 1.436 | 1.406–1.612 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.148 | 0.133–0.158 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.120 | 0.119–0.132 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.233 | 0.230–0.234 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.201 | 0.165–0.207 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.149 | 0.137–0.154 | comparator faster in every run interval |
| `literal_first` | 0.560 | 0.508–0.609 | comparator faster in every run interval |
| `literal_middle` | 0.563 | 0.478–0.667 | comparator faster in every run interval |
| `literal_end` | 0.591 | 0.572–0.598 | comparator faster in every run interval |
| `literal_absent` | 0.459 | 0.391–0.501 | comparator faster in every run interval |
| `ferrolink_markup_scan` | 0.230 | 0.226–0.236 | comparator faster in every run interval |
| `ferrolink_attribute_split` | 0.148 | 0.148–0.157 | comparator faster in every run interval |

## onigmo / steady

Common cases: 26; families: 14. Pair-specific family-weighted ratio: 3.662.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 6.253 | 5.375–6.349 | Ferroni faster in every run interval |
| `uuid_v4` | 6.160 | 6.115–6.875 | Ferroni faster in every run interval |
| `ipv4_validation` | 6.679 | 6.452–6.934 | Ferroni faster in every run interval |
| `ipv6_validation` | 21.048 | 21.016–21.935 | Ferroni faster in every run interval |
| `semver_version_parse` | 2.016 | 1.964–2.064 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.251 | 1.202–1.363 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.087 | 0.972–1.214 | inconclusive |
| `jinja_integer_token` | 1.565 | 1.505–1.737 | Ferroni faster in every run interval |
| `jinja_float_token` | 2.303 | 2.201–2.520 | Ferroni faster in every run interval |
| `django_email_local_part` | 4.929 | 4.867–4.938 | Ferroni faster in every run interval |
| `django_email_domain` | 68.997 | 65.564–73.723 | Ferroni faster in every run interval |
| `django_url_regex` | 49.398 | 48.755–53.235 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 2.401 | 2.251–2.446 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 3.046 | 2.880–3.246 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.060 | 0.986–1.105 | inconclusive |
| `mastodon_hashtag_regex_step` | 2.182 | 2.091–2.300 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 2.470 | 2.365–2.754 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 2.622 | 2.509–2.672 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 1.250 | 1.203–1.329 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_2` | 3.314 | 3.269–3.330 | Ferroni faster in every run interval |
| `literal_first` | 2.907 | 2.853–3.254 | Ferroni faster in every run interval |
| `literal_middle` | 3.739 | 3.728–4.723 | Ferroni faster in every run interval |
| `literal_end` | 5.602 | 5.305–5.795 | Ferroni faster in every run interval |
| `literal_absent` | 2.577 | 2.544–3.087 | Ferroni faster in every run interval |
| `ferrolink_markup_scan` | 2.592 | 2.560–2.620 | Ferroni faster in every run interval |
| `ferrolink_attribute_split` | 1.527 | 1.453–1.740 | Ferroni faster in every run interval |

## onigmo / compile

Common cases: 26; families: 14. Pair-specific family-weighted ratio: 0.469.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 5.104 | 4.770–5.192 | Ferroni faster in every run interval |
| `uuid_v4` | 5.337 | 5.328–6.409 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.256 | 0.254–0.262 | comparator faster in every run interval |
| `ipv6_validation` | 0.257 | 0.257–0.268 | comparator faster in every run interval |
| `semver_version_parse` | 0.253 | 0.247–0.261 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.276 | 0.263–0.298 | comparator faster in every run interval |
| `jinja_string_token` | 0.105 | 0.101–0.115 | comparator faster in every run interval |
| `jinja_integer_token` | 2.479 | 2.177–2.711 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.668 | 0.634–0.721 | comparator faster in every run interval |
| `django_email_local_part` | 2.474 | 2.406–2.536 | Ferroni faster in every run interval |
| `django_email_domain` | 0.132 | 0.123–0.138 | comparator faster in every run interval |
| `django_url_regex` | 0.275 | 0.269–0.319 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.152 | 0.143–0.152 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.166 | 0.145–0.169 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.418 | 0.395–0.480 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 1.556 | 1.508–1.615 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.102 | 0.089–0.107 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.092 | 0.090–0.099 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.215 | 0.202–0.258 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 8.737 | 8.289–9.115 | Ferroni faster in every run interval |
| `literal_first` | 0.288 | 0.260–0.292 | comparator faster in every run interval |
| `literal_middle` | 0.259 | 0.245–0.349 | comparator faster in every run interval |
| `literal_end` | 0.259 | 0.248–0.272 | comparator faster in every run interval |
| `literal_absent` | 0.283 | 0.264–0.331 | comparator faster in every run interval |
| `ferrolink_markup_scan` | 0.141 | 0.137–0.160 | comparator faster in every run interval |
| `ferrolink_attribute_split` | 0.171 | 0.165–0.193 | comparator faster in every run interval |

## onigmo / first_use

Common cases: 26; families: 14. Pair-specific family-weighted ratio: 0.473.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 3.854 | 3.727–4.162 | Ferroni faster in every run interval |
| `uuid_v4` | 4.228 | 3.895–4.265 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.238 | 0.219–0.250 | comparator faster in every run interval |
| `ipv6_validation` | 0.254 | 0.250–0.283 | comparator faster in every run interval |
| `semver_version_parse` | 0.249 | 0.247–0.252 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.268 | 0.265–0.285 | comparator faster in every run interval |
| `jinja_string_token` | 0.100 | 0.099–0.106 | comparator faster in every run interval |
| `jinja_integer_token` | 2.357 | 2.355–2.617 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.700 | 0.642–0.712 | comparator faster in every run interval |
| `django_email_local_part` | 2.295 | 2.229–2.320 | Ferroni faster in every run interval |
| `django_email_domain` | 0.134 | 0.121–0.145 | comparator faster in every run interval |
| `django_url_regex` | 0.304 | 0.286–0.330 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.141 | 0.135–0.161 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.160 | 0.153–0.171 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.414 | 0.386–0.493 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 1.488 | 1.474–1.735 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.097 | 0.092–0.102 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.093 | 0.086–0.095 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.218 | 0.211–0.246 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 8.877 | 7.923–9.024 | Ferroni faster in every run interval |
| `literal_first` | 0.351 | 0.342–0.374 | comparator faster in every run interval |
| `literal_middle` | 0.334 | 0.312–0.462 | comparator faster in every run interval |
| `literal_end` | 0.370 | 0.343–0.384 | comparator faster in every run interval |
| `literal_absent` | 0.353 | 0.324–0.418 | comparator faster in every run interval |
| `ferrolink_markup_scan` | 0.208 | 0.200–0.242 | comparator faster in every run interval |
| `ferrolink_attribute_split` | 0.185 | 0.167–0.195 | comparator faster in every run interval |

## pcre2_jit / steady

Common cases: 27; families: 14. Pair-specific family-weighted ratio: 0.729.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.924 | 0.907–0.942 | comparator faster in every run interval |
| `uuid_v4` | 0.972 | 0.945–1.215 | inconclusive |
| `ipv4_validation` | 1.444 | 1.421–1.464 | Ferroni faster in every run interval |
| `ipv6_validation` | 3.840 | 3.742–4.073 | Ferroni faster in every run interval |
| `semver_version_parse` | 0.557 | 0.546–0.576 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.552 | 0.522–0.610 | comparator faster in every run interval |
| `jinja_string_token` | 0.540 | 0.504–0.626 | comparator faster in every run interval |
| `jinja_integer_token` | 0.563 | 0.543–0.563 | comparator faster in every run interval |
| `jinja_float_token` | 0.539 | 0.509–0.604 | comparator faster in every run interval |
| `django_email_local_part` | 1.641 | 1.597–1.722 | Ferroni faster in every run interval |
| `django_email_domain` | 0.813 | 0.757–0.823 | comparator faster in every run interval |
| `django_url_regex` | 1.247 | 1.129–1.247 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 0.478 | 0.443–0.485 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.760 | 0.688–0.813 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.374 | 0.356–0.421 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.367 | 0.367–0.384 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.720 | 0.679–0.728 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.565 | 0.561–0.569 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.489 | 0.466–0.556 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.590 | 0.575–0.591 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.581 | 0.558–0.597 | comparator faster in every run interval |
| `literal_first` | 1.954 | 1.847–2.032 | Ferroni faster in every run interval |
| `literal_middle` | 2.055 | 1.923–2.406 | Ferroni faster in every run interval |
| `literal_end` | 1.835 | 1.612–1.909 | Ferroni faster in every run interval |
| `literal_absent` | 1.712 | 1.497–1.962 | Ferroni faster in every run interval |
| `ferrolink_markup_scan` | 0.354 | 0.325–0.370 | comparator faster in every run interval |
| `ferrolink_attribute_split` | 0.520 | 0.500–0.542 | comparator faster in every run interval |

## pcre2_jit / compile

Common cases: 27; families: 14. Pair-specific family-weighted ratio: 0.305.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.263 | 0.263–0.291 | comparator faster in every run interval |
| `uuid_v4` | 0.280 | 0.272–0.345 | comparator faster in every run interval |
| `ipv4_validation` | 0.290 | 0.283–0.304 | comparator faster in every run interval |
| `ipv6_validation` | 0.331 | 0.327–0.341 | comparator faster in every run interval |
| `semver_version_parse` | 0.411 | 0.400–0.416 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.373 | 0.370–0.429 | comparator faster in every run interval |
| `jinja_string_token` | 0.280 | 0.254–0.291 | comparator faster in every run interval |
| `jinja_integer_token` | 0.300 | 0.268–0.303 | comparator faster in every run interval |
| `jinja_float_token` | 0.191 | 0.190–0.217 | comparator faster in every run interval |
| `django_email_local_part` | 0.417 | 0.404–0.420 | comparator faster in every run interval |
| `django_email_domain` | 0.056 | 0.051–0.059 | comparator faster in every run interval |
| `django_url_regex` | 0.058 | 0.055–0.064 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.288 | 0.263–0.294 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.281 | 0.269–0.288 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.662 | 0.631–0.722 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.166 | 0.156–0.173 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.436 | 0.404–0.441 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.345 | 0.342–0.382 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.455 | 0.408–0.512 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.215 | 0.203–0.215 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.212 | 0.204–0.224 | comparator faster in every run interval |
| `literal_first` | 2.481 | 2.253–2.742 | Ferroni faster in every run interval |
| `literal_middle` | 2.179 | 2.116–3.155 | Ferroni faster in every run interval |
| `literal_end` | 2.273 | 2.256–2.313 | Ferroni faster in every run interval |
| `literal_absent` | 2.609 | 2.307–3.110 | Ferroni faster in every run interval |
| `ferrolink_markup_scan` | 0.248 | 0.231–0.277 | comparator faster in every run interval |
| `ferrolink_attribute_split` | 0.334 | 0.307–0.348 | comparator faster in every run interval |

## pcre2_jit / first_use

Common cases: 27; families: 14. Pair-specific family-weighted ratio: 0.339.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.212 | 0.209–0.228 | comparator faster in every run interval |
| `uuid_v4` | 0.229 | 0.209–0.258 | comparator faster in every run interval |
| `ipv4_validation` | 0.336 | 0.316–0.354 | comparator faster in every run interval |
| `ipv6_validation` | 0.352 | 0.327–0.355 | comparator faster in every run interval |
| `semver_version_parse` | 0.436 | 0.416–0.533 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.386 | 0.363–0.446 | comparator faster in every run interval |
| `jinja_string_token` | 0.319 | 0.290–0.325 | comparator faster in every run interval |
| `jinja_integer_token` | 0.342 | 0.309–0.409 | comparator faster in every run interval |
| `jinja_float_token` | 0.232 | 0.215–0.266 | comparator faster in every run interval |
| `django_email_local_part` | 0.452 | 0.450–0.474 | comparator faster in every run interval |
| `django_email_domain` | 0.057 | 0.053–0.063 | comparator faster in every run interval |
| `django_url_regex` | 0.064 | 0.057–0.065 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.276 | 0.264–0.312 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.283 | 0.278–0.284 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.878 | 0.830–1.041 | inconclusive |
| `mastodon_hashtag_regex_step` | 0.175 | 0.169–0.190 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.462 | 0.452–0.489 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.379 | 0.353–0.426 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.477 | 0.470–0.554 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.399 | 0.391–0.442 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.403 | 0.378–0.432 | comparator faster in every run interval |
| `literal_first` | 2.734 | 2.417–2.922 | Ferroni faster in every run interval |
| `literal_middle` | 2.287 | 2.092–3.224 | Ferroni faster in every run interval |
| `literal_end` | 2.356 | 2.201–2.366 | Ferroni faster in every run interval |
| `literal_absent` | 2.507 | 2.359–2.985 | Ferroni faster in every run interval |
| `ferrolink_markup_scan` | 0.278 | 0.276–0.292 | comparator faster in every run interval |
| `ferrolink_attribute_split` | 0.401 | 0.339–0.402 | comparator faster in every run interval |

## pcre2 / steady

Common cases: 27; families: 14. Pair-specific family-weighted ratio: 2.017.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.822 | 1.728–1.845 | Ferroni faster in every run interval |
| `uuid_v4` | 2.041 | 1.960–2.416 | Ferroni faster in every run interval |
| `ipv4_validation` | 10.045 | 9.939–11.153 | Ferroni faster in every run interval |
| `ipv6_validation` | 20.958 | 20.591–21.412 | Ferroni faster in every run interval |
| `semver_version_parse` | 1.466 | 1.415–1.568 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.891 | 1.688–2.037 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.144 | 1.058–1.215 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.720 | 1.713–1.743 | Ferroni faster in every run interval |
| `jinja_float_token` | 1.566 | 1.554–1.623 | Ferroni faster in every run interval |
| `django_email_local_part` | 5.961 | 5.883–5.987 | Ferroni faster in every run interval |
| `django_email_domain` | 3.087 | 3.030–3.289 | Ferroni faster in every run interval |
| `django_url_regex` | 3.196 | 2.884–3.400 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.499 | 1.419–1.588 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.750 | 1.713–1.784 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.188 | 1.115–1.234 | Ferroni faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.813 | 0.756–0.844 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 3.625 | 3.603–3.825 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 3.938 | 3.907–4.053 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 1.206 | 1.172–1.374 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.841 | 0.776–0.881 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.796 | 0.760–0.833 | comparator faster in every run interval |
| `literal_first` | 3.787 | 3.741–3.963 | Ferroni faster in every run interval |
| `literal_middle` | 3.625 | 3.576–4.399 | Ferroni faster in every run interval |
| `literal_end` | 3.428 | 3.271–3.457 | Ferroni faster in every run interval |
| `literal_absent` | 1.697 | 1.522–1.864 | Ferroni faster in every run interval |
| `ferrolink_markup_scan` | 1.167 | 1.162–1.177 | Ferroni faster in every run interval |
| `ferrolink_attribute_split` | 1.109 | 1.101–1.128 | Ferroni faster in every run interval |

## pcre2 / compile

Common cases: 27; families: 14. Pair-specific family-weighted ratio: 0.090.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.105 | 0.100–0.108 | comparator faster in every run interval |
| `uuid_v4` | 0.112 | 0.111–0.144 | comparator faster in every run interval |
| `ipv4_validation` | 0.092 | 0.091–0.101 | comparator faster in every run interval |
| `ipv6_validation` | 0.106 | 0.105–0.111 | comparator faster in every run interval |
| `semver_version_parse` | 0.115 | 0.113–0.117 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.111 | 0.101–0.127 | comparator faster in every run interval |
| `jinja_string_token` | 0.061 | 0.055–0.061 | comparator faster in every run interval |
| `jinja_integer_token` | 0.083 | 0.082–0.084 | comparator faster in every run interval |
| `jinja_float_token` | 0.044 | 0.041–0.045 | comparator faster in every run interval |
| `django_email_local_part` | 0.233 | 0.233–0.244 | comparator faster in every run interval |
| `django_email_domain` | 0.054 | 0.052–0.054 | comparator faster in every run interval |
| `django_url_regex` | 0.051 | 0.044–0.052 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.061 | 0.059–0.065 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.068 | 0.067–0.072 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.202 | 0.200–0.203 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.080 | 0.076–0.087 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.080 | 0.077–0.083 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.067 | 0.066–0.073 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.114 | 0.112–0.132 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.031 | 0.029–0.032 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.028 | 0.028–0.029 | comparator faster in every run interval |
| `literal_first` | 0.251 | 0.240–0.264 | comparator faster in every run interval |
| `literal_middle` | 0.223 | 0.221–0.294 | comparator faster in every run interval |
| `literal_end` | 0.233 | 0.227–0.242 | comparator faster in every run interval |
| `literal_absent` | 0.255 | 0.233–0.259 | comparator faster in every run interval |
| `ferrolink_markup_scan` | 0.063 | 0.059–0.066 | comparator faster in every run interval |
| `ferrolink_attribute_split` | 0.124 | 0.111–0.125 | comparator faster in every run interval |

## pcre2 / first_use

Common cases: 27; families: 14. Pair-specific family-weighted ratio: 0.109.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.094 | 0.089–0.097 | comparator faster in every run interval |
| `uuid_v4` | 0.095 | 0.092–0.114 | comparator faster in every run interval |
| `ipv4_validation` | 0.096 | 0.084–0.115 | comparator faster in every run interval |
| `ipv6_validation` | 0.115 | 0.112–0.119 | comparator faster in every run interval |
| `semver_version_parse` | 0.123 | 0.112–0.127 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.113 | 0.100–0.125 | comparator faster in every run interval |
| `jinja_string_token` | 0.072 | 0.061–0.075 | comparator faster in every run interval |
| `jinja_integer_token` | 0.086 | 0.085–0.096 | comparator faster in every run interval |
| `jinja_float_token` | 0.048 | 0.045–0.049 | comparator faster in every run interval |
| `django_email_local_part` | 0.236 | 0.230–0.243 | comparator faster in every run interval |
| `django_email_domain` | 0.052 | 0.051–0.052 | comparator faster in every run interval |
| `django_url_regex` | 0.051 | 0.047–0.057 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.072 | 0.069–0.083 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.076 | 0.076–0.084 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.223 | 0.222–0.232 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.083 | 0.083–0.083 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.098 | 0.098–0.103 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.092 | 0.083–0.095 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.128 | 0.124–0.136 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.103 | 0.101–0.107 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.077 | 0.072–0.077 | comparator faster in every run interval |
| `literal_first` | 0.514 | 0.484–0.609 | comparator faster in every run interval |
| `literal_middle` | 0.456 | 0.427–0.641 | comparator faster in every run interval |
| `literal_end` | 0.468 | 0.460–0.477 | comparator faster in every run interval |
| `literal_absent` | 0.417 | 0.365–0.473 | comparator faster in every run interval |
| `ferrolink_markup_scan` | 0.100 | 0.092–0.102 | comparator faster in every run interval |
| `ferrolink_attribute_split` | 0.136 | 0.114–0.142 | comparator faster in every run interval |

## fancy_regex / steady

Common cases: 23; families: 12. Pair-specific family-weighted ratio: 2.913.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.037 | 0.979–1.045 | inconclusive |
| `uuid_v4` | 1.050 | 0.987–1.276 | inconclusive |
| `ipv4_validation` | 1.105 | 1.086–1.173 | Ferroni faster in every run interval |
| `ipv6_validation` | 1.202 | 1.124–1.232 | Ferroni faster in every run interval |
| `semver_version_parse` | 3.183 | 2.888–3.298 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 2.421 | 2.279–2.587 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.122 | 1.065–1.255 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.527 | 1.486–1.549 | Ferroni faster in every run interval |
| `jinja_float_token` | 2.838 | 2.804–2.947 | Ferroni faster in every run interval |
| `django_email_domain` | 9.557 | 9.025–9.894 | Ferroni faster in every run interval |
| `django_url_regex` | 24.938 | 23.534–25.459 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.939 | 1.930–2.084 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 2.438 | 2.364–2.451 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 3.206 | 3.117–3.286 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 3.834 | 3.788–4.076 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 5.073 | 5.019–5.295 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 2.154 | 2.036–2.520 | Ferroni faster in every run interval |
| `literal_first` | 1.464 | 1.373–1.557 | Ferroni faster in every run interval |
| `literal_middle` | 1.542 | 1.470–1.780 | Ferroni faster in every run interval |
| `literal_end` | 1.353 | 1.298–1.385 | Ferroni faster in every run interval |
| `literal_absent` | 1.397 | 1.317–1.503 | Ferroni faster in every run interval |
| `ferrolink_markup_scan` | 4.673 | 4.570–4.849 | Ferroni faster in every run interval |
| `ferrolink_attribute_split` | 1.807 | 1.777–1.850 | Ferroni faster in every run interval |

## fancy_regex / compile

Common cases: 23; families: 12. Pair-specific family-weighted ratio: 1.978.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.151 | 1.105–1.208 | Ferroni faster in every run interval |
| `uuid_v4` | 1.138 | 1.004–1.460 | inconclusive |
| `ipv4_validation` | 0.835 | 0.798–0.963 | comparator faster in every run interval |
| `ipv6_validation` | 0.969 | 0.833–1.005 | inconclusive |
| `semver_version_parse` | 12.370 | 11.561–12.719 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 8.353 | 7.523–8.826 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.886 | 1.786–2.001 | Ferroni faster in every run interval |
| `jinja_integer_token` | 2.081 | 1.957–2.099 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.256 | 0.244–0.264 | comparator faster in every run interval |
| `django_email_domain` | 7.584 | 7.540–8.364 | Ferroni faster in every run interval |
| `django_url_regex` | 6.552 | 6.195–6.964 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.566 | 1.480–1.715 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.830 | 1.571–1.862 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.178 | 1.123–1.181 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.531 | 0.476–0.552 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.432 | 0.429–0.440 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 1.205 | 1.171–1.491 | Ferroni faster in every run interval |
| `literal_first` | 1.731 | 1.722–1.843 | Ferroni faster in every run interval |
| `literal_middle` | 1.819 | 1.573–1.989 | Ferroni faster in every run interval |
| `literal_end` | 1.681 | 1.638–1.720 | Ferroni faster in every run interval |
| `literal_absent` | 1.773 | 1.745–1.911 | Ferroni faster in every run interval |
| `ferrolink_markup_scan` | 3.086 | 3.041–3.501 | Ferroni faster in every run interval |
| `ferrolink_attribute_split` | 3.773 | 3.416–3.918 | Ferroni faster in every run interval |

## fancy_regex / first_use

Common cases: 23; families: 12. Pair-specific family-weighted ratio: 2.013.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.164 | 1.084–1.193 | Ferroni faster in every run interval |
| `uuid_v4` | 1.070 | 1.045–1.320 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.884 | 0.756–1.030 | inconclusive |
| `ipv6_validation` | 0.922 | 0.896–1.061 | inconclusive |
| `semver_version_parse` | 12.577 | 11.596–12.765 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 8.051 | 7.006–8.505 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.801 | 1.736–1.905 | Ferroni faster in every run interval |
| `jinja_integer_token` | 2.081 | 2.044–2.179 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.254 | 0.248–0.268 | comparator faster in every run interval |
| `django_email_domain` | 7.499 | 7.475–7.735 | Ferroni faster in every run interval |
| `django_url_regex` | 6.820 | 6.215–7.515 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.537 | 1.519–1.559 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.839 | 1.531–1.863 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.417 | 1.404–1.419 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.461 | 0.443–0.490 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.390 | 0.389–0.438 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 1.323 | 1.249–1.444 | Ferroni faster in every run interval |
| `literal_first` | 1.827 | 1.810–1.852 | Ferroni faster in every run interval |
| `literal_middle` | 1.733 | 1.529–2.172 | Ferroni faster in every run interval |
| `literal_end` | 1.723 | 1.655–1.737 | Ferroni faster in every run interval |
| `literal_absent` | 1.824 | 1.614–1.824 | Ferroni faster in every run interval |
| `ferrolink_markup_scan` | 3.285 | 3.231–3.369 | Ferroni faster in every run interval |
| `ferrolink_attribute_split` | 4.075 | 3.492–4.222 | Ferroni faster in every run interval |

## fancy_regex_seek / steady

Common cases: 23; families: 12. Pair-specific family-weighted ratio: 2.877.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.993 | 0.981–1.072 | inconclusive |
| `uuid_v4` | 1.115 | 0.966–1.157 | inconclusive |
| `ipv4_validation` | 1.080 | 1.077–1.175 | Ferroni faster in every run interval |
| `ipv6_validation` | 1.137 | 1.132–1.183 | Ferroni faster in every run interval |
| `semver_version_parse` | 3.234 | 2.883–3.280 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 2.492 | 2.284–2.503 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.084 | 1.042–1.265 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.514 | 1.510–1.557 | Ferroni faster in every run interval |
| `jinja_float_token` | 3.063 | 2.828–3.174 | Ferroni faster in every run interval |
| `django_email_domain` | 9.609 | 9.430–9.629 | Ferroni faster in every run interval |
| `django_url_regex` | 25.081 | 22.998–25.385 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.960 | 1.912–2.074 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 2.376 | 2.307–2.547 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 3.201 | 3.156–3.320 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 3.851 | 3.593–4.228 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 5.060 | 5.006–5.081 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 2.105 | 2.087–2.140 | Ferroni faster in every run interval |
| `literal_first` | 1.483 | 1.361–1.539 | Ferroni faster in every run interval |
| `literal_middle` | 1.577 | 1.480–1.763 | Ferroni faster in every run interval |
| `literal_end` | 1.379 | 1.294–1.469 | Ferroni faster in every run interval |
| `literal_absent` | 1.371 | 1.213–1.393 | Ferroni faster in every run interval |
| `ferrolink_markup_scan` | 2.961 | 2.959–2.986 | Ferroni faster in every run interval |
| `ferrolink_attribute_split` | 2.153 | 2.117–2.153 | Ferroni faster in every run interval |

## fancy_regex_seek / compile

Common cases: 23; families: 12. Pair-specific family-weighted ratio: 2.215.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.168 | 1.084–1.192 | Ferroni faster in every run interval |
| `uuid_v4` | 1.206 | 1.000–1.282 | inconclusive |
| `ipv4_validation` | 0.842 | 0.779–0.953 | comparator faster in every run interval |
| `ipv6_validation` | 0.856 | 0.840–0.975 | inconclusive |
| `semver_version_parse` | 13.931 | 11.324–14.022 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 8.170 | 7.251–8.933 | Ferroni faster in every run interval |
| `jinja_string_token` | 2.017 | 1.829–2.073 | Ferroni faster in every run interval |
| `jinja_integer_token` | 2.005 | 1.991–2.162 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.272 | 0.261–0.283 | comparator faster in every run interval |
| `django_email_domain` | 7.651 | 7.641–7.717 | Ferroni faster in every run interval |
| `django_url_regex` | 6.234 | 6.017–6.890 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.534 | 1.451–1.715 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.802 | 1.585–1.853 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.174 | 1.163–1.212 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.537 | 0.461–0.596 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.441 | 0.429–0.447 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 3.243 | 3.076–3.339 | Ferroni faster in every run interval |
| `literal_first` | 1.702 | 1.637–1.772 | Ferroni faster in every run interval |
| `literal_middle` | 1.623 | 1.579–2.106 | Ferroni faster in every run interval |
| `literal_end` | 1.783 | 1.737–1.863 | Ferroni faster in every run interval |
| `literal_absent` | 1.749 | 1.601–1.829 | Ferroni faster in every run interval |
| `ferrolink_markup_scan` | 4.449 | 4.203–4.885 | Ferroni faster in every run interval |
| `ferrolink_attribute_split` | 5.592 | 5.068–5.746 | Ferroni faster in every run interval |

## fancy_regex_seek / first_use

Common cases: 23; families: 12. Pair-specific family-weighted ratio: 2.254.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.171 | 1.082–1.183 | Ferroni faster in every run interval |
| `uuid_v4` | 1.115 | 1.098–1.223 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.887 | 0.781–0.988 | inconclusive |
| `ipv6_validation` | 0.930 | 0.866–1.060 | inconclusive |
| `semver_version_parse` | 12.254 | 11.223–13.250 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 7.667 | 7.198–8.723 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.841 | 1.719–2.065 | Ferroni faster in every run interval |
| `jinja_integer_token` | 2.164 | 2.054–2.198 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.288 | 0.257–0.299 | comparator faster in every run interval |
| `django_email_domain` | 7.556 | 7.501–8.166 | Ferroni faster in every run interval |
| `django_url_regex` | 6.715 | 6.686–7.365 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.495 | 1.494–1.529 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.596 | 1.595–1.896 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.424 | 1.390–1.433 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.429 | 0.423–0.480 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.390 | 0.380–0.430 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 3.483 | 3.365–3.538 | Ferroni faster in every run interval |
| `literal_first` | 1.790 | 1.714–1.819 | Ferroni faster in every run interval |
| `literal_middle` | 1.674 | 1.625–2.169 | Ferroni faster in every run interval |
| `literal_end` | 1.890 | 1.729–1.903 | Ferroni faster in every run interval |
| `literal_absent` | 1.793 | 1.614–1.805 | Ferroni faster in every run interval |
| `ferrolink_markup_scan` | 5.208 | 4.978–5.729 | Ferroni faster in every run interval |
| `ferrolink_attribute_split` | 6.355 | 5.368–6.460 | Ferroni faster in every run interval |

## regex / steady

Common cases: 15; families: 7. Pair-specific family-weighted ratio: 1.419.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.912 | 0.894–0.991 | inconclusive |
| `uuid_v4` | 1.035 | 0.909–1.114 | inconclusive |
| `ipv4_validation` | 0.991 | 0.954–1.026 | inconclusive |
| `ipv6_validation` | 1.016 | 0.986–1.041 | inconclusive |
| `semver_version_parse` | 2.744 | 2.574–3.000 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 2.040 | 2.028–2.322 | Ferroni faster in every run interval |
| `jinja_string_token` | 0.838 | 0.760–0.863 | comparator faster in every run interval |
| `jinja_integer_token` | 1.213 | 1.194–1.236 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.881 | 1.747–1.918 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 2.302 | 2.240–2.606 | Ferroni faster in every run interval |
| `literal_first` | 1.109 | 1.093–1.128 | Ferroni faster in every run interval |
| `literal_middle` | 1.176 | 1.114–1.335 | Ferroni faster in every run interval |
| `literal_end` | 1.107 | 1.099–1.117 | Ferroni faster in every run interval |
| `literal_absent` | 1.081 | 0.956–1.083 | inconclusive |
| `ferrolink_attribute_split` | 2.140 | 2.088–2.143 | Ferroni faster in every run interval |

## regex / compile

Common cases: 15; families: 7. Pair-specific family-weighted ratio: 1.808.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.883 | 0.838–0.965 | inconclusive |
| `uuid_v4` | 0.790 | 0.748–0.945 | comparator faster in every run interval |
| `ipv4_validation` | 0.779 | 0.733–0.797 | comparator faster in every run interval |
| `ipv6_validation` | 0.779 | 0.773–0.787 | comparator faster in every run interval |
| `semver_version_parse` | 12.295 | 11.231–14.050 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 7.637 | 7.450–8.729 | Ferroni faster in every run interval |
| `jinja_string_token` | 2.125 | 1.926–2.186 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.790 | 1.684–1.893 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.507 | 1.429–1.623 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.692 | 1.574–1.694 | Ferroni faster in every run interval |
| `literal_first` | 1.721 | 1.702–1.823 | Ferroni faster in every run interval |
| `literal_middle` | 1.534 | 1.423–2.039 | Ferroni faster in every run interval |
| `literal_end` | 1.660 | 1.635–1.910 | Ferroni faster in every run interval |
| `literal_absent` | 1.752 | 1.725–1.781 | Ferroni faster in every run interval |
| `ferrolink_attribute_split` | 1.929 | 1.706–1.932 | Ferroni faster in every run interval |

## regex / first_use

Common cases: 15; families: 7. Pair-specific family-weighted ratio: 1.885.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.878 | 0.873–0.910 | comparator faster in every run interval |
| `uuid_v4` | 0.845 | 0.818–0.937 | comparator faster in every run interval |
| `ipv4_validation` | 0.777 | 0.743–0.860 | comparator faster in every run interval |
| `ipv6_validation` | 0.825 | 0.812–0.825 | comparator faster in every run interval |
| `semver_version_parse` | 12.493 | 11.289–12.993 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 7.322 | 6.752–8.519 | Ferroni faster in every run interval |
| `jinja_string_token` | 2.063 | 1.813–2.064 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.998 | 1.780–2.065 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.545 | 1.420–1.590 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.623 | 1.588–1.690 | Ferroni faster in every run interval |
| `literal_first` | 1.819 | 1.705–1.903 | Ferroni faster in every run interval |
| `literal_middle` | 1.611 | 1.555–2.100 | Ferroni faster in every run interval |
| `literal_end` | 1.703 | 1.679–1.838 | Ferroni faster in every run interval |
| `literal_absent` | 1.769 | 1.766–1.792 | Ferroni faster in every run interval |
| `ferrolink_attribute_split` | 2.318 | 1.933–2.344 | Ferroni faster in every run interval |

Raw samples, estimates, confidence intervals, failures, eligibility reasons, corpus snapshot and execution order are retained beside this report.

Memory, where requested, is fresh-process peak RSS including the binary, runtime, parsed catalog, compilation, input/output and allocator. It is not isolated compiled-pattern memory.
