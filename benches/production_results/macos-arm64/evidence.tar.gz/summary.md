# Production regex comparison

Host: macOS-26.3-arm64-arm-64bit-Mach-O; arm64.

Publication candidate: review host stability, raw samples, coverage and run intervals before publishing.

Ratios are comparator / Ferroni. Compile and first-use times concern one pattern; steady times concern the complete fixture batch.

Each comparison below uses only its explicitly listed common tasks. Families have equal aggregate weight; architectures are never combined.

## Eligibility

| Case | Engine | Status |
| --- | --- | --- |
| `uuid_shape` | rust | eligible |
| `uuid_shape` | rust_erroraware | eligible |
| `uuid_shape` | c | eligible |
| `uuid_shape` | onigmo | eligible |
| `uuid_shape` | pcre2_jit | eligible |
| `uuid_shape` | pcre2 | eligible |
| `uuid_shape` | fancy_regex | eligible |
| `uuid_shape` | fancy_regex_seek | eligible |
| `uuid_shape` | regex | eligible |
| `uuid_v4` | rust | eligible |
| `uuid_v4` | rust_erroraware | eligible |
| `uuid_v4` | c | eligible |
| `uuid_v4` | onigmo | eligible |
| `uuid_v4` | pcre2_jit | eligible |
| `uuid_v4` | pcre2 | eligible |
| `uuid_v4` | fancy_regex | eligible |
| `uuid_v4` | fancy_regex_seek | eligible |
| `uuid_v4` | regex | eligible |
| `ipv4_validation` | rust | eligible |
| `ipv4_validation` | rust_erroraware | eligible |
| `ipv4_validation` | c | eligible |
| `ipv4_validation` | onigmo | eligible |
| `ipv4_validation` | pcre2_jit | eligible |
| `ipv4_validation` | pcre2 | eligible |
| `ipv4_validation` | fancy_regex | eligible |
| `ipv4_validation` | fancy_regex_seek | eligible |
| `ipv4_validation` | regex | eligible |
| `ipv6_validation` | rust | eligible |
| `ipv6_validation` | rust_erroraware | eligible |
| `ipv6_validation` | c | eligible |
| `ipv6_validation` | onigmo | eligible |
| `ipv6_validation` | pcre2_jit | eligible |
| `ipv6_validation` | pcre2 | eligible |
| `ipv6_validation` | fancy_regex | eligible |
| `ipv6_validation` | fancy_regex_seek | eligible |
| `ipv6_validation` | regex | eligible |
| `semver_version_parse` | rust | eligible |
| `semver_version_parse` | rust_erroraware | eligible |
| `semver_version_parse` | c | eligible |
| `semver_version_parse` | onigmo | eligible |
| `semver_version_parse` | pcre2_jit | eligible |
| `semver_version_parse` | pcre2 | eligible |
| `semver_version_parse` | fancy_regex | eligible |
| `semver_version_parse` | fancy_regex_seek | eligible |
| `semver_version_parse` | regex | eligible |
| `semver_hyphen_range_captures` | rust | eligible |
| `semver_hyphen_range_captures` | rust_erroraware | eligible |
| `semver_hyphen_range_captures` | c | eligible |
| `semver_hyphen_range_captures` | onigmo | eligible |
| `semver_hyphen_range_captures` | pcre2_jit | eligible |
| `semver_hyphen_range_captures` | pcre2 | eligible |
| `semver_hyphen_range_captures` | fancy_regex | eligible |
| `semver_hyphen_range_captures` | fancy_regex_seek | eligible |
| `semver_hyphen_range_captures` | regex | eligible |
| `jinja_string_token` | rust | eligible |
| `jinja_string_token` | rust_erroraware | eligible |
| `jinja_string_token` | c | eligible |
| `jinja_string_token` | onigmo | eligible |
| `jinja_string_token` | pcre2_jit | eligible |
| `jinja_string_token` | pcre2 | eligible |
| `jinja_string_token` | fancy_regex | eligible |
| `jinja_string_token` | fancy_regex_seek | eligible |
| `jinja_string_token` | regex | eligible |
| `jinja_integer_token` | rust | eligible |
| `jinja_integer_token` | rust_erroraware | eligible |
| `jinja_integer_token` | c | eligible |
| `jinja_integer_token` | onigmo | eligible |
| `jinja_integer_token` | pcre2_jit | eligible |
| `jinja_integer_token` | pcre2 | eligible |
| `jinja_integer_token` | fancy_regex | eligible |
| `jinja_integer_token` | fancy_regex_seek | eligible |
| `jinja_integer_token` | regex | eligible |
| `jinja_float_token` | rust | eligible |
| `jinja_float_token` | rust_erroraware | eligible |
| `jinja_float_token` | c | eligible |
| `jinja_float_token` | onigmo | eligible |
| `jinja_float_token` | pcre2_jit | eligible |
| `jinja_float_token` | pcre2 | eligible |
| `jinja_float_token` | fancy_regex | eligible |
| `jinja_float_token` | fancy_regex_seek | eligible |
| `jinja_float_token` | regex | syntax_rejected |
| `django_email_local_part` | rust | eligible |
| `django_email_local_part` | rust_erroraware | eligible |
| `django_email_local_part` | c | eligible |
| `django_email_local_part` | onigmo | eligible |
| `django_email_local_part` | pcre2_jit | eligible |
| `django_email_local_part` | pcre2 | eligible |
| `django_email_local_part` | fancy_regex | syntax_rejected |
| `django_email_local_part` | fancy_regex_seek | syntax_rejected |
| `django_email_local_part` | regex | syntax_rejected |
| `django_email_domain` | rust | eligible |
| `django_email_domain` | rust_erroraware | eligible |
| `django_email_domain` | c | eligible |
| `django_email_domain` | onigmo | eligible |
| `django_email_domain` | pcre2_jit | eligible |
| `django_email_domain` | pcre2 | eligible |
| `django_email_domain` | fancy_regex | eligible |
| `django_email_domain` | fancy_regex_seek | eligible |
| `django_email_domain` | regex | syntax_rejected |
| `django_url_regex` | rust | eligible |
| `django_url_regex` | rust_erroraware | eligible |
| `django_url_regex` | c | eligible |
| `django_url_regex` | onigmo | eligible |
| `django_url_regex` | pcre2_jit | eligible |
| `django_url_regex` | pcre2 | eligible |
| `django_url_regex` | fancy_regex | eligible |
| `django_url_regex` | fancy_regex_seek | eligible |
| `django_url_regex` | regex | syntax_rejected |
| `fluent_bit_apache` | rust | eligible |
| `fluent_bit_apache` | rust_erroraware | eligible |
| `fluent_bit_apache` | c | eligible |
| `fluent_bit_apache` | onigmo | eligible |
| `fluent_bit_apache` | pcre2_jit | eligible |
| `fluent_bit_apache` | pcre2 | eligible |
| `fluent_bit_apache` | fancy_regex | eligible |
| `fluent_bit_apache` | fancy_regex_seek | eligible |
| `fluent_bit_apache` | regex | eligible |
| `fluent_bit_nginx` | rust | eligible |
| `fluent_bit_nginx` | rust_erroraware | eligible |
| `fluent_bit_nginx` | c | eligible |
| `fluent_bit_nginx` | onigmo | eligible |
| `fluent_bit_nginx` | pcre2_jit | eligible |
| `fluent_bit_nginx` | pcre2 | eligible |
| `fluent_bit_nginx` | fancy_regex | eligible |
| `fluent_bit_nginx` | fancy_regex_seek | eligible |
| `fluent_bit_nginx` | regex | eligible |
| `rails_underscore_regex_step` | rust | eligible |
| `rails_underscore_regex_step` | rust_erroraware | eligible |
| `rails_underscore_regex_step` | c | eligible |
| `rails_underscore_regex_step` | onigmo | eligible |
| `rails_underscore_regex_step` | pcre2_jit | eligible |
| `rails_underscore_regex_step` | pcre2 | eligible |
| `rails_underscore_regex_step` | fancy_regex | eligible |
| `rails_underscore_regex_step` | fancy_regex_seek | eligible |
| `rails_underscore_regex_step` | regex | syntax_rejected |
| `mastodon_hashtag_regex_step` | rust | eligible |
| `mastodon_hashtag_regex_step` | rust_erroraware | eligible |
| `mastodon_hashtag_regex_step` | c | eligible |
| `mastodon_hashtag_regex_step` | onigmo | eligible |
| `mastodon_hashtag_regex_step` | pcre2_jit | eligible |
| `mastodon_hashtag_regex_step` | pcre2 | eligible |
| `mastodon_hashtag_regex_step` | fancy_regex | semantic_difference |
| `mastodon_hashtag_regex_step` | fancy_regex_seek | semantic_difference |
| `mastodon_hashtag_regex_step` | regex | syntax_rejected |
| `python_markdown_smart_emphasis_re` | rust | eligible |
| `python_markdown_smart_emphasis_re` | rust_erroraware | eligible |
| `python_markdown_smart_emphasis_re` | c | eligible |
| `python_markdown_smart_emphasis_re` | onigmo | eligible |
| `python_markdown_smart_emphasis_re` | pcre2_jit | eligible |
| `python_markdown_smart_emphasis_re` | pcre2 | eligible |
| `python_markdown_smart_emphasis_re` | fancy_regex | eligible |
| `python_markdown_smart_emphasis_re` | fancy_regex_seek | eligible |
| `python_markdown_smart_emphasis_re` | regex | syntax_rejected |
| `python_markdown_smart_strong_em_re` | rust | eligible |
| `python_markdown_smart_strong_em_re` | rust_erroraware | eligible |
| `python_markdown_smart_strong_em_re` | c | eligible |
| `python_markdown_smart_strong_em_re` | onigmo | eligible |
| `python_markdown_smart_strong_em_re` | pcre2_jit | eligible |
| `python_markdown_smart_strong_em_re` | pcre2 | eligible |
| `python_markdown_smart_strong_em_re` | fancy_regex | eligible |
| `python_markdown_smart_strong_em_re` | fancy_regex_seek | eligible |
| `python_markdown_smart_strong_em_re` | regex | syntax_rejected |
| `wordpress_shortcode_captures` | rust | eligible |
| `wordpress_shortcode_captures` | rust_erroraware | eligible |
| `wordpress_shortcode_captures` | c | eligible |
| `wordpress_shortcode_captures` | onigmo | eligible |
| `wordpress_shortcode_captures` | pcre2_jit | eligible |
| `wordpress_shortcode_captures` | pcre2 | eligible |
| `wordpress_shortcode_captures` | fancy_regex | eligible |
| `wordpress_shortcode_captures` | fancy_regex_seek | eligible |
| `wordpress_shortcode_captures` | regex | syntax_rejected |
| `symfony_grapheme_chunks_1` | rust | eligible |
| `symfony_grapheme_chunks_1` | rust_erroraware | eligible |
| `symfony_grapheme_chunks_1` | c | eligible |
| `symfony_grapheme_chunks_1` | onigmo | semantic_difference |
| `symfony_grapheme_chunks_1` | pcre2_jit | eligible |
| `symfony_grapheme_chunks_1` | pcre2 | eligible |
| `symfony_grapheme_chunks_1` | fancy_regex | syntax_rejected |
| `symfony_grapheme_chunks_1` | fancy_regex_seek | syntax_rejected |
| `symfony_grapheme_chunks_1` | regex | syntax_rejected |
| `symfony_grapheme_chunks_2` | rust | eligible |
| `symfony_grapheme_chunks_2` | rust_erroraware | eligible |
| `symfony_grapheme_chunks_2` | c | eligible |
| `symfony_grapheme_chunks_2` | onigmo | eligible |
| `symfony_grapheme_chunks_2` | pcre2_jit | eligible |
| `symfony_grapheme_chunks_2` | pcre2 | eligible |
| `symfony_grapheme_chunks_2` | fancy_regex | syntax_rejected |
| `symfony_grapheme_chunks_2` | fancy_regex_seek | syntax_rejected |
| `symfony_grapheme_chunks_2` | regex | syntax_rejected |
| `literal_first` | rust | eligible |
| `literal_first` | rust_erroraware | eligible |
| `literal_first` | c | eligible |
| `literal_first` | onigmo | eligible |
| `literal_first` | pcre2_jit | eligible |
| `literal_first` | pcre2 | eligible |
| `literal_first` | fancy_regex | eligible |
| `literal_first` | fancy_regex_seek | eligible |
| `literal_first` | regex | eligible |
| `literal_middle` | rust | eligible |
| `literal_middle` | rust_erroraware | eligible |
| `literal_middle` | c | eligible |
| `literal_middle` | onigmo | eligible |
| `literal_middle` | pcre2_jit | eligible |
| `literal_middle` | pcre2 | eligible |
| `literal_middle` | fancy_regex | eligible |
| `literal_middle` | fancy_regex_seek | eligible |
| `literal_middle` | regex | eligible |
| `literal_end` | rust | eligible |
| `literal_end` | rust_erroraware | eligible |
| `literal_end` | c | eligible |
| `literal_end` | onigmo | eligible |
| `literal_end` | pcre2_jit | eligible |
| `literal_end` | pcre2 | eligible |
| `literal_end` | fancy_regex | eligible |
| `literal_end` | fancy_regex_seek | eligible |
| `literal_end` | regex | eligible |
| `literal_absent` | rust | eligible |
| `literal_absent` | rust_erroraware | eligible |
| `literal_absent` | c | eligible |
| `literal_absent` | onigmo | eligible |
| `literal_absent` | pcre2_jit | eligible |
| `literal_absent` | pcre2 | eligible |
| `literal_absent` | fancy_regex | eligible |
| `literal_absent` | fancy_regex_seek | eligible |
| `literal_absent` | regex | eligible |
| `linkify_http_tail` | rust | pending |
| `linkify_http_tail` | rust_erroraware | pending |
| `linkify_http_tail` | c | pending |
| `linkify_http_tail` | onigmo | pending |
| `linkify_http_tail` | pcre2_jit | pending |
| `linkify_http_tail` | pcre2 | pending |
| `linkify_http_tail` | fancy_regex | pending |
| `linkify_http_tail` | fancy_regex_seek | pending |
| `linkify_http_tail` | regex | pending |
| `php_cs_fixer_recursive_types` | rust | pending |
| `php_cs_fixer_recursive_types` | rust_erroraware | pending |
| `php_cs_fixer_recursive_types` | c | pending |
| `php_cs_fixer_recursive_types` | onigmo | pending |
| `php_cs_fixer_recursive_types` | pcre2_jit | pending |
| `php_cs_fixer_recursive_types` | pcre2 | pending |
| `php_cs_fixer_recursive_types` | fancy_regex | pending |
| `php_cs_fixer_recursive_types` | fancy_regex_seek | pending |
| `php_cs_fixer_recursive_types` | regex | pending |

## rust_erroraware / steady

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 1.782.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.621 | 1.615–1.742 | Ferroni faster in every run interval |
| `uuid_v4` | 1.782 | 1.754–1.818 | Ferroni faster in every run interval |
| `ipv4_validation` | 5.510 | 5.387–5.545 | Ferroni faster in every run interval |
| `ipv6_validation` | 12.696 | 11.263–13.544 | Ferroni faster in every run interval |
| `semver_version_parse` | 1.066 | 1.062–1.084 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.042 | 1.015–1.094 | inconclusive |
| `jinja_string_token` | 1.116 | 1.079–1.145 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.138 | 1.048–1.160 | Ferroni faster in every run interval |
| `jinja_float_token` | 1.258 | 1.199–1.272 | Ferroni faster in every run interval |
| `django_email_local_part` | 3.142 | 3.127–3.233 | Ferroni faster in every run interval |
| `django_email_domain` | 7.777 | 7.357–8.056 | Ferroni faster in every run interval |
| `django_url_regex` | 11.381 | 11.234–11.764 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.183 | 1.138–1.194 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.377 | 1.285–1.449 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.013 | 1.000–1.035 | inconclusive |
| `mastodon_hashtag_regex_step` | 1.053 | 1.042–1.059 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 1.113 | 1.089–1.179 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 1.082 | 1.055–1.096 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 1.035 | 1.034–1.058 | inconclusive |
| `symfony_grapheme_chunks_1` | 1.034 | 1.032–1.036 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_2` | 1.008 | 0.954–1.016 | inconclusive |
| `literal_first` | 1.192 | 1.160–1.235 | Ferroni faster in every run interval |
| `literal_middle` | 1.213 | 1.188–1.271 | Ferroni faster in every run interval |
| `literal_end` | 1.158 | 1.146–1.160 | Ferroni faster in every run interval |
| `literal_absent` | 1.144 | 1.084–1.213 | Ferroni faster in every run interval |

## rust_erroraware / compile

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 1.001.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.986 | 0.967–1.003 | inconclusive |
| `uuid_v4` | 1.007 | 1.000–1.069 | inconclusive |
| `ipv4_validation` | 1.008 | 0.955–1.015 | inconclusive |
| `ipv6_validation` | 0.962 | 0.901–1.041 | inconclusive |
| `semver_version_parse` | 0.910 | 0.901–0.981 | inconclusive |
| `semver_hyphen_range_captures` | 0.977 | 0.931–1.066 | inconclusive |
| `jinja_string_token` | 0.997 | 0.982–1.002 | inconclusive |
| `jinja_integer_token` | 0.990 | 0.929–1.023 | inconclusive |
| `jinja_float_token` | 1.023 | 1.000–1.102 | inconclusive |
| `django_email_local_part` | 1.002 | 0.994–1.020 | inconclusive |
| `django_email_domain` | 0.986 | 0.954–1.006 | inconclusive |
| `django_url_regex` | 1.036 | 1.015–1.065 | inconclusive |
| `fluent_bit_apache` | 1.014 | 1.005–1.015 | inconclusive |
| `fluent_bit_nginx` | 1.027 | 0.995–1.128 | inconclusive |
| `rails_underscore_regex_step` | 1.011 | 0.988–1.019 | inconclusive |
| `mastodon_hashtag_regex_step` | 1.003 | 0.973–1.031 | inconclusive |
| `python_markdown_smart_emphasis_re` | 1.029 | 0.985–1.139 | inconclusive |
| `python_markdown_smart_strong_em_re` | 1.020 | 1.006–1.035 | inconclusive |
| `wordpress_shortcode_captures` | 0.989 | 0.902–1.051 | inconclusive |
| `symfony_grapheme_chunks_1` | 1.024 | 0.994–1.083 | inconclusive |
| `symfony_grapheme_chunks_2` | 0.972 | 0.936–1.028 | inconclusive |
| `literal_first` | 1.011 | 0.993–1.024 | inconclusive |
| `literal_middle` | 1.004 | 0.959–1.129 | inconclusive |
| `literal_end` | 0.984 | 0.955–1.004 | inconclusive |
| `literal_absent` | 1.053 | 0.931–1.084 | inconclusive |

## rust_erroraware / first_use

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.956.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.773 | 0.767–0.821 | comparator faster in every run interval |
| `uuid_v4` | 0.781 | 0.774–0.840 | comparator faster in every run interval |
| `ipv4_validation` | 0.930 | 0.903–0.932 | comparator faster in every run interval |
| `ipv6_validation` | 0.958 | 0.949–1.059 | inconclusive |
| `semver_version_parse` | 0.926 | 0.867–0.928 | inconclusive |
| `semver_hyphen_range_captures` | 0.935 | 0.919–0.953 | comparator faster in every run interval |
| `jinja_string_token` | 0.922 | 0.898–0.922 | comparator faster in every run interval |
| `jinja_integer_token` | 0.975 | 0.963–0.997 | inconclusive |
| `jinja_float_token` | 0.965 | 0.942–0.967 | inconclusive |
| `django_email_local_part` | 0.949 | 0.926–0.964 | inconclusive |
| `django_email_domain` | 0.994 | 0.989–1.001 | inconclusive |
| `django_url_regex` | 1.015 | 1.004–1.118 | inconclusive |
| `fluent_bit_apache` | 0.931 | 0.881–0.933 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.935 | 0.877–1.066 | inconclusive |
| `rails_underscore_regex_step` | 1.007 | 0.901–1.015 | inconclusive |
| `mastodon_hashtag_regex_step` | 1.011 | 1.007–1.042 | inconclusive |
| `python_markdown_smart_emphasis_re` | 0.860 | 0.853–0.984 | inconclusive |
| `python_markdown_smart_strong_em_re` | 0.870 | 0.813–0.876 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 1.000 | 0.890–1.082 | inconclusive |
| `symfony_grapheme_chunks_1` | 1.069 | 1.041–1.115 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.983 | 0.951–0.985 | inconclusive |
| `literal_first` | 0.988 | 0.980–0.991 | inconclusive |
| `literal_middle` | 1.017 | 1.011–1.186 | inconclusive |
| `literal_end` | 1.025 | 0.965–1.027 | inconclusive |
| `literal_absent` | 1.063 | 0.923–1.116 | inconclusive |

## c / steady

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 3.641.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 5.082 | 5.040–5.202 | Ferroni faster in every run interval |
| `uuid_v4` | 3.989 | 3.853–4.070 | Ferroni faster in every run interval |
| `ipv4_validation` | 8.415 | 8.329–8.463 | Ferroni faster in every run interval |
| `ipv6_validation` | 15.051 | 14.516–16.044 | Ferroni faster in every run interval |
| `semver_version_parse` | 1.795 | 1.723–1.943 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.293 | 1.285–1.356 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.822 | 1.710–1.825 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.406 | 1.356–1.486 | Ferroni faster in every run interval |
| `jinja_float_token` | 1.286 | 1.245–1.298 | Ferroni faster in every run interval |
| `django_email_local_part` | 9.305 | 8.283–9.354 | Ferroni faster in every run interval |
| `django_email_domain` | 38.191 | 37.544–40.210 | Ferroni faster in every run interval |
| `django_url_regex` | 21.891 | 21.490–22.725 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 2.242 | 2.135–2.291 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 2.499 | 2.419–2.669 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.311 | 1.309–1.340 | Ferroni faster in every run interval |
| `mastodon_hashtag_regex_step` | 2.273 | 2.259–2.310 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 2.912 | 2.846–2.986 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 2.760 | 2.686–2.805 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 1.520 | 1.508–1.651 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_1` | 1.882 | 1.788–1.899 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_2` | 1.943 | 1.814–1.976 | Ferroni faster in every run interval |
| `literal_first` | 10.197 | 10.118–10.373 | Ferroni faster in every run interval |
| `literal_middle` | 10.836 | 10.617–11.998 | Ferroni faster in every run interval |
| `literal_end` | 12.089 | 11.940–12.268 | Ferroni faster in every run interval |
| `literal_absent` | 1.981 | 1.916–2.008 | Ferroni faster in every run interval |

## c / compile

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.380.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 4.283 | 4.252–4.299 | Ferroni faster in every run interval |
| `uuid_v4` | 4.895 | 4.638–4.897 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.271 | 0.254–0.271 | comparator faster in every run interval |
| `ipv6_validation` | 0.269 | 0.253–0.291 | comparator faster in every run interval |
| `semver_version_parse` | 0.257 | 0.253–0.279 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.262 | 0.256–0.266 | comparator faster in every run interval |
| `jinja_string_token` | 0.123 | 0.123–0.124 | comparator faster in every run interval |
| `jinja_integer_token` | 2.285 | 2.192–2.399 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.652 | 0.615–0.770 | comparator faster in every run interval |
| `django_email_local_part` | 2.376 | 2.305–2.444 | Ferroni faster in every run interval |
| `django_email_domain` | 0.207 | 0.196–0.210 | comparator faster in every run interval |
| `django_url_regex` | 0.378 | 0.372–0.379 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.147 | 0.141–0.158 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.152 | 0.147–0.194 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.401 | 0.389–0.402 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 1.419 | 1.348–1.509 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.161 | 0.156–0.169 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.125 | 0.124–0.127 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.222 | 0.208–0.246 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.082 | 0.082–0.086 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.080 | 0.068–0.085 | comparator faster in every run interval |
| `literal_first` | 0.339 | 0.324–0.344 | comparator faster in every run interval |
| `literal_middle` | 0.330 | 0.311–0.371 | comparator faster in every run interval |
| `literal_end` | 0.323 | 0.304–0.340 | comparator faster in every run interval |
| `literal_absent` | 0.324 | 0.324–0.340 | comparator faster in every run interval |

## c / first_use

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.412.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 3.439 | 3.330–3.597 | Ferroni faster in every run interval |
| `uuid_v4` | 3.812 | 3.695–3.916 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.258 | 0.256–0.258 | comparator faster in every run interval |
| `ipv6_validation` | 0.268 | 0.265–0.289 | comparator faster in every run interval |
| `semver_version_parse` | 0.254 | 0.248–0.275 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.247 | 0.239–0.259 | comparator faster in every run interval |
| `jinja_string_token` | 0.125 | 0.125–0.127 | comparator faster in every run interval |
| `jinja_integer_token` | 2.210 | 2.174–2.311 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.640 | 0.612–0.642 | comparator faster in every run interval |
| `django_email_local_part` | 2.201 | 2.195–2.334 | Ferroni faster in every run interval |
| `django_email_domain` | 0.208 | 0.208–0.214 | comparator faster in every run interval |
| `django_url_regex` | 0.387 | 0.374–0.411 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.144 | 0.143–0.157 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.163 | 0.147–0.184 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.403 | 0.378–0.429 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 1.477 | 1.340–1.595 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.164 | 0.154–0.166 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.121 | 0.119–0.123 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.232 | 0.202–0.254 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.213 | 0.202–0.227 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.151 | 0.126–0.158 | comparator faster in every run interval |
| `literal_first` | 0.551 | 0.542–0.560 | comparator faster in every run interval |
| `literal_middle` | 0.562 | 0.528–0.596 | comparator faster in every run interval |
| `literal_end` | 0.600 | 0.592–0.600 | comparator faster in every run interval |
| `literal_absent` | 0.393 | 0.388–0.453 | comparator faster in every run interval |

## onigmo / steady

Common cases: 24; families: 13. Pair-specific family-weighted ratio: 3.882.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 5.891 | 5.738–5.965 | Ferroni faster in every run interval |
| `uuid_v4` | 6.185 | 6.135–6.337 | Ferroni faster in every run interval |
| `ipv4_validation` | 6.487 | 6.286–6.550 | Ferroni faster in every run interval |
| `ipv6_validation` | 21.141 | 18.572–22.652 | Ferroni faster in every run interval |
| `semver_version_parse` | 1.925 | 1.890–2.084 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.263 | 1.210–1.266 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.112 | 1.072–1.204 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.610 | 1.502–1.664 | Ferroni faster in every run interval |
| `jinja_float_token` | 2.558 | 2.447–2.639 | Ferroni faster in every run interval |
| `django_email_local_part` | 5.030 | 5.017–5.385 | Ferroni faster in every run interval |
| `django_email_domain` | 71.707 | 68.956–74.827 | Ferroni faster in every run interval |
| `django_url_regex` | 56.594 | 53.417–60.356 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 2.340 | 2.338–2.363 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 3.113 | 3.063–3.149 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.062 | 1.053–1.116 | Ferroni faster in every run interval |
| `mastodon_hashtag_regex_step` | 2.189 | 2.104–2.203 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 2.489 | 2.305–2.527 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 2.535 | 2.521–2.607 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 1.278 | 1.276–1.364 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_2` | 3.276 | 3.183–3.375 | Ferroni faster in every run interval |
| `literal_first` | 2.852 | 2.734–2.915 | Ferroni faster in every run interval |
| `literal_middle` | 3.691 | 3.669–3.922 | Ferroni faster in every run interval |
| `literal_end` | 5.434 | 5.392–5.683 | Ferroni faster in every run interval |
| `literal_absent` | 2.608 | 2.512–2.631 | Ferroni faster in every run interval |

## onigmo / compile

Common cases: 24; families: 13. Pair-specific family-weighted ratio: 0.500.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 4.098 | 3.831–4.104 | Ferroni faster in every run interval |
| `uuid_v4` | 4.574 | 4.557–4.653 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.255 | 0.241–0.257 | comparator faster in every run interval |
| `ipv6_validation` | 0.258 | 0.239–0.283 | comparator faster in every run interval |
| `semver_version_parse` | 0.246 | 0.237–0.268 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.283 | 0.275–0.293 | comparator faster in every run interval |
| `jinja_string_token` | 0.106 | 0.106–0.110 | comparator faster in every run interval |
| `jinja_integer_token` | 2.007 | 1.973–2.111 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.693 | 0.691–0.702 | comparator faster in every run interval |
| `django_email_local_part` | 2.344 | 2.277–2.430 | Ferroni faster in every run interval |
| `django_email_domain` | 0.128 | 0.120–0.132 | comparator faster in every run interval |
| `django_url_regex` | 0.292 | 0.282–0.305 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.150 | 0.146–0.160 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.167 | 0.154–0.184 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.423 | 0.402–0.428 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 1.459 | 1.436–1.534 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.106 | 0.097–0.111 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.092 | 0.090–0.097 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.213 | 0.194–0.226 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 8.791 | 8.750–9.451 | Ferroni faster in every run interval |
| `literal_first` | 0.284 | 0.273–0.297 | comparator faster in every run interval |
| `literal_middle` | 0.270 | 0.265–0.296 | comparator faster in every run interval |
| `literal_end` | 0.273 | 0.263–0.277 | comparator faster in every run interval |
| `literal_absent` | 0.271 | 0.263–0.273 | comparator faster in every run interval |

## onigmo / first_use

Common cases: 24; families: 13. Pair-specific family-weighted ratio: 0.496.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 3.138 | 3.012–3.347 | Ferroni faster in every run interval |
| `uuid_v4` | 3.722 | 3.577–3.732 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.240 | 0.229–0.240 | comparator faster in every run interval |
| `ipv6_validation` | 0.252 | 0.243–0.274 | comparator faster in every run interval |
| `semver_version_parse` | 0.241 | 0.227–0.242 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.264 | 0.258–0.287 | comparator faster in every run interval |
| `jinja_string_token` | 0.105 | 0.105–0.106 | comparator faster in every run interval |
| `jinja_integer_token` | 1.903 | 1.839–2.341 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.667 | 0.662–0.680 | comparator faster in every run interval |
| `django_email_local_part` | 2.170 | 2.116–2.310 | Ferroni faster in every run interval |
| `django_email_domain` | 0.134 | 0.127–0.134 | comparator faster in every run interval |
| `django_url_regex` | 0.292 | 0.287–0.323 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.147 | 0.145–0.155 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.173 | 0.163–0.197 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.428 | 0.388–0.438 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 1.460 | 1.442–1.558 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.107 | 0.102–0.109 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.091 | 0.089–0.093 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.219 | 0.187–0.223 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 8.402 | 8.282–9.171 | Ferroni faster in every run interval |
| `literal_first` | 0.340 | 0.336–0.369 | comparator faster in every run interval |
| `literal_middle` | 0.349 | 0.322–0.376 | comparator faster in every run interval |
| `literal_end` | 0.387 | 0.384–0.388 | comparator faster in every run interval |
| `literal_absent` | 0.335 | 0.331–0.361 | comparator faster in every run interval |

## pcre2_jit / steady

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.756.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.889 | 0.881–0.895 | comparator faster in every run interval |
| `uuid_v4` | 0.962 | 0.920–1.040 | inconclusive |
| `ipv4_validation` | 1.407 | 1.362–1.416 | Ferroni faster in every run interval |
| `ipv6_validation` | 3.739 | 3.406–4.300 | Ferroni faster in every run interval |
| `semver_version_parse` | 0.545 | 0.522–0.546 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.564 | 0.556–0.566 | comparator faster in every run interval |
| `jinja_string_token` | 0.566 | 0.562–0.627 | comparator faster in every run interval |
| `jinja_integer_token` | 0.548 | 0.539–0.578 | comparator faster in every run interval |
| `jinja_float_token` | 0.613 | 0.596–0.620 | comparator faster in every run interval |
| `django_email_local_part` | 1.626 | 1.578–1.649 | Ferroni faster in every run interval |
| `django_email_domain` | 0.847 | 0.813–0.861 | comparator faster in every run interval |
| `django_url_regex` | 1.320 | 1.257–1.324 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 0.464 | 0.456–0.472 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.739 | 0.703–0.812 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.385 | 0.373–0.398 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.368 | 0.367–0.371 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.657 | 0.647–0.688 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.569 | 0.562–0.571 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.477 | 0.465–0.502 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.609 | 0.571–0.649 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.573 | 0.489–0.613 | comparator faster in every run interval |
| `literal_first` | 1.814 | 1.762–1.857 | Ferroni faster in every run interval |
| `literal_middle` | 1.886 | 1.764–1.914 | Ferroni faster in every run interval |
| `literal_end` | 1.750 | 1.730–1.757 | Ferroni faster in every run interval |
| `literal_absent` | 1.584 | 1.478–1.693 | Ferroni faster in every run interval |

## pcre2_jit / compile

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.306.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.262 | 0.249–0.287 | comparator faster in every run interval |
| `uuid_v4` | 0.274 | 0.270–0.283 | comparator faster in every run interval |
| `ipv4_validation` | 0.281 | 0.277–0.294 | comparator faster in every run interval |
| `ipv6_validation` | 0.328 | 0.282–0.380 | comparator faster in every run interval |
| `semver_version_parse` | 0.408 | 0.388–0.435 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.405 | 0.374–0.407 | comparator faster in every run interval |
| `jinja_string_token` | 0.274 | 0.267–0.304 | comparator faster in every run interval |
| `jinja_integer_token` | 0.273 | 0.272–0.299 | comparator faster in every run interval |
| `jinja_float_token` | 0.221 | 0.220–0.223 | comparator faster in every run interval |
| `django_email_local_part` | 0.413 | 0.394–0.417 | comparator faster in every run interval |
| `django_email_domain` | 0.053 | 0.052–0.054 | comparator faster in every run interval |
| `django_url_regex` | 0.063 | 0.062–0.067 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.276 | 0.274–0.291 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.279 | 0.275–0.305 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.672 | 0.663–0.675 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.159 | 0.157–0.162 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.444 | 0.432–0.452 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.354 | 0.353–0.371 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.410 | 0.401–0.459 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.233 | 0.218–0.233 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.205 | 0.178–0.217 | comparator faster in every run interval |
| `literal_first` | 2.426 | 2.352–2.714 | Ferroni faster in every run interval |
| `literal_middle` | 2.410 | 2.339–2.570 | Ferroni faster in every run interval |
| `literal_end` | 2.436 | 2.390–2.566 | Ferroni faster in every run interval |
| `literal_absent` | 2.637 | 2.399–2.689 | Ferroni faster in every run interval |

## pcre2_jit / first_use

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.340.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.210 | 0.191–0.214 | comparator faster in every run interval |
| `uuid_v4` | 0.224 | 0.218–0.236 | comparator faster in every run interval |
| `ipv4_validation` | 0.311 | 0.310–0.337 | comparator faster in every run interval |
| `ipv6_validation` | 0.328 | 0.318–0.378 | comparator faster in every run interval |
| `semver_version_parse` | 0.432 | 0.403–0.479 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.387 | 0.364–0.404 | comparator faster in every run interval |
| `jinja_string_token` | 0.323 | 0.302–0.346 | comparator faster in every run interval |
| `jinja_integer_token` | 0.341 | 0.307–0.349 | comparator faster in every run interval |
| `jinja_float_token` | 0.244 | 0.240–0.251 | comparator faster in every run interval |
| `django_email_local_part` | 0.435 | 0.406–0.449 | comparator faster in every run interval |
| `django_email_domain` | 0.056 | 0.054–0.057 | comparator faster in every run interval |
| `django_url_regex` | 0.065 | 0.061–0.071 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.290 | 0.279–0.307 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.326 | 0.283–0.326 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.848 | 0.765–0.859 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.177 | 0.176–0.186 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.503 | 0.496–0.511 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.387 | 0.363–0.393 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.455 | 0.430–0.508 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.465 | 0.411–0.475 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.378 | 0.328–0.418 | comparator faster in every run interval |
| `literal_first` | 2.538 | 2.453–2.652 | Ferroni faster in every run interval |
| `literal_middle` | 2.389 | 2.266–2.591 | Ferroni faster in every run interval |
| `literal_end` | 2.492 | 2.470–2.534 | Ferroni faster in every run interval |
| `literal_absent` | 2.414 | 2.348–2.655 | Ferroni faster in every run interval |

## pcre2 / steady

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 2.131.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.803 | 1.740–1.815 | Ferroni faster in every run interval |
| `uuid_v4` | 1.931 | 1.877–2.147 | Ferroni faster in every run interval |
| `ipv4_validation` | 9.945 | 9.289–11.108 | Ferroni faster in every run interval |
| `ipv6_validation` | 20.925 | 20.831–24.122 | Ferroni faster in every run interval |
| `semver_version_parse` | 1.490 | 1.392–1.490 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.810 | 1.760–1.860 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.204 | 1.193–1.314 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.729 | 1.682–1.872 | Ferroni faster in every run interval |
| `jinja_float_token` | 1.809 | 1.652–1.820 | Ferroni faster in every run interval |
| `django_email_local_part` | 5.508 | 5.403–5.924 | Ferroni faster in every run interval |
| `django_email_domain` | 3.088 | 2.976–3.275 | Ferroni faster in every run interval |
| `django_url_regex` | 3.468 | 3.134–3.556 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.522 | 1.348–1.552 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.781 | 1.604–1.886 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.209 | 1.208–1.231 | Ferroni faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.815 | 0.789–0.817 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 3.378 | 3.325–3.472 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 3.960 | 3.923–4.007 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 1.287 | 1.265–1.305 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.897 | 0.835–0.919 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.787 | 0.680–0.863 | comparator faster in every run interval |
| `literal_first` | 3.758 | 3.571–3.823 | Ferroni faster in every run interval |
| `literal_middle` | 3.663 | 3.610–3.671 | Ferroni faster in every run interval |
| `literal_end` | 3.352 | 3.351–3.396 | Ferroni faster in every run interval |
| `literal_absent` | 1.652 | 1.648–1.668 | Ferroni faster in every run interval |

## pcre2 / compile

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.090.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.101 | 0.096–0.102 | comparator faster in every run interval |
| `uuid_v4` | 0.114 | 0.110–0.116 | comparator faster in every run interval |
| `ipv4_validation` | 0.092 | 0.087–0.103 | comparator faster in every run interval |
| `ipv6_validation` | 0.104 | 0.100–0.110 | comparator faster in every run interval |
| `semver_version_parse` | 0.112 | 0.109–0.115 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.110 | 0.100–0.111 | comparator faster in every run interval |
| `jinja_string_token` | 0.058 | 0.058–0.065 | comparator faster in every run interval |
| `jinja_integer_token` | 0.082 | 0.077–0.089 | comparator faster in every run interval |
| `jinja_float_token` | 0.048 | 0.046–0.049 | comparator faster in every run interval |
| `django_email_local_part` | 0.207 | 0.205–0.230 | comparator faster in every run interval |
| `django_email_domain` | 0.049 | 0.048–0.051 | comparator faster in every run interval |
| `django_url_regex` | 0.051 | 0.049–0.055 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.063 | 0.062–0.063 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.066 | 0.065–0.068 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.204 | 0.191–0.205 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.082 | 0.080–0.083 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.079 | 0.078–0.082 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.067 | 0.066–0.067 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.113 | 0.108–0.127 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.033 | 0.032–0.033 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.028 | 0.027–0.034 | comparator faster in every run interval |
| `literal_first` | 0.252 | 0.238–0.258 | comparator faster in every run interval |
| `literal_middle` | 0.247 | 0.236–0.254 | comparator faster in every run interval |
| `literal_end` | 0.240 | 0.235–0.246 | comparator faster in every run interval |
| `literal_absent` | 0.243 | 0.240–0.245 | comparator faster in every run interval |

## pcre2 / first_use

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.108.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.085 | 0.080–0.090 | comparator faster in every run interval |
| `uuid_v4` | 0.096 | 0.094–0.104 | comparator faster in every run interval |
| `ipv4_validation` | 0.094 | 0.087–0.108 | comparator faster in every run interval |
| `ipv6_validation` | 0.110 | 0.105–0.120 | comparator faster in every run interval |
| `semver_version_parse` | 0.113 | 0.111–0.113 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.105 | 0.102–0.115 | comparator faster in every run interval |
| `jinja_string_token` | 0.066 | 0.064–0.071 | comparator faster in every run interval |
| `jinja_integer_token` | 0.096 | 0.086–0.098 | comparator faster in every run interval |
| `jinja_float_token` | 0.050 | 0.049–0.051 | comparator faster in every run interval |
| `django_email_local_part` | 0.209 | 0.190–0.221 | comparator faster in every run interval |
| `django_email_domain` | 0.050 | 0.050–0.050 | comparator faster in every run interval |
| `django_url_regex` | 0.051 | 0.051–0.056 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.071 | 0.066–0.080 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.076 | 0.074–0.078 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.225 | 0.201–0.243 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.085 | 0.084–0.086 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.106 | 0.103–0.110 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.086 | 0.086–0.088 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.122 | 0.111–0.136 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.113 | 0.104–0.114 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.080 | 0.069–0.085 | comparator faster in every run interval |
| `literal_first` | 0.497 | 0.492–0.521 | comparator faster in every run interval |
| `literal_middle` | 0.484 | 0.467–0.515 | comparator faster in every run interval |
| `literal_end` | 0.506 | 0.487–0.506 | comparator faster in every run interval |
| `literal_absent` | 0.391 | 0.379–0.403 | comparator faster in every run interval |

## fancy_regex / steady

Common cases: 21; families: 11. Pair-specific family-weighted ratio: 2.884.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.989 | 0.941–1.001 | inconclusive |
| `uuid_v4` | 1.060 | 1.020–1.147 | inconclusive |
| `ipv4_validation` | 1.105 | 1.069–1.259 | Ferroni faster in every run interval |
| `ipv6_validation` | 1.170 | 1.099–1.241 | Ferroni faster in every run interval |
| `semver_version_parse` | 2.819 | 2.802–2.839 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 2.291 | 2.267–2.361 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.158 | 1.149–1.225 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.561 | 1.456–1.692 | Ferroni faster in every run interval |
| `jinja_float_token` | 2.951 | 2.667–3.106 | Ferroni faster in every run interval |
| `django_email_domain` | 8.883 | 8.178–9.513 | Ferroni faster in every run interval |
| `django_url_regex` | 25.560 | 24.002–25.880 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 2.069 | 1.733–2.218 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 2.545 | 2.275–2.577 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 3.249 | 3.192–3.312 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 3.519 | 3.437–3.689 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 4.938 | 4.806–4.986 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 2.262 | 2.156–2.367 | Ferroni faster in every run interval |
| `literal_first` | 1.401 | 1.399–1.427 | Ferroni faster in every run interval |
| `literal_middle` | 1.445 | 1.427–1.500 | Ferroni faster in every run interval |
| `literal_end` | 1.371 | 1.371–1.394 | Ferroni faster in every run interval |
| `literal_absent` | 1.345 | 1.328–1.399 | Ferroni faster in every run interval |

## fancy_regex / compile

Common cases: 21; families: 11. Pair-specific family-weighted ratio: 1.860.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.108 | 1.099–1.176 | Ferroni faster in every run interval |
| `uuid_v4` | 1.169 | 1.118–1.262 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.847 | 0.792–1.033 | inconclusive |
| `ipv6_validation` | 0.861 | 0.857–0.914 | comparator faster in every run interval |
| `semver_version_parse` | 11.554 | 11.550–11.766 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 8.097 | 7.424–8.513 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.885 | 1.876–2.014 | Ferroni faster in every run interval |
| `jinja_integer_token` | 2.061 | 1.956–2.266 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.286 | 0.285–0.295 | comparator faster in every run interval |
| `django_email_domain` | 6.882 | 6.839–7.416 | Ferroni faster in every run interval |
| `django_url_regex` | 6.820 | 6.350–7.775 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.678 | 1.583–1.711 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.651 | 1.632–1.712 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.205 | 1.170–1.230 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.520 | 0.508–0.531 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.439 | 0.423–0.447 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 1.217 | 1.103–1.330 | Ferroni faster in every run interval |
| `literal_first` | 1.797 | 1.667–1.967 | Ferroni faster in every run interval |
| `literal_middle` | 1.720 | 1.656–1.777 | Ferroni faster in every run interval |
| `literal_end` | 1.710 | 1.644–1.714 | Ferroni faster in every run interval |
| `literal_absent` | 1.705 | 1.640–1.930 | Ferroni faster in every run interval |

## fancy_regex / first_use

Common cases: 21; families: 11. Pair-specific family-weighted ratio: 1.900.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.096 | 1.071–1.102 | Ferroni faster in every run interval |
| `uuid_v4` | 1.177 | 1.150–1.262 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.886 | 0.839–1.079 | inconclusive |
| `ipv6_validation` | 0.907 | 0.873–0.927 | comparator faster in every run interval |
| `semver_version_parse` | 11.358 | 11.249–11.725 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 7.617 | 7.241–8.596 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.805 | 1.800–2.138 | Ferroni faster in every run interval |
| `jinja_integer_token` | 2.213 | 2.071–2.330 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.279 | 0.276–0.285 | comparator faster in every run interval |
| `django_email_domain` | 7.253 | 6.998–7.608 | Ferroni faster in every run interval |
| `django_url_regex` | 7.042 | 6.369–8.268 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.596 | 1.549–1.622 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.694 | 1.658–1.694 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.424 | 1.315–1.457 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.459 | 0.454–0.488 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.396 | 0.376–0.423 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 1.276 | 1.143–1.378 | Ferroni faster in every run interval |
| `literal_first` | 1.989 | 1.835–2.019 | Ferroni faster in every run interval |
| `literal_middle` | 1.807 | 1.642–1.835 | Ferroni faster in every run interval |
| `literal_end` | 1.700 | 1.675–1.830 | Ferroni faster in every run interval |
| `literal_absent` | 1.823 | 1.595–1.839 | Ferroni faster in every run interval |

## fancy_regex_seek / steady

Common cases: 21; families: 11. Pair-specific family-weighted ratio: 2.850.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.985 | 0.978–0.997 | inconclusive |
| `uuid_v4` | 1.064 | 1.044–1.087 | inconclusive |
| `ipv4_validation` | 1.106 | 1.102–1.133 | Ferroni faster in every run interval |
| `ipv6_validation` | 1.177 | 1.159–1.218 | Ferroni faster in every run interval |
| `semver_version_parse` | 2.852 | 2.841–2.916 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 2.448 | 2.344–2.579 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.188 | 1.173–1.288 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.535 | 1.497–1.663 | Ferroni faster in every run interval |
| `jinja_float_token` | 2.910 | 2.796–2.948 | Ferroni faster in every run interval |
| `django_email_domain` | 8.985 | 8.345–9.454 | Ferroni faster in every run interval |
| `django_url_regex` | 23.056 | 23.042–25.431 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 2.077 | 2.050–2.193 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 2.527 | 2.248–2.602 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 3.228 | 3.189–3.267 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 3.494 | 3.488–3.670 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 4.972 | 4.931–4.994 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 2.096 | 2.064–2.184 | Ferroni faster in every run interval |
| `literal_first` | 1.393 | 1.376–1.408 | Ferroni faster in every run interval |
| `literal_middle` | 1.446 | 1.444–1.517 | Ferroni faster in every run interval |
| `literal_end` | 1.419 | 1.377–1.422 | Ferroni faster in every run interval |
| `literal_absent` | 1.348 | 1.248–1.368 | Ferroni faster in every run interval |

## fancy_regex_seek / compile

Common cases: 21; families: 11. Pair-specific family-weighted ratio: 2.045.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.111 | 1.088–1.122 | Ferroni faster in every run interval |
| `uuid_v4` | 1.137 | 1.113–1.142 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.842 | 0.838–0.913 | comparator faster in every run interval |
| `ipv6_validation` | 0.869 | 0.837–0.931 | comparator faster in every run interval |
| `semver_version_parse` | 11.706 | 11.546–11.884 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 8.085 | 7.321–8.610 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.914 | 1.869–2.196 | Ferroni faster in every run interval |
| `jinja_integer_token` | 2.091 | 2.038–2.142 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.295 | 0.292–0.318 | comparator faster in every run interval |
| `django_email_domain` | 7.230 | 7.004–7.526 | Ferroni faster in every run interval |
| `django_url_regex` | 6.852 | 6.346–7.066 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.688 | 1.653–1.737 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.645 | 1.605–1.686 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.209 | 1.201–1.227 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.517 | 0.502–0.522 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.442 | 0.424–0.470 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 3.158 | 2.947–3.316 | Ferroni faster in every run interval |
| `literal_first` | 1.767 | 1.659–1.926 | Ferroni faster in every run interval |
| `literal_middle` | 1.785 | 1.752–1.788 | Ferroni faster in every run interval |
| `literal_end` | 1.750 | 1.663–1.787 | Ferroni faster in every run interval |
| `literal_absent` | 1.736 | 1.651–1.819 | Ferroni faster in every run interval |

## fancy_regex_seek / first_use

Common cases: 21; families: 11. Pair-specific family-weighted ratio: 2.083.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.104 | 1.052–1.195 | Ferroni faster in every run interval |
| `uuid_v4` | 1.137 | 1.126–1.218 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.871 | 0.851–0.882 | comparator faster in every run interval |
| `ipv6_validation` | 0.904 | 0.869–0.905 | comparator faster in every run interval |
| `semver_version_parse` | 11.247 | 10.677–11.365 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 7.383 | 7.166–8.515 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.802 | 1.792–2.179 | Ferroni faster in every run interval |
| `jinja_integer_token` | 2.127 | 2.076–2.470 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.282 | 0.280–0.285 | comparator faster in every run interval |
| `django_email_domain` | 7.684 | 6.999–7.724 | Ferroni faster in every run interval |
| `django_url_regex` | 6.855 | 6.329–8.231 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.711 | 1.589–1.721 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.619 | 1.611–1.778 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.438 | 1.325–1.457 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.460 | 0.449–0.478 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.402 | 0.395–0.408 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 3.591 | 2.996–3.661 | Ferroni faster in every run interval |
| `literal_first` | 1.796 | 1.765–1.871 | Ferroni faster in every run interval |
| `literal_middle` | 1.727 | 1.724–1.804 | Ferroni faster in every run interval |
| `literal_end` | 1.774 | 1.735–1.775 | Ferroni faster in every run interval |
| `literal_absent` | 1.760 | 1.657–1.760 | Ferroni faster in every run interval |

## regex / steady

Common cases: 14; families: 6. Pair-specific family-weighted ratio: 1.319.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.912 | 0.907–0.933 | comparator faster in every run interval |
| `uuid_v4` | 0.988 | 0.975–0.989 | inconclusive |
| `ipv4_validation` | 0.962 | 0.955–0.964 | comparator faster in every run interval |
| `ipv6_validation` | 1.036 | 0.985–1.084 | inconclusive |
| `semver_version_parse` | 2.470 | 2.452–2.601 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 2.225 | 2.218–2.275 | Ferroni faster in every run interval |
| `jinja_string_token` | 0.822 | 0.793–0.878 | comparator faster in every run interval |
| `jinja_integer_token` | 1.221 | 1.096–1.288 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.853 | 1.790–1.904 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 2.435 | 2.206–2.441 | Ferroni faster in every run interval |
| `literal_first` | 1.122 | 1.105–1.186 | Ferroni faster in every run interval |
| `literal_middle` | 1.141 | 1.130–1.195 | Ferroni faster in every run interval |
| `literal_end` | 1.094 | 1.091–1.173 | Ferroni faster in every run interval |
| `literal_absent` | 1.105 | 1.072–1.126 | Ferroni faster in every run interval |

## regex / compile

Common cases: 14; families: 6. Pair-specific family-weighted ratio: 1.769.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.819 | 0.784–0.840 | comparator faster in every run interval |
| `uuid_v4` | 0.794 | 0.777–0.828 | comparator faster in every run interval |
| `ipv4_validation` | 0.746 | 0.736–0.755 | comparator faster in every run interval |
| `ipv6_validation` | 0.777 | 0.750–0.841 | comparator faster in every run interval |
| `semver_version_parse` | 11.554 | 11.469–11.830 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 8.337 | 6.952–8.341 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.869 | 1.863–2.072 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.828 | 1.802–1.901 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.556 | 1.549–1.651 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.618 | 1.607–1.652 | Ferroni faster in every run interval |
| `literal_first` | 1.721 | 1.671–1.994 | Ferroni faster in every run interval |
| `literal_middle` | 1.704 | 1.698–1.745 | Ferroni faster in every run interval |
| `literal_end` | 1.805 | 1.676–1.806 | Ferroni faster in every run interval |
| `literal_absent` | 1.699 | 1.557–1.708 | Ferroni faster in every run interval |

## regex / first_use

Common cases: 14; families: 6. Pair-specific family-weighted ratio: 1.792.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.919 | 0.876–0.944 | comparator faster in every run interval |
| `uuid_v4` | 0.904 | 0.899–0.911 | comparator faster in every run interval |
| `ipv4_validation` | 0.789 | 0.782–0.792 | comparator faster in every run interval |
| `ipv6_validation` | 0.826 | 0.774–0.828 | comparator faster in every run interval |
| `semver_version_parse` | 10.914 | 10.895–10.915 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 7.224 | 6.966–8.143 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.793 | 1.775–1.940 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.853 | 1.830–2.122 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.547 | 1.511–1.694 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.633 | 1.587–1.652 | Ferroni faster in every run interval |
| `literal_first` | 1.797 | 1.735–1.855 | Ferroni faster in every run interval |
| `literal_middle` | 1.697 | 1.569–1.774 | Ferroni faster in every run interval |
| `literal_end` | 1.757 | 1.707–1.874 | Ferroni faster in every run interval |
| `literal_absent` | 1.736 | 1.641–1.760 | Ferroni faster in every run interval |

Raw samples, estimates, confidence intervals, failures, eligibility reasons, corpus snapshot and execution order are retained beside this report.

Memory, where requested, is fresh-process peak RSS including the binary, runtime, parsed catalog, compilation, input/output and allocator. It is not isolated compiled-pattern memory.
