# Production regex comparison

Host: macOS-26.3-arm64-arm-64bit-Mach-O; arm64.

Publication candidate: review host stability, raw samples, coverage and run intervals before publishing.

Ratios are comparator / Ferroni. Compile and first-use times concern one pattern; steady times concern the complete fixture batch.

Each comparison below uses only its explicitly listed common tasks. Families have equal aggregate weight; architectures are never combined.

## Eligibility

| Case | Engine | Status |
| --- | --- | --- |
| `uuid_shape` | rust | eligible |
| `uuid_shape` | rust_erroraware | eligible |
| `uuid_shape` | c | eligible |
| `uuid_shape` | onigmo | eligible |
| `uuid_shape` | pcre2_jit | eligible |
| `uuid_shape` | pcre2 | eligible |
| `uuid_shape` | fancy_regex | eligible |
| `uuid_shape` | fancy_regex_seek | eligible |
| `uuid_shape` | regex | eligible |
| `uuid_v4` | rust | eligible |
| `uuid_v4` | rust_erroraware | eligible |
| `uuid_v4` | c | eligible |
| `uuid_v4` | onigmo | eligible |
| `uuid_v4` | pcre2_jit | eligible |
| `uuid_v4` | pcre2 | eligible |
| `uuid_v4` | fancy_regex | eligible |
| `uuid_v4` | fancy_regex_seek | eligible |
| `uuid_v4` | regex | eligible |
| `ipv4_validation` | rust | eligible |
| `ipv4_validation` | rust_erroraware | eligible |
| `ipv4_validation` | c | eligible |
| `ipv4_validation` | onigmo | eligible |
| `ipv4_validation` | pcre2_jit | eligible |
| `ipv4_validation` | pcre2 | eligible |
| `ipv4_validation` | fancy_regex | eligible |
| `ipv4_validation` | fancy_regex_seek | eligible |
| `ipv4_validation` | regex | eligible |
| `ipv6_validation` | rust | eligible |
| `ipv6_validation` | rust_erroraware | eligible |
| `ipv6_validation` | c | eligible |
| `ipv6_validation` | onigmo | eligible |
| `ipv6_validation` | pcre2_jit | eligible |
| `ipv6_validation` | pcre2 | eligible |
| `ipv6_validation` | fancy_regex | eligible |
| `ipv6_validation` | fancy_regex_seek | eligible |
| `ipv6_validation` | regex | eligible |
| `semver_version_parse` | rust | eligible |
| `semver_version_parse` | rust_erroraware | eligible |
| `semver_version_parse` | c | eligible |
| `semver_version_parse` | onigmo | eligible |
| `semver_version_parse` | pcre2_jit | eligible |
| `semver_version_parse` | pcre2 | eligible |
| `semver_version_parse` | fancy_regex | eligible |
| `semver_version_parse` | fancy_regex_seek | eligible |
| `semver_version_parse` | regex | eligible |
| `semver_hyphen_range_captures` | rust | eligible |
| `semver_hyphen_range_captures` | rust_erroraware | eligible |
| `semver_hyphen_range_captures` | c | eligible |
| `semver_hyphen_range_captures` | onigmo | eligible |
| `semver_hyphen_range_captures` | pcre2_jit | eligible |
| `semver_hyphen_range_captures` | pcre2 | eligible |
| `semver_hyphen_range_captures` | fancy_regex | eligible |
| `semver_hyphen_range_captures` | fancy_regex_seek | eligible |
| `semver_hyphen_range_captures` | regex | eligible |
| `jinja_string_token` | rust | eligible |
| `jinja_string_token` | rust_erroraware | eligible |
| `jinja_string_token` | c | eligible |
| `jinja_string_token` | onigmo | eligible |
| `jinja_string_token` | pcre2_jit | eligible |
| `jinja_string_token` | pcre2 | eligible |
| `jinja_string_token` | fancy_regex | eligible |
| `jinja_string_token` | fancy_regex_seek | eligible |
| `jinja_string_token` | regex | eligible |
| `jinja_integer_token` | rust | eligible |
| `jinja_integer_token` | rust_erroraware | eligible |
| `jinja_integer_token` | c | eligible |
| `jinja_integer_token` | onigmo | eligible |
| `jinja_integer_token` | pcre2_jit | eligible |
| `jinja_integer_token` | pcre2 | eligible |
| `jinja_integer_token` | fancy_regex | eligible |
| `jinja_integer_token` | fancy_regex_seek | eligible |
| `jinja_integer_token` | regex | eligible |
| `jinja_float_token` | rust | eligible |
| `jinja_float_token` | rust_erroraware | eligible |
| `jinja_float_token` | c | eligible |
| `jinja_float_token` | onigmo | eligible |
| `jinja_float_token` | pcre2_jit | eligible |
| `jinja_float_token` | pcre2 | eligible |
| `jinja_float_token` | fancy_regex | eligible |
| `jinja_float_token` | fancy_regex_seek | eligible |
| `jinja_float_token` | regex | syntax_rejected |
| `django_email_local_part` | rust | eligible |
| `django_email_local_part` | rust_erroraware | eligible |
| `django_email_local_part` | c | eligible |
| `django_email_local_part` | onigmo | eligible |
| `django_email_local_part` | pcre2_jit | eligible |
| `django_email_local_part` | pcre2 | eligible |
| `django_email_local_part` | fancy_regex | syntax_rejected |
| `django_email_local_part` | fancy_regex_seek | syntax_rejected |
| `django_email_local_part` | regex | syntax_rejected |
| `django_email_domain` | rust | eligible |
| `django_email_domain` | rust_erroraware | eligible |
| `django_email_domain` | c | eligible |
| `django_email_domain` | onigmo | eligible |
| `django_email_domain` | pcre2_jit | eligible |
| `django_email_domain` | pcre2 | eligible |
| `django_email_domain` | fancy_regex | eligible |
| `django_email_domain` | fancy_regex_seek | eligible |
| `django_email_domain` | regex | syntax_rejected |
| `django_url_regex` | rust | eligible |
| `django_url_regex` | rust_erroraware | eligible |
| `django_url_regex` | c | eligible |
| `django_url_regex` | onigmo | eligible |
| `django_url_regex` | pcre2_jit | eligible |
| `django_url_regex` | pcre2 | eligible |
| `django_url_regex` | fancy_regex | eligible |
| `django_url_regex` | fancy_regex_seek | eligible |
| `django_url_regex` | regex | syntax_rejected |
| `fluent_bit_apache` | rust | eligible |
| `fluent_bit_apache` | rust_erroraware | eligible |
| `fluent_bit_apache` | c | eligible |
| `fluent_bit_apache` | onigmo | eligible |
| `fluent_bit_apache` | pcre2_jit | eligible |
| `fluent_bit_apache` | pcre2 | eligible |
| `fluent_bit_apache` | fancy_regex | eligible |
| `fluent_bit_apache` | fancy_regex_seek | eligible |
| `fluent_bit_apache` | regex | eligible |
| `fluent_bit_nginx` | rust | eligible |
| `fluent_bit_nginx` | rust_erroraware | eligible |
| `fluent_bit_nginx` | c | eligible |
| `fluent_bit_nginx` | onigmo | eligible |
| `fluent_bit_nginx` | pcre2_jit | eligible |
| `fluent_bit_nginx` | pcre2 | eligible |
| `fluent_bit_nginx` | fancy_regex | eligible |
| `fluent_bit_nginx` | fancy_regex_seek | eligible |
| `fluent_bit_nginx` | regex | eligible |
| `rails_underscore_regex_step` | rust | eligible |
| `rails_underscore_regex_step` | rust_erroraware | eligible |
| `rails_underscore_regex_step` | c | eligible |
| `rails_underscore_regex_step` | onigmo | eligible |
| `rails_underscore_regex_step` | pcre2_jit | eligible |
| `rails_underscore_regex_step` | pcre2 | eligible |
| `rails_underscore_regex_step` | fancy_regex | eligible |
| `rails_underscore_regex_step` | fancy_regex_seek | eligible |
| `rails_underscore_regex_step` | regex | syntax_rejected |
| `mastodon_hashtag_regex_step` | rust | eligible |
| `mastodon_hashtag_regex_step` | rust_erroraware | eligible |
| `mastodon_hashtag_regex_step` | c | eligible |
| `mastodon_hashtag_regex_step` | onigmo | eligible |
| `mastodon_hashtag_regex_step` | pcre2_jit | eligible |
| `mastodon_hashtag_regex_step` | pcre2 | eligible |
| `mastodon_hashtag_regex_step` | fancy_regex | semantic_difference |
| `mastodon_hashtag_regex_step` | fancy_regex_seek | semantic_difference |
| `mastodon_hashtag_regex_step` | regex | syntax_rejected |
| `python_markdown_smart_emphasis_re` | rust | eligible |
| `python_markdown_smart_emphasis_re` | rust_erroraware | eligible |
| `python_markdown_smart_emphasis_re` | c | eligible |
| `python_markdown_smart_emphasis_re` | onigmo | eligible |
| `python_markdown_smart_emphasis_re` | pcre2_jit | eligible |
| `python_markdown_smart_emphasis_re` | pcre2 | eligible |
| `python_markdown_smart_emphasis_re` | fancy_regex | eligible |
| `python_markdown_smart_emphasis_re` | fancy_regex_seek | eligible |
| `python_markdown_smart_emphasis_re` | regex | syntax_rejected |
| `python_markdown_smart_strong_em_re` | rust | eligible |
| `python_markdown_smart_strong_em_re` | rust_erroraware | eligible |
| `python_markdown_smart_strong_em_re` | c | eligible |
| `python_markdown_smart_strong_em_re` | onigmo | eligible |
| `python_markdown_smart_strong_em_re` | pcre2_jit | eligible |
| `python_markdown_smart_strong_em_re` | pcre2 | eligible |
| `python_markdown_smart_strong_em_re` | fancy_regex | eligible |
| `python_markdown_smart_strong_em_re` | fancy_regex_seek | eligible |
| `python_markdown_smart_strong_em_re` | regex | syntax_rejected |
| `wordpress_shortcode_captures` | rust | eligible |
| `wordpress_shortcode_captures` | rust_erroraware | eligible |
| `wordpress_shortcode_captures` | c | eligible |
| `wordpress_shortcode_captures` | onigmo | eligible |
| `wordpress_shortcode_captures` | pcre2_jit | eligible |
| `wordpress_shortcode_captures` | pcre2 | eligible |
| `wordpress_shortcode_captures` | fancy_regex | eligible |
| `wordpress_shortcode_captures` | fancy_regex_seek | eligible |
| `wordpress_shortcode_captures` | regex | syntax_rejected |
| `symfony_grapheme_chunks_1` | rust | eligible |
| `symfony_grapheme_chunks_1` | rust_erroraware | eligible |
| `symfony_grapheme_chunks_1` | c | eligible |
| `symfony_grapheme_chunks_1` | onigmo | semantic_difference |
| `symfony_grapheme_chunks_1` | pcre2_jit | eligible |
| `symfony_grapheme_chunks_1` | pcre2 | eligible |
| `symfony_grapheme_chunks_1` | fancy_regex | syntax_rejected |
| `symfony_grapheme_chunks_1` | fancy_regex_seek | syntax_rejected |
| `symfony_grapheme_chunks_1` | regex | syntax_rejected |
| `symfony_grapheme_chunks_2` | rust | eligible |
| `symfony_grapheme_chunks_2` | rust_erroraware | eligible |
| `symfony_grapheme_chunks_2` | c | eligible |
| `symfony_grapheme_chunks_2` | onigmo | eligible |
| `symfony_grapheme_chunks_2` | pcre2_jit | eligible |
| `symfony_grapheme_chunks_2` | pcre2 | eligible |
| `symfony_grapheme_chunks_2` | fancy_regex | syntax_rejected |
| `symfony_grapheme_chunks_2` | fancy_regex_seek | syntax_rejected |
| `symfony_grapheme_chunks_2` | regex | syntax_rejected |
| `literal_first` | rust | eligible |
| `literal_first` | rust_erroraware | eligible |
| `literal_first` | c | eligible |
| `literal_first` | onigmo | eligible |
| `literal_first` | pcre2_jit | eligible |
| `literal_first` | pcre2 | eligible |
| `literal_first` | fancy_regex | eligible |
| `literal_first` | fancy_regex_seek | eligible |
| `literal_first` | regex | eligible |
| `literal_middle` | rust | eligible |
| `literal_middle` | rust_erroraware | eligible |
| `literal_middle` | c | eligible |
| `literal_middle` | onigmo | eligible |
| `literal_middle` | pcre2_jit | eligible |
| `literal_middle` | pcre2 | eligible |
| `literal_middle` | fancy_regex | eligible |
| `literal_middle` | fancy_regex_seek | eligible |
| `literal_middle` | regex | eligible |
| `literal_end` | rust | eligible |
| `literal_end` | rust_erroraware | eligible |
| `literal_end` | c | eligible |
| `literal_end` | onigmo | eligible |
| `literal_end` | pcre2_jit | eligible |
| `literal_end` | pcre2 | eligible |
| `literal_end` | fancy_regex | eligible |
| `literal_end` | fancy_regex_seek | eligible |
| `literal_end` | regex | eligible |
| `literal_absent` | rust | eligible |
| `literal_absent` | rust_erroraware | eligible |
| `literal_absent` | c | eligible |
| `literal_absent` | onigmo | eligible |
| `literal_absent` | pcre2_jit | eligible |
| `literal_absent` | pcre2 | eligible |
| `literal_absent` | fancy_regex | eligible |
| `literal_absent` | fancy_regex_seek | eligible |
| `literal_absent` | regex | eligible |
| `linkify_http_tail` | rust | pending |
| `linkify_http_tail` | rust_erroraware | pending |
| `linkify_http_tail` | c | pending |
| `linkify_http_tail` | onigmo | pending |
| `linkify_http_tail` | pcre2_jit | pending |
| `linkify_http_tail` | pcre2 | pending |
| `linkify_http_tail` | fancy_regex | pending |
| `linkify_http_tail` | fancy_regex_seek | pending |
| `linkify_http_tail` | regex | pending |
| `php_cs_fixer_recursive_types` | rust | pending |
| `php_cs_fixer_recursive_types` | rust_erroraware | pending |
| `php_cs_fixer_recursive_types` | c | pending |
| `php_cs_fixer_recursive_types` | onigmo | pending |
| `php_cs_fixer_recursive_types` | pcre2_jit | pending |
| `php_cs_fixer_recursive_types` | pcre2 | pending |
| `php_cs_fixer_recursive_types` | fancy_regex | pending |
| `php_cs_fixer_recursive_types` | fancy_regex_seek | pending |
| `php_cs_fixer_recursive_types` | regex | pending |

## rust_erroraware / steady

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 1.764.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.620 | 1.593–1.622 | Ferroni faster in every run interval |
| `uuid_v4` | 1.752 | 1.694–1.921 | Ferroni faster in every run interval |
| `ipv4_validation` | 5.612 | 5.383–5.722 | Ferroni faster in every run interval |
| `ipv6_validation` | 13.708 | 12.600–13.763 | Ferroni faster in every run interval |
| `semver_version_parse` | 1.010 | 0.979–1.034 | inconclusive |
| `semver_hyphen_range_captures` | 1.012 | 1.002–1.053 | inconclusive |
| `jinja_string_token` | 1.030 | 0.963–1.045 | inconclusive |
| `jinja_integer_token` | 1.027 | 0.920–1.038 | inconclusive |
| `jinja_float_token` | 1.220 | 1.183–1.242 | Ferroni faster in every run interval |
| `django_email_local_part` | 3.202 | 3.151–3.274 | Ferroni faster in every run interval |
| `django_email_domain` | 7.003 | 6.724–7.511 | Ferroni faster in every run interval |
| `django_url_regex` | 11.062 | 10.132–11.152 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.221 | 1.217–1.238 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.353 | 1.312–1.439 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.009 | 0.959–1.080 | inconclusive |
| `mastodon_hashtag_regex_step` | 1.061 | 1.022–1.070 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 1.048 | 1.030–1.093 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 1.015 | 1.011–1.049 | inconclusive |
| `wordpress_shortcode_captures` | 1.056 | 0.997–1.060 | inconclusive |
| `symfony_grapheme_chunks_1` | 0.997 | 0.934–1.057 | inconclusive |
| `symfony_grapheme_chunks_2` | 1.022 | 1.000–1.059 | inconclusive |
| `literal_first` | 1.309 | 1.306–1.362 | Ferroni faster in every run interval |
| `literal_middle` | 1.334 | 1.276–1.383 | Ferroni faster in every run interval |
| `literal_end` | 1.173 | 1.117–1.333 | Ferroni faster in every run interval |
| `literal_absent` | 1.175 | 1.111–1.275 | Ferroni faster in every run interval |

## rust_erroraware / compile

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 1.001.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.999 | 0.995–1.022 | inconclusive |
| `uuid_v4` | 1.002 | 0.983–1.148 | inconclusive |
| `ipv4_validation` | 1.003 | 0.933–1.033 | inconclusive |
| `ipv6_validation` | 0.994 | 0.981–1.009 | inconclusive |
| `semver_version_parse` | 1.022 | 1.000–1.026 | inconclusive |
| `semver_hyphen_range_captures` | 1.039 | 0.927–1.040 | inconclusive |
| `jinja_string_token` | 0.997 | 0.952–1.043 | inconclusive |
| `jinja_integer_token` | 1.003 | 0.997–1.019 | inconclusive |
| `jinja_float_token` | 1.025 | 1.019–1.043 | inconclusive |
| `django_email_local_part` | 1.030 | 1.026–1.071 | inconclusive |
| `django_email_domain` | 1.008 | 0.919–1.046 | inconclusive |
| `django_url_regex` | 0.964 | 0.905–1.025 | inconclusive |
| `fluent_bit_apache` | 0.985 | 0.975–1.038 | inconclusive |
| `fluent_bit_nginx` | 0.990 | 0.864–1.004 | inconclusive |
| `rails_underscore_regex_step` | 0.974 | 0.951–1.030 | inconclusive |
| `mastodon_hashtag_regex_step` | 0.978 | 0.938–1.034 | inconclusive |
| `python_markdown_smart_emphasis_re` | 1.084 | 1.076–1.113 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 1.007 | 0.983–1.034 | inconclusive |
| `wordpress_shortcode_captures` | 0.982 | 0.944–0.998 | inconclusive |
| `symfony_grapheme_chunks_1` | 1.005 | 0.866–1.042 | inconclusive |
| `symfony_grapheme_chunks_2` | 1.042 | 0.934–1.043 | inconclusive |
| `literal_first` | 0.997 | 0.965–1.020 | inconclusive |
| `literal_middle` | 1.078 | 0.976–1.127 | inconclusive |
| `literal_end` | 0.926 | 0.923–1.105 | inconclusive |
| `literal_absent` | 1.050 | 0.910–1.208 | inconclusive |

## rust_erroraware / first_use

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.954.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.772 | 0.771–0.777 | comparator faster in every run interval |
| `uuid_v4` | 0.816 | 0.769–0.922 | comparator faster in every run interval |
| `ipv4_validation` | 0.945 | 0.913–0.969 | inconclusive |
| `ipv6_validation` | 0.977 | 0.957–1.020 | inconclusive |
| `semver_version_parse` | 0.950 | 0.927–0.954 | inconclusive |
| `semver_hyphen_range_captures` | 0.915 | 0.901–1.009 | inconclusive |
| `jinja_string_token` | 0.926 | 0.892–0.956 | comparator faster in every run interval |
| `jinja_integer_token` | 0.964 | 0.903–1.015 | inconclusive |
| `jinja_float_token` | 1.001 | 0.962–1.082 | inconclusive |
| `django_email_local_part` | 0.973 | 0.925–1.143 | inconclusive |
| `django_email_domain` | 1.006 | 0.983–1.093 | inconclusive |
| `django_url_regex` | 0.959 | 0.921–1.004 | inconclusive |
| `fluent_bit_apache` | 0.899 | 0.860–0.957 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.828 | 0.771–0.862 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 1.063 | 0.987–1.068 | inconclusive |
| `mastodon_hashtag_regex_step` | 1.023 | 0.932–1.054 | inconclusive |
| `python_markdown_smart_emphasis_re` | 0.929 | 0.845–0.931 | inconclusive |
| `python_markdown_smart_strong_em_re` | 0.885 | 0.884–0.894 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 1.009 | 0.946–1.017 | inconclusive |
| `symfony_grapheme_chunks_1` | 1.001 | 0.896–1.014 | inconclusive |
| `symfony_grapheme_chunks_2` | 0.935 | 0.923–0.952 | comparator faster in every run interval |
| `literal_first` | 0.986 | 0.967–1.026 | inconclusive |
| `literal_middle` | 1.102 | 0.954–1.112 | inconclusive |
| `literal_end` | 0.945 | 0.936–0.967 | inconclusive |
| `literal_absent` | 0.980 | 0.929–1.124 | inconclusive |

## c / steady

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 3.538.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 5.315 | 5.295–5.458 | Ferroni faster in every run interval |
| `uuid_v4` | 4.017 | 3.846–4.555 | Ferroni faster in every run interval |
| `ipv4_validation` | 8.496 | 8.463–8.508 | Ferroni faster in every run interval |
| `ipv6_validation` | 15.461 | 14.721–17.090 | Ferroni faster in every run interval |
| `semver_version_parse` | 1.791 | 1.707–1.839 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.268 | 1.224–1.293 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.617 | 1.447–1.645 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.205 | 1.161–1.281 | Ferroni faster in every run interval |
| `jinja_float_token` | 1.190 | 1.190–1.239 | Ferroni faster in every run interval |
| `django_email_local_part` | 8.731 | 7.593–9.191 | Ferroni faster in every run interval |
| `django_email_domain` | 37.674 | 37.104–37.918 | Ferroni faster in every run interval |
| `django_url_regex` | 20.091 | 18.880–21.291 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 2.193 | 2.153–2.365 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 2.463 | 2.189–2.598 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.295 | 1.202–1.340 | Ferroni faster in every run interval |
| `mastodon_hashtag_regex_step` | 2.147 | 1.990–2.365 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 2.771 | 2.518–2.805 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 2.614 | 2.549–2.671 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 1.411 | 1.334–1.474 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_1` | 1.604 | 1.442–1.774 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_2` | 1.802 | 1.683–1.837 | Ferroni faster in every run interval |
| `literal_first` | 12.820 | 12.514–12.918 | Ferroni faster in every run interval |
| `literal_middle` | 13.880 | 12.885–14.385 | Ferroni faster in every run interval |
| `literal_end` | 13.467 | 13.251–17.298 | Ferroni faster in every run interval |
| `literal_absent` | 2.166 | 2.144–2.476 | Ferroni faster in every run interval |

## c / compile

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.369.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 4.388 | 4.289–4.434 | Ferroni faster in every run interval |
| `uuid_v4` | 4.663 | 4.636–5.339 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.267 | 0.242–0.280 | comparator faster in every run interval |
| `ipv6_validation` | 0.272 | 0.266–0.286 | comparator faster in every run interval |
| `semver_version_parse` | 0.270 | 0.262–0.275 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.253 | 0.238–0.257 | comparator faster in every run interval |
| `jinja_string_token` | 0.124 | 0.123–0.131 | comparator faster in every run interval |
| `jinja_integer_token` | 2.338 | 2.308–2.518 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.639 | 0.634–0.683 | comparator faster in every run interval |
| `django_email_local_part` | 2.130 | 2.082–2.382 | Ferroni faster in every run interval |
| `django_email_domain` | 0.208 | 0.207–0.229 | comparator faster in every run interval |
| `django_url_regex` | 0.345 | 0.323–0.370 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.140 | 0.139–0.157 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.149 | 0.127–0.154 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.392 | 0.323–0.400 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 1.374 | 1.295–1.416 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.159 | 0.154–0.166 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.117 | 0.114–0.122 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.210 | 0.208–0.236 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.079 | 0.064–0.086 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.075 | 0.064–0.077 | comparator faster in every run interval |
| `literal_first` | 0.317 | 0.310–0.325 | comparator faster in every run interval |
| `literal_middle` | 0.335 | 0.335–0.356 | comparator faster in every run interval |
| `literal_end` | 0.312 | 0.297–0.408 | comparator faster in every run interval |
| `literal_absent` | 0.344 | 0.297–0.345 | comparator faster in every run interval |

## c / first_use

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.404.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 3.409 | 3.353–3.644 | Ferroni faster in every run interval |
| `uuid_v4` | 3.801 | 3.653–4.142 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.256 | 0.226–0.263 | comparator faster in every run interval |
| `ipv6_validation` | 0.267 | 0.267–0.274 | comparator faster in every run interval |
| `semver_version_parse` | 0.265 | 0.264–0.282 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.242 | 0.230–0.255 | comparator faster in every run interval |
| `jinja_string_token` | 0.128 | 0.123–0.133 | comparator faster in every run interval |
| `jinja_integer_token` | 2.152 | 2.033–2.181 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.638 | 0.594–0.680 | comparator faster in every run interval |
| `django_email_local_part` | 2.173 | 2.065–2.302 | Ferroni faster in every run interval |
| `django_email_domain` | 0.212 | 0.211–0.235 | comparator faster in every run interval |
| `django_url_regex` | 0.344 | 0.331–0.370 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.145 | 0.142–0.152 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.151 | 0.137–0.154 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.437 | 0.350–0.439 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 1.392 | 1.325–1.458 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.162 | 0.157–0.179 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.127 | 0.113–0.131 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.225 | 0.205–0.238 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.204 | 0.168–0.208 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.138 | 0.129–0.148 | comparator faster in every run interval |
| `literal_first` | 0.542 | 0.523–0.546 | comparator faster in every run interval |
| `literal_middle` | 0.563 | 0.548–0.581 | comparator faster in every run interval |
| `literal_end` | 0.587 | 0.574–0.720 | comparator faster in every run interval |
| `literal_absent` | 0.366 | 0.346–0.372 | comparator faster in every run interval |

## onigmo / steady

Common cases: 24; families: 13. Pair-specific family-weighted ratio: 3.817.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 6.040 | 5.885–6.072 | Ferroni faster in every run interval |
| `uuid_v4` | 6.116 | 5.982–6.509 | Ferroni faster in every run interval |
| `ipv4_validation` | 6.361 | 6.143–6.471 | Ferroni faster in every run interval |
| `ipv6_validation` | 22.069 | 20.543–23.614 | Ferroni faster in every run interval |
| `semver_version_parse` | 1.937 | 1.905–2.005 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.163 | 1.158–1.209 | Ferroni faster in every run interval |
| `jinja_string_token` | 0.985 | 0.978–1.071 | inconclusive |
| `jinja_integer_token` | 1.416 | 1.343–1.474 | Ferroni faster in every run interval |
| `jinja_float_token` | 2.357 | 2.354–2.367 | Ferroni faster in every run interval |
| `django_email_local_part` | 4.996 | 4.881–5.219 | Ferroni faster in every run interval |
| `django_email_domain` | 70.431 | 66.469–77.548 | Ferroni faster in every run interval |
| `django_url_regex` | 51.862 | 49.129–56.138 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 2.406 | 2.264–2.520 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 2.976 | 2.873–3.264 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.087 | 1.082–1.110 | Ferroni faster in every run interval |
| `mastodon_hashtag_regex_step` | 2.115 | 1.994–2.336 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 2.289 | 2.185–2.314 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 2.442 | 2.313–2.495 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 1.213 | 1.146–1.213 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_2` | 3.226 | 3.219–3.307 | Ferroni faster in every run interval |
| `literal_first` | 3.417 | 3.348–3.529 | Ferroni faster in every run interval |
| `literal_middle` | 4.421 | 4.249–4.773 | Ferroni faster in every run interval |
| `literal_end` | 6.278 | 6.159–7.913 | Ferroni faster in every run interval |
| `literal_absent` | 2.986 | 2.859–3.232 | Ferroni faster in every run interval |

## onigmo / compile

Common cases: 24; families: 13. Pair-specific family-weighted ratio: 0.494.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 4.176 | 3.902–4.197 | Ferroni faster in every run interval |
| `uuid_v4` | 4.717 | 4.526–5.442 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.252 | 0.226–0.262 | comparator faster in every run interval |
| `ipv6_validation` | 0.261 | 0.256–0.270 | comparator faster in every run interval |
| `semver_version_parse` | 0.263 | 0.250–0.279 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.279 | 0.259–0.298 | comparator faster in every run interval |
| `jinja_string_token` | 0.108 | 0.106–0.121 | comparator faster in every run interval |
| `jinja_integer_token` | 2.017 | 2.015–2.038 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.733 | 0.694–0.783 | comparator faster in every run interval |
| `django_email_local_part` | 2.333 | 2.287–2.402 | Ferroni faster in every run interval |
| `django_email_domain` | 0.137 | 0.113–0.144 | comparator faster in every run interval |
| `django_url_regex` | 0.273 | 0.252–0.299 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.150 | 0.141–0.154 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.149 | 0.143–0.157 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.401 | 0.381–0.418 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 1.524 | 1.451–1.581 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.109 | 0.105–0.114 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.086 | 0.075–0.089 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.201 | 0.198–0.220 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 8.408 | 8.365–8.511 | Ferroni faster in every run interval |
| `literal_first` | 0.260 | 0.259–0.277 | comparator faster in every run interval |
| `literal_middle` | 0.282 | 0.266–0.292 | comparator faster in every run interval |
| `literal_end` | 0.258 | 0.251–0.338 | comparator faster in every run interval |
| `literal_absent` | 0.281 | 0.263–0.299 | comparator faster in every run interval |

## onigmo / first_use

Common cases: 24; families: 13. Pair-specific family-weighted ratio: 0.501.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 3.204 | 3.111–3.266 | Ferroni faster in every run interval |
| `uuid_v4` | 3.667 | 3.615–3.942 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.239 | 0.215–0.240 | comparator faster in every run interval |
| `ipv6_validation` | 0.260 | 0.260–0.278 | comparator faster in every run interval |
| `semver_version_parse` | 0.251 | 0.247–0.258 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.269 | 0.248–0.273 | comparator faster in every run interval |
| `jinja_string_token` | 0.111 | 0.104–0.117 | comparator faster in every run interval |
| `jinja_integer_token` | 1.980 | 1.908–2.001 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.691 | 0.667–0.693 | comparator faster in every run interval |
| `django_email_local_part` | 2.334 | 2.145–2.432 | Ferroni faster in every run interval |
| `django_email_domain` | 0.142 | 0.115–0.149 | comparator faster in every run interval |
| `django_url_regex` | 0.272 | 0.263–0.293 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.152 | 0.148–0.152 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.163 | 0.156–0.166 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.427 | 0.354–0.443 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 1.592 | 1.358–1.656 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.110 | 0.106–0.115 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.093 | 0.074–0.095 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.225 | 0.189–0.232 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 8.177 | 8.136–8.887 | Ferroni faster in every run interval |
| `literal_first` | 0.317 | 0.314–0.344 | comparator faster in every run interval |
| `literal_middle` | 0.344 | 0.331–0.345 | comparator faster in every run interval |
| `literal_end` | 0.365 | 0.352–0.461 | comparator faster in every run interval |
| `literal_absent` | 0.347 | 0.342–0.349 | comparator faster in every run interval |

## pcre2_jit / steady

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.737.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.902 | 0.840–0.976 | comparator faster in every run interval |
| `uuid_v4` | 0.978 | 0.958–1.099 | inconclusive |
| `ipv4_validation` | 1.390 | 1.314–1.451 | Ferroni faster in every run interval |
| `ipv6_validation` | 4.107 | 3.789–4.109 | Ferroni faster in every run interval |
| `semver_version_parse` | 0.517 | 0.503–0.533 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.529 | 0.494–0.531 | comparator faster in every run interval |
| `jinja_string_token` | 0.509 | 0.491–0.523 | comparator faster in every run interval |
| `jinja_integer_token` | 0.471 | 0.462–0.536 | comparator faster in every run interval |
| `jinja_float_token` | 0.591 | 0.576–0.598 | comparator faster in every run interval |
| `django_email_local_part` | 1.643 | 1.542–1.734 | Ferroni faster in every run interval |
| `django_email_domain` | 0.791 | 0.722–0.955 | comparator faster in every run interval |
| `django_url_regex` | 1.172 | 1.144–1.266 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 0.490 | 0.450–0.495 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.759 | 0.729–0.801 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.385 | 0.372–0.403 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.356 | 0.322–0.370 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.656 | 0.552–0.729 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.529 | 0.527–0.533 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.433 | 0.422–0.443 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.524 | 0.506–0.572 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.529 | 0.527–0.557 | comparator faster in every run interval |
| `literal_first` | 2.235 | 2.058–2.250 | Ferroni faster in every run interval |
| `literal_middle` | 2.159 | 2.120–2.194 | Ferroni faster in every run interval |
| `literal_end` | 1.930 | 1.849–2.242 | Ferroni faster in every run interval |
| `literal_absent` | 1.899 | 1.740–1.909 | Ferroni faster in every run interval |

## pcre2_jit / compile

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.302.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.269 | 0.252–0.294 | comparator faster in every run interval |
| `uuid_v4` | 0.279 | 0.257–0.296 | comparator faster in every run interval |
| `ipv4_validation` | 0.301 | 0.261–0.303 | comparator faster in every run interval |
| `ipv6_validation` | 0.341 | 0.328–0.355 | comparator faster in every run interval |
| `semver_version_parse` | 0.401 | 0.386–0.404 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.354 | 0.346–0.367 | comparator faster in every run interval |
| `jinja_string_token` | 0.281 | 0.273–0.281 | comparator faster in every run interval |
| `jinja_integer_token` | 0.268 | 0.251–0.306 | comparator faster in every run interval |
| `jinja_float_token` | 0.230 | 0.220–0.242 | comparator faster in every run interval |
| `django_email_local_part` | 0.413 | 0.387–0.418 | comparator faster in every run interval |
| `django_email_domain` | 0.059 | 0.049–0.065 | comparator faster in every run interval |
| `django_url_regex` | 0.057 | 0.055–0.063 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.275 | 0.261–0.301 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.277 | 0.265–0.281 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.661 | 0.640–0.713 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.155 | 0.154–0.157 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.453 | 0.451–0.482 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.348 | 0.333–0.352 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.398 | 0.384–0.412 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.221 | 0.179–0.221 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.200 | 0.200–0.210 | comparator faster in every run interval |
| `literal_first` | 2.337 | 2.311–2.369 | Ferroni faster in every run interval |
| `literal_middle` | 2.426 | 2.172–2.545 | Ferroni faster in every run interval |
| `literal_end` | 2.270 | 2.247–2.967 | Ferroni faster in every run interval |
| `literal_absent` | 2.910 | 2.725–2.913 | Ferroni faster in every run interval |

## pcre2_jit / first_use

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.343.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.216 | 0.208–0.229 | comparator faster in every run interval |
| `uuid_v4` | 0.219 | 0.219–0.244 | comparator faster in every run interval |
| `ipv4_validation` | 0.309 | 0.306–0.335 | comparator faster in every run interval |
| `ipv6_validation` | 0.348 | 0.330–0.350 | comparator faster in every run interval |
| `semver_version_parse` | 0.425 | 0.419–0.426 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.364 | 0.358–0.381 | comparator faster in every run interval |
| `jinja_string_token` | 0.324 | 0.321–0.332 | comparator faster in every run interval |
| `jinja_integer_token` | 0.298 | 0.287–0.333 | comparator faster in every run interval |
| `jinja_float_token` | 0.248 | 0.242–0.257 | comparator faster in every run interval |
| `django_email_local_part` | 0.469 | 0.426–0.477 | comparator faster in every run interval |
| `django_email_domain` | 0.061 | 0.048–0.066 | comparator faster in every run interval |
| `django_url_regex` | 0.060 | 0.056–0.063 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.292 | 0.281–0.314 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.287 | 0.283–0.295 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.897 | 0.842–0.989 | inconclusive |
| `mastodon_hashtag_regex_step` | 0.179 | 0.164–0.179 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.544 | 0.513–0.637 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.393 | 0.352–0.395 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.451 | 0.406–0.451 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.433 | 0.430–0.454 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.489 | 0.409–0.562 | comparator faster in every run interval |
| `literal_first` | 2.453 | 2.333–2.517 | Ferroni faster in every run interval |
| `literal_middle` | 2.407 | 2.322–2.495 | Ferroni faster in every run interval |
| `literal_end` | 2.408 | 2.365–2.863 | Ferroni faster in every run interval |
| `literal_absent` | 2.692 | 2.487–2.815 | Ferroni faster in every run interval |

## pcre2 / steady

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 2.060.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.762 | 1.684–1.914 | Ferroni faster in every run interval |
| `uuid_v4` | 1.965 | 1.943–2.024 | Ferroni faster in every run interval |
| `ipv4_validation` | 9.293 | 9.242–10.422 | Ferroni faster in every run interval |
| `ipv6_validation` | 21.718 | 20.543–21.885 | Ferroni faster in every run interval |
| `semver_version_parse` | 1.328 | 1.302–1.366 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.672 | 1.671–1.759 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.005 | 1.005–1.105 | inconclusive |
| `jinja_integer_token` | 1.472 | 1.393–1.539 | Ferroni faster in every run interval |
| `jinja_float_token` | 1.678 | 1.673–1.794 | Ferroni faster in every run interval |
| `django_email_local_part` | 5.883 | 5.808–6.136 | Ferroni faster in every run interval |
| `django_email_domain` | 3.090 | 2.591–3.613 | Ferroni faster in every run interval |
| `django_url_regex` | 2.934 | 2.905–3.435 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.583 | 1.471–1.620 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.772 | 1.629–1.799 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.236 | 1.205–1.307 | Ferroni faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.770 | 0.738–0.775 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 3.295 | 2.784–3.780 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 3.873 | 3.681–3.879 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 1.158 | 1.019–1.165 | inconclusive |
| `symfony_grapheme_chunks_1` | 0.797 | 0.794–0.810 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.767 | 0.707–0.793 | comparator faster in every run interval |
| `literal_first` | 4.480 | 4.344–4.492 | Ferroni faster in every run interval |
| `literal_middle` | 4.403 | 4.076–4.581 | Ferroni faster in every run interval |
| `literal_end` | 3.770 | 3.702–4.501 | Ferroni faster in every run interval |
| `literal_absent` | 2.006 | 1.918–2.090 | Ferroni faster in every run interval |

## pcre2 / compile

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.089.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.101 | 0.097–0.108 | comparator faster in every run interval |
| `uuid_v4` | 0.111 | 0.106–0.116 | comparator faster in every run interval |
| `ipv4_validation` | 0.090 | 0.080–0.093 | comparator faster in every run interval |
| `ipv6_validation` | 0.106 | 0.100–0.113 | comparator faster in every run interval |
| `semver_version_parse` | 0.111 | 0.106–0.113 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.107 | 0.102–0.112 | comparator faster in every run interval |
| `jinja_string_token` | 0.057 | 0.055–0.060 | comparator faster in every run interval |
| `jinja_integer_token` | 0.081 | 0.075–0.085 | comparator faster in every run interval |
| `jinja_float_token` | 0.048 | 0.047–0.050 | comparator faster in every run interval |
| `django_email_local_part` | 0.226 | 0.222–0.230 | comparator faster in every run interval |
| `django_email_domain` | 0.053 | 0.045–0.062 | comparator faster in every run interval |
| `django_url_regex` | 0.047 | 0.046–0.050 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.064 | 0.059–0.066 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.064 | 0.061–0.068 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.204 | 0.198–0.209 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.077 | 0.075–0.081 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.080 | 0.076–0.089 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.066 | 0.063–0.066 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.113 | 0.096–0.114 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.032 | 0.031–0.033 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.028 | 0.026–0.033 | comparator faster in every run interval |
| `literal_first` | 0.237 | 0.236–0.238 | comparator faster in every run interval |
| `literal_middle` | 0.225 | 0.225–0.262 | comparator faster in every run interval |
| `literal_end` | 0.232 | 0.227–0.325 | comparator faster in every run interval |
| `literal_absent` | 0.248 | 0.239–0.261 | comparator faster in every run interval |

## pcre2 / first_use

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.107.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.086 | 0.086–0.098 | comparator faster in every run interval |
| `uuid_v4` | 0.099 | 0.096–0.103 | comparator faster in every run interval |
| `ipv4_validation` | 0.095 | 0.086–0.097 | comparator faster in every run interval |
| `ipv6_validation` | 0.106 | 0.103–0.109 | comparator faster in every run interval |
| `semver_version_parse` | 0.114 | 0.111–0.115 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.108 | 0.102–0.109 | comparator faster in every run interval |
| `jinja_string_token` | 0.067 | 0.059–0.070 | comparator faster in every run interval |
| `jinja_integer_token` | 0.086 | 0.076–0.097 | comparator faster in every run interval |
| `jinja_float_token` | 0.053 | 0.052–0.054 | comparator faster in every run interval |
| `django_email_local_part` | 0.230 | 0.223–0.242 | comparator faster in every run interval |
| `django_email_domain` | 0.055 | 0.044–0.061 | comparator faster in every run interval |
| `django_url_regex` | 0.050 | 0.049–0.051 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.079 | 0.073–0.081 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.072 | 0.071–0.072 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.230 | 0.211–0.242 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.081 | 0.079–0.084 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.111 | 0.096–0.113 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.090 | 0.086–0.092 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.113 | 0.111–0.123 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.111 | 0.100–0.112 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.071 | 0.067–0.084 | comparator faster in every run interval |
| `literal_first` | 0.502 | 0.484–0.523 | comparator faster in every run interval |
| `literal_middle` | 0.483 | 0.455–0.515 | comparator faster in every run interval |
| `literal_end` | 0.497 | 0.488–0.549 | comparator faster in every run interval |
| `literal_absent` | 0.385 | 0.365–0.414 | comparator faster in every run interval |

## fancy_regex / steady

Common cases: 21; families: 11. Pair-specific family-weighted ratio: 2.801.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.960 | 0.913–0.989 | inconclusive |
| `uuid_v4` | 1.065 | 1.055–1.080 | Ferroni faster in every run interval |
| `ipv4_validation` | 1.088 | 1.028–1.126 | inconclusive |
| `ipv6_validation` | 1.187 | 1.136–1.266 | Ferroni faster in every run interval |
| `semver_version_parse` | 2.611 | 2.518–2.657 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 2.358 | 2.289–2.686 | Ferroni faster in every run interval |
| `jinja_string_token` | 0.952 | 0.910–1.032 | inconclusive |
| `jinja_integer_token` | 1.269 | 1.234–1.351 | Ferroni faster in every run interval |
| `jinja_float_token` | 2.591 | 2.586–2.641 | Ferroni faster in every run interval |
| `django_email_domain` | 8.029 | 7.710–10.566 | Ferroni faster in every run interval |
| `django_url_regex` | 24.144 | 21.582–24.555 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.994 | 1.940–2.171 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 2.463 | 2.315–2.665 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 3.440 | 3.324–3.519 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 3.749 | 2.895–3.751 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 4.631 | 4.535–4.815 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 2.010 | 1.763–2.080 | Ferroni faster in every run interval |
| `literal_first` | 1.680 | 1.669–1.761 | Ferroni faster in every run interval |
| `literal_middle` | 1.749 | 1.639–1.787 | Ferroni faster in every run interval |
| `literal_end` | 1.532 | 1.523–1.857 | Ferroni faster in every run interval |
| `literal_absent` | 1.498 | 1.484–1.656 | Ferroni faster in every run interval |

## fancy_regex / compile

Common cases: 21; families: 11. Pair-specific family-weighted ratio: 1.857.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.027 | 1.026–1.096 | inconclusive |
| `uuid_v4` | 1.124 | 1.085–1.194 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.838 | 0.746–0.867 | comparator faster in every run interval |
| `ipv6_validation` | 0.895 | 0.841–0.902 | comparator faster in every run interval |
| `semver_version_parse` | 11.895 | 11.297–12.041 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 8.190 | 7.926–8.443 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.873 | 1.677–1.980 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.946 | 1.856–2.036 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.287 | 0.287–0.292 | comparator faster in every run interval |
| `django_email_domain` | 8.543 | 6.637–8.601 | Ferroni faster in every run interval |
| `django_url_regex` | 6.799 | 6.439–6.899 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.547 | 1.537–1.753 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.681 | 1.546–1.728 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.200 | 1.181–1.295 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.495 | 0.479–0.553 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.423 | 0.405–0.436 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 1.127 | 1.017–1.160 | inconclusive |
| `literal_first` | 1.762 | 1.650–1.809 | Ferroni faster in every run interval |
| `literal_middle` | 1.729 | 1.656–1.829 | Ferroni faster in every run interval |
| `literal_end` | 1.632 | 1.621–2.017 | Ferroni faster in every run interval |
| `literal_absent` | 1.576 | 1.564–1.940 | Ferroni faster in every run interval |

## fancy_regex / first_use

Common cases: 21; families: 11. Pair-specific family-weighted ratio: 1.887.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.097 | 1.095–1.100 | Ferroni faster in every run interval |
| `uuid_v4` | 1.129 | 1.095–1.168 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.870 | 0.790–0.885 | comparator faster in every run interval |
| `ipv6_validation` | 0.891 | 0.878–0.896 | comparator faster in every run interval |
| `semver_version_parse` | 11.095 | 10.830–11.771 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 7.240 | 7.045–7.703 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.904 | 1.603–1.937 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.919 | 1.911–1.978 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.283 | 0.276–0.294 | comparator faster in every run interval |
| `django_email_domain` | 8.230 | 6.581–8.475 | Ferroni faster in every run interval |
| `django_url_regex` | 6.735 | 6.416–6.766 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.590 | 1.580–1.728 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.596 | 1.460–1.626 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.566 | 1.378–1.586 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.438 | 0.428–0.473 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.414 | 0.375–0.416 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 1.158 | 1.146–1.233 | Ferroni faster in every run interval |
| `literal_first` | 1.822 | 1.750–1.846 | Ferroni faster in every run interval |
| `literal_middle` | 1.918 | 1.702–1.941 | Ferroni faster in every run interval |
| `literal_end` | 1.695 | 1.626–2.018 | Ferroni faster in every run interval |
| `literal_absent` | 1.685 | 1.624–1.834 | Ferroni faster in every run interval |

## fancy_regex_seek / steady

Common cases: 21; families: 11. Pair-specific family-weighted ratio: 2.793.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.987 | 0.951–1.008 | inconclusive |
| `uuid_v4` | 1.100 | 1.090–1.160 | Ferroni faster in every run interval |
| `ipv4_validation` | 1.080 | 1.071–1.116 | Ferroni faster in every run interval |
| `ipv6_validation` | 1.171 | 1.165–1.237 | Ferroni faster in every run interval |
| `semver_version_parse` | 2.625 | 2.461–2.640 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 2.284 | 2.166–2.439 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.010 | 0.903–1.046 | inconclusive |
| `jinja_integer_token` | 1.276 | 1.247–1.351 | Ferroni faster in every run interval |
| `jinja_float_token` | 2.641 | 2.614–2.659 | Ferroni faster in every run interval |
| `django_email_domain` | 7.974 | 7.700–9.473 | Ferroni faster in every run interval |
| `django_url_regex` | 23.162 | 22.350–23.715 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 2.049 | 1.957–2.132 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 2.405 | 2.374–2.551 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 3.486 | 3.136–3.517 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 3.397 | 2.982–3.600 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 4.591 | 4.458–5.037 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 1.954 | 1.756–2.044 | Ferroni faster in every run interval |
| `literal_first` | 1.733 | 1.730–1.802 | Ferroni faster in every run interval |
| `literal_middle` | 1.802 | 1.798–1.903 | Ferroni faster in every run interval |
| `literal_end` | 1.698 | 1.571–1.874 | Ferroni faster in every run interval |
| `literal_absent` | 1.554 | 1.543–1.635 | Ferroni faster in every run interval |

## fancy_regex_seek / compile

Common cases: 21; families: 11. Pair-specific family-weighted ratio: 2.025.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.092 | 1.089–1.142 | Ferroni faster in every run interval |
| `uuid_v4` | 1.093 | 1.075–1.341 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.854 | 0.791–0.861 | comparator faster in every run interval |
| `ipv6_validation` | 0.879 | 0.809–0.890 | comparator faster in every run interval |
| `semver_version_parse` | 11.770 | 11.170–12.178 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 8.174 | 7.817–8.209 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.865 | 1.676–1.893 | Ferroni faster in every run interval |
| `jinja_integer_token` | 2.002 | 1.911–2.088 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.294 | 0.291–0.301 | comparator faster in every run interval |
| `django_email_domain` | 7.293 | 7.108–8.420 | Ferroni faster in every run interval |
| `django_url_regex` | 6.859 | 6.443–6.863 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.580 | 1.531–1.661 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.496 | 1.487–1.569 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.241 | 1.173–1.278 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.518 | 0.429–0.555 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.430 | 0.423–0.439 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 3.138 | 3.097–3.165 | Ferroni faster in every run interval |
| `literal_first` | 1.683 | 1.634–1.808 | Ferroni faster in every run interval |
| `literal_middle` | 1.819 | 1.745–1.875 | Ferroni faster in every run interval |
| `literal_end` | 1.815 | 1.637–2.075 | Ferroni faster in every run interval |
| `literal_absent` | 1.635 | 1.606–1.925 | Ferroni faster in every run interval |

## fancy_regex_seek / first_use

Common cases: 21; families: 11. Pair-specific family-weighted ratio: 2.055.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.118 | 1.106–1.120 | Ferroni faster in every run interval |
| `uuid_v4` | 1.154 | 1.101–1.306 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.863 | 0.832–0.866 | comparator faster in every run interval |
| `ipv6_validation` | 0.881 | 0.849–0.905 | comparator faster in every run interval |
| `semver_version_parse` | 11.718 | 10.728–11.731 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 7.318 | 7.227–7.805 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.817 | 1.698–1.840 | Ferroni faster in every run interval |
| `jinja_integer_token` | 2.085 | 1.974–2.102 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.282 | 0.279–0.289 | comparator faster in every run interval |
| `django_email_domain` | 7.357 | 7.218–7.558 | Ferroni faster in every run interval |
| `django_url_regex` | 6.435 | 6.190–6.664 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.616 | 1.589–1.690 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.542 | 1.490–1.741 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.444 | 1.364–1.581 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.429 | 0.392–0.500 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.424 | 0.382–0.437 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 3.513 | 3.334–3.792 | Ferroni faster in every run interval |
| `literal_first` | 1.762 | 1.725–1.909 | Ferroni faster in every run interval |
| `literal_middle` | 1.893 | 1.789–1.897 | Ferroni faster in every run interval |
| `literal_end` | 1.940 | 1.705–2.077 | Ferroni faster in every run interval |
| `literal_absent` | 1.690 | 1.643–1.750 | Ferroni faster in every run interval |

## regex / steady

Common cases: 14; families: 6. Pair-specific family-weighted ratio: 1.310.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.911 | 0.887–0.923 | comparator faster in every run interval |
| `uuid_v4` | 0.981 | 0.959–1.020 | inconclusive |
| `ipv4_validation` | 0.951 | 0.946–0.968 | comparator faster in every run interval |
| `ipv6_validation` | 1.050 | 1.040–1.131 | Ferroni faster in every run interval |
| `semver_version_parse` | 2.321 | 2.301–2.352 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 2.085 | 2.013–2.111 | Ferroni faster in every run interval |
| `jinja_string_token` | 0.730 | 0.720–0.746 | comparator faster in every run interval |
| `jinja_integer_token` | 1.077 | 1.041–1.082 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.883 | 1.817–1.985 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 2.380 | 2.183–2.540 | Ferroni faster in every run interval |
| `literal_first` | 1.311 | 1.307–1.314 | Ferroni faster in every run interval |
| `literal_middle` | 1.360 | 1.350–1.390 | Ferroni faster in every run interval |
| `literal_end` | 1.291 | 1.207–1.442 | Ferroni faster in every run interval |
| `literal_absent` | 1.223 | 1.181–1.263 | Ferroni faster in every run interval |

## regex / compile

Common cases: 14; families: 6. Pair-specific family-weighted ratio: 1.753.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.846 | 0.809–0.852 | comparator faster in every run interval |
| `uuid_v4` | 0.807 | 0.792–0.827 | comparator faster in every run interval |
| `ipv4_validation` | 0.734 | 0.685–0.753 | comparator faster in every run interval |
| `ipv6_validation` | 0.800 | 0.772–0.805 | comparator faster in every run interval |
| `semver_version_parse` | 11.741 | 11.101–12.016 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 7.781 | 7.379–8.343 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.879 | 1.860–1.996 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.793 | 1.787–1.857 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.524 | 1.461–1.652 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.568 | 1.474–1.594 | Ferroni faster in every run interval |
| `literal_first` | 1.747 | 1.597–1.762 | Ferroni faster in every run interval |
| `literal_middle` | 1.748 | 1.675–1.758 | Ferroni faster in every run interval |
| `literal_end` | 1.656 | 1.626–1.967 | Ferroni faster in every run interval |
| `literal_absent` | 1.609 | 1.588–1.897 | Ferroni faster in every run interval |

## regex / first_use

Common cases: 14; families: 6. Pair-specific family-weighted ratio: 1.764.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.894 | 0.884–0.954 | comparator faster in every run interval |
| `uuid_v4` | 0.877 | 0.876–0.901 | comparator faster in every run interval |
| `ipv4_validation` | 0.769 | 0.712–0.785 | comparator faster in every run interval |
| `ipv6_validation` | 0.791 | 0.782–0.794 | comparator faster in every run interval |
| `semver_version_parse` | 11.154 | 10.849–11.606 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 7.441 | 7.276–7.562 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.798 | 1.796–1.882 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.771 | 1.768–1.913 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.523 | 1.523–1.538 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.535 | 1.481–1.554 | Ferroni faster in every run interval |
| `literal_first` | 1.719 | 1.676–1.769 | Ferroni faster in every run interval |
| `literal_middle` | 1.761 | 1.699–1.797 | Ferroni faster in every run interval |
| `literal_end` | 1.704 | 1.687–1.893 | Ferroni faster in every run interval |
| `literal_absent` | 1.835 | 1.572–1.842 | Ferroni faster in every run interval |

Raw samples, estimates, confidence intervals, failures, eligibility reasons, corpus snapshot and execution order are retained beside this report.

Memory, where requested, is fresh-process peak RSS including the binary, runtime, parsed catalog, compilation, input/output and allocator. It is not isolated compiled-pattern memory.
