# Production regex comparison

Host: macOS-26.3-arm64-arm-64bit-Mach-O; arm64.

Publication candidate: review host stability, raw samples, coverage and run intervals before publishing.

Ratios are comparator / Ferroni. Compile and first-use times concern one pattern; steady times concern the complete fixture batch.

Each comparison below uses only its explicitly listed common tasks. Families have equal aggregate weight; architectures are never combined.

## Eligibility

| Case | Engine | Status |
| --- | --- | --- |
| `uuid_shape` | rust | eligible |
| `uuid_shape` | rust_erroraware | eligible |
| `uuid_shape` | c | eligible |
| `uuid_shape` | onigmo | eligible |
| `uuid_shape` | pcre2_jit | eligible |
| `uuid_shape` | pcre2 | eligible |
| `uuid_shape` | fancy_regex | eligible |
| `uuid_shape` | fancy_regex_seek | eligible |
| `uuid_shape` | regex | eligible |
| `uuid_v4` | rust | eligible |
| `uuid_v4` | rust_erroraware | eligible |
| `uuid_v4` | c | eligible |
| `uuid_v4` | onigmo | eligible |
| `uuid_v4` | pcre2_jit | eligible |
| `uuid_v4` | pcre2 | eligible |
| `uuid_v4` | fancy_regex | eligible |
| `uuid_v4` | fancy_regex_seek | eligible |
| `uuid_v4` | regex | eligible |
| `ipv4_validation` | rust | eligible |
| `ipv4_validation` | rust_erroraware | eligible |
| `ipv4_validation` | c | eligible |
| `ipv4_validation` | onigmo | eligible |
| `ipv4_validation` | pcre2_jit | eligible |
| `ipv4_validation` | pcre2 | eligible |
| `ipv4_validation` | fancy_regex | eligible |
| `ipv4_validation` | fancy_regex_seek | eligible |
| `ipv4_validation` | regex | eligible |
| `ipv6_validation` | rust | eligible |
| `ipv6_validation` | rust_erroraware | eligible |
| `ipv6_validation` | c | eligible |
| `ipv6_validation` | onigmo | eligible |
| `ipv6_validation` | pcre2_jit | eligible |
| `ipv6_validation` | pcre2 | eligible |
| `ipv6_validation` | fancy_regex | eligible |
| `ipv6_validation` | fancy_regex_seek | eligible |
| `ipv6_validation` | regex | eligible |
| `semver_version_parse` | rust | eligible |
| `semver_version_parse` | rust_erroraware | eligible |
| `semver_version_parse` | c | eligible |
| `semver_version_parse` | onigmo | eligible |
| `semver_version_parse` | pcre2_jit | eligible |
| `semver_version_parse` | pcre2 | eligible |
| `semver_version_parse` | fancy_regex | eligible |
| `semver_version_parse` | fancy_regex_seek | eligible |
| `semver_version_parse` | regex | eligible |
| `semver_hyphen_range_captures` | rust | eligible |
| `semver_hyphen_range_captures` | rust_erroraware | eligible |
| `semver_hyphen_range_captures` | c | eligible |
| `semver_hyphen_range_captures` | onigmo | eligible |
| `semver_hyphen_range_captures` | pcre2_jit | eligible |
| `semver_hyphen_range_captures` | pcre2 | eligible |
| `semver_hyphen_range_captures` | fancy_regex | eligible |
| `semver_hyphen_range_captures` | fancy_regex_seek | eligible |
| `semver_hyphen_range_captures` | regex | eligible |
| `jinja_string_token` | rust | eligible |
| `jinja_string_token` | rust_erroraware | eligible |
| `jinja_string_token` | c | eligible |
| `jinja_string_token` | onigmo | eligible |
| `jinja_string_token` | pcre2_jit | eligible |
| `jinja_string_token` | pcre2 | eligible |
| `jinja_string_token` | fancy_regex | eligible |
| `jinja_string_token` | fancy_regex_seek | eligible |
| `jinja_string_token` | regex | eligible |
| `jinja_integer_token` | rust | eligible |
| `jinja_integer_token` | rust_erroraware | eligible |
| `jinja_integer_token` | c | eligible |
| `jinja_integer_token` | onigmo | eligible |
| `jinja_integer_token` | pcre2_jit | eligible |
| `jinja_integer_token` | pcre2 | eligible |
| `jinja_integer_token` | fancy_regex | eligible |
| `jinja_integer_token` | fancy_regex_seek | eligible |
| `jinja_integer_token` | regex | eligible |
| `jinja_float_token` | rust | eligible |
| `jinja_float_token` | rust_erroraware | eligible |
| `jinja_float_token` | c | eligible |
| `jinja_float_token` | onigmo | eligible |
| `jinja_float_token` | pcre2_jit | eligible |
| `jinja_float_token` | pcre2 | eligible |
| `jinja_float_token` | fancy_regex | eligible |
| `jinja_float_token` | fancy_regex_seek | eligible |
| `jinja_float_token` | regex | syntax_rejected |
| `django_email_local_part` | rust | eligible |
| `django_email_local_part` | rust_erroraware | eligible |
| `django_email_local_part` | c | eligible |
| `django_email_local_part` | onigmo | eligible |
| `django_email_local_part` | pcre2_jit | eligible |
| `django_email_local_part` | pcre2 | eligible |
| `django_email_local_part` | fancy_regex | syntax_rejected |
| `django_email_local_part` | fancy_regex_seek | syntax_rejected |
| `django_email_local_part` | regex | syntax_rejected |
| `django_email_domain` | rust | eligible |
| `django_email_domain` | rust_erroraware | eligible |
| `django_email_domain` | c | eligible |
| `django_email_domain` | onigmo | eligible |
| `django_email_domain` | pcre2_jit | eligible |
| `django_email_domain` | pcre2 | eligible |
| `django_email_domain` | fancy_regex | eligible |
| `django_email_domain` | fancy_regex_seek | eligible |
| `django_email_domain` | regex | syntax_rejected |
| `django_url_regex` | rust | eligible |
| `django_url_regex` | rust_erroraware | eligible |
| `django_url_regex` | c | eligible |
| `django_url_regex` | onigmo | eligible |
| `django_url_regex` | pcre2_jit | eligible |
| `django_url_regex` | pcre2 | eligible |
| `django_url_regex` | fancy_regex | eligible |
| `django_url_regex` | fancy_regex_seek | eligible |
| `django_url_regex` | regex | syntax_rejected |
| `fluent_bit_apache` | rust | eligible |
| `fluent_bit_apache` | rust_erroraware | eligible |
| `fluent_bit_apache` | c | eligible |
| `fluent_bit_apache` | onigmo | eligible |
| `fluent_bit_apache` | pcre2_jit | eligible |
| `fluent_bit_apache` | pcre2 | eligible |
| `fluent_bit_apache` | fancy_regex | eligible |
| `fluent_bit_apache` | fancy_regex_seek | eligible |
| `fluent_bit_apache` | regex | eligible |
| `fluent_bit_nginx` | rust | eligible |
| `fluent_bit_nginx` | rust_erroraware | eligible |
| `fluent_bit_nginx` | c | eligible |
| `fluent_bit_nginx` | onigmo | eligible |
| `fluent_bit_nginx` | pcre2_jit | eligible |
| `fluent_bit_nginx` | pcre2 | eligible |
| `fluent_bit_nginx` | fancy_regex | eligible |
| `fluent_bit_nginx` | fancy_regex_seek | eligible |
| `fluent_bit_nginx` | regex | eligible |
| `rails_underscore_regex_step` | rust | eligible |
| `rails_underscore_regex_step` | rust_erroraware | eligible |
| `rails_underscore_regex_step` | c | eligible |
| `rails_underscore_regex_step` | onigmo | eligible |
| `rails_underscore_regex_step` | pcre2_jit | eligible |
| `rails_underscore_regex_step` | pcre2 | eligible |
| `rails_underscore_regex_step` | fancy_regex | eligible |
| `rails_underscore_regex_step` | fancy_regex_seek | eligible |
| `rails_underscore_regex_step` | regex | syntax_rejected |
| `mastodon_hashtag_regex_step` | rust | eligible |
| `mastodon_hashtag_regex_step` | rust_erroraware | eligible |
| `mastodon_hashtag_regex_step` | c | eligible |
| `mastodon_hashtag_regex_step` | onigmo | eligible |
| `mastodon_hashtag_regex_step` | pcre2_jit | eligible |
| `mastodon_hashtag_regex_step` | pcre2 | eligible |
| `mastodon_hashtag_regex_step` | fancy_regex | semantic_difference |
| `mastodon_hashtag_regex_step` | fancy_regex_seek | semantic_difference |
| `mastodon_hashtag_regex_step` | regex | syntax_rejected |
| `python_markdown_smart_emphasis_re` | rust | eligible |
| `python_markdown_smart_emphasis_re` | rust_erroraware | eligible |
| `python_markdown_smart_emphasis_re` | c | eligible |
| `python_markdown_smart_emphasis_re` | onigmo | eligible |
| `python_markdown_smart_emphasis_re` | pcre2_jit | eligible |
| `python_markdown_smart_emphasis_re` | pcre2 | eligible |
| `python_markdown_smart_emphasis_re` | fancy_regex | eligible |
| `python_markdown_smart_emphasis_re` | fancy_regex_seek | eligible |
| `python_markdown_smart_emphasis_re` | regex | syntax_rejected |
| `python_markdown_smart_strong_em_re` | rust | eligible |
| `python_markdown_smart_strong_em_re` | rust_erroraware | eligible |
| `python_markdown_smart_strong_em_re` | c | eligible |
| `python_markdown_smart_strong_em_re` | onigmo | eligible |
| `python_markdown_smart_strong_em_re` | pcre2_jit | eligible |
| `python_markdown_smart_strong_em_re` | pcre2 | eligible |
| `python_markdown_smart_strong_em_re` | fancy_regex | eligible |
| `python_markdown_smart_strong_em_re` | fancy_regex_seek | eligible |
| `python_markdown_smart_strong_em_re` | regex | syntax_rejected |
| `wordpress_shortcode_captures` | rust | eligible |
| `wordpress_shortcode_captures` | rust_erroraware | eligible |
| `wordpress_shortcode_captures` | c | eligible |
| `wordpress_shortcode_captures` | onigmo | eligible |
| `wordpress_shortcode_captures` | pcre2_jit | eligible |
| `wordpress_shortcode_captures` | pcre2 | eligible |
| `wordpress_shortcode_captures` | fancy_regex | eligible |
| `wordpress_shortcode_captures` | fancy_regex_seek | eligible |
| `wordpress_shortcode_captures` | regex | syntax_rejected |
| `symfony_grapheme_chunks_1` | rust | eligible |
| `symfony_grapheme_chunks_1` | rust_erroraware | eligible |
| `symfony_grapheme_chunks_1` | c | eligible |
| `symfony_grapheme_chunks_1` | onigmo | semantic_difference |
| `symfony_grapheme_chunks_1` | pcre2_jit | eligible |
| `symfony_grapheme_chunks_1` | pcre2 | eligible |
| `symfony_grapheme_chunks_1` | fancy_regex | syntax_rejected |
| `symfony_grapheme_chunks_1` | fancy_regex_seek | syntax_rejected |
| `symfony_grapheme_chunks_1` | regex | syntax_rejected |
| `symfony_grapheme_chunks_2` | rust | eligible |
| `symfony_grapheme_chunks_2` | rust_erroraware | eligible |
| `symfony_grapheme_chunks_2` | c | eligible |
| `symfony_grapheme_chunks_2` | onigmo | eligible |
| `symfony_grapheme_chunks_2` | pcre2_jit | eligible |
| `symfony_grapheme_chunks_2` | pcre2 | eligible |
| `symfony_grapheme_chunks_2` | fancy_regex | syntax_rejected |
| `symfony_grapheme_chunks_2` | fancy_regex_seek | syntax_rejected |
| `symfony_grapheme_chunks_2` | regex | syntax_rejected |
| `literal_first` | rust | eligible |
| `literal_first` | rust_erroraware | eligible |
| `literal_first` | c | eligible |
| `literal_first` | onigmo | eligible |
| `literal_first` | pcre2_jit | eligible |
| `literal_first` | pcre2 | eligible |
| `literal_first` | fancy_regex | eligible |
| `literal_first` | fancy_regex_seek | eligible |
| `literal_first` | regex | eligible |
| `literal_middle` | rust | eligible |
| `literal_middle` | rust_erroraware | eligible |
| `literal_middle` | c | eligible |
| `literal_middle` | onigmo | eligible |
| `literal_middle` | pcre2_jit | eligible |
| `literal_middle` | pcre2 | eligible |
| `literal_middle` | fancy_regex | eligible |
| `literal_middle` | fancy_regex_seek | eligible |
| `literal_middle` | regex | eligible |
| `literal_end` | rust | eligible |
| `literal_end` | rust_erroraware | eligible |
| `literal_end` | c | eligible |
| `literal_end` | onigmo | eligible |
| `literal_end` | pcre2_jit | eligible |
| `literal_end` | pcre2 | eligible |
| `literal_end` | fancy_regex | eligible |
| `literal_end` | fancy_regex_seek | eligible |
| `literal_end` | regex | eligible |
| `literal_absent` | rust | eligible |
| `literal_absent` | rust_erroraware | eligible |
| `literal_absent` | c | eligible |
| `literal_absent` | onigmo | eligible |
| `literal_absent` | pcre2_jit | eligible |
| `literal_absent` | pcre2 | eligible |
| `literal_absent` | fancy_regex | eligible |
| `literal_absent` | fancy_regex_seek | eligible |
| `literal_absent` | regex | eligible |
| `linkify_http_tail` | rust | pending |
| `linkify_http_tail` | rust_erroraware | pending |
| `linkify_http_tail` | c | pending |
| `linkify_http_tail` | onigmo | pending |
| `linkify_http_tail` | pcre2_jit | pending |
| `linkify_http_tail` | pcre2 | pending |
| `linkify_http_tail` | fancy_regex | pending |
| `linkify_http_tail` | fancy_regex_seek | pending |
| `linkify_http_tail` | regex | pending |
| `php_cs_fixer_recursive_types` | rust | pending |
| `php_cs_fixer_recursive_types` | rust_erroraware | pending |
| `php_cs_fixer_recursive_types` | c | pending |
| `php_cs_fixer_recursive_types` | onigmo | pending |
| `php_cs_fixer_recursive_types` | pcre2_jit | pending |
| `php_cs_fixer_recursive_types` | pcre2 | pending |
| `php_cs_fixer_recursive_types` | fancy_regex | pending |
| `php_cs_fixer_recursive_types` | fancy_regex_seek | pending |
| `php_cs_fixer_recursive_types` | regex | pending |

## rust_erroraware / steady

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 1.335.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.657 | 1.583–1.695 | Ferroni faster in every run interval |
| `uuid_v4` | 1.857 | 1.794–2.018 | Ferroni faster in every run interval |
| `ipv4_validation` | 1.479 | 1.477–1.553 | Ferroni faster in every run interval |
| `ipv6_validation` | 1.200 | 1.185–1.214 | Ferroni faster in every run interval |
| `semver_version_parse` | 1.240 | 1.231–1.249 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.427 | 1.314–1.445 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.458 | 1.425–1.548 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.432 | 1.339–1.470 | Ferroni faster in every run interval |
| `jinja_float_token` | 1.474 | 1.463–1.492 | Ferroni faster in every run interval |
| `django_email_local_part` | 1.862 | 1.760–1.872 | Ferroni faster in every run interval |
| `django_email_domain` | 1.052 | 1.021–1.095 | inconclusive |
| `django_url_regex` | 0.975 | 0.918–0.991 | inconclusive |
| `fluent_bit_apache` | 1.340 | 1.273–1.345 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.261 | 1.218–1.358 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.015 | 0.986–1.025 | inconclusive |
| `mastodon_hashtag_regex_step` | 1.162 | 1.145–1.204 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 1.178 | 1.103–1.204 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 1.084 | 1.025–1.106 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 1.316 | 1.272–1.345 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_1` | 1.339 | 1.298–1.340 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_2` | 1.298 | 1.294–1.299 | Ferroni faster in every run interval |
| `literal_first` | 2.167 | 2.134–2.208 | Ferroni faster in every run interval |
| `literal_middle` | 2.092 | 1.937–2.312 | Ferroni faster in every run interval |
| `literal_end` | 2.302 | 2.295–2.503 | Ferroni faster in every run interval |
| `literal_absent` | 2.675 | 2.503–2.738 | Ferroni faster in every run interval |

## rust_erroraware / compile

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 1.003.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.944 | 0.926–1.003 | inconclusive |
| `uuid_v4` | 1.032 | 0.994–1.054 | inconclusive |
| `ipv4_validation` | 0.998 | 0.996–1.051 | inconclusive |
| `ipv6_validation` | 1.011 | 1.002–1.025 | inconclusive |
| `semver_version_parse` | 1.005 | 0.998–1.023 | inconclusive |
| `semver_hyphen_range_captures` | 0.989 | 0.905–0.996 | inconclusive |
| `jinja_string_token` | 0.997 | 0.989–1.113 | inconclusive |
| `jinja_integer_token` | 0.991 | 0.962–0.995 | inconclusive |
| `jinja_float_token` | 0.996 | 0.987–1.019 | inconclusive |
| `django_email_local_part` | 1.000 | 0.936–1.013 | inconclusive |
| `django_email_domain` | 0.988 | 0.878–1.102 | inconclusive |
| `django_url_regex` | 1.010 | 1.001–1.015 | inconclusive |
| `fluent_bit_apache` | 0.987 | 0.940–1.017 | inconclusive |
| `fluent_bit_nginx` | 0.993 | 0.978–1.064 | inconclusive |
| `rails_underscore_regex_step` | 1.051 | 0.973–1.075 | inconclusive |
| `mastodon_hashtag_regex_step` | 1.000 | 0.987–1.005 | inconclusive |
| `python_markdown_smart_emphasis_re` | 1.028 | 0.863–1.046 | inconclusive |
| `python_markdown_smart_strong_em_re` | 0.994 | 0.937–1.002 | inconclusive |
| `wordpress_shortcode_captures` | 1.006 | 0.886–1.061 | inconclusive |
| `symfony_grapheme_chunks_1` | 0.995 | 0.939–1.004 | inconclusive |
| `symfony_grapheme_chunks_2` | 1.039 | 0.980–1.039 | inconclusive |
| `literal_first` | 0.992 | 0.948–1.009 | inconclusive |
| `literal_middle` | 0.955 | 0.918–0.971 | inconclusive |
| `literal_end` | 0.993 | 0.955–1.029 | inconclusive |
| `literal_absent` | 0.977 | 0.916–0.988 | inconclusive |

## rust_erroraware / first_use

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 1.013.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.948 | 0.893–1.015 | inconclusive |
| `uuid_v4` | 1.025 | 1.006–1.044 | inconclusive |
| `ipv4_validation` | 0.984 | 0.969–1.010 | inconclusive |
| `ipv6_validation` | 1.006 | 0.982–1.019 | inconclusive |
| `semver_version_parse` | 0.999 | 0.966–1.002 | inconclusive |
| `semver_hyphen_range_captures` | 0.995 | 0.991–0.996 | inconclusive |
| `jinja_string_token` | 1.031 | 0.982–1.118 | inconclusive |
| `jinja_integer_token` | 0.995 | 0.980–1.013 | inconclusive |
| `jinja_float_token` | 1.002 | 0.994–1.007 | inconclusive |
| `django_email_local_part` | 1.002 | 0.992–1.011 | inconclusive |
| `django_email_domain` | 1.003 | 0.860–1.064 | inconclusive |
| `django_url_regex` | 1.015 | 0.998–1.025 | inconclusive |
| `fluent_bit_apache` | 0.984 | 0.946–0.993 | inconclusive |
| `fluent_bit_nginx` | 1.003 | 0.966–1.010 | inconclusive |
| `rails_underscore_regex_step` | 1.044 | 0.993–1.069 | inconclusive |
| `mastodon_hashtag_regex_step` | 0.994 | 0.978–1.031 | inconclusive |
| `python_markdown_smart_emphasis_re` | 0.998 | 0.886–1.015 | inconclusive |
| `python_markdown_smart_strong_em_re` | 1.007 | 0.938–1.017 | inconclusive |
| `wordpress_shortcode_captures` | 1.007 | 0.914–1.037 | inconclusive |
| `symfony_grapheme_chunks_1` | 1.089 | 1.045–1.140 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_2` | 1.067 | 1.031–1.153 | Ferroni faster in every run interval |
| `literal_first` | 1.091 | 1.042–1.094 | Ferroni faster in every run interval |
| `literal_middle` | 1.017 | 0.904–1.094 | inconclusive |
| `literal_end` | 1.030 | 1.029–1.127 | inconclusive |
| `literal_absent` | 1.090 | 0.935–1.093 | inconclusive |

## c / steady

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 1.447.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 2.852 | 2.849–2.893 | Ferroni faster in every run interval |
| `uuid_v4` | 2.063 | 1.951–2.102 | Ferroni faster in every run interval |
| `ipv4_validation` | 1.499 | 1.480–1.515 | Ferroni faster in every run interval |
| `ipv6_validation` | 1.125 | 1.100–1.150 | Ferroni faster in every run interval |
| `semver_version_parse` | 1.119 | 1.051–1.131 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.179 | 1.147–1.220 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.533 | 1.527–1.594 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.177 | 1.113–1.193 | Ferroni faster in every run interval |
| `jinja_float_token` | 1.067 | 1.066–1.075 | Ferroni faster in every run interval |
| `django_email_local_part` | 2.827 | 2.808–2.973 | Ferroni faster in every run interval |
| `django_email_domain` | 1.474 | 1.403–1.632 | Ferroni faster in every run interval |
| `django_url_regex` | 1.131 | 1.126–1.162 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.567 | 1.519–1.649 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.677 | 1.550–1.808 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.096 | 1.073–1.231 | Ferroni faster in every run interval |
| `mastodon_hashtag_regex_step` | 1.647 | 1.591–1.668 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 1.266 | 1.221–1.287 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.857 | 0.849–0.878 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 1.340 | 1.185–1.415 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_1` | 1.328 | 1.294–1.374 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_2` | 1.395 | 1.369–1.421 | Ferroni faster in every run interval |
| `literal_first` | 2.508 | 2.397–2.547 | Ferroni faster in every run interval |
| `literal_middle` | 2.981 | 2.120–2.987 | Ferroni faster in every run interval |
| `literal_end` | 3.528 | 3.332–3.610 | Ferroni faster in every run interval |
| `literal_absent` | 0.751 | 0.720–0.762 | comparator faster in every run interval |

## c / compile

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.858.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 8.684 | 8.664–8.803 | Ferroni faster in every run interval |
| `uuid_v4` | 9.914 | 9.887–10.145 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.642 | 0.628–0.654 | comparator faster in every run interval |
| `ipv6_validation` | 0.647 | 0.644–0.652 | comparator faster in every run interval |
| `semver_version_parse` | 0.595 | 0.572–0.610 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.542 | 0.532–0.543 | comparator faster in every run interval |
| `jinja_string_token` | 0.407 | 0.404–0.416 | comparator faster in every run interval |
| `jinja_integer_token` | 5.006 | 4.927–5.048 | Ferroni faster in every run interval |
| `jinja_float_token` | 1.788 | 1.786–1.825 | Ferroni faster in every run interval |
| `django_email_local_part` | 4.119 | 3.738–4.350 | Ferroni faster in every run interval |
| `django_email_domain` | 0.348 | 0.345–0.350 | comparator faster in every run interval |
| `django_url_regex` | 0.647 | 0.636–0.676 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.360 | 0.339–0.371 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.394 | 0.374–0.397 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.896 | 0.886–1.000 | inconclusive |
| `mastodon_hashtag_regex_step` | 3.570 | 3.411–3.719 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.409 | 0.355–0.422 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.413 | 0.394–0.420 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.564 | 0.500–0.619 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.303 | 0.297–0.305 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.306 | 0.299–0.314 | comparator faster in every run interval |
| `literal_first` | 0.392 | 0.369–0.393 | comparator faster in every run interval |
| `literal_middle` | 0.405 | 0.309–0.416 | comparator faster in every run interval |
| `literal_end` | 0.389 | 0.382–0.433 | comparator faster in every run interval |
| `literal_absent` | 0.397 | 0.362–0.402 | comparator faster in every run interval |

## c / first_use

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.938.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 8.691 | 8.272–8.828 | Ferroni faster in every run interval |
| `uuid_v4` | 9.925 | 9.818–10.166 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.639 | 0.628–0.656 | comparator faster in every run interval |
| `ipv6_validation` | 0.628 | 0.624–0.658 | comparator faster in every run interval |
| `semver_version_parse` | 0.600 | 0.587–0.606 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.554 | 0.551–0.556 | comparator faster in every run interval |
| `jinja_string_token` | 0.424 | 0.405–0.480 | comparator faster in every run interval |
| `jinja_integer_token` | 4.998 | 4.838–5.068 | Ferroni faster in every run interval |
| `jinja_float_token` | 1.773 | 1.744–1.820 | Ferroni faster in every run interval |
| `django_email_local_part` | 4.060 | 3.962–4.122 | Ferroni faster in every run interval |
| `django_email_domain` | 0.339 | 0.330–0.355 | comparator faster in every run interval |
| `django_url_regex` | 0.642 | 0.634–0.669 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.398 | 0.385–0.401 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.447 | 0.421–0.454 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.952 | 0.916–1.035 | inconclusive |
| `mastodon_hashtag_regex_step` | 3.556 | 3.335–3.655 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.449 | 0.430–0.500 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.436 | 0.432–0.457 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.574 | 0.520–0.605 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.564 | 0.560–0.597 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.498 | 0.480–0.531 | comparator faster in every run interval |
| `literal_first` | 0.596 | 0.572–0.606 | comparator faster in every run interval |
| `literal_middle` | 0.596 | 0.500–0.633 | comparator faster in every run interval |
| `literal_end` | 0.648 | 0.637–0.775 | comparator faster in every run interval |
| `literal_absent` | 0.459 | 0.449–0.461 | comparator faster in every run interval |

## onigmo / steady

Common cases: 24; families: 13. Pair-specific family-weighted ratio: 1.532.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 3.345 | 3.292–3.447 | Ferroni faster in every run interval |
| `uuid_v4` | 3.046 | 3.039–3.144 | Ferroni faster in every run interval |
| `ipv4_validation` | 1.118 | 1.110–1.136 | Ferroni faster in every run interval |
| `ipv6_validation` | 1.600 | 1.594–1.742 | Ferroni faster in every run interval |
| `semver_version_parse` | 1.198 | 1.193–1.207 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.107 | 1.097–1.143 | Ferroni faster in every run interval |
| `jinja_string_token` | 0.947 | 0.926–1.085 | inconclusive |
| `jinja_integer_token` | 1.209 | 1.162–1.272 | Ferroni faster in every run interval |
| `jinja_float_token` | 2.054 | 1.956–2.113 | Ferroni faster in every run interval |
| `django_email_local_part` | 1.511 | 1.472–1.533 | Ferroni faster in every run interval |
| `django_email_domain` | 2.540 | 2.465–2.739 | Ferroni faster in every run interval |
| `django_url_regex` | 2.911 | 2.862–2.949 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.734 | 1.539–1.825 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 2.040 | 1.899–2.175 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 0.919 | 0.864–0.964 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 1.546 | 1.498–1.591 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 1.050 | 0.992–1.062 | inconclusive |
| `python_markdown_smart_strong_em_re` | 0.822 | 0.735–0.842 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 1.148 | 0.999–1.198 | inconclusive |
| `symfony_grapheme_chunks_2` | 2.389 | 2.382–2.669 | Ferroni faster in every run interval |
| `literal_first` | 0.718 | 0.693–0.760 | comparator faster in every run interval |
| `literal_middle` | 0.852 | 0.699–0.942 | comparator faster in every run interval |
| `literal_end` | 1.636 | 1.415–1.673 | Ferroni faster in every run interval |
| `literal_absent` | 1.034 | 1.010–1.075 | inconclusive |

## onigmo / compile

Common cases: 24; families: 13. Pair-specific family-weighted ratio: 1.124.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 8.147 | 8.118–8.732 | Ferroni faster in every run interval |
| `uuid_v4` | 9.443 | 9.127–9.522 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.603 | 0.586–0.612 | comparator faster in every run interval |
| `ipv6_validation` | 0.617 | 0.617–0.619 | comparator faster in every run interval |
| `semver_version_parse` | 0.574 | 0.565–0.574 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.578 | 0.566–0.578 | comparator faster in every run interval |
| `jinja_string_token` | 0.340 | 0.331–0.391 | comparator faster in every run interval |
| `jinja_integer_token` | 4.304 | 4.248–4.316 | Ferroni faster in every run interval |
| `jinja_float_token` | 1.901 | 1.868–1.927 | Ferroni faster in every run interval |
| `django_email_local_part` | 4.080 | 3.586–4.132 | Ferroni faster in every run interval |
| `django_email_domain` | 0.202 | 0.193–0.215 | comparator faster in every run interval |
| `django_url_regex` | 0.513 | 0.501–0.527 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.386 | 0.344–0.399 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.402 | 0.381–0.428 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.955 | 0.953–1.037 | inconclusive |
| `mastodon_hashtag_regex_step` | 3.735 | 3.599–3.960 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.265 | 0.231–0.266 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.287 | 0.286–0.303 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.524 | 0.456–0.574 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 34.213 | 32.771–35.280 | Ferroni faster in every run interval |
| `literal_first` | 0.334 | 0.321–0.336 | comparator faster in every run interval |
| `literal_middle` | 0.299 | 0.260–0.348 | comparator faster in every run interval |
| `literal_end` | 0.331 | 0.313–0.366 | comparator faster in every run interval |
| `literal_absent` | 0.338 | 0.311–0.344 | comparator faster in every run interval |

## onigmo / first_use

Common cases: 24; families: 13. Pair-specific family-weighted ratio: 1.146.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 8.217 | 8.171–8.375 | Ferroni faster in every run interval |
| `uuid_v4` | 9.336 | 9.079–9.677 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.597 | 0.578–0.608 | comparator faster in every run interval |
| `ipv6_validation` | 0.618 | 0.607–0.618 | comparator faster in every run interval |
| `semver_version_parse` | 0.571 | 0.560–0.579 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.587 | 0.572–0.633 | comparator faster in every run interval |
| `jinja_string_token` | 0.356 | 0.341–0.399 | comparator faster in every run interval |
| `jinja_integer_token` | 4.402 | 4.245–4.442 | Ferroni faster in every run interval |
| `jinja_float_token` | 1.889 | 1.827–1.973 | Ferroni faster in every run interval |
| `django_email_local_part` | 3.966 | 3.946–4.064 | Ferroni faster in every run interval |
| `django_email_domain` | 0.214 | 0.197–0.216 | comparator faster in every run interval |
| `django_url_regex` | 0.511 | 0.501–0.538 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.411 | 0.385–0.446 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.470 | 0.449–0.501 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.986 | 0.951–1.042 | inconclusive |
| `mastodon_hashtag_regex_step` | 3.700 | 3.537–3.867 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.302 | 0.293–0.318 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.322 | 0.308–0.322 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.529 | 0.474–0.553 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 27.828 | 26.370–30.662 | Ferroni faster in every run interval |
| `literal_first` | 0.364 | 0.361–0.379 | comparator faster in every run interval |
| `literal_middle` | 0.339 | 0.310–0.417 | comparator faster in every run interval |
| `literal_end` | 0.439 | 0.390–0.510 | comparator faster in every run interval |
| `literal_absent` | 0.398 | 0.392–0.400 | comparator faster in every run interval |

## pcre2_jit / steady

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.297.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.490 | 0.476–0.549 | comparator faster in every run interval |
| `uuid_v4` | 0.487 | 0.463–0.488 | comparator faster in every run interval |
| `ipv4_validation` | 0.235 | 0.233–0.236 | comparator faster in every run interval |
| `ipv6_validation` | 0.290 | 0.288–0.311 | comparator faster in every run interval |
| `semver_version_parse` | 0.317 | 0.316–0.324 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.468 | 0.467–0.560 | comparator faster in every run interval |
| `jinja_string_token` | 0.502 | 0.467–0.523 | comparator faster in every run interval |
| `jinja_integer_token` | 0.442 | 0.421–0.446 | comparator faster in every run interval |
| `jinja_float_token` | 0.490 | 0.472–0.500 | comparator faster in every run interval |
| `django_email_local_part` | 0.488 | 0.487–0.488 | comparator faster in every run interval |
| `django_email_domain` | 0.032 | 0.030–0.036 | comparator faster in every run interval |
| `django_url_regex` | 0.068 | 0.064–0.069 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.357 | 0.300–0.363 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.505 | 0.494–0.520 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.326 | 0.308–0.328 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.267 | 0.259–0.271 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.293 | 0.283–0.297 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.175 | 0.171–0.179 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.417 | 0.389–0.435 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.425 | 0.407–0.433 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.402 | 0.392–0.438 | comparator faster in every run interval |
| `literal_first` | 0.423 | 0.394–0.442 | comparator faster in every run interval |
| `literal_middle` | 0.465 | 0.392–0.466 | comparator faster in every run interval |
| `literal_end` | 0.477 | 0.443–0.510 | comparator faster in every run interval |
| `literal_absent` | 0.582 | 0.572–0.609 | comparator faster in every run interval |

## pcre2_jit / compile

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.699.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.554 | 0.527–0.556 | comparator faster in every run interval |
| `uuid_v4` | 0.571 | 0.569–0.576 | comparator faster in every run interval |
| `ipv4_validation` | 0.701 | 0.661–0.710 | comparator faster in every run interval |
| `ipv6_validation` | 0.780 | 0.773–0.780 | comparator faster in every run interval |
| `semver_version_parse` | 0.889 | 0.812–0.914 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.794 | 0.776–0.948 | inconclusive |
| `jinja_string_token` | 0.906 | 0.869–0.951 | comparator faster in every run interval |
| `jinja_integer_token` | 0.604 | 0.587–0.611 | comparator faster in every run interval |
| `jinja_float_token` | 0.590 | 0.567–0.611 | comparator faster in every run interval |
| `django_email_local_part` | 0.729 | 0.693–0.731 | comparator faster in every run interval |
| `django_email_domain` | 0.095 | 0.090–0.104 | comparator faster in every run interval |
| `django_url_regex` | 0.111 | 0.110–0.121 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.718 | 0.695–0.756 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.727 | 0.727–0.807 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 1.588 | 1.508–1.651 | Ferroni faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.402 | 0.397–0.416 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 1.128 | 1.114–1.170 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 1.167 | 1.133–1.177 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 1.044 | 0.929–1.140 | inconclusive |
| `symfony_grapheme_chunks_1` | 0.832 | 0.780–0.932 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.818 | 0.790–0.844 | comparator faster in every run interval |
| `literal_first` | 2.964 | 2.792–2.988 | Ferroni faster in every run interval |
| `literal_middle` | 3.073 | 2.708–3.226 | Ferroni faster in every run interval |
| `literal_end` | 3.030 | 2.644–3.394 | Ferroni faster in every run interval |
| `literal_absent` | 2.989 | 2.836–3.002 | Ferroni faster in every run interval |

## pcre2_jit / first_use

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.782.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.551 | 0.542–0.565 | comparator faster in every run interval |
| `uuid_v4` | 0.584 | 0.579–0.598 | comparator faster in every run interval |
| `ipv4_validation` | 0.823 | 0.786–0.839 | comparator faster in every run interval |
| `ipv6_validation` | 0.782 | 0.775–0.799 | comparator faster in every run interval |
| `semver_version_parse` | 0.952 | 0.881–0.975 | inconclusive |
| `semver_hyphen_range_captures` | 0.838 | 0.838–0.996 | inconclusive |
| `jinja_string_token` | 1.048 | 0.955–1.148 | inconclusive |
| `jinja_integer_token` | 0.708 | 0.687–0.721 | comparator faster in every run interval |
| `jinja_float_token` | 0.692 | 0.680–0.701 | comparator faster in every run interval |
| `django_email_local_part` | 0.832 | 0.814–0.846 | comparator faster in every run interval |
| `django_email_domain` | 0.092 | 0.087–0.100 | comparator faster in every run interval |
| `django_url_regex` | 0.111 | 0.110–0.117 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.860 | 0.796–0.867 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.884 | 0.845–0.953 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 2.050 | 1.958–2.163 | Ferroni faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.442 | 0.436–0.462 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 1.421 | 1.416–1.481 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 1.350 | 1.274–1.368 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 1.129 | 1.031–1.198 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_1` | 1.162 | 1.077–1.240 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_2` | 1.221 | 1.184–1.659 | Ferroni faster in every run interval |
| `literal_first` | 2.815 | 2.384–2.875 | Ferroni faster in every run interval |
| `literal_middle` | 2.730 | 2.543–2.928 | Ferroni faster in every run interval |
| `literal_end` | 2.803 | 2.573–3.239 | Ferroni faster in every run interval |
| `literal_absent` | 2.875 | 2.851–2.916 | Ferroni faster in every run interval |

## pcre2 / steady

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.835.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.997 | 0.974–1.100 | inconclusive |
| `uuid_v4` | 0.967 | 0.866–0.996 | inconclusive |
| `ipv4_validation` | 1.642 | 1.606–1.658 | Ferroni faster in every run interval |
| `ipv6_validation` | 1.581 | 1.564–1.826 | Ferroni faster in every run interval |
| `semver_version_parse` | 0.834 | 0.740–0.854 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 1.621 | 1.595–1.945 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.014 | 0.966–1.129 | inconclusive |
| `jinja_integer_token` | 1.446 | 1.383–1.448 | Ferroni faster in every run interval |
| `jinja_float_token` | 1.453 | 1.453–1.482 | Ferroni faster in every run interval |
| `django_email_local_part` | 1.764 | 1.616–1.800 | Ferroni faster in every run interval |
| `django_email_domain` | 0.117 | 0.113–0.127 | comparator faster in every run interval |
| `django_url_regex` | 0.175 | 0.154–0.179 | comparator faster in every run interval |
| `fluent_bit_apache` | 1.113 | 1.078–1.171 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.242 | 1.233–1.245 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.020 | 0.996–1.047 | inconclusive |
| `mastodon_hashtag_regex_step` | 0.568 | 0.559–0.578 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 1.467 | 1.381–1.524 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 1.195 | 1.194–1.244 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 1.121 | 0.904–1.156 | inconclusive |
| `symfony_grapheme_chunks_1` | 0.612 | 0.559–0.619 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.544 | 0.542–0.569 | comparator faster in every run interval |
| `literal_first` | 0.926 | 0.915–0.946 | comparator faster in every run interval |
| `literal_middle` | 0.928 | 0.815–0.977 | inconclusive |
| `literal_end` | 1.006 | 0.942–1.032 | inconclusive |
| `literal_absent` | 0.676 | 0.627–0.685 | comparator faster in every run interval |

## pcre2 / compile

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.206.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.209 | 0.204–0.233 | comparator faster in every run interval |
| `uuid_v4` | 0.232 | 0.205–0.233 | comparator faster in every run interval |
| `ipv4_validation` | 0.222 | 0.210–0.222 | comparator faster in every run interval |
| `ipv6_validation` | 0.258 | 0.251–0.289 | comparator faster in every run interval |
| `semver_version_parse` | 0.244 | 0.217–0.251 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.225 | 0.222–0.256 | comparator faster in every run interval |
| `jinja_string_token` | 0.190 | 0.173–0.201 | comparator faster in every run interval |
| `jinja_integer_token` | 0.179 | 0.176–0.183 | comparator faster in every run interval |
| `jinja_float_token` | 0.129 | 0.128–0.131 | comparator faster in every run interval |
| `django_email_local_part` | 0.407 | 0.348–0.417 | comparator faster in every run interval |
| `django_email_domain` | 0.087 | 0.084–0.094 | comparator faster in every run interval |
| `django_url_regex` | 0.089 | 0.084–0.095 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.156 | 0.149–0.158 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.180 | 0.175–0.185 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.462 | 0.416–0.477 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.213 | 0.213–0.214 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.213 | 0.179–0.215 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.213 | 0.202–0.217 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.285 | 0.252–0.310 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.120 | 0.114–0.123 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.114 | 0.111–0.119 | comparator faster in every run interval |
| `literal_first` | 0.303 | 0.303–0.304 | comparator faster in every run interval |
| `literal_middle` | 0.310 | 0.268–0.319 | comparator faster in every run interval |
| `literal_end` | 0.311 | 0.300–0.333 | comparator faster in every run interval |
| `literal_absent` | 0.295 | 0.276–0.301 | comparator faster in every run interval |

## pcre2 / first_use

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.261.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.248 | 0.234–0.271 | comparator faster in every run interval |
| `uuid_v4` | 0.261 | 0.228–0.263 | comparator faster in every run interval |
| `ipv4_validation` | 0.250 | 0.232–0.252 | comparator faster in every run interval |
| `ipv6_validation` | 0.259 | 0.256–0.288 | comparator faster in every run interval |
| `semver_version_parse` | 0.263 | 0.262–0.263 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.242 | 0.236–0.273 | comparator faster in every run interval |
| `jinja_string_token` | 0.243 | 0.242–0.243 | comparator faster in every run interval |
| `jinja_integer_token` | 0.207 | 0.204–0.207 | comparator faster in every run interval |
| `jinja_float_token` | 0.153 | 0.150–0.154 | comparator faster in every run interval |
| `django_email_local_part` | 0.414 | 0.390–0.427 | comparator faster in every run interval |
| `django_email_domain` | 0.085 | 0.083–0.091 | comparator faster in every run interval |
| `django_url_regex` | 0.087 | 0.083–0.098 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.212 | 0.210–0.230 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.232 | 0.226–0.252 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.542 | 0.504–0.552 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.226 | 0.221–0.230 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.320 | 0.257–0.356 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.318 | 0.305–0.318 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.310 | 0.308–0.328 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.336 | 0.329–0.380 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.272 | 0.269–0.299 | comparator faster in every run interval |
| `literal_first` | 0.655 | 0.558–0.661 | comparator faster in every run interval |
| `literal_middle` | 0.688 | 0.636–0.753 | comparator faster in every run interval |
| `literal_end` | 0.665 | 0.650–0.822 | comparator faster in every run interval |
| `literal_absent` | 0.497 | 0.477–0.515 | comparator faster in every run interval |

## fancy_regex / steady

Common cases: 21; families: 11. Pair-specific family-weighted ratio: 0.929.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.562 | 0.552–0.615 | comparator faster in every run interval |
| `uuid_v4` | 0.533 | 0.491–0.544 | comparator faster in every run interval |
| `ipv4_validation` | 0.200 | 0.200–0.205 | comparator faster in every run interval |
| `ipv6_validation` | 0.090 | 0.089–0.093 | comparator faster in every run interval |
| `semver_version_parse` | 1.673 | 1.550–1.728 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 2.120 | 2.087–2.446 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.018 | 0.973–1.059 | inconclusive |
| `jinja_integer_token` | 1.276 | 1.220–1.286 | Ferroni faster in every run interval |
| `jinja_float_token` | 2.324 | 2.256–2.334 | Ferroni faster in every run interval |
| `django_email_domain` | 0.350 | 0.349–0.358 | comparator faster in every run interval |
| `django_url_regex` | 1.328 | 1.090–1.382 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.499 | 1.457–1.537 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.726 | 1.711–1.786 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 2.688 | 2.396–2.796 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 1.428 | 1.398–1.554 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 1.475 | 1.467–1.571 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 1.936 | 1.833–1.947 | Ferroni faster in every run interval |
| `literal_first` | 0.325 | 0.294–0.330 | comparator faster in every run interval |
| `literal_middle` | 0.357 | 0.317–0.365 | comparator faster in every run interval |
| `literal_end` | 0.387 | 0.384–0.401 | comparator faster in every run interval |
| `literal_absent` | 0.529 | 0.499–0.540 | comparator faster in every run interval |

## fancy_regex / compile

Common cases: 21; families: 11. Pair-specific family-weighted ratio: 4.036.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 2.427 | 2.345–2.528 | Ferroni faster in every run interval |
| `uuid_v4` | 2.306 | 2.137–2.337 | Ferroni faster in every run interval |
| `ipv4_validation` | 2.020 | 1.982–2.061 | Ferroni faster in every run interval |
| `ipv6_validation` | 2.066 | 2.040–2.120 | Ferroni faster in every run interval |
| `semver_version_parse` | 25.491 | 22.712–26.414 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 16.260 | 15.917–18.351 | Ferroni faster in every run interval |
| `jinja_string_token` | 6.369 | 6.134–6.659 | Ferroni faster in every run interval |
| `jinja_integer_token` | 4.493 | 4.490–4.589 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.789 | 0.769–0.803 | comparator faster in every run interval |
| `django_email_domain` | 12.886 | 11.338–13.148 | Ferroni faster in every run interval |
| `django_url_regex` | 11.876 | 11.823–12.647 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 4.252 | 3.905–4.261 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 4.360 | 4.265–4.699 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 2.749 | 2.490–3.020 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 1.392 | 1.155–1.407 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 1.443 | 1.340–1.491 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 3.047 | 2.807–3.287 | Ferroni faster in every run interval |
| `literal_first` | 2.136 | 1.859–2.137 | Ferroni faster in every run interval |
| `literal_middle` | 2.066 | 1.968–2.126 | Ferroni faster in every run interval |
| `literal_end` | 2.198 | 2.096–2.496 | Ferroni faster in every run interval |
| `literal_absent` | 2.119 | 2.070–2.139 | Ferroni faster in every run interval |

## fancy_regex / first_use

Common cases: 21; families: 11. Pair-specific family-weighted ratio: 4.251.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 3.138 | 2.693–3.300 | Ferroni faster in every run interval |
| `uuid_v4` | 2.908 | 2.658–2.955 | Ferroni faster in every run interval |
| `ipv4_validation` | 2.230 | 2.151–2.288 | Ferroni faster in every run interval |
| `ipv6_validation` | 2.084 | 2.060–2.318 | Ferroni faster in every run interval |
| `semver_version_parse` | 25.518 | 22.974–26.031 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 16.778 | 16.443–18.518 | Ferroni faster in every run interval |
| `jinja_string_token` | 6.339 | 6.050–6.364 | Ferroni faster in every run interval |
| `jinja_integer_token` | 4.739 | 4.708–4.831 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.793 | 0.766–0.810 | comparator faster in every run interval |
| `django_email_domain` | 12.448 | 12.423–13.188 | Ferroni faster in every run interval |
| `django_url_regex` | 12.412 | 11.835–12.595 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 4.486 | 4.154–4.758 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 4.822 | 4.578–5.137 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 3.343 | 3.277–3.426 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 1.352 | 1.179–1.379 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 1.460 | 1.346–1.482 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 3.152 | 2.975–3.326 | Ferroni faster in every run interval |
| `literal_first` | 2.014 | 2.001–2.086 | Ferroni faster in every run interval |
| `literal_middle` | 1.886 | 1.817–1.952 | Ferroni faster in every run interval |
| `literal_end` | 2.024 | 1.978–2.375 | Ferroni faster in every run interval |
| `literal_absent` | 2.034 | 1.901–2.118 | Ferroni faster in every run interval |

## fancy_regex_seek / steady

Common cases: 21; families: 11. Pair-specific family-weighted ratio: 0.929.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.582 | 0.537–0.625 | comparator faster in every run interval |
| `uuid_v4` | 0.534 | 0.487–0.549 | comparator faster in every run interval |
| `ipv4_validation` | 0.206 | 0.197–0.213 | comparator faster in every run interval |
| `ipv6_validation` | 0.090 | 0.089–0.095 | comparator faster in every run interval |
| `semver_version_parse` | 1.718 | 1.685–1.780 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 2.089 | 2.075–2.490 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.024 | 0.975–1.047 | inconclusive |
| `jinja_integer_token` | 1.288 | 1.216–1.290 | Ferroni faster in every run interval |
| `jinja_float_token` | 2.281 | 2.260–2.347 | Ferroni faster in every run interval |
| `django_email_domain` | 0.341 | 0.325–0.356 | comparator faster in every run interval |
| `django_url_regex` | 1.316 | 1.201–1.333 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.524 | 1.351–1.529 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.785 | 1.718–1.857 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 2.598 | 2.513–2.735 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 1.424 | 1.389–1.570 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 1.553 | 1.475–1.555 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 1.891 | 1.807–1.994 | Ferroni faster in every run interval |
| `literal_first` | 0.329 | 0.322–0.337 | comparator faster in every run interval |
| `literal_middle` | 0.349 | 0.321–0.364 | comparator faster in every run interval |
| `literal_end` | 0.390 | 0.339–0.392 | comparator faster in every run interval |
| `literal_absent` | 0.531 | 0.522–0.535 | comparator faster in every run interval |

## fancy_regex_seek / compile

Common cases: 21; families: 11. Pair-specific family-weighted ratio: 4.404.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 2.377 | 2.308–2.483 | Ferroni faster in every run interval |
| `uuid_v4` | 2.303 | 2.138–2.349 | Ferroni faster in every run interval |
| `ipv4_validation` | 2.037 | 1.992–2.046 | Ferroni faster in every run interval |
| `ipv6_validation` | 2.077 | 2.024–2.108 | Ferroni faster in every run interval |
| `semver_version_parse` | 25.830 | 25.698–27.291 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 16.785 | 16.035–19.020 | Ferroni faster in every run interval |
| `jinja_string_token` | 6.542 | 6.142–7.006 | Ferroni faster in every run interval |
| `jinja_integer_token` | 4.501 | 4.415–4.533 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.779 | 0.777–0.783 | comparator faster in every run interval |
| `django_email_domain` | 12.786 | 11.759–12.864 | Ferroni faster in every run interval |
| `django_url_regex` | 11.903 | 11.822–12.781 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 4.259 | 3.897–4.325 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 4.407 | 4.296–4.700 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 2.704 | 2.635–2.999 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 1.406 | 1.150–1.407 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 1.427 | 1.346–1.561 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 7.986 | 7.224–8.515 | Ferroni faster in every run interval |
| `literal_first` | 2.166 | 2.118–2.213 | Ferroni faster in every run interval |
| `literal_middle` | 2.070 | 1.960–2.096 | Ferroni faster in every run interval |
| `literal_end` | 2.091 | 1.940–2.389 | Ferroni faster in every run interval |
| `literal_absent` | 2.098 | 1.976–2.123 | Ferroni faster in every run interval |

## fancy_regex_seek / first_use

Common cases: 21; families: 11. Pair-specific family-weighted ratio: 4.629.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 3.130 | 2.902–3.213 | Ferroni faster in every run interval |
| `uuid_v4` | 2.920 | 2.658–2.968 | Ferroni faster in every run interval |
| `ipv4_validation` | 2.263 | 2.170–2.272 | Ferroni faster in every run interval |
| `ipv6_validation` | 2.067 | 2.049–2.079 | Ferroni faster in every run interval |
| `semver_version_parse` | 25.912 | 25.315–26.958 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 16.959 | 16.707–19.566 | Ferroni faster in every run interval |
| `jinja_string_token` | 6.233 | 6.009–6.373 | Ferroni faster in every run interval |
| `jinja_integer_token` | 4.713 | 4.704–4.788 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.777 | 0.765–0.798 | comparator faster in every run interval |
| `django_email_domain` | 12.338 | 11.943–12.470 | Ferroni faster in every run interval |
| `django_url_regex` | 11.699 | 11.634–12.463 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 4.461 | 4.187–4.664 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 4.828 | 4.639–4.986 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 3.367 | 3.322–3.618 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 1.372 | 1.176–1.444 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 1.444 | 1.351–1.521 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 8.626 | 8.234–9.661 | Ferroni faster in every run interval |
| `literal_first` | 2.021 | 1.951–2.031 | Ferroni faster in every run interval |
| `literal_middle` | 1.849 | 1.846–1.897 | Ferroni faster in every run interval |
| `literal_end` | 1.974 | 1.770–2.288 | Ferroni faster in every run interval |
| `literal_absent` | 2.013 | 1.942–2.122 | Ferroni faster in every run interval |

## regex / steady

Common cases: 14; families: 6. Pair-specific family-weighted ratio: 0.583.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.545 | 0.501–0.570 | comparator faster in every run interval |
| `uuid_v4` | 0.500 | 0.493–0.524 | comparator faster in every run interval |
| `ipv4_validation` | 0.166 | 0.165–0.170 | comparator faster in every run interval |
| `ipv6_validation` | 0.077 | 0.076–0.081 | comparator faster in every run interval |
| `semver_version_parse` | 1.532 | 1.482–1.542 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.907 | 1.856–2.353 | Ferroni faster in every run interval |
| `jinja_string_token` | 0.729 | 0.706–0.757 | comparator faster in every run interval |
| `jinja_integer_token` | 1.017 | 0.989–1.022 | inconclusive |
| `fluent_bit_apache` | 1.361 | 1.171–1.386 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.655 | 1.624–1.777 | Ferroni faster in every run interval |
| `literal_first` | 0.250 | 0.243–0.251 | comparator faster in every run interval |
| `literal_middle` | 0.265 | 0.245–0.268 | comparator faster in every run interval |
| `literal_end` | 0.293 | 0.253–0.305 | comparator faster in every run interval |
| `literal_absent` | 0.422 | 0.421–0.424 | comparator faster in every run interval |

## regex / compile

Common cases: 14; families: 6. Pair-specific family-weighted ratio: 3.768.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.701 | 1.659–1.713 | Ferroni faster in every run interval |
| `uuid_v4` | 1.727 | 1.667–1.783 | Ferroni faster in every run interval |
| `ipv4_validation` | 1.802 | 1.784–1.821 | Ferroni faster in every run interval |
| `ipv6_validation` | 1.869 | 1.837–1.896 | Ferroni faster in every run interval |
| `semver_version_parse` | 25.894 | 25.331–25.920 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 16.531 | 16.020–17.662 | Ferroni faster in every run interval |
| `jinja_string_token` | 6.181 | 6.112–6.263 | Ferroni faster in every run interval |
| `jinja_integer_token` | 3.999 | 3.982–4.005 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 4.135 | 3.624–4.148 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 4.259 | 4.197–4.526 | Ferroni faster in every run interval |
| `literal_first` | 2.148 | 2.102–2.163 | Ferroni faster in every run interval |
| `literal_middle` | 2.001 | 1.963–2.059 | Ferroni faster in every run interval |
| `literal_end` | 2.108 | 1.834–2.314 | Ferroni faster in every run interval |
| `literal_absent` | 2.183 | 2.130–2.189 | Ferroni faster in every run interval |

## regex / first_use

Common cases: 14; families: 6. Pair-specific family-weighted ratio: 4.062.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 2.409 | 2.191–2.422 | Ferroni faster in every run interval |
| `uuid_v4` | 2.412 | 2.285–2.475 | Ferroni faster in every run interval |
| `ipv4_validation` | 1.997 | 1.993–2.021 | Ferroni faster in every run interval |
| `ipv6_validation` | 1.870 | 1.847–1.887 | Ferroni faster in every run interval |
| `semver_version_parse` | 25.595 | 25.391–26.773 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 16.426 | 16.325–17.302 | Ferroni faster in every run interval |
| `jinja_string_token` | 6.192 | 5.989–6.204 | Ferroni faster in every run interval |
| `jinja_integer_token` | 4.259 | 4.216–4.349 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 4.636 | 4.398–4.725 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 4.674 | 4.604–4.904 | Ferroni faster in every run interval |
| `literal_first` | 2.034 | 1.957–2.046 | Ferroni faster in every run interval |
| `literal_middle` | 1.851 | 1.743–1.894 | Ferroni faster in every run interval |
| `literal_end` | 1.953 | 1.726–2.018 | Ferroni faster in every run interval |
| `literal_absent` | 2.033 | 1.998–2.039 | Ferroni faster in every run interval |

Raw samples, estimates, confidence intervals, failures, eligibility reasons, corpus snapshot and execution order are retained beside this report.

Memory, where requested, is fresh-process peak RSS including the binary, runtime, parsed catalog, compilation, input/output and allocator. It is not isolated compiled-pattern memory.
