# Production regex comparison

Host: macOS-26.3-arm64-arm-64bit-Mach-O; arm64.

Publication candidate: review host stability, raw samples, coverage and run intervals before publishing.

Ratios are comparator / Ferroni. Compile and first-use times concern one pattern; steady times concern the complete fixture batch.

Each comparison below uses only its explicitly listed common tasks. Families have equal aggregate weight; architectures are never combined.

## Eligibility

| Case | Engine | Status |
| --- | --- | --- |
| `uuid_shape` | rust | eligible |
| `uuid_shape` | rust_erroraware | eligible |
| `uuid_shape` | c | eligible |
| `uuid_shape` | onigmo | eligible |
| `uuid_shape` | pcre2_jit | eligible |
| `uuid_shape` | pcre2 | eligible |
| `uuid_shape` | fancy_regex | eligible |
| `uuid_shape` | fancy_regex_seek | eligible |
| `uuid_shape` | regex | eligible |
| `uuid_v4` | rust | eligible |
| `uuid_v4` | rust_erroraware | eligible |
| `uuid_v4` | c | eligible |
| `uuid_v4` | onigmo | eligible |
| `uuid_v4` | pcre2_jit | eligible |
| `uuid_v4` | pcre2 | eligible |
| `uuid_v4` | fancy_regex | eligible |
| `uuid_v4` | fancy_regex_seek | eligible |
| `uuid_v4` | regex | eligible |
| `ipv4_validation` | rust | eligible |
| `ipv4_validation` | rust_erroraware | eligible |
| `ipv4_validation` | c | eligible |
| `ipv4_validation` | onigmo | eligible |
| `ipv4_validation` | pcre2_jit | eligible |
| `ipv4_validation` | pcre2 | eligible |
| `ipv4_validation` | fancy_regex | eligible |
| `ipv4_validation` | fancy_regex_seek | eligible |
| `ipv4_validation` | regex | eligible |
| `ipv6_validation` | rust | eligible |
| `ipv6_validation` | rust_erroraware | eligible |
| `ipv6_validation` | c | eligible |
| `ipv6_validation` | onigmo | eligible |
| `ipv6_validation` | pcre2_jit | eligible |
| `ipv6_validation` | pcre2 | eligible |
| `ipv6_validation` | fancy_regex | eligible |
| `ipv6_validation` | fancy_regex_seek | eligible |
| `ipv6_validation` | regex | eligible |
| `semver_version_parse` | rust | eligible |
| `semver_version_parse` | rust_erroraware | eligible |
| `semver_version_parse` | c | eligible |
| `semver_version_parse` | onigmo | eligible |
| `semver_version_parse` | pcre2_jit | eligible |
| `semver_version_parse` | pcre2 | eligible |
| `semver_version_parse` | fancy_regex | eligible |
| `semver_version_parse` | fancy_regex_seek | eligible |
| `semver_version_parse` | regex | eligible |
| `semver_hyphen_range_captures` | rust | eligible |
| `semver_hyphen_range_captures` | rust_erroraware | eligible |
| `semver_hyphen_range_captures` | c | eligible |
| `semver_hyphen_range_captures` | onigmo | eligible |
| `semver_hyphen_range_captures` | pcre2_jit | eligible |
| `semver_hyphen_range_captures` | pcre2 | eligible |
| `semver_hyphen_range_captures` | fancy_regex | eligible |
| `semver_hyphen_range_captures` | fancy_regex_seek | eligible |
| `semver_hyphen_range_captures` | regex | eligible |
| `jinja_string_token` | rust | eligible |
| `jinja_string_token` | rust_erroraware | eligible |
| `jinja_string_token` | c | eligible |
| `jinja_string_token` | onigmo | eligible |
| `jinja_string_token` | pcre2_jit | eligible |
| `jinja_string_token` | pcre2 | eligible |
| `jinja_string_token` | fancy_regex | eligible |
| `jinja_string_token` | fancy_regex_seek | eligible |
| `jinja_string_token` | regex | eligible |
| `jinja_integer_token` | rust | eligible |
| `jinja_integer_token` | rust_erroraware | eligible |
| `jinja_integer_token` | c | eligible |
| `jinja_integer_token` | onigmo | eligible |
| `jinja_integer_token` | pcre2_jit | eligible |
| `jinja_integer_token` | pcre2 | eligible |
| `jinja_integer_token` | fancy_regex | eligible |
| `jinja_integer_token` | fancy_regex_seek | eligible |
| `jinja_integer_token` | regex | eligible |
| `jinja_float_token` | rust | eligible |
| `jinja_float_token` | rust_erroraware | eligible |
| `jinja_float_token` | c | eligible |
| `jinja_float_token` | onigmo | eligible |
| `jinja_float_token` | pcre2_jit | eligible |
| `jinja_float_token` | pcre2 | eligible |
| `jinja_float_token` | fancy_regex | eligible |
| `jinja_float_token` | fancy_regex_seek | eligible |
| `jinja_float_token` | regex | syntax_rejected |
| `django_email_local_part` | rust | eligible |
| `django_email_local_part` | rust_erroraware | eligible |
| `django_email_local_part` | c | eligible |
| `django_email_local_part` | onigmo | eligible |
| `django_email_local_part` | pcre2_jit | eligible |
| `django_email_local_part` | pcre2 | eligible |
| `django_email_local_part` | fancy_regex | syntax_rejected |
| `django_email_local_part` | fancy_regex_seek | syntax_rejected |
| `django_email_local_part` | regex | syntax_rejected |
| `django_email_domain` | rust | eligible |
| `django_email_domain` | rust_erroraware | eligible |
| `django_email_domain` | c | eligible |
| `django_email_domain` | onigmo | eligible |
| `django_email_domain` | pcre2_jit | eligible |
| `django_email_domain` | pcre2 | eligible |
| `django_email_domain` | fancy_regex | eligible |
| `django_email_domain` | fancy_regex_seek | eligible |
| `django_email_domain` | regex | syntax_rejected |
| `django_url_regex` | rust | eligible |
| `django_url_regex` | rust_erroraware | eligible |
| `django_url_regex` | c | eligible |
| `django_url_regex` | onigmo | eligible |
| `django_url_regex` | pcre2_jit | eligible |
| `django_url_regex` | pcre2 | eligible |
| `django_url_regex` | fancy_regex | eligible |
| `django_url_regex` | fancy_regex_seek | eligible |
| `django_url_regex` | regex | syntax_rejected |
| `fluent_bit_apache` | rust | eligible |
| `fluent_bit_apache` | rust_erroraware | eligible |
| `fluent_bit_apache` | c | eligible |
| `fluent_bit_apache` | onigmo | eligible |
| `fluent_bit_apache` | pcre2_jit | eligible |
| `fluent_bit_apache` | pcre2 | eligible |
| `fluent_bit_apache` | fancy_regex | eligible |
| `fluent_bit_apache` | fancy_regex_seek | eligible |
| `fluent_bit_apache` | regex | eligible |
| `fluent_bit_nginx` | rust | eligible |
| `fluent_bit_nginx` | rust_erroraware | eligible |
| `fluent_bit_nginx` | c | eligible |
| `fluent_bit_nginx` | onigmo | eligible |
| `fluent_bit_nginx` | pcre2_jit | eligible |
| `fluent_bit_nginx` | pcre2 | eligible |
| `fluent_bit_nginx` | fancy_regex | eligible |
| `fluent_bit_nginx` | fancy_regex_seek | eligible |
| `fluent_bit_nginx` | regex | eligible |
| `rails_underscore_regex_step` | rust | eligible |
| `rails_underscore_regex_step` | rust_erroraware | eligible |
| `rails_underscore_regex_step` | c | eligible |
| `rails_underscore_regex_step` | onigmo | eligible |
| `rails_underscore_regex_step` | pcre2_jit | eligible |
| `rails_underscore_regex_step` | pcre2 | eligible |
| `rails_underscore_regex_step` | fancy_regex | eligible |
| `rails_underscore_regex_step` | fancy_regex_seek | eligible |
| `rails_underscore_regex_step` | regex | syntax_rejected |
| `mastodon_hashtag_regex_step` | rust | eligible |
| `mastodon_hashtag_regex_step` | rust_erroraware | eligible |
| `mastodon_hashtag_regex_step` | c | eligible |
| `mastodon_hashtag_regex_step` | onigmo | eligible |
| `mastodon_hashtag_regex_step` | pcre2_jit | eligible |
| `mastodon_hashtag_regex_step` | pcre2 | eligible |
| `mastodon_hashtag_regex_step` | fancy_regex | semantic_difference |
| `mastodon_hashtag_regex_step` | fancy_regex_seek | semantic_difference |
| `mastodon_hashtag_regex_step` | regex | syntax_rejected |
| `python_markdown_smart_emphasis_re` | rust | eligible |
| `python_markdown_smart_emphasis_re` | rust_erroraware | eligible |
| `python_markdown_smart_emphasis_re` | c | eligible |
| `python_markdown_smart_emphasis_re` | onigmo | eligible |
| `python_markdown_smart_emphasis_re` | pcre2_jit | eligible |
| `python_markdown_smart_emphasis_re` | pcre2 | eligible |
| `python_markdown_smart_emphasis_re` | fancy_regex | eligible |
| `python_markdown_smart_emphasis_re` | fancy_regex_seek | eligible |
| `python_markdown_smart_emphasis_re` | regex | syntax_rejected |
| `python_markdown_smart_strong_em_re` | rust | eligible |
| `python_markdown_smart_strong_em_re` | rust_erroraware | eligible |
| `python_markdown_smart_strong_em_re` | c | eligible |
| `python_markdown_smart_strong_em_re` | onigmo | eligible |
| `python_markdown_smart_strong_em_re` | pcre2_jit | eligible |
| `python_markdown_smart_strong_em_re` | pcre2 | eligible |
| `python_markdown_smart_strong_em_re` | fancy_regex | eligible |
| `python_markdown_smart_strong_em_re` | fancy_regex_seek | eligible |
| `python_markdown_smart_strong_em_re` | regex | syntax_rejected |
| `wordpress_shortcode_captures` | rust | eligible |
| `wordpress_shortcode_captures` | rust_erroraware | eligible |
| `wordpress_shortcode_captures` | c | eligible |
| `wordpress_shortcode_captures` | onigmo | eligible |
| `wordpress_shortcode_captures` | pcre2_jit | eligible |
| `wordpress_shortcode_captures` | pcre2 | eligible |
| `wordpress_shortcode_captures` | fancy_regex | eligible |
| `wordpress_shortcode_captures` | fancy_regex_seek | eligible |
| `wordpress_shortcode_captures` | regex | syntax_rejected |
| `symfony_grapheme_chunks_1` | rust | eligible |
| `symfony_grapheme_chunks_1` | rust_erroraware | eligible |
| `symfony_grapheme_chunks_1` | c | eligible |
| `symfony_grapheme_chunks_1` | onigmo | semantic_difference |
| `symfony_grapheme_chunks_1` | pcre2_jit | eligible |
| `symfony_grapheme_chunks_1` | pcre2 | eligible |
| `symfony_grapheme_chunks_1` | fancy_regex | syntax_rejected |
| `symfony_grapheme_chunks_1` | fancy_regex_seek | syntax_rejected |
| `symfony_grapheme_chunks_1` | regex | syntax_rejected |
| `symfony_grapheme_chunks_2` | rust | eligible |
| `symfony_grapheme_chunks_2` | rust_erroraware | eligible |
| `symfony_grapheme_chunks_2` | c | eligible |
| `symfony_grapheme_chunks_2` | onigmo | eligible |
| `symfony_grapheme_chunks_2` | pcre2_jit | eligible |
| `symfony_grapheme_chunks_2` | pcre2 | eligible |
| `symfony_grapheme_chunks_2` | fancy_regex | syntax_rejected |
| `symfony_grapheme_chunks_2` | fancy_regex_seek | syntax_rejected |
| `symfony_grapheme_chunks_2` | regex | syntax_rejected |
| `literal_first` | rust | eligible |
| `literal_first` | rust_erroraware | eligible |
| `literal_first` | c | eligible |
| `literal_first` | onigmo | eligible |
| `literal_first` | pcre2_jit | eligible |
| `literal_first` | pcre2 | eligible |
| `literal_first` | fancy_regex | eligible |
| `literal_first` | fancy_regex_seek | eligible |
| `literal_first` | regex | eligible |
| `literal_middle` | rust | eligible |
| `literal_middle` | rust_erroraware | eligible |
| `literal_middle` | c | eligible |
| `literal_middle` | onigmo | eligible |
| `literal_middle` | pcre2_jit | eligible |
| `literal_middle` | pcre2 | eligible |
| `literal_middle` | fancy_regex | eligible |
| `literal_middle` | fancy_regex_seek | eligible |
| `literal_middle` | regex | eligible |
| `literal_end` | rust | eligible |
| `literal_end` | rust_erroraware | eligible |
| `literal_end` | c | eligible |
| `literal_end` | onigmo | eligible |
| `literal_end` | pcre2_jit | eligible |
| `literal_end` | pcre2 | eligible |
| `literal_end` | fancy_regex | eligible |
| `literal_end` | fancy_regex_seek | eligible |
| `literal_end` | regex | eligible |
| `literal_absent` | rust | eligible |
| `literal_absent` | rust_erroraware | eligible |
| `literal_absent` | c | eligible |
| `literal_absent` | onigmo | eligible |
| `literal_absent` | pcre2_jit | eligible |
| `literal_absent` | pcre2 | eligible |
| `literal_absent` | fancy_regex | eligible |
| `literal_absent` | fancy_regex_seek | eligible |
| `literal_absent` | regex | eligible |
| `linkify_http_tail` | rust | pending |
| `linkify_http_tail` | rust_erroraware | pending |
| `linkify_http_tail` | c | pending |
| `linkify_http_tail` | onigmo | pending |
| `linkify_http_tail` | pcre2_jit | pending |
| `linkify_http_tail` | pcre2 | pending |
| `linkify_http_tail` | fancy_regex | pending |
| `linkify_http_tail` | fancy_regex_seek | pending |
| `linkify_http_tail` | regex | pending |
| `php_cs_fixer_recursive_types` | rust | pending |
| `php_cs_fixer_recursive_types` | rust_erroraware | pending |
| `php_cs_fixer_recursive_types` | c | pending |
| `php_cs_fixer_recursive_types` | onigmo | pending |
| `php_cs_fixer_recursive_types` | pcre2_jit | pending |
| `php_cs_fixer_recursive_types` | pcre2 | pending |
| `php_cs_fixer_recursive_types` | fancy_regex | pending |
| `php_cs_fixer_recursive_types` | fancy_regex_seek | pending |
| `php_cs_fixer_recursive_types` | regex | pending |
| `ferrolink_markup_scan` | rust | eligible |
| `ferrolink_markup_scan` | rust_erroraware | eligible |
| `ferrolink_markup_scan` | c | eligible |
| `ferrolink_markup_scan` | onigmo | eligible |
| `ferrolink_markup_scan` | pcre2_jit | eligible |
| `ferrolink_markup_scan` | pcre2 | eligible |
| `ferrolink_markup_scan` | fancy_regex | eligible |
| `ferrolink_markup_scan` | fancy_regex_seek | eligible |
| `ferrolink_markup_scan` | regex | syntax_rejected |
| `ferrolink_attribute_split` | rust | eligible |
| `ferrolink_attribute_split` | rust_erroraware | eligible |
| `ferrolink_attribute_split` | c | eligible |
| `ferrolink_attribute_split` | onigmo | eligible |
| `ferrolink_attribute_split` | pcre2_jit | eligible |
| `ferrolink_attribute_split` | pcre2 | eligible |
| `ferrolink_attribute_split` | fancy_regex | eligible |
| `ferrolink_attribute_split` | fancy_regex_seek | eligible |
| `ferrolink_attribute_split` | regex | eligible |

## rust_erroraware / steady

Common cases: 27; families: 14. Pair-specific family-weighted ratio: 1.870.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.913 | 1.847–1.913 | Ferroni faster in every run interval |
| `uuid_v4` | 2.168 | 2.049–2.221 | Ferroni faster in every run interval |
| `ipv4_validation` | 9.588 | 8.982–9.899 | Ferroni faster in every run interval |
| `ipv6_validation` | 12.712 | 12.434–12.863 | Ferroni faster in every run interval |
| `semver_version_parse` | 1.114 | 1.071–1.123 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.130 | 1.108–1.184 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.175 | 1.153–1.182 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.176 | 1.155–1.315 | Ferroni faster in every run interval |
| `jinja_float_token` | 1.292 | 1.140–1.426 | Ferroni faster in every run interval |
| `django_email_local_part` | 5.976 | 5.565–6.093 | Ferroni faster in every run interval |
| `django_email_domain` | 8.116 | 7.432–8.207 | Ferroni faster in every run interval |
| `django_url_regex` | 11.190 | 9.982–11.255 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.122 | 1.106–1.154 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.300 | 1.267–1.314 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.051 | 1.013–1.072 | Ferroni faster in every run interval |
| `mastodon_hashtag_regex_step` | 1.024 | 1.010–1.054 | inconclusive |
| `python_markdown_smart_emphasis_re` | 1.103 | 0.977–1.113 | inconclusive |
| `python_markdown_smart_strong_em_re` | 1.069 | 1.043–1.120 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 1.014 | 0.961–1.057 | inconclusive |
| `symfony_grapheme_chunks_1` | 1.038 | 0.980–1.040 | inconclusive |
| `symfony_grapheme_chunks_2` | 1.058 | 1.049–1.079 | Ferroni faster in every run interval |
| `literal_first` | 1.768 | 1.762–1.786 | Ferroni faster in every run interval |
| `literal_middle` | 1.796 | 1.735–1.981 | Ferroni faster in every run interval |
| `literal_end` | 1.632 | 1.608–1.975 | Ferroni faster in every run interval |
| `literal_absent` | 1.556 | 1.555–1.685 | Ferroni faster in every run interval |
| `ferrolink_markup_scan` | 1.042 | 0.969–1.073 | inconclusive |
| `ferrolink_attribute_split` | 1.071 | 0.955–1.193 | inconclusive |

## rust_erroraware / compile

Common cases: 27; families: 14. Pair-specific family-weighted ratio: 1.001.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.030 | 0.988–1.031 | inconclusive |
| `uuid_v4` | 1.020 | 1.001–1.134 | inconclusive |
| `ipv4_validation` | 0.962 | 0.956–1.024 | inconclusive |
| `ipv6_validation` | 0.995 | 0.904–1.001 | inconclusive |
| `semver_version_parse` | 0.966 | 0.951–1.038 | inconclusive |
| `semver_hyphen_range_captures` | 1.007 | 0.928–1.008 | inconclusive |
| `jinja_string_token` | 0.970 | 0.966–1.016 | inconclusive |
| `jinja_integer_token` | 1.004 | 1.001–1.146 | inconclusive |
| `jinja_float_token` | 0.996 | 0.887–1.101 | inconclusive |
| `django_email_local_part` | 1.007 | 1.005–1.104 | inconclusive |
| `django_email_domain` | 0.972 | 0.927–1.043 | inconclusive |
| `django_url_regex` | 1.038 | 0.951–1.056 | inconclusive |
| `fluent_bit_apache` | 0.993 | 0.986–0.995 | inconclusive |
| `fluent_bit_nginx` | 0.948 | 0.932–1.082 | inconclusive |
| `rails_underscore_regex_step` | 1.003 | 0.965–1.045 | inconclusive |
| `mastodon_hashtag_regex_step` | 0.994 | 0.990–1.009 | inconclusive |
| `python_markdown_smart_emphasis_re` | 1.027 | 0.949–1.029 | inconclusive |
| `python_markdown_smart_strong_em_re` | 1.088 | 0.989–1.221 | inconclusive |
| `wordpress_shortcode_captures` | 0.999 | 0.982–1.010 | inconclusive |
| `symfony_grapheme_chunks_1` | 1.009 | 0.951–1.029 | inconclusive |
| `symfony_grapheme_chunks_2` | 0.979 | 0.938–1.004 | inconclusive |
| `literal_first` | 1.015 | 0.988–1.035 | inconclusive |
| `literal_middle` | 0.990 | 0.956–1.150 | inconclusive |
| `literal_end` | 1.038 | 0.930–1.095 | inconclusive |
| `literal_absent` | 1.003 | 0.992–1.063 | inconclusive |
| `ferrolink_markup_scan` | 0.993 | 0.984–1.047 | inconclusive |
| `ferrolink_attribute_split` | 0.976 | 0.916–1.119 | inconclusive |

## rust_erroraware / first_use

Common cases: 27; families: 14. Pair-specific family-weighted ratio: 0.783.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.534 | 0.500–0.535 | comparator faster in every run interval |
| `uuid_v4` | 0.563 | 0.556–0.636 | comparator faster in every run interval |
| `ipv4_validation` | 0.618 | 0.596–0.653 | comparator faster in every run interval |
| `ipv6_validation` | 0.692 | 0.649–0.706 | comparator faster in every run interval |
| `semver_version_parse` | 0.695 | 0.663–0.712 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.758 | 0.711–0.780 | comparator faster in every run interval |
| `jinja_string_token` | 0.524 | 0.512–0.530 | comparator faster in every run interval |
| `jinja_integer_token` | 0.726 | 0.696–0.826 | comparator faster in every run interval |
| `jinja_float_token` | 0.711 | 0.604–0.795 | comparator faster in every run interval |
| `django_email_local_part` | 0.748 | 0.711–0.787 | comparator faster in every run interval |
| `django_email_domain` | 0.794 | 0.775–0.794 | comparator faster in every run interval |
| `django_url_regex` | 0.820 | 0.726–0.860 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.556 | 0.516–0.637 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.536 | 0.506–0.556 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.987 | 0.970–1.012 | inconclusive |
| `mastodon_hashtag_regex_step` | 0.990 | 0.989–0.999 | inconclusive |
| `python_markdown_smart_emphasis_re` | 0.511 | 0.494–0.525 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.569 | 0.514–0.631 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 1.011 | 0.961–1.020 | inconclusive |
| `symfony_grapheme_chunks_1` | 0.950 | 0.919–1.021 | inconclusive |
| `symfony_grapheme_chunks_2` | 1.020 | 0.950–1.022 | inconclusive |
| `literal_first` | 1.008 | 1.000–1.047 | inconclusive |
| `literal_middle` | 1.008 | 0.905–1.194 | inconclusive |
| `literal_end` | 1.033 | 1.004–1.148 | inconclusive |
| `literal_absent` | 1.042 | 1.015–1.085 | inconclusive |
| `ferrolink_markup_scan` | 1.014 | 0.997–1.116 | inconclusive |
| `ferrolink_attribute_split` | 1.064 | 0.939–1.126 | inconclusive |

## c / steady

Common cases: 27; families: 14. Pair-specific family-weighted ratio: 3.655.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 5.548 | 5.297–5.845 | Ferroni faster in every run interval |
| `uuid_v4` | 4.349 | 4.047–4.407 | Ferroni faster in every run interval |
| `ipv4_validation` | 13.182 | 12.376–14.058 | Ferroni faster in every run interval |
| `ipv6_validation` | 14.888 | 14.606–14.893 | Ferroni faster in every run interval |
| `semver_version_parse` | 1.885 | 1.772–1.890 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.335 | 1.333–1.407 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.824 | 1.818–1.887 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.426 | 1.349–1.568 | Ferroni faster in every run interval |
| `jinja_float_token` | 1.298 | 1.205–1.381 | Ferroni faster in every run interval |
| `django_email_local_part` | 15.873 | 12.517–17.047 | Ferroni faster in every run interval |
| `django_email_domain` | 37.928 | 35.976–38.007 | Ferroni faster in every run interval |
| `django_url_regex` | 21.714 | 18.931–23.497 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 2.408 | 2.329–2.557 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 2.870 | 2.827–2.973 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.337 | 1.283–1.340 | Ferroni faster in every run interval |
| `mastodon_hashtag_regex_step` | 2.178 | 2.156–2.232 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 2.676 | 2.299–2.722 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 2.732 | 2.620–2.807 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 1.531 | 1.302–1.553 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_1` | 1.781 | 1.770–1.843 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_2` | 1.950 | 1.899–1.986 | Ferroni faster in every run interval |
| `literal_first` | 10.011 | 9.914–10.136 | Ferroni faster in every run interval |
| `literal_middle` | 11.131 | 10.706–11.962 | Ferroni faster in every run interval |
| `literal_end` | 12.226 | 11.999–12.278 | Ferroni faster in every run interval |
| `literal_absent` | 1.810 | 1.790–1.883 | Ferroni faster in every run interval |
| `ferrolink_markup_scan` | 2.461 | 2.240–2.549 | Ferroni faster in every run interval |
| `ferrolink_attribute_split` | 1.784 | 1.704–2.085 | Ferroni faster in every run interval |

## c / compile

Common cases: 27; families: 14. Pair-specific family-weighted ratio: 0.544.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 6.447 | 6.304–6.596 | Ferroni faster in every run interval |
| `uuid_v4` | 6.765 | 6.685–7.625 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.351 | 0.346–0.356 | comparator faster in every run interval |
| `ipv6_validation` | 0.403 | 0.347–0.408 | comparator faster in every run interval |
| `semver_version_parse` | 0.326 | 0.325–0.381 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.328 | 0.290–0.334 | comparator faster in every run interval |
| `jinja_string_token` | 0.210 | 0.209–0.231 | comparator faster in every run interval |
| `jinja_integer_token` | 3.050 | 2.920–3.397 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.877 | 0.818–0.911 | comparator faster in every run interval |
| `django_email_local_part` | 2.879 | 2.633–2.919 | Ferroni faster in every run interval |
| `django_email_domain` | 0.330 | 0.312–0.342 | comparator faster in every run interval |
| `django_url_regex` | 0.649 | 0.584–0.668 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.243 | 0.232–0.253 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.234 | 0.225–0.266 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.571 | 0.552–0.620 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 2.791 | 2.710–2.824 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.263 | 0.220–0.264 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.226 | 0.224–0.227 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.384 | 0.315–0.413 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.174 | 0.163–0.176 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.181 | 0.178–0.187 | comparator faster in every run interval |
| `literal_first` | 0.319 | 0.318–0.335 | comparator faster in every run interval |
| `literal_middle` | 0.320 | 0.311–0.372 | comparator faster in every run interval |
| `literal_end` | 0.321 | 0.301–0.324 | comparator faster in every run interval |
| `literal_absent` | 0.321 | 0.276–0.323 | comparator faster in every run interval |
| `ferrolink_markup_scan` | 0.262 | 0.255–0.268 | comparator faster in every run interval |
| `ferrolink_attribute_split` | 0.201 | 0.195–0.237 | comparator faster in every run interval |

## c / first_use

Common cases: 27; families: 14. Pair-specific family-weighted ratio: 0.487.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 3.293 | 3.265–3.328 | Ferroni faster in every run interval |
| `uuid_v4` | 3.802 | 3.785–4.085 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.232 | 0.231–0.250 | comparator faster in every run interval |
| `ipv6_validation` | 0.281 | 0.242–0.290 | comparator faster in every run interval |
| `semver_version_parse` | 0.252 | 0.235–0.252 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.250 | 0.225–0.254 | comparator faster in every run interval |
| `jinja_string_token` | 0.124 | 0.121–0.126 | comparator faster in every run interval |
| `jinja_integer_token` | 2.192 | 2.051–2.514 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.626 | 0.571–0.634 | comparator faster in every run interval |
| `django_email_local_part` | 2.066 | 1.960–2.175 | Ferroni faster in every run interval |
| `django_email_domain` | 0.277 | 0.253–0.282 | comparator faster in every run interval |
| `django_url_regex` | 0.529 | 0.453–0.581 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.147 | 0.143–0.148 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.156 | 0.134–0.164 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.592 | 0.580–0.607 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 2.834 | 2.668–2.841 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.151 | 0.128–0.153 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.144 | 0.140–0.146 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.390 | 0.324–0.431 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.386 | 0.354–0.413 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.350 | 0.315–0.356 | comparator faster in every run interval |
| `literal_first` | 0.539 | 0.528–0.576 | comparator faster in every run interval |
| `literal_middle` | 0.554 | 0.526–0.630 | comparator faster in every run interval |
| `literal_end` | 0.601 | 0.589–0.616 | comparator faster in every run interval |
| `literal_absent` | 0.404 | 0.390–0.415 | comparator faster in every run interval |
| `ferrolink_markup_scan` | 0.368 | 0.357–0.423 | comparator faster in every run interval |
| `ferrolink_attribute_split` | 0.241 | 0.223–0.242 | comparator faster in every run interval |

## onigmo / steady

Common cases: 26; families: 14. Pair-specific family-weighted ratio: 3.879.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 6.337 | 6.008–6.667 | Ferroni faster in every run interval |
| `uuid_v4` | 6.735 | 6.129–6.950 | Ferroni faster in every run interval |
| `ipv4_validation` | 10.325 | 9.674–11.015 | Ferroni faster in every run interval |
| `ipv6_validation` | 21.214 | 18.242–22.571 | Ferroni faster in every run interval |
| `semver_version_parse` | 1.976 | 1.776–2.061 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.232 | 1.203–1.332 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.125 | 1.117–1.216 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.459 | 1.411–1.678 | Ferroni faster in every run interval |
| `jinja_float_token` | 2.582 | 2.496–2.598 | Ferroni faster in every run interval |
| `django_email_local_part` | 8.657 | 7.661–9.020 | Ferroni faster in every run interval |
| `django_email_domain` | 68.798 | 66.582–70.521 | Ferroni faster in every run interval |
| `django_url_regex` | 54.064 | 49.155–56.342 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 2.563 | 2.522–2.587 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 3.494 | 3.058–3.615 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.107 | 0.968–1.113 | inconclusive |
| `mastodon_hashtag_regex_step` | 2.075 | 2.045–2.209 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 2.151 | 2.147–2.280 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 2.575 | 2.496–2.597 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 1.265 | 1.143–1.294 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_2` | 3.564 | 3.406–3.599 | Ferroni faster in every run interval |
| `literal_first` | 3.051 | 2.838–3.354 | Ferroni faster in every run interval |
| `literal_middle` | 3.736 | 3.685–3.977 | Ferroni faster in every run interval |
| `literal_end` | 5.806 | 5.601–6.532 | Ferroni faster in every run interval |
| `literal_absent` | 2.526 | 2.454–2.682 | Ferroni faster in every run interval |
| `ferrolink_markup_scan` | 2.870 | 2.751–3.187 | Ferroni faster in every run interval |
| `ferrolink_attribute_split` | 1.489 | 1.477–1.566 | Ferroni faster in every run interval |

## onigmo / compile

Common cases: 26; families: 14. Pair-specific family-weighted ratio: 0.706.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 6.098 | 5.834–6.599 | Ferroni faster in every run interval |
| `uuid_v4` | 6.192 | 5.857–6.483 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.336 | 0.302–0.336 | comparator faster in every run interval |
| `ipv6_validation` | 0.381 | 0.316–0.389 | comparator faster in every run interval |
| `semver_version_parse` | 0.315 | 0.312–0.340 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.351 | 0.301–0.352 | comparator faster in every run interval |
| `jinja_string_token` | 0.187 | 0.183–0.189 | comparator faster in every run interval |
| `jinja_integer_token` | 2.612 | 2.505–3.025 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.947 | 0.929–1.013 | inconclusive |
| `django_email_local_part` | 2.950 | 2.646–2.985 | Ferroni faster in every run interval |
| `django_email_domain` | 0.191 | 0.188–0.210 | comparator faster in every run interval |
| `django_url_regex` | 0.457 | 0.434–0.499 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.238 | 0.233–0.260 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.254 | 0.221–0.282 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.619 | 0.560–0.688 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 2.985 | 2.861–3.137 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.175 | 0.162–0.179 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.155 | 0.147–0.164 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.359 | 0.300–0.363 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 20.900 | 19.940–21.243 | Ferroni faster in every run interval |
| `literal_first` | 0.310 | 0.281–0.311 | comparator faster in every run interval |
| `literal_middle` | 0.272 | 0.267–0.289 | comparator faster in every run interval |
| `literal_end` | 0.272 | 0.264–0.333 | comparator faster in every run interval |
| `literal_absent` | 0.276 | 0.261–0.288 | comparator faster in every run interval |
| `ferrolink_markup_scan` | 0.236 | 0.207–0.244 | comparator faster in every run interval |
| `ferrolink_attribute_split` | 0.263 | 0.256–0.268 | comparator faster in every run interval |

## onigmo / first_use

Common cases: 26; families: 14. Pair-specific family-weighted ratio: 0.581.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 3.223 | 3.134–3.482 | Ferroni faster in every run interval |
| `uuid_v4` | 3.328 | 3.184–3.624 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.214 | 0.199–0.220 | comparator faster in every run interval |
| `ipv6_validation` | 0.262 | 0.227–0.271 | comparator faster in every run interval |
| `semver_version_parse` | 0.221 | 0.221–0.255 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.273 | 0.235–0.274 | comparator faster in every run interval |
| `jinja_string_token` | 0.103 | 0.103–0.105 | comparator faster in every run interval |
| `jinja_integer_token` | 1.932 | 1.770–2.199 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.677 | 0.662–0.761 | comparator faster in every run interval |
| `django_email_local_part` | 2.121 | 2.053–2.326 | Ferroni faster in every run interval |
| `django_email_domain` | 0.166 | 0.151–0.171 | comparator faster in every run interval |
| `django_url_regex` | 0.380 | 0.379–0.397 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.145 | 0.145–0.151 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.168 | 0.140–0.183 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.603 | 0.574–0.705 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 3.076 | 2.860–3.124 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.099 | 0.091–0.106 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.094 | 0.092–0.099 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.362 | 0.304–0.380 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 19.376 | 19.223–20.253 | Ferroni faster in every run interval |
| `literal_first` | 0.397 | 0.337–0.398 | comparator faster in every run interval |
| `literal_middle` | 0.348 | 0.325–0.374 | comparator faster in every run interval |
| `literal_end` | 0.407 | 0.385–0.464 | comparator faster in every run interval |
| `literal_absent` | 0.345 | 0.343–0.361 | comparator faster in every run interval |
| `ferrolink_markup_scan` | 0.358 | 0.357–0.367 | comparator faster in every run interval |
| `ferrolink_attribute_split` | 0.274 | 0.261–0.305 | comparator faster in every run interval |

## pcre2_jit / steady

Common cases: 27; families: 14. Pair-specific family-weighted ratio: 0.758.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.958 | 0.912–1.011 | inconclusive |
| `uuid_v4` | 0.985 | 0.975–1.111 | inconclusive |
| `ipv4_validation` | 2.023 | 2.004–2.167 | Ferroni faster in every run interval |
| `ipv6_validation` | 4.107 | 3.183–4.509 | Ferroni faster in every run interval |
| `semver_version_parse` | 0.546 | 0.528–0.551 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.521 | 0.488–0.547 | comparator faster in every run interval |
| `jinja_string_token` | 0.584 | 0.579–0.606 | comparator faster in every run interval |
| `jinja_integer_token` | 0.539 | 0.517–0.618 | comparator faster in every run interval |
| `jinja_float_token` | 0.651 | 0.613–0.679 | comparator faster in every run interval |
| `django_email_local_part` | 2.926 | 2.812–2.928 | Ferroni faster in every run interval |
| `django_email_domain` | 0.789 | 0.777–0.817 | comparator faster in every run interval |
| `django_url_regex` | 1.270 | 1.236–1.373 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 0.509 | 0.492–0.543 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.918 | 0.721–0.923 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.371 | 0.370–0.441 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.369 | 0.357–0.375 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.649 | 0.648–0.654 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.532 | 0.502–0.549 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.481 | 0.462–0.501 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.596 | 0.572–0.598 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.580 | 0.580–0.587 | comparator faster in every run interval |
| `literal_first` | 2.103 | 1.806–2.169 | Ferroni faster in every run interval |
| `literal_middle` | 1.910 | 1.853–2.004 | Ferroni faster in every run interval |
| `literal_end` | 1.714 | 1.661–2.009 | Ferroni faster in every run interval |
| `literal_absent` | 1.511 | 1.453–1.690 | Ferroni faster in every run interval |
| `ferrolink_markup_scan` | 0.365 | 0.339–0.389 | comparator faster in every run interval |
| `ferrolink_attribute_split` | 0.517 | 0.507–0.520 | comparator faster in every run interval |

## pcre2_jit / compile

Common cases: 27; families: 14. Pair-specific family-weighted ratio: 0.475.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.393 | 0.380–0.404 | comparator faster in every run interval |
| `uuid_v4` | 0.379 | 0.366–0.380 | comparator faster in every run interval |
| `ipv4_validation` | 0.384 | 0.369–0.389 | comparator faster in every run interval |
| `ipv6_validation` | 0.503 | 0.389–0.506 | comparator faster in every run interval |
| `semver_version_parse` | 0.502 | 0.485–0.509 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.471 | 0.458–0.514 | comparator faster in every run interval |
| `jinja_string_token` | 0.472 | 0.455–0.480 | comparator faster in every run interval |
| `jinja_integer_token` | 0.362 | 0.352–0.416 | comparator faster in every run interval |
| `jinja_float_token` | 0.336 | 0.336–0.353 | comparator faster in every run interval |
| `django_email_local_part` | 0.520 | 0.502–0.578 | comparator faster in every run interval |
| `django_email_domain` | 0.083 | 0.083–0.089 | comparator faster in every run interval |
| `django_url_regex` | 0.106 | 0.102–0.127 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.445 | 0.442–0.468 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.480 | 0.392–0.487 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 1.030 | 0.880–1.168 | inconclusive |
| `mastodon_hashtag_regex_step` | 0.321 | 0.312–0.322 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.777 | 0.769–0.792 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.631 | 0.568–0.672 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.708 | 0.642–0.785 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.471 | 0.445–0.491 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.500 | 0.492–0.534 | comparator faster in every run interval |
| `literal_first` | 2.851 | 2.325–2.997 | Ferroni faster in every run interval |
| `literal_middle` | 2.465 | 2.446–2.638 | Ferroni faster in every run interval |
| `literal_end` | 2.583 | 2.317–3.011 | Ferroni faster in every run interval |
| `literal_absent` | 2.524 | 2.254–2.889 | Ferroni faster in every run interval |
| `ferrolink_markup_scan` | 0.393 | 0.334–0.402 | comparator faster in every run interval |
| `ferrolink_attribute_split` | 0.508 | 0.504–0.539 | comparator faster in every run interval |

## pcre2_jit / first_use

Common cases: 27; families: 14. Pair-specific family-weighted ratio: 0.425.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.214 | 0.208–0.232 | comparator faster in every run interval |
| `uuid_v4` | 0.209 | 0.203–0.217 | comparator faster in every run interval |
| `ipv4_validation` | 0.285 | 0.284–0.291 | comparator faster in every run interval |
| `ipv6_validation` | 0.342 | 0.293–0.356 | comparator faster in every run interval |
| `semver_version_parse` | 0.401 | 0.370–0.411 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.370 | 0.328–0.406 | comparator faster in every run interval |
| `jinja_string_token` | 0.319 | 0.302–0.348 | comparator faster in every run interval |
| `jinja_integer_token` | 0.312 | 0.290–0.344 | comparator faster in every run interval |
| `jinja_float_token` | 0.276 | 0.264–0.349 | comparator faster in every run interval |
| `django_email_local_part` | 0.487 | 0.400–0.490 | comparator faster in every run interval |
| `django_email_domain` | 0.072 | 0.066–0.077 | comparator faster in every run interval |
| `django_url_regex` | 0.089 | 0.083–0.092 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.268 | 0.251–0.284 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.293 | 0.231–0.349 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 1.369 | 1.059–1.529 | Ferroni faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.341 | 0.339–0.355 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.483 | 0.474–0.491 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.392 | 0.380–0.410 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.775 | 0.727–0.870 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.755 | 0.697–0.772 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.820 | 0.794–0.839 | comparator faster in every run interval |
| `literal_first` | 3.094 | 2.383–3.186 | Ferroni faster in every run interval |
| `literal_middle` | 2.491 | 2.446–2.583 | Ferroni faster in every run interval |
| `literal_end` | 2.627 | 2.553–2.931 | Ferroni faster in every run interval |
| `literal_absent` | 2.636 | 2.476–2.902 | Ferroni faster in every run interval |
| `ferrolink_markup_scan` | 0.455 | 0.442–0.468 | comparator faster in every run interval |
| `ferrolink_attribute_split` | 0.617 | 0.543–0.699 | comparator faster in every run interval |

## pcre2 / steady

Common cases: 27; families: 14. Pair-specific family-weighted ratio: 2.127.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.974 | 1.787–2.021 | Ferroni faster in every run interval |
| `uuid_v4` | 1.949 | 1.945–2.228 | Ferroni faster in every run interval |
| `ipv4_validation` | 14.993 | 13.780–15.244 | Ferroni faster in every run interval |
| `ipv6_validation` | 21.309 | 17.582–23.736 | Ferroni faster in every run interval |
| `semver_version_parse` | 1.443 | 1.391–1.520 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.823 | 1.735–2.019 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.215 | 1.212–1.255 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.744 | 1.628–1.756 | Ferroni faster in every run interval |
| `jinja_float_token` | 1.854 | 1.826–1.870 | Ferroni faster in every run interval |
| `django_email_local_part` | 10.534 | 10.265–10.716 | Ferroni faster in every run interval |
| `django_email_domain` | 3.173 | 3.016–3.291 | Ferroni faster in every run interval |
| `django_url_regex` | 3.390 | 3.343–3.530 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.541 | 1.463–1.752 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.881 | 1.720–2.202 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.168 | 1.152–1.370 | Ferroni faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.779 | 0.742–0.794 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 3.387 | 3.104–3.434 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 3.724 | 3.645–3.858 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 1.347 | 1.306–1.371 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.858 | 0.815–0.903 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.791 | 0.777–0.837 | comparator faster in every run interval |
| `literal_first` | 3.820 | 3.654–4.458 | Ferroni faster in every run interval |
| `literal_middle` | 3.883 | 3.618–4.027 | Ferroni faster in every run interval |
| `literal_end` | 3.478 | 3.380–3.515 | Ferroni faster in every run interval |
| `literal_absent` | 1.669 | 1.558–1.702 | Ferroni faster in every run interval |
| `ferrolink_markup_scan` | 1.258 | 1.226–1.318 | Ferroni faster in every run interval |
| `ferrolink_attribute_split` | 1.123 | 1.081–1.153 | Ferroni faster in every run interval |

## pcre2 / compile

Common cases: 27; families: 14. Pair-specific family-weighted ratio: 0.138.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.159 | 0.146–0.164 | comparator faster in every run interval |
| `uuid_v4` | 0.151 | 0.147–0.157 | comparator faster in every run interval |
| `ipv4_validation` | 0.113 | 0.111–0.116 | comparator faster in every run interval |
| `ipv6_validation` | 0.162 | 0.126–0.182 | comparator faster in every run interval |
| `semver_version_parse` | 0.144 | 0.143–0.157 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.134 | 0.129–0.153 | comparator faster in every run interval |
| `jinja_string_token` | 0.102 | 0.100–0.103 | comparator faster in every run interval |
| `jinja_integer_token` | 0.117 | 0.104–0.128 | comparator faster in every run interval |
| `jinja_float_token` | 0.071 | 0.067–0.071 | comparator faster in every run interval |
| `django_email_local_part` | 0.295 | 0.285–0.301 | comparator faster in every run interval |
| `django_email_domain` | 0.085 | 0.082–0.087 | comparator faster in every run interval |
| `django_url_regex` | 0.083 | 0.083–0.089 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.097 | 0.093–0.106 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.097 | 0.093–0.126 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.279 | 0.260–0.321 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.157 | 0.157–0.170 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.142 | 0.131–0.155 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.116 | 0.109–0.117 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.199 | 0.190–0.220 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.071 | 0.066–0.073 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.070 | 0.068–0.071 | comparator faster in every run interval |
| `literal_first` | 0.244 | 0.243–0.256 | comparator faster in every run interval |
| `literal_middle` | 0.248 | 0.235–0.255 | comparator faster in every run interval |
| `literal_end` | 0.241 | 0.231–0.251 | comparator faster in every run interval |
| `literal_absent` | 0.254 | 0.224–0.279 | comparator faster in every run interval |
| `ferrolink_markup_scan` | 0.094 | 0.086–0.097 | comparator faster in every run interval |
| `ferrolink_attribute_split` | 0.187 | 0.181–0.193 | comparator faster in every run interval |

## pcre2 / first_use

Common cases: 27; families: 14. Pair-specific family-weighted ratio: 0.135.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.091 | 0.085–0.093 | comparator faster in every run interval |
| `uuid_v4` | 0.091 | 0.086–0.097 | comparator faster in every run interval |
| `ipv4_validation` | 0.083 | 0.079–0.084 | comparator faster in every run interval |
| `ipv6_validation` | 0.112 | 0.091–0.129 | comparator faster in every run interval |
| `semver_version_parse` | 0.108 | 0.106–0.127 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.109 | 0.103–0.125 | comparator faster in every run interval |
| `jinja_string_token` | 0.066 | 0.065–0.070 | comparator faster in every run interval |
| `jinja_integer_token` | 0.094 | 0.081–0.104 | comparator faster in every run interval |
| `jinja_float_token` | 0.051 | 0.049–0.057 | comparator faster in every run interval |
| `django_email_local_part` | 0.223 | 0.221–0.228 | comparator faster in every run interval |
| `django_email_domain` | 0.066 | 0.062–0.080 | comparator faster in every run interval |
| `django_url_regex` | 0.070 | 0.066–0.071 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.071 | 0.065–0.077 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.078 | 0.062–0.087 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.299 | 0.292–0.335 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.167 | 0.163–0.177 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.106 | 0.104–0.107 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.092 | 0.086–0.094 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.219 | 0.199–0.243 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.198 | 0.180–0.212 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.173 | 0.156–0.175 | comparator faster in every run interval |
| `literal_first` | 0.481 | 0.473–0.533 | comparator faster in every run interval |
| `literal_middle` | 0.511 | 0.505–0.511 | comparator faster in every run interval |
| `literal_end` | 0.481 | 0.481–0.486 | comparator faster in every run interval |
| `literal_absent` | 0.416 | 0.407–0.482 | comparator faster in every run interval |
| `ferrolink_markup_scan` | 0.155 | 0.155–0.159 | comparator faster in every run interval |
| `ferrolink_attribute_split` | 0.210 | 0.193–0.231 | comparator faster in every run interval |

## fancy_regex / steady

Common cases: 23; families: 12. Pair-specific family-weighted ratio: 2.991.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.033 | 0.986–1.121 | inconclusive |
| `uuid_v4` | 1.202 | 1.035–1.217 | Ferroni faster in every run interval |
| `ipv4_validation` | 1.616 | 1.587–1.819 | Ferroni faster in every run interval |
| `ipv6_validation` | 1.210 | 0.971–1.363 | inconclusive |
| `semver_version_parse` | 2.953 | 2.468–3.181 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 2.376 | 2.152–2.856 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.250 | 1.247–1.300 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.621 | 1.486–1.665 | Ferroni faster in every run interval |
| `jinja_float_token` | 2.840 | 2.808–2.891 | Ferroni faster in every run interval |
| `django_email_domain` | 9.236 | 9.018–9.729 | Ferroni faster in every run interval |
| `django_url_regex` | 23.837 | 23.368–25.596 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 2.167 | 2.001–2.200 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 2.831 | 2.506–2.928 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 3.240 | 3.003–3.271 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 3.257 | 3.203–3.498 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 4.885 | 4.610–4.957 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 2.151 | 2.144–2.190 | Ferroni faster in every run interval |
| `literal_first` | 1.434 | 1.428–1.557 | Ferroni faster in every run interval |
| `literal_middle` | 1.531 | 1.463–1.661 | Ferroni faster in every run interval |
| `literal_end` | 1.360 | 1.334–1.402 | Ferroni faster in every run interval |
| `literal_absent` | 1.355 | 1.231–1.364 | Ferroni faster in every run interval |
| `ferrolink_markup_scan` | 5.585 | 5.280–5.722 | Ferroni faster in every run interval |
| `ferrolink_attribute_split` | 1.858 | 1.821–1.905 | Ferroni faster in every run interval |

## fancy_regex / compile

Common cases: 23; families: 12. Pair-specific family-weighted ratio: 2.879.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.097 | 1.061–1.192 | Ferroni faster in every run interval |
| `uuid_v4` | 1.139 | 1.077–1.185 | Ferroni faster in every run interval |
| `ipv4_validation` | 1.085 | 0.994–1.165 | inconclusive |
| `ipv6_validation` | 1.269 | 1.033–1.530 | Ferroni faster in every run interval |
| `semver_version_parse` | 14.917 | 13.248–16.622 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 10.742 | 7.977–11.234 | Ferroni faster in every run interval |
| `jinja_string_token` | 3.242 | 3.216–3.362 | Ferroni faster in every run interval |
| `jinja_integer_token` | 2.794 | 2.520–2.858 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.439 | 0.430–0.440 | comparator faster in every run interval |
| `django_email_domain` | 12.485 | 12.294–13.071 | Ferroni faster in every run interval |
| `django_url_regex` | 11.677 | 11.595–11.919 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 2.587 | 2.409–2.720 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 2.640 | 2.303–2.942 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.807 | 1.607–1.821 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.946 | 0.831–0.952 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.748 | 0.696–0.753 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 2.072 | 1.860–2.075 | Ferroni faster in every run interval |
| `literal_first` | 1.776 | 1.698–1.919 | Ferroni faster in every run interval |
| `literal_middle` | 1.903 | 1.844–2.092 | Ferroni faster in every run interval |
| `literal_end` | 1.751 | 1.647–1.788 | Ferroni faster in every run interval |
| `literal_absent` | 1.825 | 1.537–1.987 | Ferroni faster in every run interval |
| `ferrolink_markup_scan` | 5.350 | 5.163–5.469 | Ferroni faster in every run interval |
| `ferrolink_attribute_split` | 5.994 | 5.856–6.030 | Ferroni faster in every run interval |

## fancy_regex / first_use

Common cases: 23; families: 12. Pair-specific family-weighted ratio: 2.295.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.804 | 0.788–0.910 | comparator faster in every run interval |
| `uuid_v4` | 0.836 | 0.816–0.901 | comparator faster in every run interval |
| `ipv4_validation` | 0.793 | 0.723–0.835 | comparator faster in every run interval |
| `ipv6_validation` | 0.902 | 0.740–1.121 | inconclusive |
| `semver_version_parse` | 11.249 | 9.332–12.443 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 8.179 | 5.958–8.729 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.793 | 1.793–1.831 | Ferroni faster in every run interval |
| `jinja_integer_token` | 2.099 | 1.846–2.133 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.306 | 0.297–0.325 | comparator faster in every run interval |
| `django_email_domain` | 9.754 | 9.573–11.444 | Ferroni faster in every run interval |
| `django_url_regex` | 9.363 | 8.948–9.571 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.567 | 1.495–1.621 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.591 | 1.348–1.713 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.978 | 1.788–2.110 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.462 | 0.425–0.470 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.401 | 0.396–0.412 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 2.210 | 2.065–2.211 | Ferroni faster in every run interval |
| `literal_first` | 1.829 | 1.740–2.101 | Ferroni faster in every run interval |
| `literal_middle` | 1.910 | 1.872–2.045 | Ferroni faster in every run interval |
| `literal_end` | 1.799 | 1.772–1.815 | Ferroni faster in every run interval |
| `literal_absent` | 1.815 | 1.729–1.863 | Ferroni faster in every run interval |
| `ferrolink_markup_scan` | 5.542 | 5.243–6.317 | Ferroni faster in every run interval |
| `ferrolink_attribute_split` | 6.795 | 5.934–7.149 | Ferroni faster in every run interval |

## fancy_regex_seek / steady

Common cases: 23; families: 12. Pair-specific family-weighted ratio: 2.910.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.994 | 0.964–1.044 | inconclusive |
| `uuid_v4` | 1.140 | 1.073–1.172 | Ferroni faster in every run interval |
| `ipv4_validation` | 1.771 | 1.563–2.225 | Ferroni faster in every run interval |
| `ipv6_validation` | 1.214 | 0.987–1.232 | inconclusive |
| `semver_version_parse` | 2.882 | 2.472–3.488 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 2.471 | 2.226–2.510 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.242 | 1.238–1.296 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.669 | 1.432–1.752 | Ferroni faster in every run interval |
| `jinja_float_token` | 2.807 | 2.666–2.863 | Ferroni faster in every run interval |
| `django_email_domain` | 9.011 | 8.641–9.343 | Ferroni faster in every run interval |
| `django_url_regex` | 23.928 | 23.048–24.293 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 2.208 | 2.181–2.257 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 2.900 | 2.624–3.061 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 2.957 | 2.942–3.280 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 3.297 | 3.287–3.650 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 4.960 | 4.575–4.993 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 2.140 | 2.032–2.199 | Ferroni faster in every run interval |
| `literal_first` | 1.433 | 1.431–1.510 | Ferroni faster in every run interval |
| `literal_middle` | 1.671 | 1.424–1.732 | Ferroni faster in every run interval |
| `literal_end` | 1.361 | 1.334–1.385 | Ferroni faster in every run interval |
| `literal_absent` | 1.309 | 1.240–1.347 | Ferroni faster in every run interval |
| `ferrolink_markup_scan` | 3.222 | 3.184–3.537 | Ferroni faster in every run interval |
| `ferrolink_attribute_split` | 1.875 | 1.829–1.952 | Ferroni faster in every run interval |

## fancy_regex_seek / compile

Common cases: 23; families: 12. Pair-specific family-weighted ratio: 3.207.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.096 | 1.064–1.123 | Ferroni faster in every run interval |
| `uuid_v4` | 1.176 | 1.114–1.182 | Ferroni faster in every run interval |
| `ipv4_validation` | 1.186 | 1.114–1.208 | Ferroni faster in every run interval |
| `ipv6_validation` | 1.310 | 1.029–1.325 | Ferroni faster in every run interval |
| `semver_version_parse` | 14.518 | 13.079–16.848 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 9.837 | 7.989–10.873 | Ferroni faster in every run interval |
| `jinja_string_token` | 3.346 | 3.226–3.348 | Ferroni faster in every run interval |
| `jinja_integer_token` | 2.783 | 2.488–3.050 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.432 | 0.431–0.446 | comparator faster in every run interval |
| `django_email_domain` | 12.426 | 11.712–12.651 | Ferroni faster in every run interval |
| `django_url_regex` | 11.869 | 11.576–11.898 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 2.687 | 2.651–2.917 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 2.741 | 2.660–2.900 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.800 | 1.638–1.810 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.865 | 0.844–0.947 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.750 | 0.728–0.764 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 5.458 | 5.126–5.478 | Ferroni faster in every run interval |
| `literal_first` | 1.729 | 1.728–2.060 | Ferroni faster in every run interval |
| `literal_middle` | 1.736 | 1.721–1.996 | Ferroni faster in every run interval |
| `literal_end` | 1.746 | 1.641–1.793 | Ferroni faster in every run interval |
| `literal_absent` | 1.773 | 1.717–1.785 | Ferroni faster in every run interval |
| `ferrolink_markup_scan` | 7.415 | 7.291–7.421 | Ferroni faster in every run interval |
| `ferrolink_attribute_split` | 8.556 | 8.106–8.897 | Ferroni faster in every run interval |

## fancy_regex_seek / first_use

Common cases: 23; families: 12. Pair-specific family-weighted ratio: 2.623.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.831 | 0.809–0.838 | comparator faster in every run interval |
| `uuid_v4` | 0.883 | 0.805–0.883 | comparator faster in every run interval |
| `ipv4_validation` | 0.892 | 0.863–0.900 | comparator faster in every run interval |
| `ipv6_validation` | 0.927 | 0.740–1.002 | inconclusive |
| `semver_version_parse` | 10.665 | 9.783–12.538 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 7.548 | 5.913–8.521 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.810 | 1.798–1.847 | Ferroni faster in every run interval |
| `jinja_integer_token` | 2.195 | 1.835–2.230 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.314 | 0.312–0.319 | comparator faster in every run interval |
| `django_email_domain` | 9.756 | 9.267–11.459 | Ferroni faster in every run interval |
| `django_url_regex` | 9.285 | 8.797–9.313 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.682 | 1.554–1.684 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.651 | 1.613–1.667 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 2.087 | 1.742–2.109 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.465 | 0.400–0.480 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.419 | 0.406–0.427 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 6.119 | 5.662–6.120 | Ferroni faster in every run interval |
| `literal_first` | 1.810 | 1.767–1.836 | Ferroni faster in every run interval |
| `literal_middle` | 1.937 | 1.750–2.113 | Ferroni faster in every run interval |
| `literal_end` | 1.770 | 1.763–1.794 | Ferroni faster in every run interval |
| `literal_absent` | 1.789 | 1.677–1.872 | Ferroni faster in every run interval |
| `ferrolink_markup_scan` | 8.996 | 8.388–10.203 | Ferroni faster in every run interval |
| `ferrolink_attribute_split` | 9.209 | 8.833–10.516 | Ferroni faster in every run interval |

## regex / steady

Common cases: 15; families: 7. Pair-specific family-weighted ratio: 1.492.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.939 | 0.932–0.971 | comparator faster in every run interval |
| `uuid_v4` | 1.082 | 0.992–1.097 | inconclusive |
| `ipv4_validation` | 1.539 | 1.449–1.581 | Ferroni faster in every run interval |
| `ipv6_validation` | 1.016 | 0.879–1.074 | inconclusive |
| `semver_version_parse` | 2.631 | 2.605–2.857 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 2.073 | 1.915–2.226 | Ferroni faster in every run interval |
| `jinja_string_token` | 0.853 | 0.828–0.857 | comparator faster in every run interval |
| `jinja_integer_token` | 1.213 | 1.130–1.319 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 2.008 | 1.990–2.093 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 2.698 | 2.680–2.747 | Ferroni faster in every run interval |
| `literal_first` | 1.126 | 1.115–1.132 | Ferroni faster in every run interval |
| `literal_middle` | 1.223 | 1.107–1.299 | Ferroni faster in every run interval |
| `literal_end` | 1.078 | 1.049–1.100 | Ferroni faster in every run interval |
| `literal_absent` | 1.043 | 0.987–1.073 | inconclusive |
| `ferrolink_attribute_split` | 2.116 | 2.082–2.194 | Ferroni faster in every run interval |

## regex / compile

Common cases: 15; families: 7. Pair-specific family-weighted ratio: 2.490.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.180 | 1.151–1.225 | Ferroni faster in every run interval |
| `uuid_v4` | 1.147 | 1.021–1.176 | inconclusive |
| `ipv4_validation` | 1.058 | 1.049–1.060 | Ferroni faster in every run interval |
| `ipv6_validation` | 1.120 | 0.950–1.141 | inconclusive |
| `semver_version_parse` | 15.261 | 14.737–16.432 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 9.725 | 7.891–9.944 | Ferroni faster in every run interval |
| `jinja_string_token` | 3.292 | 3.219–3.332 | Ferroni faster in every run interval |
| `jinja_integer_token` | 2.522 | 2.325–2.990 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 2.646 | 2.493–2.813 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 2.726 | 2.478–2.861 | Ferroni faster in every run interval |
| `literal_first` | 1.697 | 1.662–1.711 | Ferroni faster in every run interval |
| `literal_middle` | 1.871 | 1.706–2.085 | Ferroni faster in every run interval |
| `literal_end` | 1.692 | 1.584–1.725 | Ferroni faster in every run interval |
| `literal_absent` | 1.731 | 1.668–1.831 | Ferroni faster in every run interval |
| `ferrolink_attribute_split` | 2.850 | 2.760–2.869 | Ferroni faster in every run interval |

## regex / first_use

Common cases: 15; families: 7. Pair-specific family-weighted ratio: 1.970.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.884 | 0.834–0.890 | comparator faster in every run interval |
| `uuid_v4` | 0.871 | 0.771–0.888 | comparator faster in every run interval |
| `ipv4_validation` | 0.756 | 0.714–0.771 | comparator faster in every run interval |
| `ipv6_validation` | 0.819 | 0.764–0.827 | comparator faster in every run interval |
| `semver_version_parse` | 11.066 | 10.980–12.422 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 7.454 | 5.895–7.604 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.795 | 1.774–1.813 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.804 | 1.802–2.261 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.544 | 1.531–1.565 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.682 | 1.655–1.729 | Ferroni faster in every run interval |
| `literal_first` | 1.761 | 1.697–1.766 | Ferroni faster in every run interval |
| `literal_middle` | 1.789 | 1.718–2.159 | Ferroni faster in every run interval |
| `literal_end` | 1.700 | 1.695–1.749 | Ferroni faster in every run interval |
| `literal_absent` | 1.743 | 1.730–1.801 | Ferroni faster in every run interval |
| `ferrolink_attribute_split` | 3.630 | 3.290–3.768 | Ferroni faster in every run interval |

Raw samples, estimates, confidence intervals, failures, eligibility reasons, corpus snapshot and execution order are retained beside this report.

Memory, where requested, is fresh-process peak RSS including the binary, runtime, parsed catalog, compilation, input/output and allocator. It is not isolated compiled-pattern memory.
