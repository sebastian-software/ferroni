# Production regex comparison

Host: macOS-26.3-arm64-arm-64bit-Mach-O; arm64.

Publication candidate: review host stability, raw samples, coverage and run intervals before publishing.

Ratios are comparator / Ferroni. Compile and first-use times concern one pattern; steady times concern the complete fixture batch.

Each comparison below uses only its explicitly listed common tasks. Families have equal aggregate weight; architectures are never combined.

## Eligibility

| Case | Engine | Status |
| --- | --- | --- |
| `uuid_shape` | rust | eligible |
| `uuid_shape` | rust_erroraware | eligible |
| `uuid_shape` | c | eligible |
| `uuid_shape` | onigmo | eligible |
| `uuid_shape` | pcre2_jit | eligible |
| `uuid_shape` | pcre2 | eligible |
| `uuid_shape` | fancy_regex | eligible |
| `uuid_shape` | fancy_regex_seek | eligible |
| `uuid_shape` | regex | eligible |
| `uuid_v4` | rust | eligible |
| `uuid_v4` | rust_erroraware | eligible |
| `uuid_v4` | c | eligible |
| `uuid_v4` | onigmo | eligible |
| `uuid_v4` | pcre2_jit | eligible |
| `uuid_v4` | pcre2 | eligible |
| `uuid_v4` | fancy_regex | eligible |
| `uuid_v4` | fancy_regex_seek | eligible |
| `uuid_v4` | regex | eligible |
| `ipv4_validation` | rust | eligible |
| `ipv4_validation` | rust_erroraware | eligible |
| `ipv4_validation` | c | eligible |
| `ipv4_validation` | onigmo | eligible |
| `ipv4_validation` | pcre2_jit | eligible |
| `ipv4_validation` | pcre2 | eligible |
| `ipv4_validation` | fancy_regex | eligible |
| `ipv4_validation` | fancy_regex_seek | eligible |
| `ipv4_validation` | regex | eligible |
| `ipv6_validation` | rust | eligible |
| `ipv6_validation` | rust_erroraware | eligible |
| `ipv6_validation` | c | eligible |
| `ipv6_validation` | onigmo | eligible |
| `ipv6_validation` | pcre2_jit | eligible |
| `ipv6_validation` | pcre2 | eligible |
| `ipv6_validation` | fancy_regex | eligible |
| `ipv6_validation` | fancy_regex_seek | eligible |
| `ipv6_validation` | regex | eligible |
| `semver_version_parse` | rust | eligible |
| `semver_version_parse` | rust_erroraware | eligible |
| `semver_version_parse` | c | eligible |
| `semver_version_parse` | onigmo | eligible |
| `semver_version_parse` | pcre2_jit | eligible |
| `semver_version_parse` | pcre2 | eligible |
| `semver_version_parse` | fancy_regex | eligible |
| `semver_version_parse` | fancy_regex_seek | eligible |
| `semver_version_parse` | regex | eligible |
| `semver_hyphen_range_captures` | rust | eligible |
| `semver_hyphen_range_captures` | rust_erroraware | eligible |
| `semver_hyphen_range_captures` | c | eligible |
| `semver_hyphen_range_captures` | onigmo | eligible |
| `semver_hyphen_range_captures` | pcre2_jit | eligible |
| `semver_hyphen_range_captures` | pcre2 | eligible |
| `semver_hyphen_range_captures` | fancy_regex | eligible |
| `semver_hyphen_range_captures` | fancy_regex_seek | eligible |
| `semver_hyphen_range_captures` | regex | eligible |
| `jinja_string_token` | rust | eligible |
| `jinja_string_token` | rust_erroraware | eligible |
| `jinja_string_token` | c | eligible |
| `jinja_string_token` | onigmo | eligible |
| `jinja_string_token` | pcre2_jit | eligible |
| `jinja_string_token` | pcre2 | eligible |
| `jinja_string_token` | fancy_regex | eligible |
| `jinja_string_token` | fancy_regex_seek | eligible |
| `jinja_string_token` | regex | eligible |
| `jinja_integer_token` | rust | eligible |
| `jinja_integer_token` | rust_erroraware | eligible |
| `jinja_integer_token` | c | eligible |
| `jinja_integer_token` | onigmo | eligible |
| `jinja_integer_token` | pcre2_jit | eligible |
| `jinja_integer_token` | pcre2 | eligible |
| `jinja_integer_token` | fancy_regex | eligible |
| `jinja_integer_token` | fancy_regex_seek | eligible |
| `jinja_integer_token` | regex | eligible |
| `jinja_float_token` | rust | eligible |
| `jinja_float_token` | rust_erroraware | eligible |
| `jinja_float_token` | c | eligible |
| `jinja_float_token` | onigmo | eligible |
| `jinja_float_token` | pcre2_jit | eligible |
| `jinja_float_token` | pcre2 | eligible |
| `jinja_float_token` | fancy_regex | eligible |
| `jinja_float_token` | fancy_regex_seek | eligible |
| `jinja_float_token` | regex | syntax_rejected |
| `django_email_local_part` | rust | eligible |
| `django_email_local_part` | rust_erroraware | eligible |
| `django_email_local_part` | c | eligible |
| `django_email_local_part` | onigmo | eligible |
| `django_email_local_part` | pcre2_jit | eligible |
| `django_email_local_part` | pcre2 | eligible |
| `django_email_local_part` | fancy_regex | syntax_rejected |
| `django_email_local_part` | fancy_regex_seek | syntax_rejected |
| `django_email_local_part` | regex | syntax_rejected |
| `django_email_domain` | rust | eligible |
| `django_email_domain` | rust_erroraware | eligible |
| `django_email_domain` | c | eligible |
| `django_email_domain` | onigmo | eligible |
| `django_email_domain` | pcre2_jit | eligible |
| `django_email_domain` | pcre2 | eligible |
| `django_email_domain` | fancy_regex | eligible |
| `django_email_domain` | fancy_regex_seek | eligible |
| `django_email_domain` | regex | syntax_rejected |
| `django_url_regex` | rust | eligible |
| `django_url_regex` | rust_erroraware | eligible |
| `django_url_regex` | c | eligible |
| `django_url_regex` | onigmo | eligible |
| `django_url_regex` | pcre2_jit | eligible |
| `django_url_regex` | pcre2 | eligible |
| `django_url_regex` | fancy_regex | eligible |
| `django_url_regex` | fancy_regex_seek | eligible |
| `django_url_regex` | regex | syntax_rejected |
| `fluent_bit_apache` | rust | eligible |
| `fluent_bit_apache` | rust_erroraware | eligible |
| `fluent_bit_apache` | c | eligible |
| `fluent_bit_apache` | onigmo | eligible |
| `fluent_bit_apache` | pcre2_jit | eligible |
| `fluent_bit_apache` | pcre2 | eligible |
| `fluent_bit_apache` | fancy_regex | eligible |
| `fluent_bit_apache` | fancy_regex_seek | eligible |
| `fluent_bit_apache` | regex | eligible |
| `fluent_bit_nginx` | rust | eligible |
| `fluent_bit_nginx` | rust_erroraware | eligible |
| `fluent_bit_nginx` | c | eligible |
| `fluent_bit_nginx` | onigmo | eligible |
| `fluent_bit_nginx` | pcre2_jit | eligible |
| `fluent_bit_nginx` | pcre2 | eligible |
| `fluent_bit_nginx` | fancy_regex | eligible |
| `fluent_bit_nginx` | fancy_regex_seek | eligible |
| `fluent_bit_nginx` | regex | eligible |
| `rails_underscore_regex_step` | rust | eligible |
| `rails_underscore_regex_step` | rust_erroraware | eligible |
| `rails_underscore_regex_step` | c | eligible |
| `rails_underscore_regex_step` | onigmo | eligible |
| `rails_underscore_regex_step` | pcre2_jit | eligible |
| `rails_underscore_regex_step` | pcre2 | eligible |
| `rails_underscore_regex_step` | fancy_regex | eligible |
| `rails_underscore_regex_step` | fancy_regex_seek | eligible |
| `rails_underscore_regex_step` | regex | syntax_rejected |
| `mastodon_hashtag_regex_step` | rust | eligible |
| `mastodon_hashtag_regex_step` | rust_erroraware | eligible |
| `mastodon_hashtag_regex_step` | c | eligible |
| `mastodon_hashtag_regex_step` | onigmo | eligible |
| `mastodon_hashtag_regex_step` | pcre2_jit | eligible |
| `mastodon_hashtag_regex_step` | pcre2 | eligible |
| `mastodon_hashtag_regex_step` | fancy_regex | semantic_difference |
| `mastodon_hashtag_regex_step` | fancy_regex_seek | semantic_difference |
| `mastodon_hashtag_regex_step` | regex | syntax_rejected |
| `python_markdown_smart_emphasis_re` | rust | eligible |
| `python_markdown_smart_emphasis_re` | rust_erroraware | eligible |
| `python_markdown_smart_emphasis_re` | c | eligible |
| `python_markdown_smart_emphasis_re` | onigmo | eligible |
| `python_markdown_smart_emphasis_re` | pcre2_jit | eligible |
| `python_markdown_smart_emphasis_re` | pcre2 | eligible |
| `python_markdown_smart_emphasis_re` | fancy_regex | eligible |
| `python_markdown_smart_emphasis_re` | fancy_regex_seek | eligible |
| `python_markdown_smart_emphasis_re` | regex | syntax_rejected |
| `python_markdown_smart_strong_em_re` | rust | eligible |
| `python_markdown_smart_strong_em_re` | rust_erroraware | eligible |
| `python_markdown_smart_strong_em_re` | c | eligible |
| `python_markdown_smart_strong_em_re` | onigmo | eligible |
| `python_markdown_smart_strong_em_re` | pcre2_jit | eligible |
| `python_markdown_smart_strong_em_re` | pcre2 | eligible |
| `python_markdown_smart_strong_em_re` | fancy_regex | eligible |
| `python_markdown_smart_strong_em_re` | fancy_regex_seek | eligible |
| `python_markdown_smart_strong_em_re` | regex | syntax_rejected |
| `wordpress_shortcode_captures` | rust | eligible |
| `wordpress_shortcode_captures` | rust_erroraware | eligible |
| `wordpress_shortcode_captures` | c | eligible |
| `wordpress_shortcode_captures` | onigmo | eligible |
| `wordpress_shortcode_captures` | pcre2_jit | eligible |
| `wordpress_shortcode_captures` | pcre2 | eligible |
| `wordpress_shortcode_captures` | fancy_regex | eligible |
| `wordpress_shortcode_captures` | fancy_regex_seek | eligible |
| `wordpress_shortcode_captures` | regex | syntax_rejected |
| `symfony_grapheme_chunks_1` | rust | eligible |
| `symfony_grapheme_chunks_1` | rust_erroraware | eligible |
| `symfony_grapheme_chunks_1` | c | eligible |
| `symfony_grapheme_chunks_1` | onigmo | semantic_difference |
| `symfony_grapheme_chunks_1` | pcre2_jit | eligible |
| `symfony_grapheme_chunks_1` | pcre2 | eligible |
| `symfony_grapheme_chunks_1` | fancy_regex | syntax_rejected |
| `symfony_grapheme_chunks_1` | fancy_regex_seek | syntax_rejected |
| `symfony_grapheme_chunks_1` | regex | syntax_rejected |
| `symfony_grapheme_chunks_2` | rust | eligible |
| `symfony_grapheme_chunks_2` | rust_erroraware | eligible |
| `symfony_grapheme_chunks_2` | c | eligible |
| `symfony_grapheme_chunks_2` | onigmo | eligible |
| `symfony_grapheme_chunks_2` | pcre2_jit | eligible |
| `symfony_grapheme_chunks_2` | pcre2 | eligible |
| `symfony_grapheme_chunks_2` | fancy_regex | syntax_rejected |
| `symfony_grapheme_chunks_2` | fancy_regex_seek | syntax_rejected |
| `symfony_grapheme_chunks_2` | regex | syntax_rejected |
| `literal_first` | rust | eligible |
| `literal_first` | rust_erroraware | eligible |
| `literal_first` | c | eligible |
| `literal_first` | onigmo | eligible |
| `literal_first` | pcre2_jit | eligible |
| `literal_first` | pcre2 | eligible |
| `literal_first` | fancy_regex | eligible |
| `literal_first` | fancy_regex_seek | eligible |
| `literal_first` | regex | eligible |
| `literal_middle` | rust | eligible |
| `literal_middle` | rust_erroraware | eligible |
| `literal_middle` | c | eligible |
| `literal_middle` | onigmo | eligible |
| `literal_middle` | pcre2_jit | eligible |
| `literal_middle` | pcre2 | eligible |
| `literal_middle` | fancy_regex | eligible |
| `literal_middle` | fancy_regex_seek | eligible |
| `literal_middle` | regex | eligible |
| `literal_end` | rust | eligible |
| `literal_end` | rust_erroraware | eligible |
| `literal_end` | c | eligible |
| `literal_end` | onigmo | eligible |
| `literal_end` | pcre2_jit | eligible |
| `literal_end` | pcre2 | eligible |
| `literal_end` | fancy_regex | eligible |
| `literal_end` | fancy_regex_seek | eligible |
| `literal_end` | regex | eligible |
| `literal_absent` | rust | eligible |
| `literal_absent` | rust_erroraware | eligible |
| `literal_absent` | c | eligible |
| `literal_absent` | onigmo | eligible |
| `literal_absent` | pcre2_jit | eligible |
| `literal_absent` | pcre2 | eligible |
| `literal_absent` | fancy_regex | eligible |
| `literal_absent` | fancy_regex_seek | eligible |
| `literal_absent` | regex | eligible |
| `linkify_http_tail` | rust | pending |
| `linkify_http_tail` | rust_erroraware | pending |
| `linkify_http_tail` | c | pending |
| `linkify_http_tail` | onigmo | pending |
| `linkify_http_tail` | pcre2_jit | pending |
| `linkify_http_tail` | pcre2 | pending |
| `linkify_http_tail` | fancy_regex | pending |
| `linkify_http_tail` | fancy_regex_seek | pending |
| `linkify_http_tail` | regex | pending |
| `php_cs_fixer_recursive_types` | rust | pending |
| `php_cs_fixer_recursive_types` | rust_erroraware | pending |
| `php_cs_fixer_recursive_types` | c | pending |
| `php_cs_fixer_recursive_types` | onigmo | pending |
| `php_cs_fixer_recursive_types` | pcre2_jit | pending |
| `php_cs_fixer_recursive_types` | pcre2 | pending |
| `php_cs_fixer_recursive_types` | fancy_regex | pending |
| `php_cs_fixer_recursive_types` | fancy_regex_seek | pending |
| `php_cs_fixer_recursive_types` | regex | pending |

## rust_erroraware / steady

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 1.774.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.630 | 1.627–1.774 | Ferroni faster in every run interval |
| `uuid_v4` | 1.759 | 1.667–1.856 | Ferroni faster in every run interval |
| `ipv4_validation` | 5.578 | 5.408–5.780 | Ferroni faster in every run interval |
| `ipv6_validation` | 12.339 | 12.054–12.692 | Ferroni faster in every run interval |
| `semver_version_parse` | 1.084 | 0.977–1.095 | inconclusive |
| `semver_hyphen_range_captures` | 1.067 | 1.066–1.081 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.119 | 1.075–1.123 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.148 | 1.130–1.155 | Ferroni faster in every run interval |
| `jinja_float_token` | 1.287 | 1.271–1.327 | Ferroni faster in every run interval |
| `django_email_local_part` | 3.069 | 2.823–3.115 | Ferroni faster in every run interval |
| `django_email_domain` | 7.538 | 7.451–8.136 | Ferroni faster in every run interval |
| `django_url_regex` | 10.833 | 10.784–11.032 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.209 | 1.198–1.220 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.338 | 1.157–1.363 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 0.995 | 0.995–1.004 | inconclusive |
| `mastodon_hashtag_regex_step` | 1.054 | 1.044–1.079 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 1.087 | 1.008–1.112 | inconclusive |
| `python_markdown_smart_strong_em_re` | 1.073 | 1.046–1.075 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 1.058 | 1.056–1.084 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_1` | 1.041 | 1.035–1.187 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_2` | 1.053 | 1.022–1.090 | inconclusive |
| `literal_first` | 1.181 | 1.128–1.221 | Ferroni faster in every run interval |
| `literal_middle` | 1.196 | 1.166–1.203 | Ferroni faster in every run interval |
| `literal_end` | 1.148 | 1.142–1.195 | Ferroni faster in every run interval |
| `literal_absent` | 1.135 | 1.122–1.177 | Ferroni faster in every run interval |

## rust_erroraware / compile

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 1.003.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.006 | 0.986–1.008 | inconclusive |
| `uuid_v4` | 1.005 | 0.999–1.052 | inconclusive |
| `ipv4_validation` | 1.041 | 1.023–1.071 | inconclusive |
| `ipv6_validation` | 0.988 | 0.891–1.100 | inconclusive |
| `semver_version_parse` | 0.999 | 0.862–1.055 | inconclusive |
| `semver_hyphen_range_captures` | 0.972 | 0.968–0.990 | inconclusive |
| `jinja_string_token` | 1.026 | 1.022–1.036 | inconclusive |
| `jinja_integer_token` | 0.986 | 0.979–1.040 | inconclusive |
| `jinja_float_token` | 1.030 | 0.996–1.065 | inconclusive |
| `django_email_local_part` | 0.997 | 0.959–1.063 | inconclusive |
| `django_email_domain` | 1.009 | 0.819–1.015 | inconclusive |
| `django_url_regex` | 0.989 | 0.984–1.013 | inconclusive |
| `fluent_bit_apache` | 0.999 | 0.962–1.010 | inconclusive |
| `fluent_bit_nginx` | 0.977 | 0.828–1.071 | inconclusive |
| `rails_underscore_regex_step` | 0.977 | 0.954–1.010 | inconclusive |
| `mastodon_hashtag_regex_step` | 0.995 | 0.981–1.020 | inconclusive |
| `python_markdown_smart_emphasis_re` | 0.989 | 0.916–0.995 | inconclusive |
| `python_markdown_smart_strong_em_re` | 1.016 | 0.988–1.022 | inconclusive |
| `wordpress_shortcode_captures` | 1.029 | 1.002–1.072 | inconclusive |
| `symfony_grapheme_chunks_1` | 1.069 | 1.005–1.149 | inconclusive |
| `symfony_grapheme_chunks_2` | 0.973 | 0.899–1.010 | inconclusive |
| `literal_first` | 0.983 | 0.980–1.015 | inconclusive |
| `literal_middle` | 1.024 | 0.994–1.032 | inconclusive |
| `literal_end` | 1.016 | 0.985–1.038 | inconclusive |
| `literal_absent` | 1.077 | 0.995–1.125 | inconclusive |

## rust_erroraware / first_use

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.955.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.798 | 0.793–0.837 | comparator faster in every run interval |
| `uuid_v4` | 0.790 | 0.790–0.837 | comparator faster in every run interval |
| `ipv4_validation` | 0.938 | 0.928–1.051 | inconclusive |
| `ipv6_validation` | 1.006 | 0.962–1.038 | inconclusive |
| `semver_version_parse` | 0.980 | 0.860–0.984 | inconclusive |
| `semver_hyphen_range_captures` | 0.990 | 0.959–1.026 | inconclusive |
| `jinja_string_token` | 0.916 | 0.883–0.929 | comparator faster in every run interval |
| `jinja_integer_token` | 0.984 | 0.900–0.992 | inconclusive |
| `jinja_float_token` | 0.991 | 0.968–1.030 | inconclusive |
| `django_email_local_part` | 1.005 | 0.971–1.010 | inconclusive |
| `django_email_domain` | 0.987 | 0.875–1.020 | inconclusive |
| `django_url_regex` | 0.996 | 0.980–0.999 | inconclusive |
| `fluent_bit_apache` | 0.890 | 0.832–0.914 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.879 | 0.804–0.908 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.991 | 0.986–0.995 | inconclusive |
| `mastodon_hashtag_regex_step` | 0.996 | 0.992–1.020 | inconclusive |
| `python_markdown_smart_emphasis_re` | 0.829 | 0.747–0.870 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.866 | 0.861–0.878 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.997 | 0.987–1.066 | inconclusive |
| `symfony_grapheme_chunks_1` | 1.011 | 1.004–1.171 | inconclusive |
| `symfony_grapheme_chunks_2` | 0.978 | 0.955–0.991 | inconclusive |
| `literal_first` | 1.011 | 0.947–1.044 | inconclusive |
| `literal_middle` | 1.033 | 1.006–1.049 | inconclusive |
| `literal_end` | 1.021 | 0.984–1.024 | inconclusive |
| `literal_absent` | 1.088 | 1.005–1.246 | inconclusive |

## c / steady

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 3.643.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 5.657 | 5.105–5.996 | Ferroni faster in every run interval |
| `uuid_v4` | 3.941 | 3.768–4.193 | Ferroni faster in every run interval |
| `ipv4_validation` | 8.487 | 7.669–8.622 | Ferroni faster in every run interval |
| `ipv6_validation` | 15.107 | 14.831–15.442 | Ferroni faster in every run interval |
| `semver_version_parse` | 1.913 | 1.715–1.955 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.302 | 1.272–1.382 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.738 | 1.696–1.769 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.461 | 1.424–1.487 | Ferroni faster in every run interval |
| `jinja_float_token` | 1.313 | 1.294–1.503 | Ferroni faster in every run interval |
| `django_email_local_part` | 8.654 | 8.257–9.191 | Ferroni faster in every run interval |
| `django_email_domain` | 37.934 | 37.452–38.604 | Ferroni faster in every run interval |
| `django_url_regex` | 21.024 | 20.495–21.155 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 2.264 | 2.165–2.348 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 2.373 | 1.970–2.439 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.368 | 1.365–1.371 | Ferroni faster in every run interval |
| `mastodon_hashtag_regex_step` | 2.344 | 2.209–2.361 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 2.760 | 2.444–2.933 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 2.680 | 2.625–2.734 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 1.546 | 1.533–1.651 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_1` | 1.822 | 1.812–2.144 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_2` | 1.884 | 1.862–1.926 | Ferroni faster in every run interval |
| `literal_first` | 9.977 | 9.888–10.222 | Ferroni faster in every run interval |
| `literal_middle` | 11.552 | 10.681–11.664 | Ferroni faster in every run interval |
| `literal_end` | 12.465 | 12.414–12.808 | Ferroni faster in every run interval |
| `literal_absent` | 1.823 | 1.781–2.059 | Ferroni faster in every run interval |

## c / compile

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.381.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 4.750 | 4.297–4.786 | Ferroni faster in every run interval |
| `uuid_v4` | 4.905 | 4.864–5.085 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.269 | 0.248–0.269 | comparator faster in every run interval |
| `ipv6_validation` | 0.276 | 0.251–0.312 | comparator faster in every run interval |
| `semver_version_parse` | 0.271 | 0.232–0.284 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.261 | 0.246–0.270 | comparator faster in every run interval |
| `jinja_string_token` | 0.125 | 0.107–0.126 | comparator faster in every run interval |
| `jinja_integer_token` | 2.234 | 2.232–2.318 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.659 | 0.655–0.693 | comparator faster in every run interval |
| `django_email_local_part` | 2.234 | 1.950–2.324 | Ferroni faster in every run interval |
| `django_email_domain` | 0.211 | 0.166–0.214 | comparator faster in every run interval |
| `django_url_regex` | 0.361 | 0.355–0.372 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.145 | 0.145–0.152 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.150 | 0.119–0.152 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.405 | 0.366–0.406 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 1.420 | 1.309–1.466 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.150 | 0.128–0.159 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.125 | 0.122–0.130 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.234 | 0.232–0.237 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.084 | 0.082–0.089 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.077 | 0.070–0.079 | comparator faster in every run interval |
| `literal_first` | 0.322 | 0.315–0.324 | comparator faster in every run interval |
| `literal_middle` | 0.333 | 0.327–0.342 | comparator faster in every run interval |
| `literal_end` | 0.334 | 0.321–0.341 | comparator faster in every run interval |
| `literal_absent` | 0.328 | 0.323–0.366 | comparator faster in every run interval |

## c / first_use

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.411.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 3.693 | 3.397–3.972 | Ferroni faster in every run interval |
| `uuid_v4` | 3.813 | 3.767–3.948 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.253 | 0.246–0.258 | comparator faster in every run interval |
| `ipv6_validation` | 0.278 | 0.273–0.296 | comparator faster in every run interval |
| `semver_version_parse` | 0.266 | 0.232–0.270 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.261 | 0.235–0.271 | comparator faster in every run interval |
| `jinja_string_token` | 0.127 | 0.109–0.128 | comparator faster in every run interval |
| `jinja_integer_token` | 2.150 | 2.020–2.249 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.641 | 0.636–0.758 | comparator faster in every run interval |
| `django_email_local_part` | 2.214 | 1.891–2.284 | Ferroni faster in every run interval |
| `django_email_domain` | 0.210 | 0.186–0.211 | comparator faster in every run interval |
| `django_url_regex` | 0.371 | 0.368–0.378 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.144 | 0.138–0.145 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.147 | 0.132–0.159 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.426 | 0.416–0.427 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 1.419 | 1.295–1.456 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.153 | 0.143–0.166 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.125 | 0.123–0.127 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.233 | 0.232–0.243 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.206 | 0.201–0.216 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.146 | 0.131–0.147 | comparator faster in every run interval |
| `literal_first` | 0.535 | 0.525–0.539 | comparator faster in every run interval |
| `literal_middle` | 0.567 | 0.566–0.586 | comparator faster in every run interval |
| `literal_end` | 0.596 | 0.570–0.611 | comparator faster in every run interval |
| `literal_absent` | 0.405 | 0.391–0.446 | comparator faster in every run interval |

## onigmo / steady

Common cases: 24; families: 13. Pair-specific family-weighted ratio: 3.894.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 5.938 | 5.931–6.958 | Ferroni faster in every run interval |
| `uuid_v4` | 6.186 | 5.829–6.586 | Ferroni faster in every run interval |
| `ipv4_validation` | 6.544 | 5.740–6.633 | Ferroni faster in every run interval |
| `ipv6_validation` | 20.830 | 20.509–21.831 | Ferroni faster in every run interval |
| `semver_version_parse` | 2.023 | 1.929–2.105 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.265 | 1.209–1.347 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.085 | 1.006–1.100 | inconclusive |
| `jinja_integer_token` | 1.500 | 1.498–1.564 | Ferroni faster in every run interval |
| `jinja_float_token` | 2.647 | 2.593–2.849 | Ferroni faster in every run interval |
| `django_email_local_part` | 5.048 | 4.589–5.237 | Ferroni faster in every run interval |
| `django_email_domain` | 71.101 | 69.247–71.543 | Ferroni faster in every run interval |
| `django_url_regex` | 53.880 | 52.797–54.283 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 2.387 | 2.370–2.401 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 2.954 | 2.411–3.004 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.112 | 1.101–1.124 | Ferroni faster in every run interval |
| `mastodon_hashtag_regex_step` | 2.192 | 2.103–2.199 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 2.330 | 2.247–2.497 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 2.665 | 2.625–2.862 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 1.317 | 1.317–1.365 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_2` | 3.381 | 3.069–3.457 | Ferroni faster in every run interval |
| `literal_first` | 2.733 | 2.643–2.812 | Ferroni faster in every run interval |
| `literal_middle` | 3.775 | 3.774–4.076 | Ferroni faster in every run interval |
| `literal_end` | 5.745 | 5.627–5.746 | Ferroni faster in every run interval |
| `literal_absent` | 2.563 | 2.458–2.690 | Ferroni faster in every run interval |

## onigmo / compile

Common cases: 24; families: 13. Pair-specific family-weighted ratio: 0.497.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 4.501 | 4.081–4.586 | Ferroni faster in every run interval |
| `uuid_v4` | 4.707 | 4.653–4.847 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.254 | 0.224–0.257 | comparator faster in every run interval |
| `ipv6_validation` | 0.268 | 0.244–0.287 | comparator faster in every run interval |
| `semver_version_parse` | 0.261 | 0.238–0.266 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.281 | 0.249–0.289 | comparator faster in every run interval |
| `jinja_string_token` | 0.107 | 0.095–0.109 | comparator faster in every run interval |
| `jinja_integer_token` | 1.959 | 1.916–2.009 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.696 | 0.688–0.697 | comparator faster in every run interval |
| `django_email_local_part` | 2.261 | 2.256–2.296 | Ferroni faster in every run interval |
| `django_email_domain` | 0.127 | 0.103–0.128 | comparator faster in every run interval |
| `django_url_regex` | 0.290 | 0.281–0.298 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.148 | 0.146–0.149 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.150 | 0.119–0.154 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.410 | 0.388–0.421 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 1.519 | 1.371–1.550 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.100 | 0.090–0.101 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.093 | 0.092–0.104 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.218 | 0.217–0.226 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 8.137 | 7.618–8.677 | Ferroni faster in every run interval |
| `literal_first` | 0.261 | 0.260–0.275 | comparator faster in every run interval |
| `literal_middle` | 0.274 | 0.271–0.302 | comparator faster in every run interval |
| `literal_end` | 0.264 | 0.258–0.270 | comparator faster in every run interval |
| `literal_absent` | 0.266 | 0.265–0.339 | comparator faster in every run interval |

## onigmo / first_use

Common cases: 24; families: 13. Pair-specific family-weighted ratio: 0.494.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 3.547 | 3.206–3.588 | Ferroni faster in every run interval |
| `uuid_v4` | 3.623 | 3.594–3.757 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.237 | 0.210–0.238 | comparator faster in every run interval |
| `ipv6_validation` | 0.268 | 0.265–0.279 | comparator faster in every run interval |
| `semver_version_parse` | 0.252 | 0.237–0.258 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.282 | 0.241–0.284 | comparator faster in every run interval |
| `jinja_string_token` | 0.104 | 0.089–0.104 | comparator faster in every run interval |
| `jinja_integer_token` | 1.863 | 1.738–1.988 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.691 | 0.661–0.710 | comparator faster in every run interval |
| `django_email_local_part` | 2.211 | 2.186–2.281 | Ferroni faster in every run interval |
| `django_email_domain` | 0.131 | 0.124–0.131 | comparator faster in every run interval |
| `django_url_regex` | 0.292 | 0.288–0.305 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.145 | 0.137–0.147 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.161 | 0.139–0.164 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.414 | 0.408–0.426 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 1.510 | 1.380–1.522 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.099 | 0.090–0.108 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.095 | 0.094–0.105 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.215 | 0.213–0.234 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 7.722 | 7.464–8.223 | Ferroni faster in every run interval |
| `literal_first` | 0.334 | 0.322–0.340 | comparator faster in every run interval |
| `literal_middle` | 0.349 | 0.344–0.366 | comparator faster in every run interval |
| `literal_end` | 0.378 | 0.365–0.384 | comparator faster in every run interval |
| `literal_absent` | 0.341 | 0.339–0.424 | comparator faster in every run interval |

## pcre2_jit / steady

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.760.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.937 | 0.876–1.014 | inconclusive |
| `uuid_v4` | 0.971 | 0.927–1.020 | inconclusive |
| `ipv4_validation` | 1.374 | 1.226–1.409 | Ferroni faster in every run interval |
| `ipv6_validation` | 3.811 | 3.762–3.862 | Ferroni faster in every run interval |
| `semver_version_parse` | 0.550 | 0.548–0.599 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.471 | 0.415–0.533 | comparator faster in every run interval |
| `jinja_string_token` | 0.579 | 0.530–0.583 | comparator faster in every run interval |
| `jinja_integer_token` | 0.562 | 0.556–0.566 | comparator faster in every run interval |
| `jinja_float_token` | 0.636 | 0.623–0.678 | comparator faster in every run interval |
| `django_email_local_part` | 1.680 | 1.674–1.682 | Ferroni faster in every run interval |
| `django_email_domain` | 0.823 | 0.814–0.828 | comparator faster in every run interval |
| `django_url_regex` | 1.250 | 1.248–1.252 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 0.446 | 0.435–0.457 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.763 | 0.581–0.788 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.395 | 0.390–0.396 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.378 | 0.362–0.382 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.673 | 0.584–0.716 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.579 | 0.564–0.591 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.498 | 0.492–0.527 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.617 | 0.611–0.744 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.599 | 0.566–0.601 | comparator faster in every run interval |
| `literal_first` | 1.856 | 1.690–1.901 | Ferroni faster in every run interval |
| `literal_middle` | 1.872 | 1.852–1.939 | Ferroni faster in every run interval |
| `literal_end` | 1.721 | 1.593–1.780 | Ferroni faster in every run interval |
| `literal_absent` | 1.681 | 1.485–1.686 | Ferroni faster in every run interval |

## pcre2_jit / compile

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.311.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.295 | 0.257–0.301 | comparator faster in every run interval |
| `uuid_v4` | 0.276 | 0.271–0.310 | comparator faster in every run interval |
| `ipv4_validation` | 0.288 | 0.282–0.292 | comparator faster in every run interval |
| `ipv6_validation` | 0.341 | 0.320–0.372 | comparator faster in every run interval |
| `semver_version_parse` | 0.410 | 0.375–0.449 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.374 | 0.335–0.380 | comparator faster in every run interval |
| `jinja_string_token` | 0.281 | 0.249–0.287 | comparator faster in every run interval |
| `jinja_integer_token` | 0.284 | 0.276–0.290 | comparator faster in every run interval |
| `jinja_float_token` | 0.225 | 0.212–0.232 | comparator faster in every run interval |
| `django_email_local_part` | 0.413 | 0.399–0.422 | comparator faster in every run interval |
| `django_email_domain` | 0.056 | 0.046–0.056 | comparator faster in every run interval |
| `django_url_regex` | 0.063 | 0.062–0.069 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.274 | 0.274–0.277 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.275 | 0.231–0.302 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.690 | 0.681–0.719 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.163 | 0.144–0.168 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.424 | 0.375–0.431 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.371 | 0.350–0.391 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.428 | 0.424–0.449 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.225 | 0.220–0.282 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.217 | 0.203–0.224 | comparator faster in every run interval |
| `literal_first` | 2.554 | 2.511–2.665 | Ferroni faster in every run interval |
| `literal_middle` | 2.534 | 2.532–2.708 | Ferroni faster in every run interval |
| `literal_end` | 2.358 | 2.332–2.492 | Ferroni faster in every run interval |
| `literal_absent` | 2.796 | 2.388–2.887 | Ferroni faster in every run interval |

## pcre2_jit / first_use

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.341.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.234 | 0.215–0.247 | comparator faster in every run interval |
| `uuid_v4` | 0.224 | 0.220–0.237 | comparator faster in every run interval |
| `ipv4_validation` | 0.315 | 0.300–0.319 | comparator faster in every run interval |
| `ipv6_validation` | 0.351 | 0.347–0.360 | comparator faster in every run interval |
| `semver_version_parse` | 0.428 | 0.416–0.442 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.363 | 0.352–0.387 | comparator faster in every run interval |
| `jinja_string_token` | 0.316 | 0.293–0.324 | comparator faster in every run interval |
| `jinja_integer_token` | 0.315 | 0.292–0.327 | comparator faster in every run interval |
| `jinja_float_token` | 0.246 | 0.244–0.272 | comparator faster in every run interval |
| `django_email_local_part` | 0.453 | 0.450–0.487 | comparator faster in every run interval |
| `django_email_domain` | 0.056 | 0.050–0.056 | comparator faster in every run interval |
| `django_url_regex` | 0.065 | 0.065–0.072 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.285 | 0.284–0.289 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.286 | 0.281–0.313 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.901 | 0.868–0.920 | inconclusive |
| `mastodon_hashtag_regex_step` | 0.175 | 0.165–0.185 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.455 | 0.435–0.502 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.396 | 0.387–0.417 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.472 | 0.468–0.503 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.422 | 0.416–0.507 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.378 | 0.364–0.578 | comparator faster in every run interval |
| `literal_first` | 2.574 | 2.476–2.914 | Ferroni faster in every run interval |
| `literal_middle` | 2.503 | 2.488–2.787 | Ferroni faster in every run interval |
| `literal_end` | 2.383 | 2.359–2.409 | Ferroni faster in every run interval |
| `literal_absent` | 2.786 | 2.628–2.826 | Ferroni faster in every run interval |

## pcre2 / steady

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 2.125.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.868 | 1.734–2.014 | Ferroni faster in every run interval |
| `uuid_v4` | 2.045 | 1.854–2.052 | Ferroni faster in every run interval |
| `ipv4_validation` | 9.498 | 8.542–10.067 | Ferroni faster in every run interval |
| `ipv6_validation` | 20.548 | 18.212–21.256 | Ferroni faster in every run interval |
| `semver_version_parse` | 1.360 | 1.348–1.413 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.709 | 1.544–1.780 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.188 | 1.114–1.190 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.703 | 1.690–1.721 | Ferroni faster in every run interval |
| `jinja_float_token` | 1.824 | 1.817–1.843 | Ferroni faster in every run interval |
| `django_email_local_part` | 5.964 | 5.740–5.968 | Ferroni faster in every run interval |
| `django_email_domain` | 3.063 | 3.036–3.292 | Ferroni faster in every run interval |
| `django_url_regex` | 3.207 | 3.206–3.306 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.518 | 1.503–1.552 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.765 | 1.642–1.771 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.257 | 1.244–1.257 | Ferroni faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.810 | 0.757–0.812 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 3.410 | 3.147–3.465 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 4.013 | 3.984–4.056 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 1.307 | 1.306–1.363 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.886 | 0.883–0.997 | inconclusive |
| `symfony_grapheme_chunks_2` | 0.837 | 0.817–0.939 | comparator faster in every run interval |
| `literal_first` | 3.827 | 3.718–3.917 | Ferroni faster in every run interval |
| `literal_middle` | 3.725 | 3.703–4.000 | Ferroni faster in every run interval |
| `literal_end` | 3.312 | 3.265–3.442 | Ferroni faster in every run interval |
| `literal_absent` | 1.604 | 1.600–1.853 | Ferroni faster in every run interval |

## pcre2 / compile

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.090.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.112 | 0.101–0.119 | comparator faster in every run interval |
| `uuid_v4` | 0.117 | 0.113–0.120 | comparator faster in every run interval |
| `ipv4_validation` | 0.090 | 0.085–0.092 | comparator faster in every run interval |
| `ipv6_validation` | 0.108 | 0.101–0.109 | comparator faster in every run interval |
| `semver_version_parse` | 0.111 | 0.100–0.112 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.104 | 0.092–0.105 | comparator faster in every run interval |
| `jinja_string_token` | 0.059 | 0.051–0.059 | comparator faster in every run interval |
| `jinja_integer_token` | 0.081 | 0.080–0.083 | comparator faster in every run interval |
| `jinja_float_token` | 0.048 | 0.047–0.048 | comparator faster in every run interval |
| `django_email_local_part` | 0.232 | 0.230–0.237 | comparator faster in every run interval |
| `django_email_domain` | 0.051 | 0.046–0.052 | comparator faster in every run interval |
| `django_url_regex` | 0.051 | 0.049–0.053 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.061 | 0.060–0.064 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.064 | 0.063–0.072 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.202 | 0.188–0.213 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.081 | 0.078–0.081 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.076 | 0.073–0.080 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.066 | 0.066–0.067 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.116 | 0.116–0.116 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.033 | 0.032–0.037 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.030 | 0.028–0.034 | comparator faster in every run interval |
| `literal_first` | 0.250 | 0.249–0.268 | comparator faster in every run interval |
| `literal_middle` | 0.257 | 0.254–0.267 | comparator faster in every run interval |
| `literal_end` | 0.235 | 0.230–0.248 | comparator faster in every run interval |
| `literal_absent` | 0.260 | 0.223–0.278 | comparator faster in every run interval |

## pcre2 / first_use

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.107.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.096 | 0.090–0.104 | comparator faster in every run interval |
| `uuid_v4` | 0.098 | 0.094–0.100 | comparator faster in every run interval |
| `ipv4_validation` | 0.092 | 0.085–0.093 | comparator faster in every run interval |
| `ipv6_validation` | 0.109 | 0.104–0.110 | comparator faster in every run interval |
| `semver_version_parse` | 0.112 | 0.105–0.115 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.101 | 0.096–0.110 | comparator faster in every run interval |
| `jinja_string_token` | 0.064 | 0.057–0.066 | comparator faster in every run interval |
| `jinja_integer_token` | 0.086 | 0.079–0.087 | comparator faster in every run interval |
| `jinja_float_token` | 0.052 | 0.051–0.057 | comparator faster in every run interval |
| `django_email_local_part` | 0.225 | 0.221–0.233 | comparator faster in every run interval |
| `django_email_domain` | 0.051 | 0.050–0.051 | comparator faster in every run interval |
| `django_url_regex` | 0.051 | 0.051–0.053 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.073 | 0.072–0.076 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.078 | 0.076–0.080 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.221 | 0.216–0.231 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.084 | 0.078–0.084 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.096 | 0.096–0.103 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.087 | 0.086–0.087 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.124 | 0.120–0.124 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.106 | 0.100–0.122 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.071 | 0.071–0.081 | comparator faster in every run interval |
| `literal_first` | 0.536 | 0.500–0.579 | comparator faster in every run interval |
| `literal_middle` | 0.489 | 0.479–0.550 | comparator faster in every run interval |
| `literal_end` | 0.449 | 0.448–0.465 | comparator faster in every run interval |
| `literal_absent` | 0.451 | 0.383–0.479 | comparator faster in every run interval |

## fancy_regex / steady

Common cases: 21; families: 11. Pair-specific family-weighted ratio: 2.850.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.978 | 0.976–1.035 | inconclusive |
| `uuid_v4` | 1.069 | 1.017–1.217 | Ferroni faster in every run interval |
| `ipv4_validation` | 1.090 | 0.970–1.116 | inconclusive |
| `ipv6_validation` | 1.153 | 1.039–1.203 | Ferroni faster in every run interval |
| `semver_version_parse` | 2.794 | 2.771–2.937 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 2.340 | 2.175–2.605 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.133 | 1.048–1.165 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.514 | 1.508–1.562 | Ferroni faster in every run interval |
| `jinja_float_token` | 2.960 | 2.934–3.276 | Ferroni faster in every run interval |
| `django_email_domain` | 8.851 | 8.803–9.321 | Ferroni faster in every run interval |
| `django_url_regex` | 23.814 | 23.748–23.849 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 2.053 | 2.023–2.070 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 2.385 | 2.222–2.510 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 3.225 | 3.217–3.268 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 3.527 | 3.396–3.619 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 4.915 | 4.889–4.947 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 2.248 | 2.214–2.321 | Ferroni faster in every run interval |
| `literal_first` | 1.494 | 1.424–1.502 | Ferroni faster in every run interval |
| `literal_middle` | 1.479 | 1.474–1.548 | Ferroni faster in every run interval |
| `literal_end` | 1.350 | 1.326–1.382 | Ferroni faster in every run interval |
| `literal_absent` | 1.370 | 1.253–1.436 | Ferroni faster in every run interval |

## fancy_regex / compile

Common cases: 21; families: 11. Pair-specific family-weighted ratio: 1.858.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.112 | 1.079–1.164 | Ferroni faster in every run interval |
| `uuid_v4` | 1.147 | 1.131–1.177 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.826 | 0.765–0.837 | comparator faster in every run interval |
| `ipv6_validation` | 0.867 | 0.797–0.891 | comparator faster in every run interval |
| `semver_version_parse` | 10.993 | 10.798–11.558 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 7.802 | 6.930–7.815 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.912 | 1.674–1.927 | Ferroni faster in every run interval |
| `jinja_integer_token` | 2.049 | 1.992–2.094 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.295 | 0.285–0.299 | comparator faster in every run interval |
| `django_email_domain` | 7.623 | 6.727–7.662 | Ferroni faster in every run interval |
| `django_url_regex` | 6.863 | 6.722–6.917 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.586 | 1.561–1.620 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.630 | 1.550–1.755 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.176 | 1.175–1.202 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.490 | 0.472–0.494 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.425 | 0.420–0.431 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 1.224 | 1.133–1.230 | Ferroni faster in every run interval |
| `literal_first` | 1.880 | 1.775–1.881 | Ferroni faster in every run interval |
| `literal_middle` | 1.769 | 1.702–1.844 | Ferroni faster in every run interval |
| `literal_end` | 1.660 | 1.588–1.722 | Ferroni faster in every run interval |
| `literal_absent` | 1.790 | 1.613–1.835 | Ferroni faster in every run interval |

## fancy_regex / first_use

Common cases: 21; families: 11. Pair-specific family-weighted ratio: 1.883.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.119 | 1.101–1.156 | Ferroni faster in every run interval |
| `uuid_v4` | 1.134 | 1.132–1.189 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.851 | 0.819–0.878 | comparator faster in every run interval |
| `ipv6_validation` | 0.866 | 0.834–0.894 | comparator faster in every run interval |
| `semver_version_parse` | 10.673 | 10.356–11.317 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 7.616 | 7.179–7.702 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.812 | 1.607–1.815 | Ferroni faster in every run interval |
| `jinja_integer_token` | 2.022 | 1.891–2.094 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.304 | 0.284–0.330 | comparator faster in every run interval |
| `django_email_domain` | 7.567 | 7.216–7.582 | Ferroni faster in every run interval |
| `django_url_regex` | 6.932 | 6.915–6.935 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.581 | 1.578–1.693 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.624 | 1.550–1.652 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.431 | 1.415–1.438 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.456 | 0.414–0.464 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.401 | 0.397–0.403 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 1.256 | 1.256–1.258 | Ferroni faster in every run interval |
| `literal_first` | 1.938 | 1.759–2.056 | Ferroni faster in every run interval |
| `literal_middle` | 1.786 | 1.748–1.839 | Ferroni faster in every run interval |
| `literal_end` | 1.676 | 1.673–1.682 | Ferroni faster in every run interval |
| `literal_absent` | 1.821 | 1.718–1.841 | Ferroni faster in every run interval |

## fancy_regex_seek / steady

Common cases: 21; families: 11. Pair-specific family-weighted ratio: 2.861.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.987 | 0.974–1.031 | inconclusive |
| `uuid_v4` | 1.070 | 1.016–1.071 | Ferroni faster in every run interval |
| `ipv4_validation` | 1.114 | 0.988–1.122 | inconclusive |
| `ipv6_validation` | 1.137 | 1.034–1.172 | Ferroni faster in every run interval |
| `semver_version_parse` | 2.842 | 2.825–3.043 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 2.290 | 2.071–2.599 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.131 | 1.063–1.137 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.535 | 1.514–1.536 | Ferroni faster in every run interval |
| `jinja_float_token` | 3.005 | 2.978–3.055 | Ferroni faster in every run interval |
| `django_email_domain` | 8.954 | 8.789–9.093 | Ferroni faster in every run interval |
| `django_url_regex` | 23.588 | 23.208–23.742 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 2.040 | 2.020–2.286 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 2.441 | 2.336–2.514 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 3.250 | 3.149–3.278 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 3.515 | 3.338–3.604 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 4.902 | 4.890–4.933 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 2.263 | 2.133–2.293 | Ferroni faster in every run interval |
| `literal_first` | 1.507 | 1.426–1.511 | Ferroni faster in every run interval |
| `literal_middle` | 1.484 | 1.474–1.540 | Ferroni faster in every run interval |
| `literal_end` | 1.395 | 1.384–1.399 | Ferroni faster in every run interval |
| `literal_absent` | 1.337 | 1.286–1.382 | Ferroni faster in every run interval |

## fancy_regex_seek / compile

Common cases: 21; families: 11. Pair-specific family-weighted ratio: 2.022.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.101 | 1.096–1.169 | Ferroni faster in every run interval |
| `uuid_v4` | 1.133 | 1.132–1.143 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.827 | 0.816–0.851 | comparator faster in every run interval |
| `ipv6_validation` | 0.889 | 0.786–0.897 | comparator faster in every run interval |
| `semver_version_parse` | 11.322 | 10.773–11.508 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 7.401 | 6.666–7.643 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.914 | 1.661–1.921 | Ferroni faster in every run interval |
| `jinja_integer_token` | 2.028 | 2.018–2.162 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.290 | 0.286–0.297 | comparator faster in every run interval |
| `django_email_domain` | 7.624 | 6.348–7.652 | Ferroni faster in every run interval |
| `django_url_regex` | 6.883 | 6.832–7.028 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.569 | 1.547–1.808 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.621 | 1.404–1.720 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.173 | 1.064–1.229 | inconclusive |
| `python_markdown_smart_emphasis_re` | 0.480 | 0.480–0.500 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.424 | 0.421–0.430 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 3.213 | 3.207–3.310 | Ferroni faster in every run interval |
| `literal_first` | 1.898 | 1.710–2.014 | Ferroni faster in every run interval |
| `literal_middle` | 1.828 | 1.730–1.926 | Ferroni faster in every run interval |
| `literal_end` | 1.719 | 1.584–1.777 | Ferroni faster in every run interval |
| `literal_absent` | 1.688 | 1.635–1.778 | Ferroni faster in every run interval |

## fancy_regex_seek / first_use

Common cases: 21; families: 11. Pair-specific family-weighted ratio: 2.062.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.122 | 1.115–1.161 | Ferroni faster in every run interval |
| `uuid_v4` | 1.123 | 1.117–1.171 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.857 | 0.847–0.866 | comparator faster in every run interval |
| `ipv6_validation` | 0.901 | 0.844–0.944 | inconclusive |
| `semver_version_parse` | 10.892 | 10.440–11.249 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 7.641 | 6.466–7.768 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.798 | 1.578–1.812 | Ferroni faster in every run interval |
| `jinja_integer_token` | 2.091 | 1.914–2.136 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.289 | 0.280–0.299 | comparator faster in every run interval |
| `django_email_domain` | 7.547 | 6.554–7.588 | Ferroni faster in every run interval |
| `django_url_regex` | 6.958 | 6.915–7.193 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.562 | 1.559–1.712 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.595 | 1.543–1.632 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.413 | 1.384–1.508 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.443 | 0.419–0.461 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.400 | 0.399–0.402 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 3.510 | 3.479–3.716 | Ferroni faster in every run interval |
| `literal_first` | 1.878 | 1.810–2.020 | Ferroni faster in every run interval |
| `literal_middle` | 1.758 | 1.755–1.827 | Ferroni faster in every run interval |
| `literal_end` | 1.720 | 1.680–1.769 | Ferroni faster in every run interval |
| `literal_absent` | 1.811 | 1.705–1.833 | Ferroni faster in every run interval |

## regex / steady

Common cases: 14; families: 6. Pair-specific family-weighted ratio: 1.315.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.908 | 0.906–0.909 | comparator faster in every run interval |
| `uuid_v4` | 0.996 | 0.947–0.998 | inconclusive |
| `ipv4_validation` | 0.956 | 0.888–0.961 | comparator faster in every run interval |
| `ipv6_validation` | 1.040 | 0.928–1.095 | inconclusive |
| `semver_version_parse` | 2.573 | 2.464–2.604 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 2.109 | 2.059–2.209 | Ferroni faster in every run interval |
| `jinja_string_token` | 0.816 | 0.788–0.828 | comparator faster in every run interval |
| `jinja_integer_token` | 1.227 | 1.218–1.364 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.857 | 1.823–1.879 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 2.393 | 2.198–2.460 | Ferroni faster in every run interval |
| `literal_first` | 1.096 | 1.086–1.130 | Ferroni faster in every run interval |
| `literal_middle` | 1.140 | 1.136–1.184 | Ferroni faster in every run interval |
| `literal_end` | 1.103 | 1.087–1.216 | Ferroni faster in every run interval |
| `literal_absent` | 1.093 | 1.017–1.103 | inconclusive |

## regex / compile

Common cases: 14; families: 6. Pair-specific family-weighted ratio: 1.753.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.831 | 0.826–0.886 | comparator faster in every run interval |
| `uuid_v4` | 0.816 | 0.812–0.818 | comparator faster in every run interval |
| `ipv4_validation` | 0.751 | 0.723–0.768 | comparator faster in every run interval |
| `ipv6_validation` | 0.792 | 0.785–0.810 | comparator faster in every run interval |
| `semver_version_parse` | 11.576 | 11.363–11.632 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 7.401 | 7.354–7.695 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.906 | 1.667–1.941 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.795 | 1.794–2.071 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.535 | 1.524–1.668 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.574 | 1.441–1.587 | Ferroni faster in every run interval |
| `literal_first` | 1.750 | 1.716–1.919 | Ferroni faster in every run interval |
| `literal_middle` | 1.762 | 1.738–1.778 | Ferroni faster in every run interval |
| `literal_end` | 1.724 | 1.722–1.810 | Ferroni faster in every run interval |
| `literal_absent` | 1.635 | 1.608–1.755 | Ferroni faster in every run interval |

## regex / first_use

Common cases: 14; families: 6. Pair-specific family-weighted ratio: 1.776.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.908 | 0.903–0.948 | comparator faster in every run interval |
| `uuid_v4` | 0.868 | 0.862–0.868 | comparator faster in every run interval |
| `ipv4_validation` | 0.770 | 0.770–0.833 | comparator faster in every run interval |
| `ipv6_validation` | 0.823 | 0.800–0.871 | comparator faster in every run interval |
| `semver_version_parse` | 11.177 | 10.911–11.218 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 7.337 | 7.310–7.532 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.815 | 1.630–1.832 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.875 | 1.707–1.911 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.524 | 1.515–1.575 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.555 | 1.541–1.580 | Ferroni faster in every run interval |
| `literal_first` | 1.761 | 1.746–2.021 | Ferroni faster in every run interval |
| `literal_middle` | 1.741 | 1.694–1.772 | Ferroni faster in every run interval |
| `literal_end` | 1.648 | 1.628–1.734 | Ferroni faster in every run interval |
| `literal_absent` | 1.748 | 1.681–1.796 | Ferroni faster in every run interval |

Raw samples, estimates, confidence intervals, failures, eligibility reasons, corpus snapshot and execution order are retained beside this report.

Memory, where requested, is fresh-process peak RSS including the binary, runtime, parsed catalog, compilation, input/output and allocator. It is not isolated compiled-pattern memory.
