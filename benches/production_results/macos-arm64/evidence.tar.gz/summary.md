# Production regex comparison

Host: macOS-26.3-arm64-arm-64bit-Mach-O; arm64.

Publication candidate: review host stability, raw samples, coverage and run intervals before publishing.

Ratios are comparator / Ferroni. Compile and first-use times concern one pattern; steady times concern the complete fixture batch.

Each comparison below uses only its explicitly listed common tasks. Families have equal aggregate weight; architectures are never combined.

## Eligibility

| Case | Engine | Status |
| --- | --- | --- |
| `uuid_shape` | rust | eligible |
| `uuid_shape` | rust_erroraware | eligible |
| `uuid_shape` | c | eligible |
| `uuid_shape` | onigmo | eligible |
| `uuid_shape` | pcre2_jit | eligible |
| `uuid_shape` | pcre2 | eligible |
| `uuid_shape` | fancy_regex | eligible |
| `uuid_shape` | fancy_regex_seek | eligible |
| `uuid_shape` | regex | eligible |
| `uuid_v4` | rust | eligible |
| `uuid_v4` | rust_erroraware | eligible |
| `uuid_v4` | c | eligible |
| `uuid_v4` | onigmo | eligible |
| `uuid_v4` | pcre2_jit | eligible |
| `uuid_v4` | pcre2 | eligible |
| `uuid_v4` | fancy_regex | eligible |
| `uuid_v4` | fancy_regex_seek | eligible |
| `uuid_v4` | regex | eligible |
| `ipv4_validation` | rust | eligible |
| `ipv4_validation` | rust_erroraware | eligible |
| `ipv4_validation` | c | eligible |
| `ipv4_validation` | onigmo | eligible |
| `ipv4_validation` | pcre2_jit | eligible |
| `ipv4_validation` | pcre2 | eligible |
| `ipv4_validation` | fancy_regex | eligible |
| `ipv4_validation` | fancy_regex_seek | eligible |
| `ipv4_validation` | regex | eligible |
| `ipv6_validation` | rust | eligible |
| `ipv6_validation` | rust_erroraware | eligible |
| `ipv6_validation` | c | eligible |
| `ipv6_validation` | onigmo | eligible |
| `ipv6_validation` | pcre2_jit | eligible |
| `ipv6_validation` | pcre2 | eligible |
| `ipv6_validation` | fancy_regex | eligible |
| `ipv6_validation` | fancy_regex_seek | eligible |
| `ipv6_validation` | regex | eligible |
| `semver_version_parse` | rust | eligible |
| `semver_version_parse` | rust_erroraware | eligible |
| `semver_version_parse` | c | eligible |
| `semver_version_parse` | onigmo | eligible |
| `semver_version_parse` | pcre2_jit | eligible |
| `semver_version_parse` | pcre2 | eligible |
| `semver_version_parse` | fancy_regex | eligible |
| `semver_version_parse` | fancy_regex_seek | eligible |
| `semver_version_parse` | regex | eligible |
| `semver_hyphen_range_captures` | rust | eligible |
| `semver_hyphen_range_captures` | rust_erroraware | eligible |
| `semver_hyphen_range_captures` | c | eligible |
| `semver_hyphen_range_captures` | onigmo | eligible |
| `semver_hyphen_range_captures` | pcre2_jit | eligible |
| `semver_hyphen_range_captures` | pcre2 | eligible |
| `semver_hyphen_range_captures` | fancy_regex | eligible |
| `semver_hyphen_range_captures` | fancy_regex_seek | eligible |
| `semver_hyphen_range_captures` | regex | eligible |
| `jinja_string_token` | rust | eligible |
| `jinja_string_token` | rust_erroraware | eligible |
| `jinja_string_token` | c | eligible |
| `jinja_string_token` | onigmo | eligible |
| `jinja_string_token` | pcre2_jit | eligible |
| `jinja_string_token` | pcre2 | eligible |
| `jinja_string_token` | fancy_regex | eligible |
| `jinja_string_token` | fancy_regex_seek | eligible |
| `jinja_string_token` | regex | eligible |
| `jinja_integer_token` | rust | eligible |
| `jinja_integer_token` | rust_erroraware | eligible |
| `jinja_integer_token` | c | eligible |
| `jinja_integer_token` | onigmo | eligible |
| `jinja_integer_token` | pcre2_jit | eligible |
| `jinja_integer_token` | pcre2 | eligible |
| `jinja_integer_token` | fancy_regex | eligible |
| `jinja_integer_token` | fancy_regex_seek | eligible |
| `jinja_integer_token` | regex | eligible |
| `jinja_float_token` | rust | eligible |
| `jinja_float_token` | rust_erroraware | eligible |
| `jinja_float_token` | c | eligible |
| `jinja_float_token` | onigmo | eligible |
| `jinja_float_token` | pcre2_jit | eligible |
| `jinja_float_token` | pcre2 | eligible |
| `jinja_float_token` | fancy_regex | eligible |
| `jinja_float_token` | fancy_regex_seek | eligible |
| `jinja_float_token` | regex | syntax_rejected |
| `django_email_local_part` | rust | eligible |
| `django_email_local_part` | rust_erroraware | eligible |
| `django_email_local_part` | c | eligible |
| `django_email_local_part` | onigmo | eligible |
| `django_email_local_part` | pcre2_jit | eligible |
| `django_email_local_part` | pcre2 | eligible |
| `django_email_local_part` | fancy_regex | syntax_rejected |
| `django_email_local_part` | fancy_regex_seek | syntax_rejected |
| `django_email_local_part` | regex | syntax_rejected |
| `django_email_domain` | rust | eligible |
| `django_email_domain` | rust_erroraware | eligible |
| `django_email_domain` | c | eligible |
| `django_email_domain` | onigmo | eligible |
| `django_email_domain` | pcre2_jit | eligible |
| `django_email_domain` | pcre2 | eligible |
| `django_email_domain` | fancy_regex | eligible |
| `django_email_domain` | fancy_regex_seek | eligible |
| `django_email_domain` | regex | syntax_rejected |
| `django_url_regex` | rust | eligible |
| `django_url_regex` | rust_erroraware | eligible |
| `django_url_regex` | c | eligible |
| `django_url_regex` | onigmo | eligible |
| `django_url_regex` | pcre2_jit | eligible |
| `django_url_regex` | pcre2 | eligible |
| `django_url_regex` | fancy_regex | eligible |
| `django_url_regex` | fancy_regex_seek | eligible |
| `django_url_regex` | regex | syntax_rejected |
| `fluent_bit_apache` | rust | eligible |
| `fluent_bit_apache` | rust_erroraware | eligible |
| `fluent_bit_apache` | c | eligible |
| `fluent_bit_apache` | onigmo | eligible |
| `fluent_bit_apache` | pcre2_jit | eligible |
| `fluent_bit_apache` | pcre2 | eligible |
| `fluent_bit_apache` | fancy_regex | eligible |
| `fluent_bit_apache` | fancy_regex_seek | eligible |
| `fluent_bit_apache` | regex | eligible |
| `fluent_bit_nginx` | rust | eligible |
| `fluent_bit_nginx` | rust_erroraware | eligible |
| `fluent_bit_nginx` | c | eligible |
| `fluent_bit_nginx` | onigmo | eligible |
| `fluent_bit_nginx` | pcre2_jit | eligible |
| `fluent_bit_nginx` | pcre2 | eligible |
| `fluent_bit_nginx` | fancy_regex | eligible |
| `fluent_bit_nginx` | fancy_regex_seek | eligible |
| `fluent_bit_nginx` | regex | eligible |
| `rails_underscore_regex_step` | rust | eligible |
| `rails_underscore_regex_step` | rust_erroraware | eligible |
| `rails_underscore_regex_step` | c | eligible |
| `rails_underscore_regex_step` | onigmo | eligible |
| `rails_underscore_regex_step` | pcre2_jit | eligible |
| `rails_underscore_regex_step` | pcre2 | eligible |
| `rails_underscore_regex_step` | fancy_regex | eligible |
| `rails_underscore_regex_step` | fancy_regex_seek | eligible |
| `rails_underscore_regex_step` | regex | syntax_rejected |
| `mastodon_hashtag_regex_step` | rust | eligible |
| `mastodon_hashtag_regex_step` | rust_erroraware | eligible |
| `mastodon_hashtag_regex_step` | c | eligible |
| `mastodon_hashtag_regex_step` | onigmo | eligible |
| `mastodon_hashtag_regex_step` | pcre2_jit | eligible |
| `mastodon_hashtag_regex_step` | pcre2 | eligible |
| `mastodon_hashtag_regex_step` | fancy_regex | semantic_difference |
| `mastodon_hashtag_regex_step` | fancy_regex_seek | semantic_difference |
| `mastodon_hashtag_regex_step` | regex | syntax_rejected |
| `python_markdown_smart_emphasis_re` | rust | eligible |
| `python_markdown_smart_emphasis_re` | rust_erroraware | eligible |
| `python_markdown_smart_emphasis_re` | c | eligible |
| `python_markdown_smart_emphasis_re` | onigmo | eligible |
| `python_markdown_smart_emphasis_re` | pcre2_jit | eligible |
| `python_markdown_smart_emphasis_re` | pcre2 | eligible |
| `python_markdown_smart_emphasis_re` | fancy_regex | eligible |
| `python_markdown_smart_emphasis_re` | fancy_regex_seek | eligible |
| `python_markdown_smart_emphasis_re` | regex | syntax_rejected |
| `python_markdown_smart_strong_em_re` | rust | eligible |
| `python_markdown_smart_strong_em_re` | rust_erroraware | eligible |
| `python_markdown_smart_strong_em_re` | c | eligible |
| `python_markdown_smart_strong_em_re` | onigmo | eligible |
| `python_markdown_smart_strong_em_re` | pcre2_jit | eligible |
| `python_markdown_smart_strong_em_re` | pcre2 | eligible |
| `python_markdown_smart_strong_em_re` | fancy_regex | eligible |
| `python_markdown_smart_strong_em_re` | fancy_regex_seek | eligible |
| `python_markdown_smart_strong_em_re` | regex | syntax_rejected |
| `wordpress_shortcode_captures` | rust | eligible |
| `wordpress_shortcode_captures` | rust_erroraware | eligible |
| `wordpress_shortcode_captures` | c | eligible |
| `wordpress_shortcode_captures` | onigmo | eligible |
| `wordpress_shortcode_captures` | pcre2_jit | eligible |
| `wordpress_shortcode_captures` | pcre2 | eligible |
| `wordpress_shortcode_captures` | fancy_regex | eligible |
| `wordpress_shortcode_captures` | fancy_regex_seek | eligible |
| `wordpress_shortcode_captures` | regex | syntax_rejected |
| `symfony_grapheme_chunks_1` | rust | eligible |
| `symfony_grapheme_chunks_1` | rust_erroraware | eligible |
| `symfony_grapheme_chunks_1` | c | eligible |
| `symfony_grapheme_chunks_1` | onigmo | semantic_difference |
| `symfony_grapheme_chunks_1` | pcre2_jit | eligible |
| `symfony_grapheme_chunks_1` | pcre2 | eligible |
| `symfony_grapheme_chunks_1` | fancy_regex | syntax_rejected |
| `symfony_grapheme_chunks_1` | fancy_regex_seek | syntax_rejected |
| `symfony_grapheme_chunks_1` | regex | syntax_rejected |
| `symfony_grapheme_chunks_2` | rust | eligible |
| `symfony_grapheme_chunks_2` | rust_erroraware | eligible |
| `symfony_grapheme_chunks_2` | c | eligible |
| `symfony_grapheme_chunks_2` | onigmo | eligible |
| `symfony_grapheme_chunks_2` | pcre2_jit | eligible |
| `symfony_grapheme_chunks_2` | pcre2 | eligible |
| `symfony_grapheme_chunks_2` | fancy_regex | syntax_rejected |
| `symfony_grapheme_chunks_2` | fancy_regex_seek | syntax_rejected |
| `symfony_grapheme_chunks_2` | regex | syntax_rejected |
| `literal_first` | rust | eligible |
| `literal_first` | rust_erroraware | eligible |
| `literal_first` | c | eligible |
| `literal_first` | onigmo | eligible |
| `literal_first` | pcre2_jit | eligible |
| `literal_first` | pcre2 | eligible |
| `literal_first` | fancy_regex | eligible |
| `literal_first` | fancy_regex_seek | eligible |
| `literal_first` | regex | eligible |
| `literal_middle` | rust | eligible |
| `literal_middle` | rust_erroraware | eligible |
| `literal_middle` | c | eligible |
| `literal_middle` | onigmo | eligible |
| `literal_middle` | pcre2_jit | eligible |
| `literal_middle` | pcre2 | eligible |
| `literal_middle` | fancy_regex | eligible |
| `literal_middle` | fancy_regex_seek | eligible |
| `literal_middle` | regex | eligible |
| `literal_end` | rust | eligible |
| `literal_end` | rust_erroraware | eligible |
| `literal_end` | c | eligible |
| `literal_end` | onigmo | eligible |
| `literal_end` | pcre2_jit | eligible |
| `literal_end` | pcre2 | eligible |
| `literal_end` | fancy_regex | eligible |
| `literal_end` | fancy_regex_seek | eligible |
| `literal_end` | regex | eligible |
| `literal_absent` | rust | eligible |
| `literal_absent` | rust_erroraware | eligible |
| `literal_absent` | c | eligible |
| `literal_absent` | onigmo | eligible |
| `literal_absent` | pcre2_jit | eligible |
| `literal_absent` | pcre2 | eligible |
| `literal_absent` | fancy_regex | eligible |
| `literal_absent` | fancy_regex_seek | eligible |
| `literal_absent` | regex | eligible |
| `linkify_http_tail` | rust | pending |
| `linkify_http_tail` | rust_erroraware | pending |
| `linkify_http_tail` | c | pending |
| `linkify_http_tail` | onigmo | pending |
| `linkify_http_tail` | pcre2_jit | pending |
| `linkify_http_tail` | pcre2 | pending |
| `linkify_http_tail` | fancy_regex | pending |
| `linkify_http_tail` | fancy_regex_seek | pending |
| `linkify_http_tail` | regex | pending |
| `php_cs_fixer_recursive_types` | rust | pending |
| `php_cs_fixer_recursive_types` | rust_erroraware | pending |
| `php_cs_fixer_recursive_types` | c | pending |
| `php_cs_fixer_recursive_types` | onigmo | pending |
| `php_cs_fixer_recursive_types` | pcre2_jit | pending |
| `php_cs_fixer_recursive_types` | pcre2 | pending |
| `php_cs_fixer_recursive_types` | fancy_regex | pending |
| `php_cs_fixer_recursive_types` | fancy_regex_seek | pending |
| `php_cs_fixer_recursive_types` | regex | pending |

## rust_erroraware / steady

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 1.169.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.696 | 1.636–1.769 | Ferroni faster in every run interval |
| `uuid_v4` | 1.668 | 1.667–1.733 | Ferroni faster in every run interval |
| `ipv4_validation` | 5.560 | 5.544–6.541 | Ferroni faster in every run interval |
| `ipv6_validation` | 1.565 | 1.555–1.573 | Ferroni faster in every run interval |
| `semver_version_parse` | 1.042 | 0.989–1.046 | inconclusive |
| `semver_hyphen_range_captures` | 1.008 | 0.914–1.056 | inconclusive |
| `jinja_string_token` | 1.043 | 0.995–1.050 | inconclusive |
| `jinja_integer_token` | 1.015 | 0.963–1.069 | inconclusive |
| `jinja_float_token` | 1.029 | 0.951–1.030 | inconclusive |
| `django_email_local_part` | 0.987 | 0.982–1.008 | inconclusive |
| `django_email_domain` | 1.045 | 0.997–1.114 | inconclusive |
| `django_url_regex` | 0.998 | 0.972–0.999 | inconclusive |
| `fluent_bit_apache` | 1.001 | 0.970–1.025 | inconclusive |
| `fluent_bit_nginx` | 1.030 | 1.013–1.098 | inconclusive |
| `rails_underscore_regex_step` | 1.006 | 0.960–1.018 | inconclusive |
| `mastodon_hashtag_regex_step` | 1.068 | 1.007–1.070 | inconclusive |
| `python_markdown_smart_emphasis_re` | 1.002 | 1.002–1.098 | inconclusive |
| `python_markdown_smart_strong_em_re` | 1.021 | 1.017–1.028 | inconclusive |
| `wordpress_shortcode_captures` | 1.042 | 1.036–1.044 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_1` | 1.034 | 1.022–1.068 | inconclusive |
| `symfony_grapheme_chunks_2` | 1.046 | 1.011–1.047 | inconclusive |
| `literal_first` | 1.241 | 1.219–1.269 | Ferroni faster in every run interval |
| `literal_middle` | 1.278 | 1.276–1.326 | Ferroni faster in every run interval |
| `literal_end` | 1.186 | 1.156–1.188 | Ferroni faster in every run interval |
| `literal_absent` | 1.110 | 1.060–1.184 | Ferroni faster in every run interval |

## rust_erroraware / compile

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 1.002.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.002 | 0.911–1.028 | inconclusive |
| `uuid_v4` | 1.012 | 0.965–1.047 | inconclusive |
| `ipv4_validation` | 1.012 | 0.953–1.157 | inconclusive |
| `ipv6_validation` | 0.992 | 0.921–0.998 | inconclusive |
| `semver_version_parse` | 1.033 | 0.965–1.096 | inconclusive |
| `semver_hyphen_range_captures` | 1.018 | 0.966–1.227 | inconclusive |
| `jinja_string_token` | 0.987 | 0.916–1.006 | inconclusive |
| `jinja_integer_token` | 1.007 | 0.961–1.095 | inconclusive |
| `jinja_float_token` | 1.002 | 0.892–1.022 | inconclusive |
| `django_email_local_part` | 1.015 | 0.886–1.024 | inconclusive |
| `django_email_domain` | 0.983 | 0.954–1.010 | inconclusive |
| `django_url_regex` | 1.000 | 0.960–1.019 | inconclusive |
| `fluent_bit_apache` | 0.979 | 0.977–1.000 | inconclusive |
| `fluent_bit_nginx` | 1.020 | 1.013–1.115 | inconclusive |
| `rails_underscore_regex_step` | 0.997 | 0.941–1.013 | inconclusive |
| `mastodon_hashtag_regex_step` | 0.988 | 0.986–1.016 | inconclusive |
| `python_markdown_smart_emphasis_re` | 1.015 | 0.991–1.091 | inconclusive |
| `python_markdown_smart_strong_em_re` | 1.041 | 1.031–1.041 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 0.992 | 0.978–1.022 | inconclusive |
| `symfony_grapheme_chunks_1` | 1.028 | 1.019–1.201 | inconclusive |
| `symfony_grapheme_chunks_2` | 1.005 | 0.995–1.087 | inconclusive |
| `literal_first` | 0.923 | 0.911–0.983 | inconclusive |
| `literal_middle` | 0.977 | 0.939–0.992 | inconclusive |
| `literal_end` | 0.972 | 0.953–0.994 | inconclusive |
| `literal_absent` | 1.017 | 0.966–1.037 | inconclusive |

## rust_erroraware / first_use

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.977.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.758 | 0.743–0.849 | comparator faster in every run interval |
| `uuid_v4` | 0.797 | 0.777–0.797 | comparator faster in every run interval |
| `ipv4_validation` | 1.006 | 0.967–1.055 | inconclusive |
| `ipv6_validation` | 1.010 | 0.854–1.038 | inconclusive |
| `semver_version_parse` | 1.075 | 1.005–1.097 | inconclusive |
| `semver_hyphen_range_captures` | 1.034 | 0.988–1.249 | inconclusive |
| `jinja_string_token` | 0.966 | 0.956–1.001 | inconclusive |
| `jinja_integer_token` | 0.890 | 0.834–1.093 | inconclusive |
| `jinja_float_token` | 1.009 | 0.990–1.021 | inconclusive |
| `django_email_local_part` | 0.950 | 0.821–0.964 | inconclusive |
| `django_email_domain` | 0.976 | 0.926–0.992 | inconclusive |
| `django_url_regex` | 0.978 | 0.977–0.995 | inconclusive |
| `fluent_bit_apache` | 0.999 | 0.988–1.008 | inconclusive |
| `fluent_bit_nginx` | 1.018 | 1.002–1.106 | inconclusive |
| `rails_underscore_regex_step` | 0.990 | 0.975–1.024 | inconclusive |
| `mastodon_hashtag_regex_step` | 0.995 | 0.949–1.013 | inconclusive |
| `python_markdown_smart_emphasis_re` | 1.015 | 0.937–1.055 | inconclusive |
| `python_markdown_smart_strong_em_re` | 0.984 | 0.966–1.018 | inconclusive |
| `wordpress_shortcode_captures` | 0.986 | 0.953–1.023 | inconclusive |
| `symfony_grapheme_chunks_1` | 0.999 | 0.996–1.102 | inconclusive |
| `symfony_grapheme_chunks_2` | 1.049 | 0.998–1.140 | inconclusive |
| `literal_first` | 1.010 | 0.898–1.053 | inconclusive |
| `literal_middle` | 0.985 | 0.982–1.090 | inconclusive |
| `literal_end` | 0.983 | 0.946–0.992 | inconclusive |
| `literal_absent` | 0.981 | 0.975–1.041 | inconclusive |

## c / steady

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 2.024.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 5.616 | 5.268–5.659 | Ferroni faster in every run interval |
| `uuid_v4` | 3.996 | 3.971–4.285 | Ferroni faster in every run interval |
| `ipv4_validation` | 8.484 | 7.698–10.111 | Ferroni faster in every run interval |
| `ipv6_validation` | 1.775 | 1.761–1.902 | Ferroni faster in every run interval |
| `semver_version_parse` | 1.209 | 1.124–1.233 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.232 | 1.223–1.239 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.596 | 1.563–1.625 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.315 | 1.139–1.356 | Ferroni faster in every run interval |
| `jinja_float_token` | 1.011 | 1.008–1.059 | inconclusive |
| `django_email_local_part` | 2.582 | 2.407–2.605 | Ferroni faster in every run interval |
| `django_email_domain` | 5.160 | 5.039–5.279 | Ferroni faster in every run interval |
| `django_url_regex` | 1.563 | 1.551–1.581 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.696 | 1.630–1.807 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.721 | 1.644–1.784 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.062 | 0.944–1.154 | inconclusive |
| `mastodon_hashtag_regex_step` | 1.611 | 1.509–1.612 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 1.307 | 1.240–1.341 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 1.297 | 1.272–1.346 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 1.387 | 1.383–1.394 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_1` | 1.298 | 1.245–1.321 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_2` | 1.344 | 1.287–1.371 | Ferroni faster in every run interval |
| `literal_first` | 12.419 | 12.256–12.431 | Ferroni faster in every run interval |
| `literal_middle` | 13.893 | 13.290–14.456 | Ferroni faster in every run interval |
| `literal_end` | 13.493 | 12.620–13.684 | Ferroni faster in every run interval |
| `literal_absent` | 2.081 | 2.021–2.083 | Ferroni faster in every run interval |

## c / compile

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.392.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 4.424 | 4.395–4.838 | Ferroni faster in every run interval |
| `uuid_v4` | 4.898 | 4.894–4.965 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.270 | 0.206–0.297 | comparator faster in every run interval |
| `ipv6_validation` | 0.258 | 0.253–0.275 | comparator faster in every run interval |
| `semver_version_parse` | 0.274 | 0.254–0.300 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.268 | 0.249–0.270 | comparator faster in every run interval |
| `jinja_string_token` | 0.126 | 0.119–0.128 | comparator faster in every run interval |
| `jinja_integer_token` | 2.383 | 2.238–2.493 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.645 | 0.642–0.667 | comparator faster in every run interval |
| `django_email_local_part` | 2.346 | 2.003–2.396 | Ferroni faster in every run interval |
| `django_email_domain` | 0.256 | 0.233–0.257 | comparator faster in every run interval |
| `django_url_regex` | 0.464 | 0.462–0.465 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.150 | 0.145–0.167 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.154 | 0.150–0.155 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.424 | 0.348–0.430 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 1.359 | 1.305–1.596 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.164 | 0.154–0.168 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.134 | 0.129–0.135 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.227 | 0.226–0.228 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.083 | 0.078–0.089 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.079 | 0.077–0.079 | comparator faster in every run interval |
| `literal_first` | 0.309 | 0.287–0.320 | comparator faster in every run interval |
| `literal_middle` | 0.323 | 0.313–0.324 | comparator faster in every run interval |
| `literal_end` | 0.316 | 0.306–0.321 | comparator faster in every run interval |
| `literal_absent` | 0.318 | 0.302–0.332 | comparator faster in every run interval |

## c / first_use

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.434.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 3.672 | 3.364–3.701 | Ferroni faster in every run interval |
| `uuid_v4` | 4.045 | 3.822–4.219 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.251 | 0.217–0.287 | comparator faster in every run interval |
| `ipv6_validation` | 0.275 | 0.251–0.277 | comparator faster in every run interval |
| `semver_version_parse` | 0.259 | 0.258–0.290 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.280 | 0.257–0.286 | comparator faster in every run interval |
| `jinja_string_token` | 0.136 | 0.135–0.139 | comparator faster in every run interval |
| `jinja_integer_token` | 2.235 | 2.129–2.478 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.646 | 0.645–0.731 | comparator faster in every run interval |
| `django_email_local_part` | 2.174 | 1.870–2.245 | Ferroni faster in every run interval |
| `django_email_domain` | 0.255 | 0.233–0.272 | comparator faster in every run interval |
| `django_url_regex` | 0.458 | 0.457–0.467 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.164 | 0.162–0.169 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.177 | 0.175–0.189 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.441 | 0.390–0.451 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 1.393 | 1.376–1.441 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.188 | 0.170–0.210 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.149 | 0.143–0.154 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.230 | 0.228–0.230 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.195 | 0.191–0.201 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.146 | 0.139–0.156 | comparator faster in every run interval |
| `literal_first` | 0.552 | 0.507–0.570 | comparator faster in every run interval |
| `literal_middle` | 0.552 | 0.543–0.570 | comparator faster in every run interval |
| `literal_end` | 0.595 | 0.578–0.599 | comparator faster in every run interval |
| `literal_absent` | 0.404 | 0.397–0.435 | comparator faster in every run interval |

## onigmo / steady

Common cases: 24; families: 13. Pair-specific family-weighted ratio: 2.160.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 6.492 | 6.091–6.656 | Ferroni faster in every run interval |
| `uuid_v4` | 6.031 | 6.012–6.564 | Ferroni faster in every run interval |
| `ipv4_validation` | 6.502 | 5.671–7.099 | Ferroni faster in every run interval |
| `ipv6_validation` | 2.596 | 2.532–2.609 | Ferroni faster in every run interval |
| `semver_version_parse` | 1.201 | 1.195–1.249 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.167 | 1.121–1.180 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.019 | 0.989–1.028 | inconclusive |
| `jinja_integer_token` | 1.397 | 1.282–1.429 | Ferroni faster in every run interval |
| `jinja_float_token` | 2.157 | 2.119–2.164 | Ferroni faster in every run interval |
| `django_email_local_part` | 1.481 | 1.427–1.536 | Ferroni faster in every run interval |
| `django_email_domain` | 9.643 | 9.245–10.091 | Ferroni faster in every run interval |
| `django_url_regex` | 4.023 | 3.900–4.257 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.744 | 1.653–1.877 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 2.038 | 2.023–2.107 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 0.904 | 0.764–0.921 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 1.555 | 1.402–1.587 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 1.069 | 1.045–1.206 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 1.218 | 1.183–1.228 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 1.190 | 1.171–1.351 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_2` | 2.279 | 2.206–2.371 | Ferroni faster in every run interval |
| `literal_first` | 3.404 | 3.297–3.448 | Ferroni faster in every run interval |
| `literal_middle` | 4.501 | 4.464–4.604 | Ferroni faster in every run interval |
| `literal_end` | 6.122 | 5.893–6.441 | Ferroni faster in every run interval |
| `literal_absent` | 2.858 | 2.757–2.914 | Ferroni faster in every run interval |

## onigmo / compile

Common cases: 24; families: 13. Pair-specific family-weighted ratio: 0.510.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 4.117 | 4.111–4.222 | Ferroni faster in every run interval |
| `uuid_v4` | 4.768 | 4.561–4.797 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.250 | 0.193–0.272 | comparator faster in every run interval |
| `ipv6_validation` | 0.267 | 0.266–0.267 | comparator faster in every run interval |
| `semver_version_parse` | 0.241 | 0.239–0.280 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.277 | 0.266–0.288 | comparator faster in every run interval |
| `jinja_string_token` | 0.107 | 0.105–0.108 | comparator faster in every run interval |
| `jinja_integer_token` | 2.161 | 2.055–2.327 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.676 | 0.665–0.703 | comparator faster in every run interval |
| `django_email_local_part` | 2.446 | 2.039–2.530 | Ferroni faster in every run interval |
| `django_email_domain` | 0.154 | 0.148–0.159 | comparator faster in every run interval |
| `django_url_regex` | 0.364 | 0.359–0.372 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.147 | 0.138–0.148 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.154 | 0.151–0.163 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.391 | 0.368–0.474 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 1.458 | 1.388–1.552 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.112 | 0.107–0.113 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.099 | 0.097–0.101 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.216 | 0.207–0.233 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 8.493 | 8.127–8.719 | Ferroni faster in every run interval |
| `literal_first` | 0.268 | 0.259–0.282 | comparator faster in every run interval |
| `literal_middle` | 0.262 | 0.251–0.292 | comparator faster in every run interval |
| `literal_end` | 0.272 | 0.271–0.273 | comparator faster in every run interval |
| `literal_absent` | 0.279 | 0.267–0.282 | comparator faster in every run interval |

## onigmo / first_use

Common cases: 24; families: 13. Pair-specific family-weighted ratio: 0.526.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 3.352 | 3.178–3.490 | Ferroni faster in every run interval |
| `uuid_v4` | 3.733 | 3.545–3.734 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.234 | 0.208–0.275 | comparator faster in every run interval |
| `ipv6_validation` | 0.260 | 0.250–0.263 | comparator faster in every run interval |
| `semver_version_parse` | 0.254 | 0.242–0.268 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.290 | 0.273–0.297 | comparator faster in every run interval |
| `jinja_string_token` | 0.114 | 0.111–0.116 | comparator faster in every run interval |
| `jinja_integer_token` | 1.996 | 1.942–2.182 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.695 | 0.674–0.764 | comparator faster in every run interval |
| `django_email_local_part` | 2.334 | 1.894–2.414 | Ferroni faster in every run interval |
| `django_email_domain` | 0.151 | 0.145–0.160 | comparator faster in every run interval |
| `django_url_regex` | 0.387 | 0.351–0.407 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.165 | 0.157–0.172 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.187 | 0.174–0.206 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.399 | 0.396–0.458 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 1.438 | 1.411–1.595 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.133 | 0.124–0.136 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.111 | 0.109–0.114 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.218 | 0.212–0.228 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 8.289 | 7.625–8.303 | Ferroni faster in every run interval |
| `literal_first` | 0.335 | 0.332–0.339 | comparator faster in every run interval |
| `literal_middle` | 0.360 | 0.352–0.402 | comparator faster in every run interval |
| `literal_end` | 0.387 | 0.384–0.392 | comparator faster in every run interval |
| `literal_absent` | 0.358 | 0.345–0.367 | comparator faster in every run interval |

## pcre2_jit / steady

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.415.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.917 | 0.890–0.975 | inconclusive |
| `uuid_v4` | 0.991 | 0.941–1.060 | inconclusive |
| `ipv4_validation` | 1.396 | 1.211–1.558 | Ferroni faster in every run interval |
| `ipv6_validation` | 0.473 | 0.469–0.487 | comparator faster in every run interval |
| `semver_version_parse` | 0.339 | 0.336–0.345 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.496 | 0.481–0.497 | comparator faster in every run interval |
| `jinja_string_token` | 0.526 | 0.516–0.541 | comparator faster in every run interval |
| `jinja_integer_token` | 0.495 | 0.480–0.507 | comparator faster in every run interval |
| `jinja_float_token` | 0.502 | 0.501–0.511 | comparator faster in every run interval |
| `django_email_local_part` | 0.489 | 0.471–0.527 | comparator faster in every run interval |
| `django_email_domain` | 0.110 | 0.102–0.112 | comparator faster in every run interval |
| `django_url_regex` | 0.094 | 0.089–0.103 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.345 | 0.335–0.366 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.513 | 0.500–0.520 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.284 | 0.282–0.348 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.247 | 0.237–0.278 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.335 | 0.307–0.339 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.280 | 0.273–0.295 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.433 | 0.431–0.486 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.399 | 0.395–0.427 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.388 | 0.388–0.408 | comparator faster in every run interval |
| `literal_first` | 2.092 | 1.972–2.155 | Ferroni faster in every run interval |
| `literal_middle` | 2.300 | 2.284–2.374 | Ferroni faster in every run interval |
| `literal_end` | 1.900 | 1.775–1.987 | Ferroni faster in every run interval |
| `literal_absent` | 1.699 | 1.659–1.764 | Ferroni faster in every run interval |

## pcre2_jit / compile

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.318.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.261 | 0.254–0.271 | comparator faster in every run interval |
| `uuid_v4` | 0.294 | 0.285–0.309 | comparator faster in every run interval |
| `ipv4_validation` | 0.288 | 0.225–0.333 | comparator faster in every run interval |
| `ipv6_validation` | 0.319 | 0.317–0.337 | comparator faster in every run interval |
| `semver_version_parse` | 0.390 | 0.390–0.431 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.379 | 0.350–0.402 | comparator faster in every run interval |
| `jinja_string_token` | 0.271 | 0.269–0.278 | comparator faster in every run interval |
| `jinja_integer_token` | 0.305 | 0.281–0.311 | comparator faster in every run interval |
| `jinja_float_token` | 0.219 | 0.215–0.219 | comparator faster in every run interval |
| `django_email_local_part` | 0.439 | 0.359–0.481 | comparator faster in every run interval |
| `django_email_domain` | 0.069 | 0.058–0.069 | comparator faster in every run interval |
| `django_url_regex` | 0.077 | 0.077–0.087 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.277 | 0.256–0.304 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.273 | 0.265–0.305 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.648 | 0.636–0.809 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.164 | 0.149–0.169 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.497 | 0.470–0.509 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.394 | 0.360–0.402 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.427 | 0.420–0.493 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.230 | 0.215–0.249 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.215 | 0.194–0.224 | comparator faster in every run interval |
| `literal_first` | 2.367 | 2.072–2.511 | Ferroni faster in every run interval |
| `literal_middle` | 2.514 | 2.300–2.709 | Ferroni faster in every run interval |
| `literal_end` | 2.451 | 2.326–2.504 | Ferroni faster in every run interval |
| `literal_absent` | 2.416 | 2.319–2.754 | Ferroni faster in every run interval |

## pcre2_jit / first_use

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.363.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.206 | 0.203–0.221 | comparator faster in every run interval |
| `uuid_v4` | 0.230 | 0.221–0.248 | comparator faster in every run interval |
| `ipv4_validation` | 0.313 | 0.291–0.345 | comparator faster in every run interval |
| `ipv6_validation` | 0.339 | 0.314–0.347 | comparator faster in every run interval |
| `semver_version_parse` | 0.423 | 0.414–0.451 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.401 | 0.397–0.424 | comparator faster in every run interval |
| `jinja_string_token` | 0.354 | 0.342–0.355 | comparator faster in every run interval |
| `jinja_integer_token` | 0.317 | 0.315–0.378 | comparator faster in every run interval |
| `jinja_float_token` | 0.276 | 0.254–0.285 | comparator faster in every run interval |
| `django_email_local_part` | 0.461 | 0.380–0.544 | comparator faster in every run interval |
| `django_email_domain` | 0.069 | 0.058–0.070 | comparator faster in every run interval |
| `django_url_regex` | 0.084 | 0.078–0.089 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.318 | 0.311–0.359 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.343 | 0.318–0.391 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.889 | 0.859–1.010 | inconclusive |
| `mastodon_hashtag_regex_step` | 0.180 | 0.168–0.192 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.661 | 0.592–0.692 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.469 | 0.468–0.469 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.459 | 0.455–0.533 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.411 | 0.371–0.431 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.391 | 0.359–0.530 | comparator faster in every run interval |
| `literal_first` | 2.546 | 2.477–2.632 | Ferroni faster in every run interval |
| `literal_middle` | 2.568 | 2.470–2.940 | Ferroni faster in every run interval |
| `literal_end` | 2.444 | 2.443–2.564 | Ferroni faster in every run interval |
| `literal_absent` | 2.471 | 2.427–2.504 | Ferroni faster in every run interval |

## pcre2 / steady

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 1.166.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.821 | 1.798–1.862 | Ferroni faster in every run interval |
| `uuid_v4` | 1.945 | 1.940–2.142 | Ferroni faster in every run interval |
| `ipv4_validation` | 9.451 | 8.877–10.454 | Ferroni faster in every run interval |
| `ipv6_validation` | 2.503 | 2.288–2.527 | Ferroni faster in every run interval |
| `semver_version_parse` | 0.857 | 0.829–0.909 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 1.633 | 1.564–1.636 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.078 | 1.049–1.082 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.479 | 1.452–1.536 | Ferroni faster in every run interval |
| `jinja_float_token` | 1.511 | 1.488–1.526 | Ferroni faster in every run interval |
| `django_email_local_part` | 1.731 | 1.699–1.834 | Ferroni faster in every run interval |
| `django_email_domain` | 0.409 | 0.378–0.411 | comparator faster in every run interval |
| `django_url_regex` | 0.244 | 0.237–0.275 | comparator faster in every run interval |
| `fluent_bit_apache` | 1.090 | 1.078–1.139 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.206 | 1.188–1.237 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 0.984 | 0.933–1.130 | inconclusive |
| `mastodon_hashtag_regex_step` | 0.555 | 0.538–0.591 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 1.595 | 1.589–1.688 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 1.902 | 1.736–1.967 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 1.170 | 1.164–1.302 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.587 | 0.566–0.596 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.539 | 0.538–0.554 | comparator faster in every run interval |
| `literal_first` | 4.450 | 4.047–4.662 | Ferroni faster in every run interval |
| `literal_middle` | 4.587 | 4.443–4.791 | Ferroni faster in every run interval |
| `literal_end` | 3.813 | 3.616–3.859 | Ferroni faster in every run interval |
| `literal_absent` | 1.815 | 1.795–1.967 | Ferroni faster in every run interval |

## pcre2 / compile

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.094.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.107 | 0.106–0.111 | comparator faster in every run interval |
| `uuid_v4` | 0.116 | 0.114–0.120 | comparator faster in every run interval |
| `ipv4_validation` | 0.091 | 0.070–0.099 | comparator faster in every run interval |
| `ipv6_validation` | 0.101 | 0.086–0.103 | comparator faster in every run interval |
| `semver_version_parse` | 0.102 | 0.097–0.116 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.111 | 0.103–0.112 | comparator faster in every run interval |
| `jinja_string_token` | 0.059 | 0.056–0.063 | comparator faster in every run interval |
| `jinja_integer_token` | 0.087 | 0.086–0.091 | comparator faster in every run interval |
| `jinja_float_token` | 0.047 | 0.044–0.049 | comparator faster in every run interval |
| `django_email_local_part` | 0.248 | 0.203–0.263 | comparator faster in every run interval |
| `django_email_domain` | 0.063 | 0.052–0.064 | comparator faster in every run interval |
| `django_url_regex` | 0.065 | 0.064–0.072 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.060 | 0.058–0.061 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.070 | 0.067–0.070 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.197 | 0.194–0.243 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.082 | 0.082–0.083 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.088 | 0.086–0.091 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.073 | 0.065–0.078 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.119 | 0.115–0.128 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.033 | 0.032–0.036 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.029 | 0.029–0.032 | comparator faster in every run interval |
| `literal_first` | 0.245 | 0.210–0.258 | comparator faster in every run interval |
| `literal_middle` | 0.242 | 0.227–0.244 | comparator faster in every run interval |
| `literal_end` | 0.241 | 0.236–0.251 | comparator faster in every run interval |
| `literal_absent` | 0.242 | 0.234–0.244 | comparator faster in every run interval |

## pcre2 / first_use

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.116.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.094 | 0.093–0.100 | comparator faster in every run interval |
| `uuid_v4` | 0.101 | 0.096–0.101 | comparator faster in every run interval |
| `ipv4_validation` | 0.096 | 0.079–0.098 | comparator faster in every run interval |
| `ipv6_validation` | 0.097 | 0.095–0.108 | comparator faster in every run interval |
| `semver_version_parse` | 0.110 | 0.108–0.119 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.116 | 0.110–0.116 | comparator faster in every run interval |
| `jinja_string_token` | 0.079 | 0.073–0.082 | comparator faster in every run interval |
| `jinja_integer_token` | 0.092 | 0.082–0.097 | comparator faster in every run interval |
| `jinja_float_token` | 0.055 | 0.054–0.067 | comparator faster in every run interval |
| `django_email_local_part` | 0.254 | 0.195–0.256 | comparator faster in every run interval |
| `django_email_domain` | 0.059 | 0.053–0.064 | comparator faster in every run interval |
| `django_url_regex` | 0.065 | 0.062–0.074 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.080 | 0.080–0.081 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.086 | 0.085–0.094 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.222 | 0.217–0.256 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.085 | 0.084–0.090 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.139 | 0.127–0.140 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.112 | 0.098–0.114 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.129 | 0.123–0.140 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.101 | 0.099–0.104 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.079 | 0.069–0.082 | comparator faster in every run interval |
| `literal_first` | 0.515 | 0.505–0.556 | comparator faster in every run interval |
| `literal_middle` | 0.537 | 0.528–0.581 | comparator faster in every run interval |
| `literal_end` | 0.500 | 0.493–0.516 | comparator faster in every run interval |
| `literal_absent` | 0.411 | 0.362–0.448 | comparator faster in every run interval |

## fancy_regex / steady

Common cases: 21; families: 11. Pair-specific family-weighted ratio: 1.477.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.994 | 0.990–1.008 | inconclusive |
| `uuid_v4` | 1.069 | 0.995–1.178 | inconclusive |
| `ipv4_validation` | 1.109 | 0.948–1.117 | inconclusive |
| `ipv6_validation` | 0.135 | 0.132–0.137 | comparator faster in every run interval |
| `semver_version_parse` | 1.716 | 1.656–1.740 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 2.227 | 1.918–2.268 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.065 | 1.054–1.077 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.334 | 1.333–1.356 | Ferroni faster in every run interval |
| `jinja_float_token` | 2.392 | 2.165–2.393 | Ferroni faster in every run interval |
| `django_email_domain` | 1.268 | 1.100–1.270 | Ferroni faster in every run interval |
| `django_url_regex` | 1.940 | 1.836–2.079 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.440 | 1.437–1.534 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.715 | 1.708–1.764 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 2.565 | 2.450–2.914 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 1.669 | 1.593–1.952 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 2.219 | 2.120–2.546 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 1.983 | 1.902–2.336 | Ferroni faster in every run interval |
| `literal_first` | 1.736 | 1.617–1.797 | Ferroni faster in every run interval |
| `literal_middle` | 1.872 | 1.855–1.900 | Ferroni faster in every run interval |
| `literal_end` | 1.534 | 1.411–1.545 | Ferroni faster in every run interval |
| `literal_absent` | 1.450 | 1.354–1.577 | Ferroni faster in every run interval |

## fancy_regex / compile

Common cases: 21; families: 11. Pair-specific family-weighted ratio: 1.985.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.134 | 1.095–1.139 | Ferroni faster in every run interval |
| `uuid_v4` | 1.144 | 1.101–1.216 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.842 | 0.633–0.855 | comparator faster in every run interval |
| `ipv6_validation` | 0.831 | 0.776–0.886 | comparator faster in every run interval |
| `semver_version_parse` | 11.382 | 11.236–11.421 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 7.843 | 7.039–7.926 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.966 | 1.839–2.031 | Ferroni faster in every run interval |
| `jinja_integer_token` | 2.180 | 2.125–2.198 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.288 | 0.264–0.303 | comparator faster in every run interval |
| `django_email_domain` | 9.452 | 7.755–9.868 | Ferroni faster in every run interval |
| `django_url_regex` | 8.742 | 8.385–8.846 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.631 | 1.495–1.636 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.690 | 1.681–1.771 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.284 | 1.154–1.326 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.560 | 0.528–0.643 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.484 | 0.443–0.484 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 1.258 | 1.244–1.470 | Ferroni faster in every run interval |
| `literal_first` | 1.762 | 1.731–1.769 | Ferroni faster in every run interval |
| `literal_middle` | 1.728 | 1.721–1.735 | Ferroni faster in every run interval |
| `literal_end` | 1.649 | 1.624–1.721 | Ferroni faster in every run interval |
| `literal_absent` | 1.622 | 1.523–1.673 | Ferroni faster in every run interval |

## fancy_regex / first_use

Common cases: 21; families: 11. Pair-specific family-weighted ratio: 2.068.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.133 | 1.084–1.260 | Ferroni faster in every run interval |
| `uuid_v4` | 1.148 | 1.133–1.224 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.859 | 0.766–0.878 | comparator faster in every run interval |
| `ipv6_validation` | 0.832 | 0.806–0.911 | comparator faster in every run interval |
| `semver_version_parse` | 11.042 | 11.020–11.225 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 7.790 | 7.547–8.035 | Ferroni faster in every run interval |
| `jinja_string_token` | 2.019 | 1.990–2.048 | Ferroni faster in every run interval |
| `jinja_integer_token` | 2.205 | 2.023–2.268 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.297 | 0.256–0.315 | comparator faster in every run interval |
| `django_email_domain` | 9.386 | 7.749–9.427 | Ferroni faster in every run interval |
| `django_url_regex` | 8.858 | 8.439–9.077 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.767 | 1.737–1.929 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.932 | 1.831–1.966 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.541 | 1.369–1.542 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.585 | 0.509–0.651 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.506 | 0.485–0.523 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 1.320 | 1.298–1.420 | Ferroni faster in every run interval |
| `literal_first` | 1.787 | 1.666–2.057 | Ferroni faster in every run interval |
| `literal_middle` | 1.893 | 1.782–1.908 | Ferroni faster in every run interval |
| `literal_end` | 1.738 | 1.677–1.831 | Ferroni faster in every run interval |
| `literal_absent` | 1.682 | 1.530–1.691 | Ferroni faster in every run interval |

## fancy_regex_seek / steady

Common cases: 21; families: 11. Pair-specific family-weighted ratio: 1.472.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.961 | 0.924–0.977 | comparator faster in every run interval |
| `uuid_v4` | 1.113 | 1.100–1.117 | Ferroni faster in every run interval |
| `ipv4_validation` | 1.098 | 0.956–1.108 | inconclusive |
| `ipv6_validation` | 0.141 | 0.136–0.147 | comparator faster in every run interval |
| `semver_version_parse` | 1.736 | 1.694–1.758 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 2.357 | 1.871–2.387 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.031 | 1.012–1.039 | inconclusive |
| `jinja_integer_token` | 1.287 | 1.233–1.328 | Ferroni faster in every run interval |
| `jinja_float_token` | 2.323 | 1.978–2.599 | Ferroni faster in every run interval |
| `django_email_domain` | 1.171 | 1.086–1.209 | Ferroni faster in every run interval |
| `django_url_regex` | 1.847 | 1.846–1.905 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.457 | 1.439–1.511 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.711 | 1.622–1.715 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 2.633 | 2.421–2.653 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 1.568 | 1.562–1.634 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 2.493 | 2.320–2.511 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 1.971 | 1.937–2.263 | Ferroni faster in every run interval |
| `literal_first` | 1.741 | 1.599–1.860 | Ferroni faster in every run interval |
| `literal_middle` | 1.835 | 1.745–1.856 | Ferroni faster in every run interval |
| `literal_end` | 1.600 | 1.409–1.623 | Ferroni faster in every run interval |
| `literal_absent` | 1.532 | 1.312–1.543 | Ferroni faster in every run interval |

## fancy_regex_seek / compile

Common cases: 21; families: 11. Pair-specific family-weighted ratio: 2.155.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.091 | 0.958–1.107 | inconclusive |
| `uuid_v4` | 1.179 | 1.076–1.183 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.841 | 0.749–0.859 | comparator faster in every run interval |
| `ipv6_validation` | 0.891 | 0.810–0.893 | comparator faster in every run interval |
| `semver_version_parse` | 11.450 | 11.205–11.839 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 8.037 | 6.542–9.078 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.910 | 1.905–1.928 | Ferroni faster in every run interval |
| `jinja_integer_token` | 2.073 | 1.966–2.178 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.298 | 0.227–0.332 | comparator faster in every run interval |
| `django_email_domain` | 9.432 | 7.578–9.453 | Ferroni faster in every run interval |
| `django_url_regex` | 8.668 | 8.419–8.759 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.532 | 1.518–1.732 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.659 | 1.639–1.662 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.241 | 1.192–1.284 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.560 | 0.512–0.611 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.490 | 0.451–0.517 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 3.315 | 3.314–3.826 | Ferroni faster in every run interval |
| `literal_first` | 1.786 | 1.586–1.874 | Ferroni faster in every run interval |
| `literal_middle` | 1.635 | 1.627–1.658 | Ferroni faster in every run interval |
| `literal_end` | 1.639 | 1.622–1.742 | Ferroni faster in every run interval |
| `literal_absent` | 1.584 | 1.501–1.686 | Ferroni faster in every run interval |

## fancy_regex_seek / first_use

Common cases: 21; families: 11. Pair-specific family-weighted ratio: 2.249.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.093 | 1.059–1.108 | Ferroni faster in every run interval |
| `uuid_v4` | 1.182 | 1.069–1.258 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.863 | 0.863–0.931 | comparator faster in every run interval |
| `ipv6_validation` | 0.907 | 0.880–0.923 | comparator faster in every run interval |
| `semver_version_parse` | 11.330 | 11.251–11.345 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 7.999 | 7.056–8.260 | Ferroni faster in every run interval |
| `jinja_string_token` | 2.043 | 1.971–2.092 | Ferroni faster in every run interval |
| `jinja_integer_token` | 2.037 | 2.019–2.152 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.294 | 0.259–0.343 | comparator faster in every run interval |
| `django_email_domain` | 9.009 | 7.526–9.370 | Ferroni faster in every run interval |
| `django_url_regex` | 8.573 | 8.252–8.841 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.714 | 1.697–1.758 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.910 | 1.791–2.083 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.481 | 1.416–1.535 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.587 | 0.544–0.590 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.509 | 0.438–0.518 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 3.643 | 3.641–4.052 | Ferroni faster in every run interval |
| `literal_first` | 1.890 | 1.688–1.974 | Ferroni faster in every run interval |
| `literal_middle` | 1.798 | 1.751–1.871 | Ferroni faster in every run interval |
| `literal_end` | 1.702 | 1.671–1.781 | Ferroni faster in every run interval |
| `literal_absent` | 1.683 | 1.595–1.794 | Ferroni faster in every run interval |

## regex / steady

Common cases: 14; families: 6. Pair-specific family-weighted ratio: 0.983.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.895 | 0.851–0.908 | comparator faster in every run interval |
| `uuid_v4` | 0.989 | 0.980–0.994 | inconclusive |
| `ipv4_validation` | 0.955 | 0.955–0.994 | inconclusive |
| `ipv6_validation` | 0.124 | 0.122–0.130 | comparator faster in every run interval |
| `semver_version_parse` | 1.524 | 1.511–1.588 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.981 | 1.760–1.990 | Ferroni faster in every run interval |
| `jinja_string_token` | 0.735 | 0.730–0.746 | comparator faster in every run interval |
| `jinja_integer_token` | 1.057 | 0.992–1.172 | inconclusive |
| `fluent_bit_apache` | 1.355 | 1.339–1.491 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.570 | 1.559–1.638 | Ferroni faster in every run interval |
| `literal_first` | 1.309 | 1.220–1.325 | Ferroni faster in every run interval |
| `literal_middle` | 1.340 | 1.321–1.413 | Ferroni faster in every run interval |
| `literal_end` | 1.163 | 1.148–1.220 | Ferroni faster in every run interval |
| `literal_absent` | 1.193 | 0.982–1.241 | inconclusive |

## regex / compile

Common cases: 14; families: 6. Pair-specific family-weighted ratio: 1.787.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.835 | 0.717–0.853 | comparator faster in every run interval |
| `uuid_v4` | 0.839 | 0.766–0.878 | comparator faster in every run interval |
| `ipv4_validation` | 0.750 | 0.660–0.777 | comparator faster in every run interval |
| `ipv6_validation` | 0.791 | 0.736–0.791 | comparator faster in every run interval |
| `semver_version_parse` | 11.463 | 10.739–12.020 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 7.912 | 7.590–8.424 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.937 | 1.931–1.951 | Ferroni faster in every run interval |
| `jinja_integer_token` | 2.009 | 1.769–2.060 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.562 | 1.542–1.664 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.605 | 1.528–1.618 | Ferroni faster in every run interval |
| `literal_first` | 1.732 | 1.674–1.816 | Ferroni faster in every run interval |
| `literal_middle` | 1.705 | 1.571–1.752 | Ferroni faster in every run interval |
| `literal_end` | 1.667 | 1.594–1.707 | Ferroni faster in every run interval |
| `literal_absent` | 1.680 | 1.533–1.808 | Ferroni faster in every run interval |

## regex / first_use

Common cases: 14; families: 6. Pair-specific family-weighted ratio: 1.863.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.890 | 0.852–0.921 | comparator faster in every run interval |
| `uuid_v4` | 0.867 | 0.861–0.895 | comparator faster in every run interval |
| `ipv4_validation` | 0.785 | 0.782–0.786 | comparator faster in every run interval |
| `ipv6_validation` | 0.770 | 0.753–0.824 | comparator faster in every run interval |
| `semver_version_parse` | 11.646 | 11.209–11.823 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 8.304 | 7.666–8.579 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.994 | 1.991–2.007 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.958 | 1.842–2.156 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.772 | 1.685–1.896 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.850 | 1.807–1.865 | Ferroni faster in every run interval |
| `literal_first` | 1.775 | 1.742–1.955 | Ferroni faster in every run interval |
| `literal_middle` | 1.675 | 1.621–1.757 | Ferroni faster in every run interval |
| `literal_end` | 1.693 | 1.667–1.729 | Ferroni faster in every run interval |
| `literal_absent` | 1.816 | 1.744–1.852 | Ferroni faster in every run interval |

Raw samples, estimates, confidence intervals, failures, eligibility reasons, corpus snapshot and execution order are retained beside this report.

Memory, where requested, is fresh-process peak RSS including the binary, runtime, parsed catalog, compilation, input/output and allocator. It is not isolated compiled-pattern memory.
