# Production regex comparison

Host: macOS-26.3-arm64-arm-64bit-Mach-O; arm64.

Publication candidate: review host stability, raw samples, coverage and run intervals before publishing.

Ratios are comparator / Ferroni. Compile and first-use times concern one pattern; steady times concern the complete fixture batch.

Each comparison below uses only its explicitly listed common tasks. Families have equal aggregate weight; architectures are never combined.

## Eligibility

| Case | Engine | Status |
| --- | --- | --- |
| `uuid_shape` | rust | eligible |
| `uuid_shape` | rust_erroraware | eligible |
| `uuid_shape` | c | eligible |
| `uuid_shape` | onigmo | eligible |
| `uuid_shape` | pcre2_jit | eligible |
| `uuid_shape` | pcre2 | eligible |
| `uuid_shape` | fancy_regex | eligible |
| `uuid_shape` | fancy_regex_seek | eligible |
| `uuid_shape` | regex | eligible |
| `uuid_v4` | rust | eligible |
| `uuid_v4` | rust_erroraware | eligible |
| `uuid_v4` | c | eligible |
| `uuid_v4` | onigmo | eligible |
| `uuid_v4` | pcre2_jit | eligible |
| `uuid_v4` | pcre2 | eligible |
| `uuid_v4` | fancy_regex | eligible |
| `uuid_v4` | fancy_regex_seek | eligible |
| `uuid_v4` | regex | eligible |
| `ipv4_validation` | rust | eligible |
| `ipv4_validation` | rust_erroraware | eligible |
| `ipv4_validation` | c | eligible |
| `ipv4_validation` | onigmo | eligible |
| `ipv4_validation` | pcre2_jit | eligible |
| `ipv4_validation` | pcre2 | eligible |
| `ipv4_validation` | fancy_regex | eligible |
| `ipv4_validation` | fancy_regex_seek | eligible |
| `ipv4_validation` | regex | eligible |
| `ipv6_validation` | rust | eligible |
| `ipv6_validation` | rust_erroraware | eligible |
| `ipv6_validation` | c | eligible |
| `ipv6_validation` | onigmo | eligible |
| `ipv6_validation` | pcre2_jit | eligible |
| `ipv6_validation` | pcre2 | eligible |
| `ipv6_validation` | fancy_regex | eligible |
| `ipv6_validation` | fancy_regex_seek | eligible |
| `ipv6_validation` | regex | eligible |
| `semver_version_parse` | rust | eligible |
| `semver_version_parse` | rust_erroraware | eligible |
| `semver_version_parse` | c | eligible |
| `semver_version_parse` | onigmo | eligible |
| `semver_version_parse` | pcre2_jit | eligible |
| `semver_version_parse` | pcre2 | eligible |
| `semver_version_parse` | fancy_regex | eligible |
| `semver_version_parse` | fancy_regex_seek | eligible |
| `semver_version_parse` | regex | eligible |
| `semver_hyphen_range_captures` | rust | eligible |
| `semver_hyphen_range_captures` | rust_erroraware | eligible |
| `semver_hyphen_range_captures` | c | eligible |
| `semver_hyphen_range_captures` | onigmo | eligible |
| `semver_hyphen_range_captures` | pcre2_jit | eligible |
| `semver_hyphen_range_captures` | pcre2 | eligible |
| `semver_hyphen_range_captures` | fancy_regex | eligible |
| `semver_hyphen_range_captures` | fancy_regex_seek | eligible |
| `semver_hyphen_range_captures` | regex | eligible |
| `jinja_string_token` | rust | eligible |
| `jinja_string_token` | rust_erroraware | eligible |
| `jinja_string_token` | c | eligible |
| `jinja_string_token` | onigmo | eligible |
| `jinja_string_token` | pcre2_jit | eligible |
| `jinja_string_token` | pcre2 | eligible |
| `jinja_string_token` | fancy_regex | eligible |
| `jinja_string_token` | fancy_regex_seek | eligible |
| `jinja_string_token` | regex | eligible |
| `jinja_integer_token` | rust | eligible |
| `jinja_integer_token` | rust_erroraware | eligible |
| `jinja_integer_token` | c | eligible |
| `jinja_integer_token` | onigmo | eligible |
| `jinja_integer_token` | pcre2_jit | eligible |
| `jinja_integer_token` | pcre2 | eligible |
| `jinja_integer_token` | fancy_regex | eligible |
| `jinja_integer_token` | fancy_regex_seek | eligible |
| `jinja_integer_token` | regex | eligible |
| `jinja_float_token` | rust | eligible |
| `jinja_float_token` | rust_erroraware | eligible |
| `jinja_float_token` | c | eligible |
| `jinja_float_token` | onigmo | eligible |
| `jinja_float_token` | pcre2_jit | eligible |
| `jinja_float_token` | pcre2 | eligible |
| `jinja_float_token` | fancy_regex | eligible |
| `jinja_float_token` | fancy_regex_seek | eligible |
| `jinja_float_token` | regex | syntax_rejected |
| `django_email_local_part` | rust | eligible |
| `django_email_local_part` | rust_erroraware | eligible |
| `django_email_local_part` | c | eligible |
| `django_email_local_part` | onigmo | eligible |
| `django_email_local_part` | pcre2_jit | eligible |
| `django_email_local_part` | pcre2 | eligible |
| `django_email_local_part` | fancy_regex | syntax_rejected |
| `django_email_local_part` | fancy_regex_seek | syntax_rejected |
| `django_email_local_part` | regex | syntax_rejected |
| `django_email_domain` | rust | eligible |
| `django_email_domain` | rust_erroraware | eligible |
| `django_email_domain` | c | eligible |
| `django_email_domain` | onigmo | eligible |
| `django_email_domain` | pcre2_jit | eligible |
| `django_email_domain` | pcre2 | eligible |
| `django_email_domain` | fancy_regex | eligible |
| `django_email_domain` | fancy_regex_seek | eligible |
| `django_email_domain` | regex | syntax_rejected |
| `django_url_regex` | rust | eligible |
| `django_url_regex` | rust_erroraware | eligible |
| `django_url_regex` | c | eligible |
| `django_url_regex` | onigmo | eligible |
| `django_url_regex` | pcre2_jit | eligible |
| `django_url_regex` | pcre2 | eligible |
| `django_url_regex` | fancy_regex | eligible |
| `django_url_regex` | fancy_regex_seek | eligible |
| `django_url_regex` | regex | syntax_rejected |
| `fluent_bit_apache` | rust | eligible |
| `fluent_bit_apache` | rust_erroraware | eligible |
| `fluent_bit_apache` | c | eligible |
| `fluent_bit_apache` | onigmo | eligible |
| `fluent_bit_apache` | pcre2_jit | eligible |
| `fluent_bit_apache` | pcre2 | eligible |
| `fluent_bit_apache` | fancy_regex | eligible |
| `fluent_bit_apache` | fancy_regex_seek | eligible |
| `fluent_bit_apache` | regex | eligible |
| `fluent_bit_nginx` | rust | eligible |
| `fluent_bit_nginx` | rust_erroraware | eligible |
| `fluent_bit_nginx` | c | eligible |
| `fluent_bit_nginx` | onigmo | eligible |
| `fluent_bit_nginx` | pcre2_jit | eligible |
| `fluent_bit_nginx` | pcre2 | eligible |
| `fluent_bit_nginx` | fancy_regex | eligible |
| `fluent_bit_nginx` | fancy_regex_seek | eligible |
| `fluent_bit_nginx` | regex | eligible |
| `rails_underscore_regex_step` | rust | eligible |
| `rails_underscore_regex_step` | rust_erroraware | eligible |
| `rails_underscore_regex_step` | c | eligible |
| `rails_underscore_regex_step` | onigmo | eligible |
| `rails_underscore_regex_step` | pcre2_jit | eligible |
| `rails_underscore_regex_step` | pcre2 | eligible |
| `rails_underscore_regex_step` | fancy_regex | eligible |
| `rails_underscore_regex_step` | fancy_regex_seek | eligible |
| `rails_underscore_regex_step` | regex | syntax_rejected |
| `mastodon_hashtag_regex_step` | rust | eligible |
| `mastodon_hashtag_regex_step` | rust_erroraware | eligible |
| `mastodon_hashtag_regex_step` | c | eligible |
| `mastodon_hashtag_regex_step` | onigmo | eligible |
| `mastodon_hashtag_regex_step` | pcre2_jit | eligible |
| `mastodon_hashtag_regex_step` | pcre2 | eligible |
| `mastodon_hashtag_regex_step` | fancy_regex | semantic_difference |
| `mastodon_hashtag_regex_step` | fancy_regex_seek | semantic_difference |
| `mastodon_hashtag_regex_step` | regex | syntax_rejected |
| `python_markdown_smart_emphasis_re` | rust | eligible |
| `python_markdown_smart_emphasis_re` | rust_erroraware | eligible |
| `python_markdown_smart_emphasis_re` | c | eligible |
| `python_markdown_smart_emphasis_re` | onigmo | eligible |
| `python_markdown_smart_emphasis_re` | pcre2_jit | eligible |
| `python_markdown_smart_emphasis_re` | pcre2 | eligible |
| `python_markdown_smart_emphasis_re` | fancy_regex | eligible |
| `python_markdown_smart_emphasis_re` | fancy_regex_seek | eligible |
| `python_markdown_smart_emphasis_re` | regex | syntax_rejected |
| `python_markdown_smart_strong_em_re` | rust | eligible |
| `python_markdown_smart_strong_em_re` | rust_erroraware | eligible |
| `python_markdown_smart_strong_em_re` | c | eligible |
| `python_markdown_smart_strong_em_re` | onigmo | eligible |
| `python_markdown_smart_strong_em_re` | pcre2_jit | eligible |
| `python_markdown_smart_strong_em_re` | pcre2 | eligible |
| `python_markdown_smart_strong_em_re` | fancy_regex | eligible |
| `python_markdown_smart_strong_em_re` | fancy_regex_seek | eligible |
| `python_markdown_smart_strong_em_re` | regex | syntax_rejected |
| `wordpress_shortcode_captures` | rust | eligible |
| `wordpress_shortcode_captures` | rust_erroraware | eligible |
| `wordpress_shortcode_captures` | c | eligible |
| `wordpress_shortcode_captures` | onigmo | eligible |
| `wordpress_shortcode_captures` | pcre2_jit | eligible |
| `wordpress_shortcode_captures` | pcre2 | eligible |
| `wordpress_shortcode_captures` | fancy_regex | eligible |
| `wordpress_shortcode_captures` | fancy_regex_seek | eligible |
| `wordpress_shortcode_captures` | regex | syntax_rejected |
| `symfony_grapheme_chunks_1` | rust | eligible |
| `symfony_grapheme_chunks_1` | rust_erroraware | eligible |
| `symfony_grapheme_chunks_1` | c | eligible |
| `symfony_grapheme_chunks_1` | onigmo | semantic_difference |
| `symfony_grapheme_chunks_1` | pcre2_jit | eligible |
| `symfony_grapheme_chunks_1` | pcre2 | eligible |
| `symfony_grapheme_chunks_1` | fancy_regex | syntax_rejected |
| `symfony_grapheme_chunks_1` | fancy_regex_seek | syntax_rejected |
| `symfony_grapheme_chunks_1` | regex | syntax_rejected |
| `symfony_grapheme_chunks_2` | rust | eligible |
| `symfony_grapheme_chunks_2` | rust_erroraware | eligible |
| `symfony_grapheme_chunks_2` | c | eligible |
| `symfony_grapheme_chunks_2` | onigmo | eligible |
| `symfony_grapheme_chunks_2` | pcre2_jit | eligible |
| `symfony_grapheme_chunks_2` | pcre2 | eligible |
| `symfony_grapheme_chunks_2` | fancy_regex | syntax_rejected |
| `symfony_grapheme_chunks_2` | fancy_regex_seek | syntax_rejected |
| `symfony_grapheme_chunks_2` | regex | syntax_rejected |
| `literal_first` | rust | eligible |
| `literal_first` | rust_erroraware | eligible |
| `literal_first` | c | eligible |
| `literal_first` | onigmo | eligible |
| `literal_first` | pcre2_jit | eligible |
| `literal_first` | pcre2 | eligible |
| `literal_first` | fancy_regex | eligible |
| `literal_first` | fancy_regex_seek | eligible |
| `literal_first` | regex | eligible |
| `literal_middle` | rust | eligible |
| `literal_middle` | rust_erroraware | eligible |
| `literal_middle` | c | eligible |
| `literal_middle` | onigmo | eligible |
| `literal_middle` | pcre2_jit | eligible |
| `literal_middle` | pcre2 | eligible |
| `literal_middle` | fancy_regex | eligible |
| `literal_middle` | fancy_regex_seek | eligible |
| `literal_middle` | regex | eligible |
| `literal_end` | rust | eligible |
| `literal_end` | rust_erroraware | eligible |
| `literal_end` | c | eligible |
| `literal_end` | onigmo | eligible |
| `literal_end` | pcre2_jit | eligible |
| `literal_end` | pcre2 | eligible |
| `literal_end` | fancy_regex | eligible |
| `literal_end` | fancy_regex_seek | eligible |
| `literal_end` | regex | eligible |
| `literal_absent` | rust | eligible |
| `literal_absent` | rust_erroraware | eligible |
| `literal_absent` | c | eligible |
| `literal_absent` | onigmo | eligible |
| `literal_absent` | pcre2_jit | eligible |
| `literal_absent` | pcre2 | eligible |
| `literal_absent` | fancy_regex | eligible |
| `literal_absent` | fancy_regex_seek | eligible |
| `literal_absent` | regex | eligible |
| `linkify_http_tail` | rust | pending |
| `linkify_http_tail` | rust_erroraware | pending |
| `linkify_http_tail` | c | pending |
| `linkify_http_tail` | onigmo | pending |
| `linkify_http_tail` | pcre2_jit | pending |
| `linkify_http_tail` | pcre2 | pending |
| `linkify_http_tail` | fancy_regex | pending |
| `linkify_http_tail` | fancy_regex_seek | pending |
| `linkify_http_tail` | regex | pending |
| `php_cs_fixer_recursive_types` | rust | pending |
| `php_cs_fixer_recursive_types` | rust_erroraware | pending |
| `php_cs_fixer_recursive_types` | c | pending |
| `php_cs_fixer_recursive_types` | onigmo | pending |
| `php_cs_fixer_recursive_types` | pcre2_jit | pending |
| `php_cs_fixer_recursive_types` | pcre2 | pending |
| `php_cs_fixer_recursive_types` | fancy_regex | pending |
| `php_cs_fixer_recursive_types` | fancy_regex_seek | pending |
| `php_cs_fixer_recursive_types` | regex | pending |
| `ferrolink_markup_scan` | rust | eligible |
| `ferrolink_markup_scan` | rust_erroraware | eligible |
| `ferrolink_markup_scan` | c | eligible |
| `ferrolink_markup_scan` | onigmo | eligible |
| `ferrolink_markup_scan` | pcre2_jit | eligible |
| `ferrolink_markup_scan` | pcre2 | eligible |
| `ferrolink_markup_scan` | fancy_regex | eligible |
| `ferrolink_markup_scan` | fancy_regex_seek | eligible |
| `ferrolink_markup_scan` | regex | syntax_rejected |
| `ferrolink_attribute_split` | rust | eligible |
| `ferrolink_attribute_split` | rust_erroraware | eligible |
| `ferrolink_attribute_split` | c | eligible |
| `ferrolink_attribute_split` | onigmo | eligible |
| `ferrolink_attribute_split` | pcre2_jit | eligible |
| `ferrolink_attribute_split` | pcre2 | eligible |
| `ferrolink_attribute_split` | fancy_regex | eligible |
| `ferrolink_attribute_split` | fancy_regex_seek | eligible |
| `ferrolink_attribute_split` | regex | eligible |

## rust_erroraware / steady

Common cases: 27; families: 14. Pair-specific family-weighted ratio: 1.802.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.841 | 1.728–1.912 | Ferroni faster in every run interval |
| `uuid_v4` | 1.923 | 1.848–1.991 | Ferroni faster in every run interval |
| `ipv4_validation` | 6.144 | 5.814–6.580 | Ferroni faster in every run interval |
| `ipv6_validation` | 13.966 | 13.021–14.072 | Ferroni faster in every run interval |
| `semver_version_parse` | 1.083 | 1.071–1.109 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.111 | 1.093–1.121 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.160 | 1.157–1.163 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.144 | 1.066–1.232 | Ferroni faster in every run interval |
| `jinja_float_token` | 1.351 | 1.301–1.387 | Ferroni faster in every run interval |
| `django_email_local_part` | 3.446 | 3.261–3.534 | Ferroni faster in every run interval |
| `django_email_domain` | 7.789 | 7.353–7.791 | Ferroni faster in every run interval |
| `django_url_regex` | 11.498 | 11.023–12.630 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.106 | 1.093–1.127 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.269 | 1.242–1.289 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 0.999 | 0.998–1.009 | inconclusive |
| `mastodon_hashtag_regex_step` | 1.058 | 1.037–1.073 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 1.170 | 0.996–1.173 | inconclusive |
| `python_markdown_smart_strong_em_re` | 1.070 | 1.018–1.109 | inconclusive |
| `wordpress_shortcode_captures` | 1.069 | 1.018–1.075 | inconclusive |
| `symfony_grapheme_chunks_1` | 1.044 | 1.040–1.106 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_2` | 1.047 | 1.006–1.123 | inconclusive |
| `literal_first` | 1.796 | 1.541–1.812 | Ferroni faster in every run interval |
| `literal_middle` | 1.753 | 1.702–1.900 | Ferroni faster in every run interval |
| `literal_end` | 1.616 | 1.528–1.712 | Ferroni faster in every run interval |
| `literal_absent` | 1.564 | 1.505–1.568 | Ferroni faster in every run interval |
| `ferrolink_markup_scan` | 1.028 | 1.009–1.045 | inconclusive |
| `ferrolink_attribute_split` | 1.066 | 1.052–1.140 | Ferroni faster in every run interval |

## rust_erroraware / compile

Common cases: 27; families: 14. Pair-specific family-weighted ratio: 1.004.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.980 | 0.952–0.993 | inconclusive |
| `uuid_v4` | 1.011 | 0.996–1.024 | inconclusive |
| `ipv4_validation` | 0.986 | 0.975–1.030 | inconclusive |
| `ipv6_validation` | 0.994 | 0.958–1.013 | inconclusive |
| `semver_version_parse` | 1.020 | 0.826–1.061 | inconclusive |
| `semver_hyphen_range_captures` | 1.003 | 0.973–1.029 | inconclusive |
| `jinja_string_token` | 0.996 | 0.949–1.027 | inconclusive |
| `jinja_integer_token` | 0.985 | 0.970–1.064 | inconclusive |
| `jinja_float_token` | 0.998 | 0.972–1.056 | inconclusive |
| `django_email_local_part` | 0.989 | 0.981–1.019 | inconclusive |
| `django_email_domain` | 0.982 | 0.831–1.054 | inconclusive |
| `django_url_regex` | 1.013 | 1.004–1.220 | inconclusive |
| `fluent_bit_apache` | 1.041 | 1.018–1.042 | inconclusive |
| `fluent_bit_nginx` | 1.030 | 1.016–1.135 | inconclusive |
| `rails_underscore_regex_step` | 1.012 | 1.002–1.071 | inconclusive |
| `mastodon_hashtag_regex_step` | 1.028 | 0.962–1.105 | inconclusive |
| `python_markdown_smart_emphasis_re` | 1.038 | 0.836–1.041 | inconclusive |
| `python_markdown_smart_strong_em_re` | 0.947 | 0.921–1.096 | inconclusive |
| `wordpress_shortcode_captures` | 0.993 | 0.983–1.037 | inconclusive |
| `symfony_grapheme_chunks_1` | 0.986 | 0.956–1.021 | inconclusive |
| `symfony_grapheme_chunks_2` | 1.013 | 0.992–1.060 | inconclusive |
| `literal_first` | 1.005 | 0.937–1.050 | inconclusive |
| `literal_middle` | 0.937 | 0.898–1.009 | inconclusive |
| `literal_end` | 1.056 | 1.044–1.113 | inconclusive |
| `literal_absent` | 0.955 | 0.920–0.984 | comparator faster in every run interval |
| `ferrolink_markup_scan` | 0.998 | 0.989–1.039 | inconclusive |
| `ferrolink_attribute_split` | 1.045 | 0.988–1.081 | inconclusive |

## rust_erroraware / first_use

Common cases: 27; families: 14. Pair-specific family-weighted ratio: 0.779.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.520 | 0.514–0.550 | comparator faster in every run interval |
| `uuid_v4` | 0.534 | 0.532–0.563 | comparator faster in every run interval |
| `ipv4_validation` | 0.702 | 0.691–0.761 | comparator faster in every run interval |
| `ipv6_validation` | 0.716 | 0.676–0.732 | comparator faster in every run interval |
| `semver_version_parse` | 0.708 | 0.645–0.762 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.806 | 0.722–0.898 | comparator faster in every run interval |
| `jinja_string_token` | 0.541 | 0.528–0.542 | comparator faster in every run interval |
| `jinja_integer_token` | 0.747 | 0.737–0.773 | comparator faster in every run interval |
| `jinja_float_token` | 0.714 | 0.673–0.774 | comparator faster in every run interval |
| `django_email_local_part` | 0.766 | 0.685–0.892 | comparator faster in every run interval |
| `django_email_domain` | 0.796 | 0.656–0.829 | comparator faster in every run interval |
| `django_url_regex` | 0.792 | 0.786–0.891 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.566 | 0.525–0.580 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.555 | 0.539–0.581 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 1.026 | 1.014–1.099 | Ferroni faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.989 | 0.957–1.040 | inconclusive |
| `python_markdown_smart_emphasis_re` | 0.462 | 0.409–0.524 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.498 | 0.435–0.575 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.979 | 0.974–0.980 | inconclusive |
| `symfony_grapheme_chunks_1` | 0.989 | 0.987–1.033 | inconclusive |
| `symfony_grapheme_chunks_2` | 0.992 | 0.987–1.051 | inconclusive |
| `literal_first` | 0.928 | 0.920–1.039 | inconclusive |
| `literal_middle` | 0.989 | 0.986–1.009 | inconclusive |
| `literal_end` | 1.004 | 0.960–1.018 | inconclusive |
| `literal_absent` | 0.998 | 0.928–1.019 | inconclusive |
| `ferrolink_markup_scan` | 1.018 | 1.001–1.046 | inconclusive |
| `ferrolink_attribute_split` | 1.022 | 1.004–1.065 | inconclusive |

## c / steady

Common cases: 27; families: 14. Pair-specific family-weighted ratio: 3.523.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 5.153 | 4.879–5.685 | Ferroni faster in every run interval |
| `uuid_v4` | 3.987 | 3.875–4.253 | Ferroni faster in every run interval |
| `ipv4_validation` | 9.303 | 8.405–9.637 | Ferroni faster in every run interval |
| `ipv6_validation` | 15.459 | 14.227–15.583 | Ferroni faster in every run interval |
| `semver_version_parse` | 1.920 | 1.638–1.932 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.346 | 1.246–1.373 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.792 | 1.773–1.794 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.325 | 1.207–1.438 | Ferroni faster in every run interval |
| `jinja_float_token` | 1.337 | 1.233–1.364 | Ferroni faster in every run interval |
| `django_email_local_part` | 8.920 | 8.373–9.289 | Ferroni faster in every run interval |
| `django_email_domain` | 38.529 | 30.136–39.550 | Ferroni faster in every run interval |
| `django_url_regex` | 21.087 | 20.788–23.462 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 2.397 | 2.292–2.473 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 2.750 | 2.740–2.828 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.392 | 1.256–1.394 | Ferroni faster in every run interval |
| `mastodon_hashtag_regex_step` | 2.236 | 2.196–2.261 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 2.682 | 2.232–3.132 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 2.597 | 2.180–2.614 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 1.525 | 1.519–1.538 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_1` | 1.795 | 1.780–1.797 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_2` | 1.971 | 1.966–2.008 | Ferroni faster in every run interval |
| `literal_first` | 10.599 | 8.940–10.781 | Ferroni faster in every run interval |
| `literal_middle` | 11.030 | 11.004–11.902 | Ferroni faster in every run interval |
| `literal_end` | 11.397 | 11.323–11.805 | Ferroni faster in every run interval |
| `literal_absent` | 1.788 | 1.719–1.796 | Ferroni faster in every run interval |
| `ferrolink_markup_scan` | 2.430 | 2.404–2.476 | Ferroni faster in every run interval |
| `ferrolink_attribute_split` | 1.881 | 1.863–1.905 | Ferroni faster in every run interval |

## c / compile

Common cases: 27; families: 14. Pair-specific family-weighted ratio: 0.546.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 6.289 | 6.061–6.489 | Ferroni faster in every run interval |
| `uuid_v4` | 6.999 | 6.961–7.088 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.371 | 0.367–0.387 | comparator faster in every run interval |
| `ipv6_validation` | 0.405 | 0.398–0.407 | comparator faster in every run interval |
| `semver_version_parse` | 0.337 | 0.315–0.367 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.311 | 0.309–0.399 | comparator faster in every run interval |
| `jinja_string_token` | 0.212 | 0.206–0.227 | comparator faster in every run interval |
| `jinja_integer_token` | 2.877 | 2.871–3.171 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.877 | 0.844–0.968 | comparator faster in every run interval |
| `django_email_local_part` | 2.836 | 2.687–3.024 | Ferroni faster in every run interval |
| `django_email_domain` | 0.362 | 0.294–0.384 | comparator faster in every run interval |
| `django_url_regex` | 0.617 | 0.608–0.748 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.245 | 0.245–0.246 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.262 | 0.251–0.270 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.580 | 0.538–0.600 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 2.836 | 2.662–2.857 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.262 | 0.211–0.322 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.210 | 0.175–0.227 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.381 | 0.377–0.407 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.171 | 0.166–0.176 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.191 | 0.187–0.212 | comparator faster in every run interval |
| `literal_first` | 0.330 | 0.309–0.337 | comparator faster in every run interval |
| `literal_middle` | 0.298 | 0.287–0.335 | comparator faster in every run interval |
| `literal_end` | 0.321 | 0.285–0.353 | comparator faster in every run interval |
| `literal_absent` | 0.318 | 0.309–0.327 | comparator faster in every run interval |
| `ferrolink_markup_scan` | 0.258 | 0.249–0.269 | comparator faster in every run interval |
| `ferrolink_attribute_split` | 0.214 | 0.213–0.215 | comparator faster in every run interval |

## c / first_use

Common cases: 27; families: 14. Pair-specific family-weighted ratio: 0.483.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 3.285 | 3.234–3.566 | Ferroni faster in every run interval |
| `uuid_v4` | 3.821 | 3.808–3.842 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.264 | 0.245–0.265 | comparator faster in every run interval |
| `ipv6_validation` | 0.286 | 0.272–0.289 | comparator faster in every run interval |
| `semver_version_parse` | 0.246 | 0.240–0.271 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.245 | 0.241–0.248 | comparator faster in every run interval |
| `jinja_string_token` | 0.125 | 0.125–0.131 | comparator faster in every run interval |
| `jinja_integer_token` | 2.265 | 2.193–2.272 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.620 | 0.602–0.697 | comparator faster in every run interval |
| `django_email_local_part` | 2.039 | 1.993–2.539 | Ferroni faster in every run interval |
| `django_email_domain` | 0.289 | 0.224–0.310 | comparator faster in every run interval |
| `django_url_regex` | 0.483 | 0.455–0.571 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.141 | 0.128–0.143 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.158 | 0.153–0.159 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.625 | 0.572–0.792 | inconclusive |
| `mastodon_hashtag_regex_step` | 2.598 | 2.586–2.846 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.157 | 0.134–0.167 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.125 | 0.104–0.127 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.407 | 0.384–0.423 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.397 | 0.381–0.399 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.337 | 0.332–0.359 | comparator faster in every run interval |
| `literal_first` | 0.559 | 0.534–0.571 | comparator faster in every run interval |
| `literal_middle` | 0.558 | 0.536–0.595 | comparator faster in every run interval |
| `literal_end` | 0.566 | 0.547–0.573 | comparator faster in every run interval |
| `literal_absent` | 0.392 | 0.369–0.401 | comparator faster in every run interval |
| `ferrolink_markup_scan` | 0.372 | 0.335–0.382 | comparator faster in every run interval |
| `ferrolink_attribute_split` | 0.232 | 0.225–0.233 | comparator faster in every run interval |

## onigmo / steady

Common cases: 26; families: 14. Pair-specific family-weighted ratio: 3.700.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 6.070 | 5.611–6.243 | Ferroni faster in every run interval |
| `uuid_v4` | 6.012 | 5.955–6.469 | Ferroni faster in every run interval |
| `ipv4_validation` | 6.604 | 6.582–6.877 | Ferroni faster in every run interval |
| `ipv6_validation` | 19.879 | 18.134–20.739 | Ferroni faster in every run interval |
| `semver_version_parse` | 1.888 | 1.764–2.027 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.339 | 1.107–1.387 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.118 | 1.110–1.120 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.439 | 1.384–1.505 | Ferroni faster in every run interval |
| `jinja_float_token` | 2.626 | 2.451–2.639 | Ferroni faster in every run interval |
| `django_email_local_part` | 4.808 | 4.613–5.283 | Ferroni faster in every run interval |
| `django_email_domain` | 67.718 | 57.032–75.799 | Ferroni faster in every run interval |
| `django_url_regex` | 53.492 | 53.054–53.930 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 2.437 | 2.392–2.515 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 3.401 | 3.288–3.426 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.068 | 1.064–1.073 | Ferroni faster in every run interval |
| `mastodon_hashtag_regex_step` | 2.127 | 2.022–2.566 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 2.256 | 2.077–2.326 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 2.611 | 2.424–2.621 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 1.289 | 1.278–1.314 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_2` | 3.390 | 3.371–3.453 | Ferroni faster in every run interval |
| `literal_first` | 2.919 | 2.671–2.952 | Ferroni faster in every run interval |
| `literal_middle` | 3.527 | 3.463–3.770 | Ferroni faster in every run interval |
| `literal_end` | 5.524 | 5.447–5.615 | Ferroni faster in every run interval |
| `literal_absent` | 2.406 | 2.394–2.468 | Ferroni faster in every run interval |
| `ferrolink_markup_scan` | 3.114 | 2.879–3.131 | Ferroni faster in every run interval |
| `ferrolink_attribute_split` | 1.574 | 1.567–1.598 | Ferroni faster in every run interval |

## onigmo / compile

Common cases: 26; families: 14. Pair-specific family-weighted ratio: 0.723.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 6.047 | 5.713–6.115 | Ferroni faster in every run interval |
| `uuid_v4` | 6.785 | 6.205–7.206 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.347 | 0.337–0.356 | comparator faster in every run interval |
| `ipv6_validation` | 0.379 | 0.346–0.387 | comparator faster in every run interval |
| `semver_version_parse` | 0.309 | 0.287–0.357 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.359 | 0.339–0.393 | comparator faster in every run interval |
| `jinja_string_token` | 0.184 | 0.180–0.190 | comparator faster in every run interval |
| `jinja_integer_token` | 2.757 | 2.374–3.053 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.916 | 0.908–0.958 | comparator faster in every run interval |
| `django_email_local_part` | 2.867 | 2.686–3.032 | Ferroni faster in every run interval |
| `django_email_domain` | 0.213 | 0.180–0.239 | comparator faster in every run interval |
| `django_url_regex` | 0.475 | 0.475–0.481 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.243 | 0.235–0.245 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.261 | 0.250–0.282 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.654 | 0.568–0.665 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 3.068 | 3.042–3.095 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.190 | 0.154–0.217 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.157 | 0.153–0.188 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.368 | 0.366–0.370 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 21.390 | 20.411–21.646 | Ferroni faster in every run interval |
| `literal_first` | 0.281 | 0.251–0.287 | comparator faster in every run interval |
| `literal_middle` | 0.249 | 0.248–0.252 | comparator faster in every run interval |
| `literal_end` | 0.272 | 0.242–0.290 | comparator faster in every run interval |
| `literal_absent` | 0.265 | 0.265–0.273 | comparator faster in every run interval |
| `ferrolink_markup_scan` | 0.241 | 0.232–0.247 | comparator faster in every run interval |
| `ferrolink_attribute_split` | 0.285 | 0.283–0.286 | comparator faster in every run interval |

## onigmo / first_use

Common cases: 26; families: 14. Pair-specific family-weighted ratio: 0.586.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 3.300 | 3.053–3.333 | Ferroni faster in every run interval |
| `uuid_v4` | 3.524 | 3.380–3.860 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.239 | 0.226–0.241 | comparator faster in every run interval |
| `ipv6_validation` | 0.272 | 0.267–0.280 | comparator faster in every run interval |
| `semver_version_parse` | 0.219 | 0.208–0.262 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.282 | 0.259–0.302 | comparator faster in every run interval |
| `jinja_string_token` | 0.106 | 0.103–0.108 | comparator faster in every run interval |
| `jinja_integer_token` | 1.965 | 1.772–2.240 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.655 | 0.654–0.681 | comparator faster in every run interval |
| `django_email_local_part` | 2.019 | 1.970–2.285 | Ferroni faster in every run interval |
| `django_email_domain` | 0.164 | 0.139–0.191 | comparator faster in every run interval |
| `django_url_regex` | 0.375 | 0.364–0.388 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.150 | 0.137–0.152 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.161 | 0.161–0.165 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.639 | 0.577–0.673 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 3.017 | 2.877–3.033 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.106 | 0.094–0.109 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.095 | 0.089–0.098 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.364 | 0.361–0.364 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 18.837 | 18.064–19.224 | Ferroni faster in every run interval |
| `literal_first` | 0.335 | 0.333–0.340 | comparator faster in every run interval |
| `literal_middle` | 0.348 | 0.324–0.349 | comparator faster in every run interval |
| `literal_end` | 0.377 | 0.336–0.391 | comparator faster in every run interval |
| `literal_absent` | 0.351 | 0.318–0.378 | comparator faster in every run interval |
| `ferrolink_markup_scan` | 0.353 | 0.333–0.362 | comparator faster in every run interval |
| `ferrolink_attribute_split` | 0.288 | 0.288–0.303 | comparator faster in every run interval |

## pcre2_jit / steady

Common cases: 27; families: 14. Pair-specific family-weighted ratio: 0.741.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.911 | 0.877–0.936 | comparator faster in every run interval |
| `uuid_v4` | 0.949 | 0.899–0.991 | inconclusive |
| `ipv4_validation` | 1.469 | 1.386–1.518 | Ferroni faster in every run interval |
| `ipv6_validation` | 3.980 | 3.527–4.047 | Ferroni faster in every run interval |
| `semver_version_parse` | 0.521 | 0.497–0.530 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.590 | 0.428–0.613 | comparator faster in every run interval |
| `jinja_string_token` | 0.585 | 0.567–0.594 | comparator faster in every run interval |
| `jinja_integer_token` | 0.509 | 0.506–0.567 | comparator faster in every run interval |
| `jinja_float_token` | 0.633 | 0.591–0.658 | comparator faster in every run interval |
| `django_email_local_part` | 1.562 | 1.553–1.685 | Ferroni faster in every run interval |
| `django_email_domain` | 0.882 | 0.659–0.897 | comparator faster in every run interval |
| `django_url_regex` | 1.286 | 1.244–1.311 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 0.486 | 0.472–0.506 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.811 | 0.802–0.836 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.434 | 0.367–0.440 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.362 | 0.346–0.431 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.658 | 0.571–0.693 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.542 | 0.518–0.559 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.487 | 0.473–0.573 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.600 | 0.599–0.605 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.586 | 0.566–0.595 | comparator faster in every run interval |
| `literal_first` | 1.900 | 1.638–1.916 | Ferroni faster in every run interval |
| `literal_middle` | 1.918 | 1.729–1.927 | Ferroni faster in every run interval |
| `literal_end` | 1.662 | 1.512–1.683 | Ferroni faster in every run interval |
| `literal_absent` | 1.494 | 1.452–1.585 | Ferroni faster in every run interval |
| `ferrolink_markup_scan` | 0.401 | 0.392–0.426 | comparator faster in every run interval |
| `ferrolink_attribute_split` | 0.555 | 0.550–0.559 | comparator faster in every run interval |

## pcre2_jit / compile

Common cases: 27; families: 14. Pair-specific family-weighted ratio: 0.480.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.400 | 0.372–0.405 | comparator faster in every run interval |
| `uuid_v4` | 0.404 | 0.362–0.451 | comparator faster in every run interval |
| `ipv4_validation` | 0.398 | 0.386–0.456 | comparator faster in every run interval |
| `ipv6_validation` | 0.486 | 0.394–0.500 | comparator faster in every run interval |
| `semver_version_parse` | 0.495 | 0.470–0.539 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.505 | 0.457–0.521 | comparator faster in every run interval |
| `jinja_string_token` | 0.466 | 0.444–0.482 | comparator faster in every run interval |
| `jinja_integer_token` | 0.369 | 0.345–0.394 | comparator faster in every run interval |
| `jinja_float_token` | 0.301 | 0.299–0.304 | comparator faster in every run interval |
| `django_email_local_part` | 0.507 | 0.492–0.519 | comparator faster in every run interval |
| `django_email_domain` | 0.091 | 0.077–0.100 | comparator faster in every run interval |
| `django_url_regex` | 0.107 | 0.097–0.109 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.453 | 0.443–0.462 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.464 | 0.456–0.507 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 1.180 | 0.928–1.195 | inconclusive |
| `mastodon_hashtag_regex_step` | 0.323 | 0.321–0.326 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.774 | 0.639–0.840 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.599 | 0.551–0.603 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.717 | 0.701–0.786 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.477 | 0.421–0.495 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.491 | 0.480–0.530 | comparator faster in every run interval |
| `literal_first` | 2.444 | 2.408–2.525 | Ferroni faster in every run interval |
| `literal_middle` | 2.358 | 2.235–2.474 | Ferroni faster in every run interval |
| `literal_end` | 2.301 | 2.139–2.435 | Ferroni faster in every run interval |
| `literal_absent` | 2.467 | 2.265–2.602 | Ferroni faster in every run interval |
| `ferrolink_markup_scan` | 0.386 | 0.385–0.409 | comparator faster in every run interval |
| `ferrolink_attribute_split` | 0.542 | 0.527–0.547 | comparator faster in every run interval |

## pcre2_jit / first_use

Common cases: 27; families: 14. Pair-specific family-weighted ratio: 0.421.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.205 | 0.198–0.209 | comparator faster in every run interval |
| `uuid_v4` | 0.219 | 0.188–0.223 | comparator faster in every run interval |
| `ipv4_validation` | 0.321 | 0.316–0.357 | comparator faster in every run interval |
| `ipv6_validation` | 0.336 | 0.298–0.375 | comparator faster in every run interval |
| `semver_version_parse` | 0.423 | 0.383–0.453 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.415 | 0.354–0.417 | comparator faster in every run interval |
| `jinja_string_token` | 0.312 | 0.309–0.326 | comparator faster in every run interval |
| `jinja_integer_token` | 0.320 | 0.290–0.342 | comparator faster in every run interval |
| `jinja_float_token` | 0.247 | 0.241–0.253 | comparator faster in every run interval |
| `django_email_local_part` | 0.410 | 0.390–0.490 | comparator faster in every run interval |
| `django_email_domain` | 0.070 | 0.060–0.080 | comparator faster in every run interval |
| `django_url_regex` | 0.084 | 0.073–0.087 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.279 | 0.265–0.295 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.288 | 0.274–0.294 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 1.395 | 1.183–1.417 | Ferroni faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.346 | 0.327–0.349 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.479 | 0.439–0.506 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.368 | 0.366–0.383 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.742 | 0.723–0.836 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.818 | 0.809–0.819 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.824 | 0.801–1.001 | inconclusive |
| `literal_first` | 2.476 | 2.439–2.631 | Ferroni faster in every run interval |
| `literal_middle` | 2.365 | 2.269–2.817 | Ferroni faster in every run interval |
| `literal_end` | 2.280 | 2.241–2.476 | Ferroni faster in every run interval |
| `literal_absent` | 2.456 | 2.369–2.777 | Ferroni faster in every run interval |
| `ferrolink_markup_scan` | 0.473 | 0.460–0.476 | comparator faster in every run interval |
| `ferrolink_attribute_split` | 0.616 | 0.602–0.640 | comparator faster in every run interval |

## pcre2 / steady

Common cases: 27; families: 14. Pair-specific family-weighted ratio: 2.032.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.809 | 1.677–1.890 | Ferroni faster in every run interval |
| `uuid_v4` | 1.832 | 1.826–1.923 | Ferroni faster in every run interval |
| `ipv4_validation` | 10.109 | 9.451–10.621 | Ferroni faster in every run interval |
| `ipv6_validation` | 20.906 | 20.416–22.434 | Ferroni faster in every run interval |
| `semver_version_parse` | 1.465 | 1.433–1.494 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.803 | 1.689–1.908 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.208 | 1.182–1.214 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.613 | 1.578–1.663 | Ferroni faster in every run interval |
| `jinja_float_token` | 1.785 | 1.719–1.792 | Ferroni faster in every run interval |
| `django_email_local_part` | 5.734 | 5.482–5.794 | Ferroni faster in every run interval |
| `django_email_domain` | 2.959 | 2.807–3.000 | Ferroni faster in every run interval |
| `django_url_regex` | 3.230 | 2.915–3.396 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.585 | 1.533–1.641 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.971 | 1.952–2.026 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.186 | 1.178–1.317 | Ferroni faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.775 | 0.749–0.845 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 3.282 | 2.831–3.619 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 3.698 | 3.608–3.948 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 1.330 | 1.210–1.498 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.880 | 0.872–0.891 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.782 | 0.740–0.784 | comparator faster in every run interval |
| `literal_first` | 3.828 | 3.575–4.048 | Ferroni faster in every run interval |
| `literal_middle` | 3.765 | 3.406–3.910 | Ferroni faster in every run interval |
| `literal_end` | 3.353 | 3.009–3.448 | Ferroni faster in every run interval |
| `literal_absent` | 1.677 | 1.569–1.681 | Ferroni faster in every run interval |
| `ferrolink_markup_scan` | 1.342 | 1.313–1.425 | Ferroni faster in every run interval |
| `ferrolink_attribute_split` | 1.178 | 1.170–1.199 | Ferroni faster in every run interval |

## pcre2 / compile

Common cases: 27; families: 14. Pair-specific family-weighted ratio: 0.141.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.154 | 0.144–0.158 | comparator faster in every run interval |
| `uuid_v4` | 0.150 | 0.146–0.174 | comparator faster in every run interval |
| `ipv4_validation` | 0.133 | 0.122–0.135 | comparator faster in every run interval |
| `ipv6_validation` | 0.155 | 0.133–0.168 | comparator faster in every run interval |
| `semver_version_parse` | 0.152 | 0.137–0.159 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.137 | 0.128–0.145 | comparator faster in every run interval |
| `jinja_string_token` | 0.099 | 0.096–0.105 | comparator faster in every run interval |
| `jinja_integer_token` | 0.112 | 0.106–0.124 | comparator faster in every run interval |
| `jinja_float_token` | 0.064 | 0.063–0.064 | comparator faster in every run interval |
| `django_email_local_part` | 0.277 | 0.277–0.283 | comparator faster in every run interval |
| `django_email_domain` | 0.083 | 0.081–0.086 | comparator faster in every run interval |
| `django_url_regex` | 0.086 | 0.077–0.087 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.099 | 0.095–0.105 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.113 | 0.108–0.113 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.293 | 0.277–0.304 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.170 | 0.164–0.172 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.144 | 0.115–0.152 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.113 | 0.101–0.118 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.208 | 0.185–0.235 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.070 | 0.064–0.071 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.070 | 0.068–0.070 | comparator faster in every run interval |
| `literal_first` | 0.266 | 0.227–0.270 | comparator faster in every run interval |
| `literal_middle` | 0.225 | 0.224–0.244 | comparator faster in every run interval |
| `literal_end` | 0.245 | 0.215–0.268 | comparator faster in every run interval |
| `literal_absent` | 0.236 | 0.231–0.254 | comparator faster in every run interval |
| `ferrolink_markup_scan` | 0.094 | 0.094–0.095 | comparator faster in every run interval |
| `ferrolink_attribute_split` | 0.196 | 0.195–0.196 | comparator faster in every run interval |

## pcre2 / first_use

Common cases: 27; families: 14. Pair-specific family-weighted ratio: 0.137.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.089 | 0.085–0.092 | comparator faster in every run interval |
| `uuid_v4` | 0.091 | 0.089–0.100 | comparator faster in every run interval |
| `ipv4_validation` | 0.097 | 0.094–0.098 | comparator faster in every run interval |
| `ipv6_validation` | 0.104 | 0.102–0.112 | comparator faster in every run interval |
| `semver_version_parse` | 0.116 | 0.107–0.129 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.112 | 0.100–0.113 | comparator faster in every run interval |
| `jinja_string_token` | 0.067 | 0.064–0.067 | comparator faster in every run interval |
| `jinja_integer_token` | 0.088 | 0.086–0.094 | comparator faster in every run interval |
| `jinja_float_token` | 0.051 | 0.049–0.051 | comparator faster in every run interval |
| `django_email_local_part` | 0.217 | 0.194–0.247 | comparator faster in every run interval |
| `django_email_domain` | 0.067 | 0.064–0.067 | comparator faster in every run interval |
| `django_url_regex` | 0.066 | 0.060–0.069 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.072 | 0.068–0.073 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.077 | 0.073–0.078 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.356 | 0.304–0.358 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.168 | 0.164–0.170 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.103 | 0.083–0.109 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.088 | 0.078–0.089 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.222 | 0.194–0.241 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.203 | 0.192–0.209 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.165 | 0.160–0.167 | comparator faster in every run interval |
| `literal_first` | 0.531 | 0.500–0.538 | comparator faster in every run interval |
| `literal_middle` | 0.495 | 0.440–0.546 | comparator faster in every run interval |
| `literal_end` | 0.506 | 0.459–0.530 | comparator faster in every run interval |
| `literal_absent` | 0.430 | 0.402–0.433 | comparator faster in every run interval |
| `ferrolink_markup_scan` | 0.153 | 0.153–0.163 | comparator faster in every run interval |
| `ferrolink_attribute_split` | 0.210 | 0.208–0.218 | comparator faster in every run interval |

## fancy_regex / steady

Common cases: 23; families: 12. Pair-specific family-weighted ratio: 2.895.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.980 | 0.931–1.011 | inconclusive |
| `uuid_v4` | 1.023 | 0.986–1.045 | inconclusive |
| `ipv4_validation` | 1.093 | 1.089–1.206 | Ferroni faster in every run interval |
| `ipv6_validation` | 1.107 | 1.093–1.160 | Ferroni faster in every run interval |
| `semver_version_parse` | 2.851 | 2.739–3.025 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 2.375 | 2.372–2.585 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.182 | 1.150–1.186 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.474 | 1.440–1.543 | Ferroni faster in every run interval |
| `jinja_float_token` | 2.818 | 2.724–2.920 | Ferroni faster in every run interval |
| `django_email_domain` | 8.544 | 8.160–8.866 | Ferroni faster in every run interval |
| `django_url_regex` | 24.658 | 22.348–26.478 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 2.153 | 2.144–2.242 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 2.844 | 2.744–2.863 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 3.434 | 2.972–3.683 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 3.403 | 2.752–3.761 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 4.529 | 4.390–4.918 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 2.242 | 2.198–2.312 | Ferroni faster in every run interval |
| `literal_first` | 1.467 | 1.357–1.528 | Ferroni faster in every run interval |
| `literal_middle` | 1.372 | 1.340–1.531 | Ferroni faster in every run interval |
| `literal_end` | 1.367 | 1.310–1.399 | Ferroni faster in every run interval |
| `literal_absent` | 1.347 | 1.209–1.364 | Ferroni faster in every run interval |
| `ferrolink_markup_scan` | 5.438 | 5.319–5.495 | Ferroni faster in every run interval |
| `ferrolink_attribute_split` | 1.941 | 1.934–1.941 | Ferroni faster in every run interval |

## fancy_regex / compile

Common cases: 23; families: 12. Pair-specific family-weighted ratio: 2.947.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.623 | 1.520–1.661 | Ferroni faster in every run interval |
| `uuid_v4` | 1.648 | 1.494–1.654 | Ferroni faster in every run interval |
| `ipv4_validation` | 1.237 | 1.145–1.240 | Ferroni faster in every run interval |
| `ipv6_validation` | 1.198 | 1.160–1.227 | Ferroni faster in every run interval |
| `semver_version_parse` | 14.793 | 12.950–17.053 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 10.780 | 9.574–11.303 | Ferroni faster in every run interval |
| `jinja_string_token` | 3.268 | 3.150–3.444 | Ferroni faster in every run interval |
| `jinja_integer_token` | 2.804 | 2.783–3.023 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.387 | 0.341–0.400 | comparator faster in every run interval |
| `django_email_domain` | 12.621 | 12.587–13.313 | Ferroni faster in every run interval |
| `django_url_regex` | 11.313 | 10.885–11.663 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 2.669 | 2.566–2.754 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 2.901 | 2.730–2.977 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.676 | 1.644–1.952 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.906 | 0.775–1.033 | inconclusive |
| `python_markdown_smart_strong_em_re` | 0.740 | 0.690–0.755 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 2.166 | 2.034–2.228 | Ferroni faster in every run interval |
| `literal_first` | 1.759 | 1.664–1.870 | Ferroni faster in every run interval |
| `literal_middle` | 1.658 | 1.520–1.660 | Ferroni faster in every run interval |
| `literal_end` | 1.773 | 1.468–1.875 | Ferroni faster in every run interval |
| `literal_absent` | 1.762 | 1.641–1.766 | Ferroni faster in every run interval |
| `ferrolink_markup_scan` | 4.932 | 4.855–4.987 | Ferroni faster in every run interval |
| `ferrolink_attribute_split` | 6.051 | 6.013–6.166 | Ferroni faster in every run interval |

## fancy_regex / first_use

Common cases: 23; families: 12. Pair-specific family-weighted ratio: 2.336.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.115 | 1.075–1.154 | Ferroni faster in every run interval |
| `uuid_v4` | 1.123 | 0.996–1.237 | inconclusive |
| `ipv4_validation` | 0.894 | 0.873–0.996 | inconclusive |
| `ipv6_validation` | 0.894 | 0.884–0.976 | inconclusive |
| `semver_version_parse` | 10.401 | 10.109–13.415 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 8.105 | 7.010–8.266 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.808 | 1.779–1.852 | Ferroni faster in every run interval |
| `jinja_integer_token` | 2.154 | 2.119–2.374 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.280 | 0.253–0.285 | comparator faster in every run interval |
| `django_email_domain` | 10.195 | 9.837–10.264 | Ferroni faster in every run interval |
| `django_url_regex` | 8.605 | 8.280–9.185 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.543 | 1.489–1.559 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.671 | 1.599–1.705 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 2.071 | 1.933–2.349 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.457 | 0.374–0.483 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.404 | 0.368–0.409 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 2.221 | 2.058–2.267 | Ferroni faster in every run interval |
| `literal_first` | 1.770 | 1.717–1.857 | Ferroni faster in every run interval |
| `literal_middle` | 1.654 | 1.653–1.848 | Ferroni faster in every run interval |
| `literal_end` | 1.731 | 1.546–1.870 | Ferroni faster in every run interval |
| `literal_absent` | 1.716 | 1.699–1.916 | Ferroni faster in every run interval |
| `ferrolink_markup_scan` | 5.278 | 5.099–5.338 | Ferroni faster in every run interval |
| `ferrolink_attribute_split` | 6.473 | 6.458–6.598 | Ferroni faster in every run interval |

## fancy_regex_seek / steady

Common cases: 23; families: 12. Pair-specific family-weighted ratio: 2.842.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.002 | 0.938–1.047 | inconclusive |
| `uuid_v4` | 1.039 | 0.980–1.064 | inconclusive |
| `ipv4_validation` | 1.179 | 1.097–1.222 | Ferroni faster in every run interval |
| `ipv6_validation` | 1.162 | 1.122–1.218 | Ferroni faster in every run interval |
| `semver_version_parse` | 2.937 | 2.658–3.135 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 2.496 | 2.393–2.616 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.176 | 1.167–1.190 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.490 | 1.458–1.563 | Ferroni faster in every run interval |
| `jinja_float_token` | 2.789 | 2.783–2.898 | Ferroni faster in every run interval |
| `django_email_domain` | 8.665 | 8.549–8.699 | Ferroni faster in every run interval |
| `django_url_regex` | 24.112 | 23.955–24.368 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 2.176 | 2.153–2.351 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 2.846 | 2.750–2.964 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 3.030 | 2.946–3.527 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 3.395 | 3.127–3.605 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 4.718 | 4.495–4.875 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 2.079 | 2.041–2.203 | Ferroni faster in every run interval |
| `literal_first` | 1.376 | 1.374–1.526 | Ferroni faster in every run interval |
| `literal_middle` | 1.462 | 1.414–1.582 | Ferroni faster in every run interval |
| `literal_end` | 1.361 | 1.315–1.515 | Ferroni faster in every run interval |
| `literal_absent` | 1.326 | 1.319–1.335 | Ferroni faster in every run interval |
| `ferrolink_markup_scan` | 3.448 | 3.311–3.532 | Ferroni faster in every run interval |
| `ferrolink_attribute_split` | 2.259 | 2.229–2.288 | Ferroni faster in every run interval |

## fancy_regex_seek / compile

Common cases: 23; families: 12. Pair-specific family-weighted ratio: 3.285.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.607 | 1.520–1.692 | Ferroni faster in every run interval |
| `uuid_v4` | 1.554 | 1.485–1.692 | Ferroni faster in every run interval |
| `ipv4_validation` | 1.156 | 1.138–1.201 | Ferroni faster in every run interval |
| `ipv6_validation` | 1.297 | 1.210–1.410 | Ferroni faster in every run interval |
| `semver_version_parse` | 15.745 | 12.626–18.036 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 10.177 | 10.091–11.667 | Ferroni faster in every run interval |
| `jinja_string_token` | 3.297 | 3.155–3.383 | Ferroni faster in every run interval |
| `jinja_integer_token` | 2.781 | 2.637–3.130 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.389 | 0.355–0.392 | comparator faster in every run interval |
| `django_email_domain` | 12.791 | 12.567–12.826 | Ferroni faster in every run interval |
| `django_url_regex` | 11.655 | 11.606–11.938 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 2.650 | 2.575–2.855 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 2.791 | 2.685–2.906 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.685 | 1.638–1.879 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.924 | 0.909–0.929 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.754 | 0.691–0.761 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 5.484 | 5.442–5.623 | Ferroni faster in every run interval |
| `literal_first` | 1.795 | 1.625–1.796 | Ferroni faster in every run interval |
| `literal_middle` | 1.597 | 1.570–1.675 | Ferroni faster in every run interval |
| `literal_end` | 1.701 | 1.662–2.179 | Ferroni faster in every run interval |
| `literal_absent` | 1.644 | 1.610–1.677 | Ferroni faster in every run interval |
| `ferrolink_markup_scan` | 7.137 | 6.803–7.161 | Ferroni faster in every run interval |
| `ferrolink_attribute_split` | 9.006 | 8.863–9.098 | Ferroni faster in every run interval |

## fancy_regex_seek / first_use

Common cases: 23; families: 12. Pair-specific family-weighted ratio: 2.635.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.112 | 1.081–1.157 | Ferroni faster in every run interval |
| `uuid_v4` | 1.050 | 1.040–1.221 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.896 | 0.838–0.937 | comparator faster in every run interval |
| `ipv6_validation` | 0.918 | 0.857–1.124 | inconclusive |
| `semver_version_parse` | 10.155 | 9.880–12.380 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 8.138 | 7.396–8.705 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.840 | 1.828–1.844 | Ferroni faster in every run interval |
| `jinja_integer_token` | 2.214 | 2.085–2.287 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.279 | 0.266–0.283 | comparator faster in every run interval |
| `django_email_domain` | 9.933 | 9.674–10.201 | Ferroni faster in every run interval |
| `django_url_regex` | 9.169 | 8.643–9.586 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.586 | 1.567–1.612 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.687 | 1.634–1.812 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 2.014 | 1.948–2.256 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.462 | 0.429–0.484 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.397 | 0.369–0.404 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 6.016 | 5.909–6.065 | Ferroni faster in every run interval |
| `literal_first` | 1.866 | 1.672–1.978 | Ferroni faster in every run interval |
| `literal_middle` | 1.758 | 1.632–1.838 | Ferroni faster in every run interval |
| `literal_end` | 1.677 | 1.673–1.854 | Ferroni faster in every run interval |
| `literal_absent` | 1.743 | 1.715–1.892 | Ferroni faster in every run interval |
| `ferrolink_markup_scan` | 7.918 | 7.890–8.607 | Ferroni faster in every run interval |
| `ferrolink_attribute_split` | 9.901 | 9.717–10.011 | Ferroni faster in every run interval |

## regex / steady

Common cases: 15; families: 7. Pair-specific family-weighted ratio: 1.438.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.908 | 0.885–0.943 | comparator faster in every run interval |
| `uuid_v4` | 0.978 | 0.962–1.009 | inconclusive |
| `ipv4_validation` | 0.990 | 0.974–0.995 | inconclusive |
| `ipv6_validation` | 1.053 | 1.048–1.139 | Ferroni faster in every run interval |
| `semver_version_parse` | 2.527 | 2.456–2.751 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 2.196 | 2.122–2.263 | Ferroni faster in every run interval |
| `jinja_string_token` | 0.833 | 0.817–0.962 | comparator faster in every run interval |
| `jinja_integer_token` | 1.160 | 1.139–1.207 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.972 | 1.955–2.001 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 2.698 | 2.516–2.734 | Ferroni faster in every run interval |
| `literal_first` | 1.123 | 1.120–1.217 | Ferroni faster in every run interval |
| `literal_middle` | 1.148 | 1.041–1.171 | Ferroni faster in every run interval |
| `literal_end` | 1.118 | 1.094–1.151 | Ferroni faster in every run interval |
| `literal_absent` | 1.042 | 1.041–1.089 | Ferroni faster in every run interval |
| `ferrolink_attribute_split` | 2.230 | 2.227–2.244 | Ferroni faster in every run interval |

## regex / compile

Common cases: 15; families: 7. Pair-specific family-weighted ratio: 2.497.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.193 | 1.185–1.215 | Ferroni faster in every run interval |
| `uuid_v4` | 1.126 | 1.107–1.140 | Ferroni faster in every run interval |
| `ipv4_validation` | 1.020 | 0.862–1.026 | inconclusive |
| `ipv6_validation` | 1.148 | 1.055–1.188 | inconclusive |
| `semver_version_parse` | 14.873 | 13.150–16.825 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 10.049 | 9.297–11.625 | Ferroni faster in every run interval |
| `jinja_string_token` | 3.394 | 3.253–3.542 | Ferroni faster in every run interval |
| `jinja_integer_token` | 2.562 | 2.354–2.636 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 2.547 | 2.541–2.706 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 2.770 | 2.677–2.862 | Ferroni faster in every run interval |
| `literal_first` | 1.726 | 1.722–1.840 | Ferroni faster in every run interval |
| `literal_middle` | 1.577 | 1.546–1.632 | Ferroni faster in every run interval |
| `literal_end` | 1.671 | 1.599–2.060 | Ferroni faster in every run interval |
| `literal_absent` | 1.692 | 1.685–1.730 | Ferroni faster in every run interval |
| `ferrolink_attribute_split` | 3.022 | 3.013–3.066 | Ferroni faster in every run interval |

## regex / first_use

Common cases: 15; families: 7. Pair-specific family-weighted ratio: 1.980.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.893 | 0.876–0.895 | comparator faster in every run interval |
| `uuid_v4` | 0.867 | 0.781–0.879 | comparator faster in every run interval |
| `ipv4_validation` | 0.777 | 0.709–0.802 | comparator faster in every run interval |
| `ipv6_validation` | 0.817 | 0.796–0.845 | comparator faster in every run interval |
| `semver_version_parse` | 11.530 | 11.321–12.607 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 7.452 | 7.101–8.014 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.818 | 1.804–2.112 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.942 | 1.912–2.145 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.507 | 1.467–1.523 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.677 | 1.571–1.789 | Ferroni faster in every run interval |
| `literal_first` | 1.760 | 1.654–1.907 | Ferroni faster in every run interval |
| `literal_middle` | 1.592 | 1.573–1.779 | Ferroni faster in every run interval |
| `literal_end` | 1.752 | 1.599–1.793 | Ferroni faster in every run interval |
| `literal_absent` | 1.770 | 1.743–1.792 | Ferroni faster in every run interval |
| `ferrolink_attribute_split` | 3.586 | 3.530–3.608 | Ferroni faster in every run interval |

Raw samples, estimates, confidence intervals, failures, eligibility reasons, corpus snapshot and execution order are retained beside this report.

Memory, where requested, is fresh-process peak RSS including the binary, runtime, parsed catalog, compilation, input/output and allocator. It is not isolated compiled-pattern memory.
