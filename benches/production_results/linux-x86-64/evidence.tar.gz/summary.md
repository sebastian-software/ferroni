# Production regex comparison

Host: Linux-6.6.141-x86_64-with-glibc2.39; x86_64.

Publication candidate: review host stability, raw samples, coverage and run intervals before publishing.

Ratios are comparator / Ferroni. Compile and first-use times concern one pattern; steady times concern the complete fixture batch.

Each comparison below uses only its explicitly listed common tasks. Families have equal aggregate weight; architectures are never combined.

## Eligibility

| Case | Engine | Status |
| --- | --- | --- |
| `uuid_shape` | rust | eligible |
| `uuid_shape` | rust_erroraware | eligible |
| `uuid_shape` | c | eligible |
| `uuid_shape` | onigmo | eligible |
| `uuid_shape` | pcre2_jit | eligible |
| `uuid_shape` | pcre2 | eligible |
| `uuid_shape` | fancy_regex | eligible |
| `uuid_shape` | fancy_regex_seek | eligible |
| `uuid_shape` | regex | eligible |
| `uuid_v4` | rust | eligible |
| `uuid_v4` | rust_erroraware | eligible |
| `uuid_v4` | c | eligible |
| `uuid_v4` | onigmo | eligible |
| `uuid_v4` | pcre2_jit | eligible |
| `uuid_v4` | pcre2 | eligible |
| `uuid_v4` | fancy_regex | eligible |
| `uuid_v4` | fancy_regex_seek | eligible |
| `uuid_v4` | regex | eligible |
| `ipv4_validation` | rust | eligible |
| `ipv4_validation` | rust_erroraware | eligible |
| `ipv4_validation` | c | eligible |
| `ipv4_validation` | onigmo | eligible |
| `ipv4_validation` | pcre2_jit | eligible |
| `ipv4_validation` | pcre2 | eligible |
| `ipv4_validation` | fancy_regex | eligible |
| `ipv4_validation` | fancy_regex_seek | eligible |
| `ipv4_validation` | regex | eligible |
| `ipv6_validation` | rust | eligible |
| `ipv6_validation` | rust_erroraware | eligible |
| `ipv6_validation` | c | eligible |
| `ipv6_validation` | onigmo | eligible |
| `ipv6_validation` | pcre2_jit | eligible |
| `ipv6_validation` | pcre2 | eligible |
| `ipv6_validation` | fancy_regex | eligible |
| `ipv6_validation` | fancy_regex_seek | eligible |
| `ipv6_validation` | regex | eligible |
| `semver_version_parse` | rust | eligible |
| `semver_version_parse` | rust_erroraware | eligible |
| `semver_version_parse` | c | eligible |
| `semver_version_parse` | onigmo | eligible |
| `semver_version_parse` | pcre2_jit | eligible |
| `semver_version_parse` | pcre2 | eligible |
| `semver_version_parse` | fancy_regex | eligible |
| `semver_version_parse` | fancy_regex_seek | eligible |
| `semver_version_parse` | regex | eligible |
| `semver_hyphen_range_captures` | rust | eligible |
| `semver_hyphen_range_captures` | rust_erroraware | eligible |
| `semver_hyphen_range_captures` | c | eligible |
| `semver_hyphen_range_captures` | onigmo | eligible |
| `semver_hyphen_range_captures` | pcre2_jit | eligible |
| `semver_hyphen_range_captures` | pcre2 | eligible |
| `semver_hyphen_range_captures` | fancy_regex | eligible |
| `semver_hyphen_range_captures` | fancy_regex_seek | eligible |
| `semver_hyphen_range_captures` | regex | eligible |
| `jinja_string_token` | rust | eligible |
| `jinja_string_token` | rust_erroraware | eligible |
| `jinja_string_token` | c | eligible |
| `jinja_string_token` | onigmo | eligible |
| `jinja_string_token` | pcre2_jit | eligible |
| `jinja_string_token` | pcre2 | eligible |
| `jinja_string_token` | fancy_regex | eligible |
| `jinja_string_token` | fancy_regex_seek | eligible |
| `jinja_string_token` | regex | eligible |
| `jinja_integer_token` | rust | eligible |
| `jinja_integer_token` | rust_erroraware | eligible |
| `jinja_integer_token` | c | eligible |
| `jinja_integer_token` | onigmo | eligible |
| `jinja_integer_token` | pcre2_jit | eligible |
| `jinja_integer_token` | pcre2 | eligible |
| `jinja_integer_token` | fancy_regex | eligible |
| `jinja_integer_token` | fancy_regex_seek | eligible |
| `jinja_integer_token` | regex | eligible |
| `jinja_float_token` | rust | eligible |
| `jinja_float_token` | rust_erroraware | eligible |
| `jinja_float_token` | c | eligible |
| `jinja_float_token` | onigmo | eligible |
| `jinja_float_token` | pcre2_jit | eligible |
| `jinja_float_token` | pcre2 | eligible |
| `jinja_float_token` | fancy_regex | eligible |
| `jinja_float_token` | fancy_regex_seek | eligible |
| `jinja_float_token` | regex | syntax_rejected |
| `django_email_local_part` | rust | eligible |
| `django_email_local_part` | rust_erroraware | eligible |
| `django_email_local_part` | c | eligible |
| `django_email_local_part` | onigmo | eligible |
| `django_email_local_part` | pcre2_jit | eligible |
| `django_email_local_part` | pcre2 | eligible |
| `django_email_local_part` | fancy_regex | syntax_rejected |
| `django_email_local_part` | fancy_regex_seek | syntax_rejected |
| `django_email_local_part` | regex | syntax_rejected |
| `django_email_domain` | rust | eligible |
| `django_email_domain` | rust_erroraware | eligible |
| `django_email_domain` | c | eligible |
| `django_email_domain` | onigmo | eligible |
| `django_email_domain` | pcre2_jit | eligible |
| `django_email_domain` | pcre2 | eligible |
| `django_email_domain` | fancy_regex | eligible |
| `django_email_domain` | fancy_regex_seek | eligible |
| `django_email_domain` | regex | syntax_rejected |
| `django_url_regex` | rust | eligible |
| `django_url_regex` | rust_erroraware | eligible |
| `django_url_regex` | c | eligible |
| `django_url_regex` | onigmo | eligible |
| `django_url_regex` | pcre2_jit | eligible |
| `django_url_regex` | pcre2 | eligible |
| `django_url_regex` | fancy_regex | eligible |
| `django_url_regex` | fancy_regex_seek | eligible |
| `django_url_regex` | regex | syntax_rejected |
| `fluent_bit_apache` | rust | eligible |
| `fluent_bit_apache` | rust_erroraware | eligible |
| `fluent_bit_apache` | c | eligible |
| `fluent_bit_apache` | onigmo | eligible |
| `fluent_bit_apache` | pcre2_jit | eligible |
| `fluent_bit_apache` | pcre2 | eligible |
| `fluent_bit_apache` | fancy_regex | eligible |
| `fluent_bit_apache` | fancy_regex_seek | eligible |
| `fluent_bit_apache` | regex | eligible |
| `fluent_bit_nginx` | rust | eligible |
| `fluent_bit_nginx` | rust_erroraware | eligible |
| `fluent_bit_nginx` | c | eligible |
| `fluent_bit_nginx` | onigmo | eligible |
| `fluent_bit_nginx` | pcre2_jit | eligible |
| `fluent_bit_nginx` | pcre2 | eligible |
| `fluent_bit_nginx` | fancy_regex | eligible |
| `fluent_bit_nginx` | fancy_regex_seek | eligible |
| `fluent_bit_nginx` | regex | eligible |
| `rails_underscore_regex_step` | rust | eligible |
| `rails_underscore_regex_step` | rust_erroraware | eligible |
| `rails_underscore_regex_step` | c | eligible |
| `rails_underscore_regex_step` | onigmo | eligible |
| `rails_underscore_regex_step` | pcre2_jit | eligible |
| `rails_underscore_regex_step` | pcre2 | eligible |
| `rails_underscore_regex_step` | fancy_regex | eligible |
| `rails_underscore_regex_step` | fancy_regex_seek | eligible |
| `rails_underscore_regex_step` | regex | syntax_rejected |
| `mastodon_hashtag_regex_step` | rust | eligible |
| `mastodon_hashtag_regex_step` | rust_erroraware | eligible |
| `mastodon_hashtag_regex_step` | c | eligible |
| `mastodon_hashtag_regex_step` | onigmo | eligible |
| `mastodon_hashtag_regex_step` | pcre2_jit | eligible |
| `mastodon_hashtag_regex_step` | pcre2 | eligible |
| `mastodon_hashtag_regex_step` | fancy_regex | semantic_difference |
| `mastodon_hashtag_regex_step` | fancy_regex_seek | semantic_difference |
| `mastodon_hashtag_regex_step` | regex | syntax_rejected |
| `python_markdown_smart_emphasis_re` | rust | eligible |
| `python_markdown_smart_emphasis_re` | rust_erroraware | eligible |
| `python_markdown_smart_emphasis_re` | c | eligible |
| `python_markdown_smart_emphasis_re` | onigmo | eligible |
| `python_markdown_smart_emphasis_re` | pcre2_jit | eligible |
| `python_markdown_smart_emphasis_re` | pcre2 | eligible |
| `python_markdown_smart_emphasis_re` | fancy_regex | eligible |
| `python_markdown_smart_emphasis_re` | fancy_regex_seek | eligible |
| `python_markdown_smart_emphasis_re` | regex | syntax_rejected |
| `python_markdown_smart_strong_em_re` | rust | eligible |
| `python_markdown_smart_strong_em_re` | rust_erroraware | eligible |
| `python_markdown_smart_strong_em_re` | c | eligible |
| `python_markdown_smart_strong_em_re` | onigmo | eligible |
| `python_markdown_smart_strong_em_re` | pcre2_jit | eligible |
| `python_markdown_smart_strong_em_re` | pcre2 | eligible |
| `python_markdown_smart_strong_em_re` | fancy_regex | eligible |
| `python_markdown_smart_strong_em_re` | fancy_regex_seek | eligible |
| `python_markdown_smart_strong_em_re` | regex | syntax_rejected |
| `wordpress_shortcode_captures` | rust | eligible |
| `wordpress_shortcode_captures` | rust_erroraware | eligible |
| `wordpress_shortcode_captures` | c | eligible |
| `wordpress_shortcode_captures` | onigmo | eligible |
| `wordpress_shortcode_captures` | pcre2_jit | eligible |
| `wordpress_shortcode_captures` | pcre2 | eligible |
| `wordpress_shortcode_captures` | fancy_regex | eligible |
| `wordpress_shortcode_captures` | fancy_regex_seek | eligible |
| `wordpress_shortcode_captures` | regex | syntax_rejected |
| `symfony_grapheme_chunks_1` | rust | eligible |
| `symfony_grapheme_chunks_1` | rust_erroraware | eligible |
| `symfony_grapheme_chunks_1` | c | eligible |
| `symfony_grapheme_chunks_1` | onigmo | semantic_difference |
| `symfony_grapheme_chunks_1` | pcre2_jit | eligible |
| `symfony_grapheme_chunks_1` | pcre2 | eligible |
| `symfony_grapheme_chunks_1` | fancy_regex | syntax_rejected |
| `symfony_grapheme_chunks_1` | fancy_regex_seek | syntax_rejected |
| `symfony_grapheme_chunks_1` | regex | syntax_rejected |
| `symfony_grapheme_chunks_2` | rust | eligible |
| `symfony_grapheme_chunks_2` | rust_erroraware | eligible |
| `symfony_grapheme_chunks_2` | c | eligible |
| `symfony_grapheme_chunks_2` | onigmo | eligible |
| `symfony_grapheme_chunks_2` | pcre2_jit | eligible |
| `symfony_grapheme_chunks_2` | pcre2 | eligible |
| `symfony_grapheme_chunks_2` | fancy_regex | syntax_rejected |
| `symfony_grapheme_chunks_2` | fancy_regex_seek | syntax_rejected |
| `symfony_grapheme_chunks_2` | regex | syntax_rejected |
| `literal_first` | rust | eligible |
| `literal_first` | rust_erroraware | eligible |
| `literal_first` | c | eligible |
| `literal_first` | onigmo | eligible |
| `literal_first` | pcre2_jit | eligible |
| `literal_first` | pcre2 | eligible |
| `literal_first` | fancy_regex | eligible |
| `literal_first` | fancy_regex_seek | eligible |
| `literal_first` | regex | eligible |
| `literal_middle` | rust | eligible |
| `literal_middle` | rust_erroraware | eligible |
| `literal_middle` | c | eligible |
| `literal_middle` | onigmo | eligible |
| `literal_middle` | pcre2_jit | eligible |
| `literal_middle` | pcre2 | eligible |
| `literal_middle` | fancy_regex | eligible |
| `literal_middle` | fancy_regex_seek | eligible |
| `literal_middle` | regex | eligible |
| `literal_end` | rust | eligible |
| `literal_end` | rust_erroraware | eligible |
| `literal_end` | c | eligible |
| `literal_end` | onigmo | eligible |
| `literal_end` | pcre2_jit | eligible |
| `literal_end` | pcre2 | eligible |
| `literal_end` | fancy_regex | eligible |
| `literal_end` | fancy_regex_seek | eligible |
| `literal_end` | regex | eligible |
| `literal_absent` | rust | eligible |
| `literal_absent` | rust_erroraware | eligible |
| `literal_absent` | c | eligible |
| `literal_absent` | onigmo | eligible |
| `literal_absent` | pcre2_jit | eligible |
| `literal_absent` | pcre2 | eligible |
| `literal_absent` | fancy_regex | eligible |
| `literal_absent` | fancy_regex_seek | eligible |
| `literal_absent` | regex | eligible |
| `linkify_http_tail` | rust | pending |
| `linkify_http_tail` | rust_erroraware | pending |
| `linkify_http_tail` | c | pending |
| `linkify_http_tail` | onigmo | pending |
| `linkify_http_tail` | pcre2_jit | pending |
| `linkify_http_tail` | pcre2 | pending |
| `linkify_http_tail` | fancy_regex | pending |
| `linkify_http_tail` | fancy_regex_seek | pending |
| `linkify_http_tail` | regex | pending |
| `php_cs_fixer_recursive_types` | rust | pending |
| `php_cs_fixer_recursive_types` | rust_erroraware | pending |
| `php_cs_fixer_recursive_types` | c | pending |
| `php_cs_fixer_recursive_types` | onigmo | pending |
| `php_cs_fixer_recursive_types` | pcre2_jit | pending |
| `php_cs_fixer_recursive_types` | pcre2 | pending |
| `php_cs_fixer_recursive_types` | fancy_regex | pending |
| `php_cs_fixer_recursive_types` | fancy_regex_seek | pending |
| `php_cs_fixer_recursive_types` | regex | pending |

## rust_erroraware / steady

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 1.765.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.801 | 1.573–1.807 | Ferroni faster in every run interval |
| `uuid_v4` | 2.020 | 1.917–2.033 | Ferroni faster in every run interval |
| `ipv4_validation` | 5.336 | 4.830–5.447 | Ferroni faster in every run interval |
| `ipv6_validation` | 11.466 | 9.382–14.301 | Ferroni faster in every run interval |
| `semver_version_parse` | 1.064 | 1.011–1.091 | inconclusive |
| `semver_hyphen_range_captures` | 1.064 | 1.023–1.150 | inconclusive |
| `jinja_string_token` | 1.107 | 1.080–1.108 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.053 | 0.978–1.112 | inconclusive |
| `jinja_float_token` | 1.308 | 1.178–1.408 | Ferroni faster in every run interval |
| `django_email_local_part` | 3.041 | 2.974–3.191 | Ferroni faster in every run interval |
| `django_email_domain` | 7.773 | 7.475–9.354 | Ferroni faster in every run interval |
| `django_url_regex` | 7.186 | 6.696–8.476 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.170 | 1.136–1.214 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.492 | 1.302–1.528 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.018 | 0.970–1.029 | inconclusive |
| `mastodon_hashtag_regex_step` | 1.038 | 0.974–1.059 | inconclusive |
| `python_markdown_smart_emphasis_re` | 1.137 | 1.117–1.451 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 1.059 | 1.021–1.063 | inconclusive |
| `wordpress_shortcode_captures` | 1.090 | 1.028–1.153 | inconclusive |
| `symfony_grapheme_chunks_1` | 1.136 | 0.997–1.203 | inconclusive |
| `symfony_grapheme_chunks_2` | 1.037 | 1.007–1.045 | inconclusive |
| `literal_first` | 1.462 | 1.424–1.465 | Ferroni faster in every run interval |
| `literal_middle` | 1.495 | 1.423–1.664 | Ferroni faster in every run interval |
| `literal_end` | 1.357 | 1.336–1.360 | Ferroni faster in every run interval |
| `literal_absent` | 1.262 | 1.162–1.278 | Ferroni faster in every run interval |

## rust_erroraware / compile

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 1.004.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.036 | 0.989–1.050 | inconclusive |
| `uuid_v4` | 1.035 | 0.964–1.138 | inconclusive |
| `ipv4_validation` | 0.992 | 0.939–1.014 | inconclusive |
| `ipv6_validation` | 1.031 | 0.817–1.119 | inconclusive |
| `semver_version_parse` | 1.022 | 0.928–1.057 | inconclusive |
| `semver_hyphen_range_captures` | 1.010 | 0.988–1.069 | inconclusive |
| `jinja_string_token` | 1.059 | 0.950–1.073 | inconclusive |
| `jinja_integer_token` | 0.944 | 0.861–0.958 | inconclusive |
| `jinja_float_token` | 1.072 | 1.064–1.145 | inconclusive |
| `django_email_local_part` | 0.984 | 0.984–1.330 | inconclusive |
| `django_email_domain` | 1.014 | 0.955–1.070 | inconclusive |
| `django_url_regex` | 1.019 | 1.006–1.109 | inconclusive |
| `fluent_bit_apache` | 1.009 | 1.008–1.036 | inconclusive |
| `fluent_bit_nginx` | 0.991 | 0.991–1.044 | inconclusive |
| `rails_underscore_regex_step` | 1.034 | 0.989–1.057 | inconclusive |
| `mastodon_hashtag_regex_step` | 0.993 | 0.992–1.081 | inconclusive |
| `python_markdown_smart_emphasis_re` | 0.985 | 0.851–1.443 | inconclusive |
| `python_markdown_smart_strong_em_re` | 0.973 | 0.953–1.011 | inconclusive |
| `wordpress_shortcode_captures` | 0.997 | 0.991–1.054 | inconclusive |
| `symfony_grapheme_chunks_1` | 0.977 | 0.919–1.023 | inconclusive |
| `symfony_grapheme_chunks_2` | 0.983 | 0.801–1.043 | inconclusive |
| `literal_first` | 1.049 | 0.983–1.075 | inconclusive |
| `literal_middle` | 0.925 | 0.913–1.009 | inconclusive |
| `literal_end` | 0.961 | 0.956–1.049 | inconclusive |
| `literal_absent` | 0.963 | 0.876–0.986 | inconclusive |

## rust_erroraware / first_use

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.951.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.747 | 0.682–0.757 | comparator faster in every run interval |
| `uuid_v4` | 0.746 | 0.664–0.807 | comparator faster in every run interval |
| `ipv4_validation` | 0.953 | 0.880–0.956 | comparator faster in every run interval |
| `ipv6_validation` | 1.024 | 0.923–1.184 | inconclusive |
| `semver_version_parse` | 0.910 | 0.899–0.937 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 1.001 | 0.920–1.011 | inconclusive |
| `jinja_string_token` | 0.941 | 0.920–0.999 | inconclusive |
| `jinja_integer_token` | 0.947 | 0.943–1.096 | inconclusive |
| `jinja_float_token` | 0.989 | 0.883–1.055 | inconclusive |
| `django_email_local_part` | 0.983 | 0.938–1.076 | inconclusive |
| `django_email_domain` | 0.976 | 0.925–1.338 | inconclusive |
| `django_url_regex` | 0.972 | 0.942–1.088 | inconclusive |
| `fluent_bit_apache` | 0.908 | 0.863–0.935 | inconclusive |
| `fluent_bit_nginx` | 0.856 | 0.835–0.892 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 1.037 | 0.959–1.076 | inconclusive |
| `mastodon_hashtag_regex_step` | 0.967 | 0.964–1.059 | inconclusive |
| `python_markdown_smart_emphasis_re` | 0.924 | 0.850–1.109 | inconclusive |
| `python_markdown_smart_strong_em_re` | 0.884 | 0.839–0.897 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.979 | 0.950–1.047 | inconclusive |
| `symfony_grapheme_chunks_1` | 1.053 | 0.981–1.445 | inconclusive |
| `symfony_grapheme_chunks_2` | 0.968 | 0.706–0.997 | inconclusive |
| `literal_first` | 1.089 | 0.958–1.172 | inconclusive |
| `literal_middle` | 1.070 | 1.057–1.152 | inconclusive |
| `literal_end` | 0.961 | 0.929–1.100 | inconclusive |
| `literal_absent` | 0.965 | 0.849–0.984 | inconclusive |

## c / steady

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 2.782.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 3.676 | 3.666–4.101 | Ferroni faster in every run interval |
| `uuid_v4` | 3.042 | 2.919–3.076 | Ferroni faster in every run interval |
| `ipv4_validation` | 6.202 | 5.961–6.821 | Ferroni faster in every run interval |
| `ipv6_validation` | 9.856 | 8.825–10.170 | Ferroni faster in every run interval |
| `semver_version_parse` | 1.469 | 1.320–1.505 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.100 | 0.943–1.270 | inconclusive |
| `jinja_string_token` | 1.124 | 1.074–1.160 | Ferroni faster in every run interval |
| `jinja_integer_token` | 0.938 | 0.904–1.084 | inconclusive |
| `jinja_float_token` | 1.067 | 1.011–1.151 | inconclusive |
| `django_email_local_part` | 5.506 | 5.028–6.257 | Ferroni faster in every run interval |
| `django_email_domain` | 39.689 | 39.585–44.499 | Ferroni faster in every run interval |
| `django_url_regex` | 21.449 | 19.586–22.417 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.793 | 1.621–2.003 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 2.291 | 2.192–2.675 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.111 | 1.082–1.124 | Ferroni faster in every run interval |
| `mastodon_hashtag_regex_step` | 1.877 | 1.791–1.933 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 2.196 | 2.027–2.911 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 2.312 | 2.308–2.394 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 1.141 | 1.101–1.440 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_1` | 1.259 | 1.178–1.445 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_2` | 1.270 | 1.215–1.321 | Ferroni faster in every run interval |
| `literal_first` | 4.023 | 3.932–4.192 | Ferroni faster in every run interval |
| `literal_middle` | 4.633 | 4.083–5.028 | Ferroni faster in every run interval |
| `literal_end` | 5.031 | 5.004–5.319 | Ferroni faster in every run interval |
| `literal_absent` | 2.642 | 2.499–2.939 | Ferroni faster in every run interval |

## c / compile

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.334.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 3.817 | 3.717–4.702 | Ferroni faster in every run interval |
| `uuid_v4` | 4.016 | 3.608–4.140 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.273 | 0.239–0.274 | comparator faster in every run interval |
| `ipv6_validation` | 0.230 | 0.196–0.243 | comparator faster in every run interval |
| `semver_version_parse` | 0.258 | 0.252–0.272 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.231 | 0.223–0.234 | comparator faster in every run interval |
| `jinja_string_token` | 0.139 | 0.136–0.142 | comparator faster in every run interval |
| `jinja_integer_token` | 2.232 | 2.021–2.234 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.535 | 0.437–0.567 | comparator faster in every run interval |
| `django_email_local_part` | 2.460 | 2.455–2.531 | Ferroni faster in every run interval |
| `django_email_domain` | 0.176 | 0.174–0.204 | comparator faster in every run interval |
| `django_url_regex` | 0.384 | 0.320–0.413 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.144 | 0.134–0.146 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.151 | 0.149–0.158 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.374 | 0.349–0.374 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.472 | 0.471–0.526 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.160 | 0.130–0.249 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.121 | 0.119–0.131 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.230 | 0.224–0.267 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.108 | 0.093–0.109 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.084 | 0.077–0.093 | comparator faster in every run interval |
| `literal_first` | 0.262 | 0.258–0.269 | comparator faster in every run interval |
| `literal_middle` | 0.242 | 0.213–0.280 | comparator faster in every run interval |
| `literal_end` | 0.242 | 0.241–0.262 | comparator faster in every run interval |
| `literal_absent` | 0.244 | 0.216–0.254 | comparator faster in every run interval |

## c / first_use

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.366.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 2.963 | 2.786–2.967 | Ferroni faster in every run interval |
| `uuid_v4` | 2.966 | 2.880–3.250 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.267 | 0.243–0.271 | comparator faster in every run interval |
| `ipv6_validation` | 0.271 | 0.231–0.317 | comparator faster in every run interval |
| `semver_version_parse` | 0.270 | 0.264–0.284 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.247 | 0.242–0.266 | comparator faster in every run interval |
| `jinja_string_token` | 0.145 | 0.145–0.153 | comparator faster in every run interval |
| `jinja_integer_token` | 2.384 | 2.203–2.604 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.545 | 0.513–0.713 | comparator faster in every run interval |
| `django_email_local_part` | 2.440 | 2.361–2.490 | Ferroni faster in every run interval |
| `django_email_domain` | 0.209 | 0.202–0.213 | comparator faster in every run interval |
| `django_url_regex` | 0.330 | 0.329–0.351 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.167 | 0.145–0.171 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.156 | 0.144–0.172 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.417 | 0.375–0.433 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.470 | 0.459–0.498 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.180 | 0.162–0.259 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.134 | 0.130–0.140 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.226 | 0.202–0.240 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.195 | 0.181–0.205 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.154 | 0.128–0.158 | comparator faster in every run interval |
| `literal_first` | 0.414 | 0.372–0.437 | comparator faster in every run interval |
| `literal_middle` | 0.424 | 0.364–0.441 | comparator faster in every run interval |
| `literal_end` | 0.429 | 0.422–0.459 | comparator faster in every run interval |
| `literal_absent` | 0.309 | 0.276–0.332 | comparator faster in every run interval |

## onigmo / steady

Common cases: 24; families: 13. Pair-specific family-weighted ratio: 3.515.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 5.699 | 4.437–6.030 | Ferroni faster in every run interval |
| `uuid_v4` | 5.433 | 5.341–5.981 | Ferroni faster in every run interval |
| `ipv4_validation` | 5.967 | 5.875–6.145 | Ferroni faster in every run interval |
| `ipv6_validation` | 15.762 | 14.350–16.191 | Ferroni faster in every run interval |
| `semver_version_parse` | 1.728 | 1.520–1.890 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.150 | 1.103–1.385 | Ferroni faster in every run interval |
| `jinja_string_token` | 0.828 | 0.825–0.894 | comparator faster in every run interval |
| `jinja_integer_token` | 1.243 | 1.133–1.471 | Ferroni faster in every run interval |
| `jinja_float_token` | 2.264 | 1.665–2.798 | Ferroni faster in every run interval |
| `django_email_local_part` | 4.857 | 4.619–4.911 | Ferroni faster in every run interval |
| `django_email_domain` | 66.063 | 63.474–79.590 | Ferroni faster in every run interval |
| `django_url_regex` | 56.202 | 49.996–88.071 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 2.352 | 2.285–2.502 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 3.117 | 2.410–3.237 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 0.966 | 0.891–0.971 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 2.040 | 1.907–2.188 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 2.326 | 2.192–2.912 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 2.557 | 2.419–2.571 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 1.215 | 1.165–1.315 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_2` | 3.175 | 2.963–3.212 | Ferroni faster in every run interval |
| `literal_first` | 1.795 | 1.711–1.915 | Ferroni faster in every run interval |
| `literal_middle` | 2.364 | 2.147–2.371 | Ferroni faster in every run interval |
| `literal_end` | 3.187 | 3.078–3.401 | Ferroni faster in every run interval |
| `literal_absent` | 2.698 | 2.481–2.766 | Ferroni faster in every run interval |

## onigmo / compile

Common cases: 24; families: 13. Pair-specific family-weighted ratio: 0.394.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 3.694 | 3.384–3.838 | Ferroni faster in every run interval |
| `uuid_v4` | 4.111 | 3.778–4.180 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.243 | 0.207–0.245 | comparator faster in every run interval |
| `ipv6_validation` | 0.204 | 0.203–0.224 | comparator faster in every run interval |
| `semver_version_parse` | 0.254 | 0.254–0.254 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.249 | 0.244–0.288 | comparator faster in every run interval |
| `jinja_string_token` | 0.118 | 0.109–0.122 | comparator faster in every run interval |
| `jinja_integer_token` | 1.987 | 1.970–2.418 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.560 | 0.492–0.584 | comparator faster in every run interval |
| `django_email_local_part` | 2.336 | 2.310–2.542 | Ferroni faster in every run interval |
| `django_email_domain` | 0.110 | 0.108–0.121 | comparator faster in every run interval |
| `django_url_regex` | 0.245 | 0.237–0.316 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.156 | 0.133–0.157 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.141 | 0.134–0.143 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.340 | 0.336–0.344 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.490 | 0.432–0.544 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.115 | 0.093–0.165 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.095 | 0.090–0.098 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.202 | 0.201–0.211 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 4.139 | 3.171–4.202 | Ferroni faster in every run interval |
| `literal_first` | 0.190 | 0.181–0.201 | comparator faster in every run interval |
| `literal_middle` | 0.198 | 0.186–0.200 | comparator faster in every run interval |
| `literal_end` | 0.180 | 0.178–0.185 | comparator faster in every run interval |
| `literal_absent` | 0.180 | 0.158–0.183 | comparator faster in every run interval |

## onigmo / first_use

Common cases: 24; families: 13. Pair-specific family-weighted ratio: 0.404.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 2.703 | 2.493–2.986 | Ferroni faster in every run interval |
| `uuid_v4` | 3.189 | 3.175–4.031 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.230 | 0.220–0.233 | comparator faster in every run interval |
| `ipv6_validation` | 0.249 | 0.214–0.301 | comparator faster in every run interval |
| `semver_version_parse` | 0.242 | 0.222–0.245 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.237 | 0.228–0.261 | comparator faster in every run interval |
| `jinja_string_token` | 0.118 | 0.118–0.122 | comparator faster in every run interval |
| `jinja_integer_token` | 1.984 | 1.956–1.988 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.566 | 0.495–0.653 | comparator faster in every run interval |
| `django_email_local_part` | 2.290 | 2.212–2.379 | Ferroni faster in every run interval |
| `django_email_domain` | 0.115 | 0.114–0.118 | comparator faster in every run interval |
| `django_url_regex` | 0.235 | 0.226–0.252 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.131 | 0.130–0.135 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.140 | 0.133–0.154 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.356 | 0.346–0.411 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.600 | 0.491–0.643 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.127 | 0.113–0.155 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.101 | 0.101–0.104 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.204 | 0.201–0.213 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 4.131 | 2.728–4.159 | Ferroni faster in every run interval |
| `literal_first` | 0.248 | 0.247–0.255 | comparator faster in every run interval |
| `literal_middle` | 0.277 | 0.261–0.286 | comparator faster in every run interval |
| `literal_end` | 0.281 | 0.268–0.290 | comparator faster in every run interval |
| `literal_absent` | 0.262 | 0.232–0.313 | comparator faster in every run interval |

## pcre2_jit / steady

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.672.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.833 | 0.829–0.868 | comparator faster in every run interval |
| `uuid_v4` | 1.021 | 0.946–1.144 | inconclusive |
| `ipv4_validation` | 1.465 | 1.428–1.657 | Ferroni faster in every run interval |
| `ipv6_validation` | 2.701 | 2.463–3.748 | Ferroni faster in every run interval |
| `semver_version_parse` | 0.406 | 0.379–0.458 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.410 | 0.378–0.427 | comparator faster in every run interval |
| `jinja_string_token` | 0.466 | 0.436–0.501 | comparator faster in every run interval |
| `jinja_integer_token` | 0.465 | 0.431–0.638 | comparator faster in every run interval |
| `jinja_float_token` | 0.596 | 0.490–0.634 | comparator faster in every run interval |
| `django_email_local_part` | 1.770 | 1.725–1.841 | Ferroni faster in every run interval |
| `django_email_domain` | 0.861 | 0.764–0.949 | inconclusive |
| `django_url_regex` | 1.371 | 1.285–1.746 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 0.482 | 0.436–0.495 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.495 | 0.460–0.526 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.335 | 0.333–0.349 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.346 | 0.331–0.358 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.601 | 0.599–0.662 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.493 | 0.489–0.504 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.398 | 0.394–0.444 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.553 | 0.532–0.576 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.510 | 0.484–0.575 | comparator faster in every run interval |
| `literal_first` | 1.435 | 1.409–1.448 | Ferroni faster in every run interval |
| `literal_middle` | 1.418 | 1.377–1.489 | Ferroni faster in every run interval |
| `literal_end` | 1.378 | 1.353–1.393 | Ferroni faster in every run interval |
| `literal_absent` | 1.275 | 1.057–1.325 | Ferroni faster in every run interval |

## pcre2_jit / compile

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.289.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.234 | 0.226–0.285 | comparator faster in every run interval |
| `uuid_v4` | 0.228 | 0.228–0.237 | comparator faster in every run interval |
| `ipv4_validation` | 0.268 | 0.218–0.282 | comparator faster in every run interval |
| `ipv6_validation` | 0.238 | 0.206–0.276 | comparator faster in every run interval |
| `semver_version_parse` | 0.374 | 0.370–0.383 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.297 | 0.278–0.311 | comparator faster in every run interval |
| `jinja_string_token` | 0.279 | 0.269–0.280 | comparator faster in every run interval |
| `jinja_integer_token` | 0.296 | 0.293–0.369 | comparator faster in every run interval |
| `jinja_float_token` | 0.238 | 0.221–0.290 | comparator faster in every run interval |
| `django_email_local_part` | 0.310 | 0.297–0.335 | comparator faster in every run interval |
| `django_email_domain` | 0.034 | 0.033–0.041 | comparator faster in every run interval |
| `django_url_regex` | 0.042 | 0.039–0.054 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.240 | 0.215–0.311 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.238 | 0.236–0.361 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.768 | 0.746–0.853 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.158 | 0.133–0.173 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.495 | 0.408–0.685 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.384 | 0.341–0.398 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.373 | 0.364–0.391 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.332 | 0.330–0.344 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.284 | 0.267–0.321 | comparator faster in every run interval |
| `literal_first` | 3.093 | 2.894–3.142 | Ferroni faster in every run interval |
| `literal_middle` | 2.972 | 2.728–3.198 | Ferroni faster in every run interval |
| `literal_end` | 3.072 | 2.983–3.095 | Ferroni faster in every run interval |
| `literal_absent` | 2.834 | 2.502–3.034 | Ferroni faster in every run interval |

## pcre2_jit / first_use

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.313.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.186 | 0.178–0.205 | comparator faster in every run interval |
| `uuid_v4` | 0.196 | 0.175–0.199 | comparator faster in every run interval |
| `ipv4_validation` | 0.306 | 0.249–0.323 | comparator faster in every run interval |
| `ipv6_validation` | 0.250 | 0.237–0.364 | comparator faster in every run interval |
| `semver_version_parse` | 0.397 | 0.371–0.465 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.308 | 0.268–0.308 | comparator faster in every run interval |
| `jinja_string_token` | 0.317 | 0.307–0.317 | comparator faster in every run interval |
| `jinja_integer_token` | 0.417 | 0.336–0.418 | comparator faster in every run interval |
| `jinja_float_token` | 0.250 | 0.236–0.374 | comparator faster in every run interval |
| `django_email_local_part` | 0.343 | 0.319–0.354 | comparator faster in every run interval |
| `django_email_domain` | 0.036 | 0.032–0.036 | comparator faster in every run interval |
| `django_url_regex` | 0.040 | 0.040–0.051 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.266 | 0.248–0.284 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.254 | 0.232–0.284 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.946 | 0.939–0.956 | inconclusive |
| `mastodon_hashtag_regex_step` | 0.169 | 0.159–0.178 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.522 | 0.521–0.691 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.407 | 0.390–0.425 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.394 | 0.374–0.419 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.511 | 0.462–0.708 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.416 | 0.302–0.437 | comparator faster in every run interval |
| `literal_first` | 3.081 | 3.072–3.428 | Ferroni faster in every run interval |
| `literal_middle` | 3.077 | 3.075–3.422 | Ferroni faster in every run interval |
| `literal_end` | 2.988 | 2.867–3.670 | Ferroni faster in every run interval |
| `literal_absent` | 2.733 | 2.527–3.089 | Ferroni faster in every run interval |

## pcre2 / steady

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 1.902.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.591 | 1.434–1.683 | Ferroni faster in every run interval |
| `uuid_v4` | 1.864 | 1.749–1.921 | Ferroni faster in every run interval |
| `ipv4_validation` | 7.837 | 7.821–8.577 | Ferroni faster in every run interval |
| `ipv6_validation` | 16.173 | 14.112–18.174 | Ferroni faster in every run interval |
| `semver_version_parse` | 1.311 | 1.215–1.437 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.672 | 1.460–1.713 | Ferroni faster in every run interval |
| `jinja_string_token` | 0.995 | 0.973–0.998 | inconclusive |
| `jinja_integer_token` | 1.475 | 1.424–2.044 | Ferroni faster in every run interval |
| `jinja_float_token` | 1.774 | 1.462–2.129 | Ferroni faster in every run interval |
| `django_email_local_part` | 5.318 | 4.809–5.510 | Ferroni faster in every run interval |
| `django_email_domain` | 2.938 | 2.682–3.535 | Ferroni faster in every run interval |
| `django_url_regex` | 4.051 | 3.659–4.561 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.407 | 1.340–1.493 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.782 | 1.635–2.158 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 0.990 | 0.960–1.100 | inconclusive |
| `mastodon_hashtag_regex_step` | 0.734 | 0.684–0.857 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 3.053 | 3.044–3.337 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 3.856 | 3.844–3.883 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 1.066 | 1.041–1.189 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.800 | 0.766–0.845 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.720 | 0.663–0.736 | comparator faster in every run interval |
| `literal_first` | 2.574 | 2.461–2.722 | Ferroni faster in every run interval |
| `literal_middle` | 2.471 | 2.357–2.572 | Ferroni faster in every run interval |
| `literal_end` | 2.307 | 2.196–2.326 | Ferroni faster in every run interval |
| `literal_absent` | 1.348 | 1.256–1.528 | Ferroni faster in every run interval |

## pcre2 / compile

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.069.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.073 | 0.073–0.078 | comparator faster in every run interval |
| `uuid_v4` | 0.086 | 0.081–0.091 | comparator faster in every run interval |
| `ipv4_validation` | 0.078 | 0.063–0.078 | comparator faster in every run interval |
| `ipv6_validation` | 0.077 | 0.062–0.097 | comparator faster in every run interval |
| `semver_version_parse` | 0.086 | 0.081–0.086 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.074 | 0.067–0.075 | comparator faster in every run interval |
| `jinja_string_token` | 0.046 | 0.044–0.047 | comparator faster in every run interval |
| `jinja_integer_token` | 0.064 | 0.063–0.073 | comparator faster in every run interval |
| `jinja_float_token` | 0.038 | 0.035–0.038 | comparator faster in every run interval |
| `django_email_local_part` | 0.125 | 0.124–0.126 | comparator faster in every run interval |
| `django_email_domain` | 0.032 | 0.028–0.034 | comparator faster in every run interval |
| `django_url_regex` | 0.035 | 0.031–0.038 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.041 | 0.040–0.048 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.046 | 0.045–0.075 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.206 | 0.194–0.219 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.074 | 0.068–0.074 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.063 | 0.054–0.086 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.045 | 0.043–0.053 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.091 | 0.081–0.091 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.032 | 0.030–0.041 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.027 | 0.021–0.028 | comparator faster in every run interval |
| `literal_first` | 0.162 | 0.159–0.187 | comparator faster in every run interval |
| `literal_middle` | 0.171 | 0.135–0.191 | comparator faster in every run interval |
| `literal_end` | 0.156 | 0.155–0.170 | comparator faster in every run interval |
| `literal_absent` | 0.150 | 0.133–0.282 | comparator faster in every run interval |

## pcre2 / first_use

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.117.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.095 | 0.091–0.100 | comparator faster in every run interval |
| `uuid_v4` | 0.104 | 0.087–0.110 | comparator faster in every run interval |
| `ipv4_validation` | 0.111 | 0.110–0.111 | comparator faster in every run interval |
| `ipv6_validation` | 0.077 | 0.076–0.105 | comparator faster in every run interval |
| `semver_version_parse` | 0.108 | 0.102–0.108 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.088 | 0.081–0.091 | comparator faster in every run interval |
| `jinja_string_token` | 0.085 | 0.079–0.088 | comparator faster in every run interval |
| `jinja_integer_token` | 0.103 | 0.103–0.119 | comparator faster in every run interval |
| `jinja_float_token` | 0.056 | 0.054–0.071 | comparator faster in every run interval |
| `django_email_local_part` | 0.150 | 0.138–0.157 | comparator faster in every run interval |
| `django_email_domain` | 0.037 | 0.029–0.039 | comparator faster in every run interval |
| `django_url_regex` | 0.031 | 0.030–0.031 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.080 | 0.068–0.084 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.091 | 0.070–0.099 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.335 | 0.309–0.402 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.089 | 0.081–0.089 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.154 | 0.133–0.155 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.101 | 0.098–0.106 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.112 | 0.105–0.117 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.187 | 0.167–0.261 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.140 | 0.101–0.143 | comparator faster in every run interval |
| `literal_first` | 0.927 | 0.873–1.049 | inconclusive |
| `literal_middle` | 0.910 | 0.871–0.922 | inconclusive |
| `literal_end` | 0.864 | 0.849–0.887 | inconclusive |
| `literal_absent` | 0.820 | 0.701–0.832 | comparator faster in every run interval |

## fancy_regex / steady

Common cases: 21; families: 11. Pair-specific family-weighted ratio: 2.693.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.169 | 1.107–1.261 | Ferroni faster in every run interval |
| `uuid_v4` | 1.182 | 1.114–1.286 | Ferroni faster in every run interval |
| `ipv4_validation` | 1.327 | 1.318–1.340 | Ferroni faster in every run interval |
| `ipv6_validation` | 1.257 | 1.105–1.470 | Ferroni faster in every run interval |
| `semver_version_parse` | 2.166 | 2.111–2.295 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.603 | 1.390–1.759 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.053 | 1.020–1.101 | inconclusive |
| `jinja_integer_token` | 1.376 | 1.296–1.435 | Ferroni faster in every run interval |
| `jinja_float_token` | 2.535 | 2.268–2.751 | Ferroni faster in every run interval |
| `django_email_domain` | 9.254 | 9.100–12.047 | Ferroni faster in every run interval |
| `django_url_regex` | 30.875 | 24.193–35.672 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.680 | 1.627–1.824 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 2.064 | 1.981–2.269 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 2.946 | 2.797–3.061 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 2.959 | 2.915–3.264 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 4.680 | 4.518–4.785 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 1.873 | 1.852–2.065 | Ferroni faster in every run interval |
| `literal_first` | 1.170 | 1.140–1.296 | Ferroni faster in every run interval |
| `literal_middle` | 1.152 | 1.146–1.256 | Ferroni faster in every run interval |
| `literal_end` | 1.095 | 1.078–1.104 | Ferroni faster in every run interval |
| `literal_absent` | 1.113 | 1.034–1.145 | Ferroni faster in every run interval |

## fancy_regex / compile

Common cases: 21; families: 11. Pair-specific family-weighted ratio: 1.369.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.933 | 0.878–0.973 | inconclusive |
| `uuid_v4` | 0.922 | 0.904–1.009 | inconclusive |
| `ipv4_validation` | 0.805 | 0.760–0.893 | comparator faster in every run interval |
| `ipv6_validation` | 0.814 | 0.788–0.903 | comparator faster in every run interval |
| `semver_version_parse` | 14.907 | 13.977–15.109 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 9.208 | 8.695–9.224 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.709 | 1.692–1.782 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.846 | 1.629–2.191 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.246 | 0.224–0.258 | comparator faster in every run interval |
| `django_email_domain` | 1.947 | 1.809–1.954 | Ferroni faster in every run interval |
| `django_url_regex` | 1.851 | 1.673–2.211 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.680 | 1.252–1.719 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.459 | 1.408–1.994 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.175 | 1.132–1.258 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.544 | 0.513–0.581 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.428 | 0.379–0.437 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 1.044 | 1.015–1.180 | inconclusive |
| `literal_first` | 1.255 | 1.218–1.337 | Ferroni faster in every run interval |
| `literal_middle` | 1.166 | 1.055–1.199 | inconclusive |
| `literal_end` | 1.153 | 1.148–1.207 | Ferroni faster in every run interval |
| `literal_absent` | 1.129 | 0.967–1.193 | inconclusive |

## fancy_regex / first_use

Common cases: 21; families: 11. Pair-specific family-weighted ratio: 1.408.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.037 | 0.915–1.059 | inconclusive |
| `uuid_v4` | 1.007 | 0.954–1.047 | inconclusive |
| `ipv4_validation` | 0.866 | 0.849–0.902 | comparator faster in every run interval |
| `ipv6_validation` | 0.933 | 0.875–1.048 | inconclusive |
| `semver_version_parse` | 14.249 | 13.816–14.330 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 8.985 | 8.696–9.028 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.648 | 1.644–1.713 | Ferroni faster in every run interval |
| `jinja_integer_token` | 2.247 | 1.966–2.304 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.259 | 0.251–0.264 | comparator faster in every run interval |
| `django_email_domain` | 1.978 | 1.832–2.357 | Ferroni faster in every run interval |
| `django_url_regex` | 1.791 | 1.783–1.882 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.440 | 1.261–1.496 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.513 | 1.407–1.761 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.413 | 1.384–1.438 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.488 | 0.471–0.519 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.380 | 0.380–0.477 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 1.099 | 1.045–1.118 | Ferroni faster in every run interval |
| `literal_first` | 1.235 | 1.215–1.270 | Ferroni faster in every run interval |
| `literal_middle` | 1.276 | 1.263–1.478 | Ferroni faster in every run interval |
| `literal_end` | 1.217 | 1.163–1.220 | Ferroni faster in every run interval |
| `literal_absent` | 1.086 | 1.007–1.253 | inconclusive |

## fancy_regex_seek / steady

Common cases: 21; families: 11. Pair-specific family-weighted ratio: 2.728.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.209 | 1.185–1.224 | Ferroni faster in every run interval |
| `uuid_v4` | 1.333 | 1.182–1.509 | Ferroni faster in every run interval |
| `ipv4_validation` | 1.324 | 1.299–1.338 | Ferroni faster in every run interval |
| `ipv6_validation` | 1.229 | 1.157–1.581 | Ferroni faster in every run interval |
| `semver_version_parse` | 2.098 | 2.070–2.145 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.670 | 1.402–1.738 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.035 | 1.030–1.121 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.280 | 1.237–1.867 | Ferroni faster in every run interval |
| `jinja_float_token` | 2.732 | 2.121–2.755 | Ferroni faster in every run interval |
| `django_email_domain` | 10.000 | 9.129–11.698 | Ferroni faster in every run interval |
| `django_url_regex` | 27.736 | 25.096–40.338 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.757 | 1.705–2.067 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.986 | 1.983–2.104 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 3.095 | 2.694–3.107 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 2.945 | 2.791–3.036 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 4.605 | 4.597–5.177 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 2.019 | 1.995–2.056 | Ferroni faster in every run interval |
| `literal_first` | 1.192 | 1.166–1.275 | Ferroni faster in every run interval |
| `literal_middle` | 1.139 | 1.129–1.196 | Ferroni faster in every run interval |
| `literal_end` | 1.084 | 1.065–1.108 | Ferroni faster in every run interval |
| `literal_absent` | 1.083 | 1.035–1.133 | Ferroni faster in every run interval |

## fancy_regex_seek / compile

Common cases: 21; families: 11. Pair-specific family-weighted ratio: 1.544.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.977 | 0.973–0.985 | inconclusive |
| `uuid_v4` | 0.962 | 0.954–1.084 | inconclusive |
| `ipv4_validation` | 0.808 | 0.736–0.832 | comparator faster in every run interval |
| `ipv6_validation` | 0.907 | 0.741–0.962 | inconclusive |
| `semver_version_parse` | 14.999 | 14.522–15.284 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 9.606 | 8.956–9.763 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.684 | 1.655–1.740 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.713 | 1.630–1.879 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.248 | 0.245–0.256 | comparator faster in every run interval |
| `django_email_domain` | 1.973 | 1.853–1.995 | Ferroni faster in every run interval |
| `django_url_regex` | 2.182 | 1.824–2.354 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.486 | 1.279–1.589 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.494 | 1.398–2.052 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.194 | 1.158–1.226 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.468 | 0.434–0.566 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.453 | 0.391–0.520 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 3.283 | 3.229–3.324 | Ferroni faster in every run interval |
| `literal_first` | 1.167 | 1.166–1.202 | Ferroni faster in every run interval |
| `literal_middle` | 1.111 | 1.056–1.268 | inconclusive |
| `literal_end` | 1.170 | 1.122–1.202 | Ferroni faster in every run interval |
| `literal_absent` | 1.142 | 0.947–1.184 | inconclusive |

## fancy_regex_seek / first_use

Common cases: 21; families: 11. Pair-specific family-weighted ratio: 1.571.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.955 | 0.926–1.034 | inconclusive |
| `uuid_v4` | 1.153 | 0.950–1.184 | inconclusive |
| `ipv4_validation` | 0.855 | 0.813–0.916 | comparator faster in every run interval |
| `ipv6_validation` | 0.917 | 0.886–0.925 | inconclusive |
| `semver_version_parse` | 14.613 | 13.983–14.715 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 8.858 | 8.763–9.597 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.723 | 1.602–1.789 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.926 | 1.906–2.002 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.254 | 0.247–0.279 | comparator faster in every run interval |
| `django_email_domain` | 2.038 | 1.884–2.044 | Ferroni faster in every run interval |
| `django_url_regex` | 1.847 | 1.752–2.134 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.505 | 1.267–1.508 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.466 | 1.432–1.746 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.396 | 1.341–1.503 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.475 | 0.470–0.481 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.384 | 0.376–0.461 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 3.561 | 3.521–3.675 | Ferroni faster in every run interval |
| `literal_first` | 1.220 | 1.209–1.249 | Ferroni faster in every run interval |
| `literal_middle` | 1.337 | 1.300–1.489 | Ferroni faster in every run interval |
| `literal_end` | 1.228 | 1.227–1.282 | Ferroni faster in every run interval |
| `literal_absent` | 1.092 | 1.063–1.235 | inconclusive |

## regex / steady

Common cases: 14; families: 6. Pair-specific family-weighted ratio: 1.323.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.390 | 1.355–1.457 | Ferroni faster in every run interval |
| `uuid_v4` | 1.548 | 1.514–1.606 | Ferroni faster in every run interval |
| `ipv4_validation` | 1.571 | 1.551–1.649 | Ferroni faster in every run interval |
| `ipv6_validation` | 1.447 | 1.402–1.536 | Ferroni faster in every run interval |
| `semver_version_parse` | 1.914 | 1.865–1.949 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.331 | 1.257–1.498 | Ferroni faster in every run interval |
| `jinja_string_token` | 0.669 | 0.650–0.706 | comparator faster in every run interval |
| `jinja_integer_token` | 1.048 | 1.004–1.116 | inconclusive |
| `fluent_bit_apache` | 1.535 | 1.511–1.696 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 2.071 | 1.877–2.073 | Ferroni faster in every run interval |
| `literal_first` | 1.049 | 1.030–1.066 | Ferroni faster in every run interval |
| `literal_middle` | 1.041 | 1.017–1.054 | inconclusive |
| `literal_end` | 1.001 | 0.993–1.030 | inconclusive |
| `literal_absent` | 0.979 | 0.906–0.980 | inconclusive |

## regex / compile

Common cases: 14; families: 6. Pair-specific family-weighted ratio: 1.643.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.745 | 0.694–0.781 | comparator faster in every run interval |
| `uuid_v4` | 0.723 | 0.705–0.727 | comparator faster in every run interval |
| `ipv4_validation` | 0.724 | 0.674–0.901 | comparator faster in every run interval |
| `ipv6_validation` | 0.782 | 0.668–0.788 | comparator faster in every run interval |
| `semver_version_parse` | 15.330 | 13.915–15.775 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 9.645 | 9.504–9.929 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.715 | 1.605–1.731 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.605 | 1.572–1.665 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.542 | 1.515–1.594 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.442 | 1.387–1.940 | Ferroni faster in every run interval |
| `literal_first` | 1.184 | 1.141–1.437 | Ferroni faster in every run interval |
| `literal_middle` | 1.141 | 1.096–1.264 | Ferroni faster in every run interval |
| `literal_end` | 1.292 | 1.157–1.296 | Ferroni faster in every run interval |
| `literal_absent` | 1.120 | 1.021–1.196 | inconclusive |

## regex / first_use

Common cases: 14; families: 6. Pair-specific family-weighted ratio: 1.699.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.789 | 0.784–0.802 | comparator faster in every run interval |
| `uuid_v4` | 0.796 | 0.771–0.894 | comparator faster in every run interval |
| `ipv4_validation` | 0.799 | 0.721–0.806 | comparator faster in every run interval |
| `ipv6_validation` | 0.823 | 0.737–0.885 | comparator faster in every run interval |
| `semver_version_parse` | 14.194 | 13.893–14.570 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 9.232 | 8.794–9.315 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.674 | 1.590–1.850 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.819 | 1.771–2.417 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.348 | 1.281–1.540 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.445 | 1.386–1.733 | Ferroni faster in every run interval |
| `literal_first` | 1.361 | 1.251–1.480 | Ferroni faster in every run interval |
| `literal_middle` | 1.359 | 1.328–1.367 | Ferroni faster in every run interval |
| `literal_end` | 1.268 | 1.219–1.344 | Ferroni faster in every run interval |
| `literal_absent` | 1.378 | 1.252–1.403 | Ferroni faster in every run interval |

Raw samples, estimates, confidence intervals, failures, eligibility reasons, corpus snapshot and execution order are retained beside this report.

Memory, where requested, is fresh-process peak RSS including the binary, runtime, parsed catalog, compilation, input/output and allocator. It is not isolated compiled-pattern memory.
