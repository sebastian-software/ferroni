# Production regex comparison

Host: Linux-6.6.141-x86_64-with-glibc2.39; x86_64.

Publication candidate: review host stability, raw samples, coverage and run intervals before publishing.

Ratios are comparator / Ferroni. Compile and first-use times concern one pattern; steady times concern the complete fixture batch.

Each comparison below uses only its explicitly listed common tasks. Families have equal aggregate weight; architectures are never combined.

## Eligibility

| Case | Engine | Status |
| --- | --- | --- |
| `uuid_shape` | rust | eligible |
| `uuid_shape` | rust_erroraware | eligible |
| `uuid_shape` | c | eligible |
| `uuid_shape` | onigmo | eligible |
| `uuid_shape` | pcre2_jit | eligible |
| `uuid_shape` | pcre2 | eligible |
| `uuid_shape` | fancy_regex | eligible |
| `uuid_shape` | fancy_regex_seek | eligible |
| `uuid_shape` | regex | eligible |
| `uuid_v4` | rust | eligible |
| `uuid_v4` | rust_erroraware | eligible |
| `uuid_v4` | c | eligible |
| `uuid_v4` | onigmo | eligible |
| `uuid_v4` | pcre2_jit | eligible |
| `uuid_v4` | pcre2 | eligible |
| `uuid_v4` | fancy_regex | eligible |
| `uuid_v4` | fancy_regex_seek | eligible |
| `uuid_v4` | regex | eligible |
| `ipv4_validation` | rust | eligible |
| `ipv4_validation` | rust_erroraware | eligible |
| `ipv4_validation` | c | eligible |
| `ipv4_validation` | onigmo | eligible |
| `ipv4_validation` | pcre2_jit | eligible |
| `ipv4_validation` | pcre2 | eligible |
| `ipv4_validation` | fancy_regex | eligible |
| `ipv4_validation` | fancy_regex_seek | eligible |
| `ipv4_validation` | regex | eligible |
| `ipv6_validation` | rust | eligible |
| `ipv6_validation` | rust_erroraware | eligible |
| `ipv6_validation` | c | eligible |
| `ipv6_validation` | onigmo | eligible |
| `ipv6_validation` | pcre2_jit | eligible |
| `ipv6_validation` | pcre2 | eligible |
| `ipv6_validation` | fancy_regex | eligible |
| `ipv6_validation` | fancy_regex_seek | eligible |
| `ipv6_validation` | regex | eligible |
| `semver_version_parse` | rust | eligible |
| `semver_version_parse` | rust_erroraware | eligible |
| `semver_version_parse` | c | eligible |
| `semver_version_parse` | onigmo | eligible |
| `semver_version_parse` | pcre2_jit | eligible |
| `semver_version_parse` | pcre2 | eligible |
| `semver_version_parse` | fancy_regex | eligible |
| `semver_version_parse` | fancy_regex_seek | eligible |
| `semver_version_parse` | regex | eligible |
| `semver_hyphen_range_captures` | rust | eligible |
| `semver_hyphen_range_captures` | rust_erroraware | eligible |
| `semver_hyphen_range_captures` | c | eligible |
| `semver_hyphen_range_captures` | onigmo | eligible |
| `semver_hyphen_range_captures` | pcre2_jit | eligible |
| `semver_hyphen_range_captures` | pcre2 | eligible |
| `semver_hyphen_range_captures` | fancy_regex | eligible |
| `semver_hyphen_range_captures` | fancy_regex_seek | eligible |
| `semver_hyphen_range_captures` | regex | eligible |
| `jinja_string_token` | rust | eligible |
| `jinja_string_token` | rust_erroraware | eligible |
| `jinja_string_token` | c | eligible |
| `jinja_string_token` | onigmo | eligible |
| `jinja_string_token` | pcre2_jit | eligible |
| `jinja_string_token` | pcre2 | eligible |
| `jinja_string_token` | fancy_regex | eligible |
| `jinja_string_token` | fancy_regex_seek | eligible |
| `jinja_string_token` | regex | eligible |
| `jinja_integer_token` | rust | eligible |
| `jinja_integer_token` | rust_erroraware | eligible |
| `jinja_integer_token` | c | eligible |
| `jinja_integer_token` | onigmo | eligible |
| `jinja_integer_token` | pcre2_jit | eligible |
| `jinja_integer_token` | pcre2 | eligible |
| `jinja_integer_token` | fancy_regex | eligible |
| `jinja_integer_token` | fancy_regex_seek | eligible |
| `jinja_integer_token` | regex | eligible |
| `jinja_float_token` | rust | eligible |
| `jinja_float_token` | rust_erroraware | eligible |
| `jinja_float_token` | c | eligible |
| `jinja_float_token` | onigmo | eligible |
| `jinja_float_token` | pcre2_jit | eligible |
| `jinja_float_token` | pcre2 | eligible |
| `jinja_float_token` | fancy_regex | eligible |
| `jinja_float_token` | fancy_regex_seek | eligible |
| `jinja_float_token` | regex | syntax_rejected |
| `django_email_local_part` | rust | eligible |
| `django_email_local_part` | rust_erroraware | eligible |
| `django_email_local_part` | c | eligible |
| `django_email_local_part` | onigmo | eligible |
| `django_email_local_part` | pcre2_jit | eligible |
| `django_email_local_part` | pcre2 | eligible |
| `django_email_local_part` | fancy_regex | syntax_rejected |
| `django_email_local_part` | fancy_regex_seek | syntax_rejected |
| `django_email_local_part` | regex | syntax_rejected |
| `django_email_domain` | rust | eligible |
| `django_email_domain` | rust_erroraware | eligible |
| `django_email_domain` | c | eligible |
| `django_email_domain` | onigmo | eligible |
| `django_email_domain` | pcre2_jit | eligible |
| `django_email_domain` | pcre2 | eligible |
| `django_email_domain` | fancy_regex | eligible |
| `django_email_domain` | fancy_regex_seek | eligible |
| `django_email_domain` | regex | syntax_rejected |
| `django_url_regex` | rust | eligible |
| `django_url_regex` | rust_erroraware | eligible |
| `django_url_regex` | c | eligible |
| `django_url_regex` | onigmo | eligible |
| `django_url_regex` | pcre2_jit | eligible |
| `django_url_regex` | pcre2 | eligible |
| `django_url_regex` | fancy_regex | eligible |
| `django_url_regex` | fancy_regex_seek | eligible |
| `django_url_regex` | regex | syntax_rejected |
| `fluent_bit_apache` | rust | eligible |
| `fluent_bit_apache` | rust_erroraware | eligible |
| `fluent_bit_apache` | c | eligible |
| `fluent_bit_apache` | onigmo | eligible |
| `fluent_bit_apache` | pcre2_jit | eligible |
| `fluent_bit_apache` | pcre2 | eligible |
| `fluent_bit_apache` | fancy_regex | eligible |
| `fluent_bit_apache` | fancy_regex_seek | eligible |
| `fluent_bit_apache` | regex | eligible |
| `fluent_bit_nginx` | rust | eligible |
| `fluent_bit_nginx` | rust_erroraware | eligible |
| `fluent_bit_nginx` | c | eligible |
| `fluent_bit_nginx` | onigmo | eligible |
| `fluent_bit_nginx` | pcre2_jit | eligible |
| `fluent_bit_nginx` | pcre2 | eligible |
| `fluent_bit_nginx` | fancy_regex | eligible |
| `fluent_bit_nginx` | fancy_regex_seek | eligible |
| `fluent_bit_nginx` | regex | eligible |
| `rails_underscore_regex_step` | rust | eligible |
| `rails_underscore_regex_step` | rust_erroraware | eligible |
| `rails_underscore_regex_step` | c | eligible |
| `rails_underscore_regex_step` | onigmo | eligible |
| `rails_underscore_regex_step` | pcre2_jit | eligible |
| `rails_underscore_regex_step` | pcre2 | eligible |
| `rails_underscore_regex_step` | fancy_regex | eligible |
| `rails_underscore_regex_step` | fancy_regex_seek | eligible |
| `rails_underscore_regex_step` | regex | syntax_rejected |
| `mastodon_hashtag_regex_step` | rust | eligible |
| `mastodon_hashtag_regex_step` | rust_erroraware | eligible |
| `mastodon_hashtag_regex_step` | c | eligible |
| `mastodon_hashtag_regex_step` | onigmo | eligible |
| `mastodon_hashtag_regex_step` | pcre2_jit | eligible |
| `mastodon_hashtag_regex_step` | pcre2 | eligible |
| `mastodon_hashtag_regex_step` | fancy_regex | semantic_difference |
| `mastodon_hashtag_regex_step` | fancy_regex_seek | semantic_difference |
| `mastodon_hashtag_regex_step` | regex | syntax_rejected |
| `python_markdown_smart_emphasis_re` | rust | eligible |
| `python_markdown_smart_emphasis_re` | rust_erroraware | eligible |
| `python_markdown_smart_emphasis_re` | c | eligible |
| `python_markdown_smart_emphasis_re` | onigmo | eligible |
| `python_markdown_smart_emphasis_re` | pcre2_jit | eligible |
| `python_markdown_smart_emphasis_re` | pcre2 | eligible |
| `python_markdown_smart_emphasis_re` | fancy_regex | eligible |
| `python_markdown_smart_emphasis_re` | fancy_regex_seek | eligible |
| `python_markdown_smart_emphasis_re` | regex | syntax_rejected |
| `python_markdown_smart_strong_em_re` | rust | eligible |
| `python_markdown_smart_strong_em_re` | rust_erroraware | eligible |
| `python_markdown_smart_strong_em_re` | c | eligible |
| `python_markdown_smart_strong_em_re` | onigmo | eligible |
| `python_markdown_smart_strong_em_re` | pcre2_jit | eligible |
| `python_markdown_smart_strong_em_re` | pcre2 | eligible |
| `python_markdown_smart_strong_em_re` | fancy_regex | eligible |
| `python_markdown_smart_strong_em_re` | fancy_regex_seek | eligible |
| `python_markdown_smart_strong_em_re` | regex | syntax_rejected |
| `wordpress_shortcode_captures` | rust | eligible |
| `wordpress_shortcode_captures` | rust_erroraware | eligible |
| `wordpress_shortcode_captures` | c | eligible |
| `wordpress_shortcode_captures` | onigmo | eligible |
| `wordpress_shortcode_captures` | pcre2_jit | eligible |
| `wordpress_shortcode_captures` | pcre2 | eligible |
| `wordpress_shortcode_captures` | fancy_regex | eligible |
| `wordpress_shortcode_captures` | fancy_regex_seek | eligible |
| `wordpress_shortcode_captures` | regex | syntax_rejected |
| `symfony_grapheme_chunks_1` | rust | eligible |
| `symfony_grapheme_chunks_1` | rust_erroraware | eligible |
| `symfony_grapheme_chunks_1` | c | eligible |
| `symfony_grapheme_chunks_1` | onigmo | semantic_difference |
| `symfony_grapheme_chunks_1` | pcre2_jit | eligible |
| `symfony_grapheme_chunks_1` | pcre2 | eligible |
| `symfony_grapheme_chunks_1` | fancy_regex | syntax_rejected |
| `symfony_grapheme_chunks_1` | fancy_regex_seek | syntax_rejected |
| `symfony_grapheme_chunks_1` | regex | syntax_rejected |
| `symfony_grapheme_chunks_2` | rust | eligible |
| `symfony_grapheme_chunks_2` | rust_erroraware | eligible |
| `symfony_grapheme_chunks_2` | c | eligible |
| `symfony_grapheme_chunks_2` | onigmo | eligible |
| `symfony_grapheme_chunks_2` | pcre2_jit | eligible |
| `symfony_grapheme_chunks_2` | pcre2 | eligible |
| `symfony_grapheme_chunks_2` | fancy_regex | syntax_rejected |
| `symfony_grapheme_chunks_2` | fancy_regex_seek | syntax_rejected |
| `symfony_grapheme_chunks_2` | regex | syntax_rejected |
| `literal_first` | rust | eligible |
| `literal_first` | rust_erroraware | eligible |
| `literal_first` | c | eligible |
| `literal_first` | onigmo | eligible |
| `literal_first` | pcre2_jit | eligible |
| `literal_first` | pcre2 | eligible |
| `literal_first` | fancy_regex | eligible |
| `literal_first` | fancy_regex_seek | eligible |
| `literal_first` | regex | eligible |
| `literal_middle` | rust | eligible |
| `literal_middle` | rust_erroraware | eligible |
| `literal_middle` | c | eligible |
| `literal_middle` | onigmo | eligible |
| `literal_middle` | pcre2_jit | eligible |
| `literal_middle` | pcre2 | eligible |
| `literal_middle` | fancy_regex | eligible |
| `literal_middle` | fancy_regex_seek | eligible |
| `literal_middle` | regex | eligible |
| `literal_end` | rust | eligible |
| `literal_end` | rust_erroraware | eligible |
| `literal_end` | c | eligible |
| `literal_end` | onigmo | eligible |
| `literal_end` | pcre2_jit | eligible |
| `literal_end` | pcre2 | eligible |
| `literal_end` | fancy_regex | eligible |
| `literal_end` | fancy_regex_seek | eligible |
| `literal_end` | regex | eligible |
| `literal_absent` | rust | eligible |
| `literal_absent` | rust_erroraware | eligible |
| `literal_absent` | c | eligible |
| `literal_absent` | onigmo | eligible |
| `literal_absent` | pcre2_jit | eligible |
| `literal_absent` | pcre2 | eligible |
| `literal_absent` | fancy_regex | eligible |
| `literal_absent` | fancy_regex_seek | eligible |
| `literal_absent` | regex | eligible |
| `linkify_http_tail` | rust | pending |
| `linkify_http_tail` | rust_erroraware | pending |
| `linkify_http_tail` | c | pending |
| `linkify_http_tail` | onigmo | pending |
| `linkify_http_tail` | pcre2_jit | pending |
| `linkify_http_tail` | pcre2 | pending |
| `linkify_http_tail` | fancy_regex | pending |
| `linkify_http_tail` | fancy_regex_seek | pending |
| `linkify_http_tail` | regex | pending |
| `php_cs_fixer_recursive_types` | rust | pending |
| `php_cs_fixer_recursive_types` | rust_erroraware | pending |
| `php_cs_fixer_recursive_types` | c | pending |
| `php_cs_fixer_recursive_types` | onigmo | pending |
| `php_cs_fixer_recursive_types` | pcre2_jit | pending |
| `php_cs_fixer_recursive_types` | pcre2 | pending |
| `php_cs_fixer_recursive_types` | fancy_regex | pending |
| `php_cs_fixer_recursive_types` | fancy_regex_seek | pending |
| `php_cs_fixer_recursive_types` | regex | pending |
| `ferrolink_markup_scan` | rust | eligible |
| `ferrolink_markup_scan` | rust_erroraware | eligible |
| `ferrolink_markup_scan` | c | eligible |
| `ferrolink_markup_scan` | onigmo | eligible |
| `ferrolink_markup_scan` | pcre2_jit | eligible |
| `ferrolink_markup_scan` | pcre2 | eligible |
| `ferrolink_markup_scan` | fancy_regex | eligible |
| `ferrolink_markup_scan` | fancy_regex_seek | eligible |
| `ferrolink_markup_scan` | regex | syntax_rejected |
| `ferrolink_attribute_split` | rust | eligible |
| `ferrolink_attribute_split` | rust_erroraware | eligible |
| `ferrolink_attribute_split` | c | eligible |
| `ferrolink_attribute_split` | onigmo | eligible |
| `ferrolink_attribute_split` | pcre2_jit | eligible |
| `ferrolink_attribute_split` | pcre2 | eligible |
| `ferrolink_attribute_split` | fancy_regex | eligible |
| `ferrolink_attribute_split` | fancy_regex_seek | eligible |
| `ferrolink_attribute_split` | regex | eligible |

## rust_erroraware / steady

Common cases: 27; families: 14. Pair-specific family-weighted ratio: 1.725.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.817 | 1.717–1.934 | Ferroni faster in every run interval |
| `uuid_v4` | 1.967 | 1.804–2.053 | Ferroni faster in every run interval |
| `ipv4_validation` | 5.425 | 5.141–5.679 | Ferroni faster in every run interval |
| `ipv6_validation` | 11.704 | 11.327–11.880 | Ferroni faster in every run interval |
| `semver_version_parse` | 1.096 | 1.059–1.124 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.094 | 1.071–1.099 | inconclusive |
| `jinja_string_token` | 1.220 | 1.189–1.230 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.182 | 1.137–1.201 | Ferroni faster in every run interval |
| `jinja_float_token` | 1.336 | 1.242–1.422 | Ferroni faster in every run interval |
| `django_email_local_part` | 3.091 | 2.991–3.182 | Ferroni faster in every run interval |
| `django_email_domain` | 7.849 | 7.653–8.458 | Ferroni faster in every run interval |
| `django_url_regex` | 7.104 | 6.986–7.564 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.220 | 1.207–1.250 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.497 | 1.456–1.524 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.037 | 1.030–1.080 | inconclusive |
| `mastodon_hashtag_regex_step` | 1.060 | 1.040–1.085 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 1.117 | 1.067–1.136 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 1.089 | 1.088–1.105 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 1.037 | 1.017–1.037 | inconclusive |
| `symfony_grapheme_chunks_1` | 1.075 | 1.061–1.082 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_2` | 1.079 | 1.059–1.150 | Ferroni faster in every run interval |
| `literal_first` | 1.531 | 1.522–1.610 | Ferroni faster in every run interval |
| `literal_middle` | 1.519 | 1.491–1.521 | Ferroni faster in every run interval |
| `literal_end` | 1.586 | 1.488–1.590 | Ferroni faster in every run interval |
| `literal_absent` | 1.357 | 1.325–1.361 | Ferroni faster in every run interval |
| `ferrolink_markup_scan` | 1.076 | 1.020–1.078 | inconclusive |
| `ferrolink_attribute_split` | 1.033 | 0.999–1.077 | inconclusive |

## rust_erroraware / compile

Common cases: 27; families: 14. Pair-specific family-weighted ratio: 1.005.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.979 | 0.921–1.067 | inconclusive |
| `uuid_v4` | 1.018 | 0.973–1.049 | inconclusive |
| `ipv4_validation` | 0.991 | 0.984–1.087 | inconclusive |
| `ipv6_validation` | 0.976 | 0.971–0.977 | inconclusive |
| `semver_version_parse` | 0.988 | 0.958–0.996 | inconclusive |
| `semver_hyphen_range_captures` | 1.000 | 0.954–1.005 | inconclusive |
| `jinja_string_token` | 0.999 | 0.988–1.042 | inconclusive |
| `jinja_integer_token` | 1.008 | 0.990–1.016 | inconclusive |
| `jinja_float_token` | 0.996 | 0.933–1.050 | inconclusive |
| `django_email_local_part` | 1.025 | 0.985–1.106 | inconclusive |
| `django_email_domain` | 0.986 | 0.885–0.991 | inconclusive |
| `django_url_regex` | 1.022 | 0.976–1.056 | inconclusive |
| `fluent_bit_apache` | 0.981 | 0.953–0.986 | inconclusive |
| `fluent_bit_nginx` | 0.999 | 0.996–1.040 | inconclusive |
| `rails_underscore_regex_step` | 1.015 | 0.996–1.050 | inconclusive |
| `mastodon_hashtag_regex_step` | 1.026 | 0.984–1.028 | inconclusive |
| `python_markdown_smart_emphasis_re` | 1.008 | 0.979–1.031 | inconclusive |
| `python_markdown_smart_strong_em_re` | 1.008 | 0.987–1.134 | inconclusive |
| `wordpress_shortcode_captures` | 1.020 | 0.890–1.048 | inconclusive |
| `symfony_grapheme_chunks_1` | 0.954 | 0.930–0.998 | inconclusive |
| `symfony_grapheme_chunks_2` | 0.982 | 0.972–0.985 | inconclusive |
| `literal_first` | 0.964 | 0.963–1.052 | inconclusive |
| `literal_middle` | 1.084 | 0.962–1.091 | inconclusive |
| `literal_end` | 1.128 | 1.089–1.164 | inconclusive |
| `literal_absent` | 0.929 | 0.854–0.990 | inconclusive |
| `ferrolink_markup_scan` | 1.006 | 0.984–1.006 | inconclusive |
| `ferrolink_attribute_split` | 1.022 | 0.974–1.025 | inconclusive |

## rust_erroraware / first_use

Common cases: 27; families: 14. Pair-specific family-weighted ratio: 0.959.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.758 | 0.701–0.759 | comparator faster in every run interval |
| `uuid_v4` | 0.811 | 0.794–0.866 | comparator faster in every run interval |
| `ipv4_validation` | 0.939 | 0.912–1.064 | inconclusive |
| `ipv6_validation` | 0.994 | 0.978–0.999 | inconclusive |
| `semver_version_parse` | 0.961 | 0.944–0.979 | inconclusive |
| `semver_hyphen_range_captures` | 0.975 | 0.893–0.990 | inconclusive |
| `jinja_string_token` | 0.936 | 0.868–0.959 | comparator faster in every run interval |
| `jinja_integer_token` | 0.962 | 0.955–0.962 | inconclusive |
| `jinja_float_token` | 0.970 | 0.964–1.051 | inconclusive |
| `django_email_local_part` | 1.000 | 0.949–1.135 | inconclusive |
| `django_email_domain` | 0.978 | 0.965–0.990 | inconclusive |
| `django_url_regex` | 0.972 | 0.965–0.987 | inconclusive |
| `fluent_bit_apache` | 0.937 | 0.895–0.955 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.901 | 0.873–0.908 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.991 | 0.974–1.028 | inconclusive |
| `mastodon_hashtag_regex_step` | 1.025 | 0.965–1.029 | inconclusive |
| `python_markdown_smart_emphasis_re` | 0.868 | 0.833–0.872 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.896 | 0.880–1.085 | inconclusive |
| `wordpress_shortcode_captures` | 1.013 | 0.973–1.023 | inconclusive |
| `symfony_grapheme_chunks_1` | 0.954 | 0.907–1.005 | inconclusive |
| `symfony_grapheme_chunks_2` | 0.998 | 0.962–1.044 | inconclusive |
| `literal_first` | 1.052 | 1.044–1.277 | inconclusive |
| `literal_middle` | 0.960 | 0.914–1.051 | inconclusive |
| `literal_end` | 1.071 | 0.947–1.180 | inconclusive |
| `literal_absent` | 1.026 | 0.999–1.177 | inconclusive |
| `ferrolink_markup_scan` | 0.997 | 0.961–1.044 | inconclusive |
| `ferrolink_attribute_split` | 0.995 | 0.974–1.023 | inconclusive |

## c / steady

Common cases: 27; families: 14. Pair-specific family-weighted ratio: 2.696.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 3.917 | 3.893–4.171 | Ferroni faster in every run interval |
| `uuid_v4` | 3.044 | 2.759–3.133 | Ferroni faster in every run interval |
| `ipv4_validation` | 6.130 | 5.883–7.328 | Ferroni faster in every run interval |
| `ipv6_validation` | 11.083 | 10.364–11.934 | Ferroni faster in every run interval |
| `semver_version_parse` | 1.398 | 1.346–1.474 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.121 | 1.065–1.136 | inconclusive |
| `jinja_string_token` | 1.127 | 1.115–1.175 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.020 | 1.005–1.083 | inconclusive |
| `jinja_float_token` | 1.066 | 1.037–1.132 | Ferroni faster in every run interval |
| `django_email_local_part` | 6.043 | 5.574–6.749 | Ferroni faster in every run interval |
| `django_email_domain` | 40.452 | 39.832–40.927 | Ferroni faster in every run interval |
| `django_url_regex` | 21.307 | 21.010–21.634 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.860 | 1.859–1.860 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 2.316 | 2.191–2.420 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.082 | 1.044–1.139 | Ferroni faster in every run interval |
| `mastodon_hashtag_regex_step` | 1.806 | 1.781–1.916 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 2.059 | 2.032–2.118 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 2.415 | 2.333–2.468 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 1.038 | 1.035–1.076 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_1` | 1.334 | 1.278–1.345 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_2` | 1.274 | 1.266–1.460 | Ferroni faster in every run interval |
| `literal_first` | 4.036 | 3.823–4.657 | Ferroni faster in every run interval |
| `literal_middle` | 4.833 | 4.542–5.022 | Ferroni faster in every run interval |
| `literal_end` | 5.492 | 5.371–6.418 | Ferroni faster in every run interval |
| `literal_absent` | 2.829 | 2.716–3.006 | Ferroni faster in every run interval |
| `ferrolink_markup_scan` | 1.864 | 1.802–2.006 | Ferroni faster in every run interval |
| `ferrolink_attribute_split` | 1.459 | 1.272–1.462 | Ferroni faster in every run interval |

## c / compile

Common cases: 27; families: 14. Pair-specific family-weighted ratio: 0.309.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 3.587 | 3.550–3.839 | Ferroni faster in every run interval |
| `uuid_v4` | 4.295 | 4.062–4.540 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.253 | 0.251–0.256 | comparator faster in every run interval |
| `ipv6_validation` | 0.234 | 0.231–0.240 | comparator faster in every run interval |
| `semver_version_parse` | 0.255 | 0.252–0.259 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.246 | 0.233–0.257 | comparator faster in every run interval |
| `jinja_string_token` | 0.138 | 0.132–0.143 | comparator faster in every run interval |
| `jinja_integer_token` | 2.358 | 2.219–2.430 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.489 | 0.486–0.512 | comparator faster in every run interval |
| `django_email_local_part` | 2.515 | 2.362–2.649 | Ferroni faster in every run interval |
| `django_email_domain` | 0.173 | 0.161–0.176 | comparator faster in every run interval |
| `django_url_regex` | 0.313 | 0.313–0.316 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.147 | 0.136–0.151 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.158 | 0.147–0.159 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.365 | 0.359–0.379 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.437 | 0.420–0.444 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.167 | 0.161–0.169 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.123 | 0.122–0.127 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.219 | 0.202–0.234 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.090 | 0.085–0.090 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.083 | 0.078–0.083 | comparator faster in every run interval |
| `literal_first` | 0.261 | 0.257–0.304 | comparator faster in every run interval |
| `literal_middle` | 0.265 | 0.246–0.296 | comparator faster in every run interval |
| `literal_end` | 0.290 | 0.226–0.308 | comparator faster in every run interval |
| `literal_absent` | 0.256 | 0.238–0.263 | comparator faster in every run interval |
| `ferrolink_markup_scan` | 0.176 | 0.174–0.177 | comparator faster in every run interval |
| `ferrolink_attribute_split` | 0.133 | 0.132–0.136 | comparator faster in every run interval |

## c / first_use

Common cases: 27; families: 14. Pair-specific family-weighted ratio: 0.343.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 2.798 | 2.695–2.923 | Ferroni faster in every run interval |
| `uuid_v4` | 3.396 | 3.195–3.413 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.237 | 0.235–0.256 | comparator faster in every run interval |
| `ipv6_validation` | 0.260 | 0.258–0.268 | comparator faster in every run interval |
| `semver_version_parse` | 0.268 | 0.266–0.271 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.249 | 0.248–0.252 | comparator faster in every run interval |
| `jinja_string_token` | 0.140 | 0.130–0.150 | comparator faster in every run interval |
| `jinja_integer_token` | 2.330 | 2.239–2.434 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.484 | 0.443–0.496 | comparator faster in every run interval |
| `django_email_local_part` | 2.371 | 2.195–2.489 | Ferroni faster in every run interval |
| `django_email_domain` | 0.204 | 0.189–0.207 | comparator faster in every run interval |
| `django_url_regex` | 0.334 | 0.327–0.334 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.157 | 0.155–0.177 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.174 | 0.161–0.174 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.389 | 0.373–0.391 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.417 | 0.383–0.433 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.188 | 0.186–0.194 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.143 | 0.134–0.145 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.229 | 0.226–0.242 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.183 | 0.182–0.190 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.149 | 0.148–0.151 | comparator faster in every run interval |
| `literal_first` | 0.402 | 0.369–0.503 | comparator faster in every run interval |
| `literal_middle` | 0.408 | 0.377–0.435 | comparator faster in every run interval |
| `literal_end` | 0.455 | 0.350–0.485 | comparator faster in every run interval |
| `literal_absent` | 0.316 | 0.310–0.350 | comparator faster in every run interval |
| `ferrolink_markup_scan` | 0.245 | 0.241–0.254 | comparator faster in every run interval |
| `ferrolink_attribute_split` | 0.149 | 0.141–0.149 | comparator faster in every run interval |

## onigmo / steady

Common cases: 26; families: 14. Pair-specific family-weighted ratio: 3.395.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 5.918 | 5.384–5.948 | Ferroni faster in every run interval |
| `uuid_v4` | 5.892 | 5.182–5.920 | Ferroni faster in every run interval |
| `ipv4_validation` | 5.699 | 5.559–5.712 | Ferroni faster in every run interval |
| `ipv6_validation` | 17.233 | 16.403–17.565 | Ferroni faster in every run interval |
| `semver_version_parse` | 1.773 | 1.728–1.833 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.204 | 1.173–1.274 | Ferroni faster in every run interval |
| `jinja_string_token` | 0.909 | 0.882–1.029 | inconclusive |
| `jinja_integer_token` | 1.304 | 1.298–1.373 | Ferroni faster in every run interval |
| `jinja_float_token` | 1.964 | 1.925–2.098 | Ferroni faster in every run interval |
| `django_email_local_part` | 4.881 | 4.707–5.197 | Ferroni faster in every run interval |
| `django_email_domain` | 70.138 | 69.129–71.380 | Ferroni faster in every run interval |
| `django_url_regex` | 56.986 | 53.411–58.156 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 2.335 | 2.325–2.457 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 3.231 | 2.956–3.303 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 0.941 | 0.934–0.961 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 2.034 | 1.965–2.099 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 2.119 | 2.101–2.138 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 2.500 | 2.448–2.606 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 1.187 | 1.179–1.198 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_2` | 3.102 | 3.040–3.157 | Ferroni faster in every run interval |
| `literal_first` | 1.804 | 1.773–1.896 | Ferroni faster in every run interval |
| `literal_middle` | 2.476 | 2.203–2.533 | Ferroni faster in every run interval |
| `literal_end` | 3.816 | 3.474–4.524 | Ferroni faster in every run interval |
| `literal_absent` | 2.692 | 2.599–2.724 | Ferroni faster in every run interval |
| `ferrolink_markup_scan` | 2.569 | 2.503–2.596 | Ferroni faster in every run interval |
| `ferrolink_attribute_split` | 1.487 | 1.477–1.501 | Ferroni faster in every run interval |

## onigmo / compile

Common cases: 26; families: 14. Pair-specific family-weighted ratio: 0.378.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 3.831 | 3.665–3.859 | Ferroni faster in every run interval |
| `uuid_v4` | 4.746 | 4.173–4.792 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.245 | 0.230–0.246 | comparator faster in every run interval |
| `ipv6_validation` | 0.240 | 0.233–0.243 | comparator faster in every run interval |
| `semver_version_parse` | 0.249 | 0.243–0.267 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.258 | 0.246–0.269 | comparator faster in every run interval |
| `jinja_string_token` | 0.121 | 0.119–0.125 | comparator faster in every run interval |
| `jinja_integer_token` | 2.092 | 1.956–2.261 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.558 | 0.528–0.559 | comparator faster in every run interval |
| `django_email_local_part` | 2.639 | 2.491–2.676 | Ferroni faster in every run interval |
| `django_email_domain` | 0.110 | 0.101–0.116 | comparator faster in every run interval |
| `django_url_regex` | 0.264 | 0.256–0.316 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.144 | 0.138–0.155 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.146 | 0.136–0.150 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.355 | 0.337–0.358 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.452 | 0.446–0.505 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.118 | 0.112–0.120 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.096 | 0.095–0.111 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.202 | 0.186–0.217 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 3.806 | 3.764–3.875 | Ferroni faster in every run interval |
| `literal_first` | 0.213 | 0.182–0.213 | comparator faster in every run interval |
| `literal_middle` | 0.209 | 0.181–0.210 | comparator faster in every run interval |
| `literal_end` | 0.220 | 0.197–0.224 | comparator faster in every run interval |
| `literal_absent` | 0.173 | 0.171–0.206 | comparator faster in every run interval |
| `ferrolink_markup_scan` | 0.169 | 0.168–0.173 | comparator faster in every run interval |
| `ferrolink_attribute_split` | 0.155 | 0.153–0.158 | comparator faster in every run interval |

## onigmo / first_use

Common cases: 26; families: 14. Pair-specific family-weighted ratio: 0.386.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 2.966 | 2.762–2.982 | Ferroni faster in every run interval |
| `uuid_v4` | 3.331 | 3.266–3.566 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.231 | 0.220–0.233 | comparator faster in every run interval |
| `ipv6_validation` | 0.247 | 0.245–0.265 | comparator faster in every run interval |
| `semver_version_parse` | 0.247 | 0.242–0.275 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.257 | 0.246–0.276 | comparator faster in every run interval |
| `jinja_string_token` | 0.118 | 0.117–0.131 | comparator faster in every run interval |
| `jinja_integer_token` | 1.908 | 1.826–1.955 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.537 | 0.504–0.571 | comparator faster in every run interval |
| `django_email_local_part` | 2.503 | 2.371–2.592 | Ferroni faster in every run interval |
| `django_email_domain` | 0.114 | 0.113–0.114 | comparator faster in every run interval |
| `django_url_regex` | 0.258 | 0.248–0.272 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.139 | 0.138–0.149 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.152 | 0.146–0.155 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.368 | 0.356–0.372 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.471 | 0.423–0.478 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.131 | 0.122–0.140 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.103 | 0.098–0.104 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.208 | 0.207–0.211 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 3.875 | 3.773–4.021 | Ferroni faster in every run interval |
| `literal_first` | 0.269 | 0.238–0.281 | comparator faster in every run interval |
| `literal_middle` | 0.251 | 0.239–0.305 | comparator faster in every run interval |
| `literal_end` | 0.290 | 0.260–0.310 | comparator faster in every run interval |
| `literal_absent` | 0.297 | 0.293–0.314 | comparator faster in every run interval |
| `ferrolink_markup_scan` | 0.232 | 0.226–0.232 | comparator faster in every run interval |
| `ferrolink_attribute_split` | 0.165 | 0.163–0.178 | comparator faster in every run interval |

## pcre2_jit / steady

Common cases: 27; families: 14. Pair-specific family-weighted ratio: 0.645.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.882 | 0.805–0.884 | comparator faster in every run interval |
| `uuid_v4` | 1.020 | 0.930–1.049 | inconclusive |
| `ipv4_validation` | 1.447 | 1.446–1.510 | Ferroni faster in every run interval |
| `ipv6_validation` | 2.988 | 2.767–3.029 | Ferroni faster in every run interval |
| `semver_version_parse` | 0.419 | 0.418–0.435 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.439 | 0.383–0.451 | comparator faster in every run interval |
| `jinja_string_token` | 0.487 | 0.487–0.496 | comparator faster in every run interval |
| `jinja_integer_token` | 0.489 | 0.464–0.516 | comparator faster in every run interval |
| `jinja_float_token` | 0.538 | 0.521–0.576 | comparator faster in every run interval |
| `django_email_local_part` | 1.759 | 1.662–1.815 | Ferroni faster in every run interval |
| `django_email_domain` | 0.809 | 0.779–0.838 | comparator faster in every run interval |
| `django_url_regex` | 1.305 | 1.268–1.407 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 0.428 | 0.427–0.440 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.510 | 0.501–0.525 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.351 | 0.332–0.353 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.329 | 0.304–0.339 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.601 | 0.598–0.604 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.524 | 0.495–0.527 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.391 | 0.386–0.394 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.564 | 0.535–0.571 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.527 | 0.522–0.543 | comparator faster in every run interval |
| `literal_first` | 1.437 | 1.376–1.440 | Ferroni faster in every run interval |
| `literal_middle` | 1.384 | 1.368–1.389 | Ferroni faster in every run interval |
| `literal_end` | 1.434 | 1.259–1.471 | Ferroni faster in every run interval |
| `literal_absent` | 1.168 | 1.163–1.223 | Ferroni faster in every run interval |
| `ferrolink_markup_scan` | 0.305 | 0.302–0.317 | comparator faster in every run interval |
| `ferrolink_attribute_split` | 0.454 | 0.442–0.456 | comparator faster in every run interval |

## pcre2_jit / compile

Common cases: 27; families: 14. Pair-specific family-weighted ratio: 0.285.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.229 | 0.227–0.241 | comparator faster in every run interval |
| `uuid_v4` | 0.240 | 0.234–0.255 | comparator faster in every run interval |
| `ipv4_validation` | 0.275 | 0.270–0.278 | comparator faster in every run interval |
| `ipv6_validation` | 0.250 | 0.235–0.267 | comparator faster in every run interval |
| `semver_version_parse` | 0.351 | 0.332–0.380 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.315 | 0.262–0.317 | comparator faster in every run interval |
| `jinja_string_token` | 0.272 | 0.267–0.275 | comparator faster in every run interval |
| `jinja_integer_token` | 0.298 | 0.289–0.305 | comparator faster in every run interval |
| `jinja_float_token` | 0.217 | 0.209–0.220 | comparator faster in every run interval |
| `django_email_local_part` | 0.299 | 0.292–0.347 | comparator faster in every run interval |
| `django_email_domain` | 0.032 | 0.030–0.033 | comparator faster in every run interval |
| `django_url_regex` | 0.038 | 0.037–0.041 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.234 | 0.230–0.243 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.250 | 0.238–0.251 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.787 | 0.766–0.806 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.150 | 0.135–0.155 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.520 | 0.500–0.522 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.379 | 0.357–0.416 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.358 | 0.336–0.359 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.317 | 0.304–0.334 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.295 | 0.289–0.298 | comparator faster in every run interval |
| `literal_first` | 3.003 | 2.926–3.181 | Ferroni faster in every run interval |
| `literal_middle` | 3.138 | 2.981–3.251 | Ferroni faster in every run interval |
| `literal_end` | 3.141 | 2.840–3.894 | Ferroni faster in every run interval |
| `literal_absent` | 2.858 | 2.805–2.874 | Ferroni faster in every run interval |
| `ferrolink_markup_scan` | 0.235 | 0.231–0.241 | comparator faster in every run interval |
| `ferrolink_attribute_split` | 0.354 | 0.332–0.368 | comparator faster in every run interval |

## pcre2_jit / first_use

Common cases: 27; families: 14. Pair-specific family-weighted ratio: 0.312.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.190 | 0.183–0.197 | comparator faster in every run interval |
| `uuid_v4` | 0.201 | 0.184–0.211 | comparator faster in every run interval |
| `ipv4_validation` | 0.295 | 0.291–0.311 | comparator faster in every run interval |
| `ipv6_validation` | 0.261 | 0.235–0.270 | comparator faster in every run interval |
| `semver_version_parse` | 0.366 | 0.350–0.379 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.298 | 0.289–0.321 | comparator faster in every run interval |
| `jinja_string_token` | 0.311 | 0.310–0.349 | comparator faster in every run interval |
| `jinja_integer_token` | 0.317 | 0.293–0.329 | comparator faster in every run interval |
| `jinja_float_token` | 0.240 | 0.217–0.246 | comparator faster in every run interval |
| `django_email_local_part` | 0.348 | 0.329–0.363 | comparator faster in every run interval |
| `django_email_domain` | 0.034 | 0.033–0.034 | comparator faster in every run interval |
| `django_url_regex` | 0.041 | 0.038–0.042 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.256 | 0.250–0.275 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.254 | 0.251–0.259 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.985 | 0.911–0.989 | inconclusive |
| `mastodon_hashtag_regex_step` | 0.163 | 0.139–0.182 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.554 | 0.534–0.556 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.438 | 0.410–0.454 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.380 | 0.372–0.402 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.513 | 0.477–0.554 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.431 | 0.430–0.456 | comparator faster in every run interval |
| `literal_first` | 3.077 | 2.980–3.187 | Ferroni faster in every run interval |
| `literal_middle` | 2.771 | 2.684–3.530 | Ferroni faster in every run interval |
| `literal_end` | 2.797 | 2.493–3.436 | Ferroni faster in every run interval |
| `literal_absent` | 3.120 | 2.982–3.146 | Ferroni faster in every run interval |
| `ferrolink_markup_scan` | 0.295 | 0.275–0.317 | comparator faster in every run interval |
| `ferrolink_attribute_split` | 0.394 | 0.391–0.405 | comparator faster in every run interval |

## pcre2 / steady

Common cases: 27; families: 14. Pair-specific family-weighted ratio: 1.830.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.641 | 1.554–1.663 | Ferroni faster in every run interval |
| `uuid_v4` | 1.820 | 1.740–1.942 | Ferroni faster in every run interval |
| `ipv4_validation` | 8.285 | 8.102–8.438 | Ferroni faster in every run interval |
| `ipv6_validation` | 17.755 | 17.171–17.852 | Ferroni faster in every run interval |
| `semver_version_parse` | 1.318 | 1.255–1.327 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.765 | 1.468–1.795 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.009 | 0.972–1.037 | inconclusive |
| `jinja_integer_token` | 1.601 | 1.552–1.669 | Ferroni faster in every run interval |
| `jinja_float_token` | 1.665 | 1.595–1.795 | Ferroni faster in every run interval |
| `django_email_local_part` | 5.109 | 5.103–5.376 | Ferroni faster in every run interval |
| `django_email_domain` | 2.766 | 2.722–2.873 | Ferroni faster in every run interval |
| `django_url_regex` | 3.786 | 3.689–3.865 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.422 | 1.412–1.507 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.758 | 1.718–1.769 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.032 | 1.022–1.054 | inconclusive |
| `mastodon_hashtag_regex_step` | 0.732 | 0.730–0.801 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 2.890 | 2.865–2.906 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 4.112 | 4.060–4.209 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 1.137 | 1.114–1.163 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.800 | 0.764–0.819 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.732 | 0.727–0.758 | comparator faster in every run interval |
| `literal_first` | 2.549 | 2.433–2.580 | Ferroni faster in every run interval |
| `literal_middle` | 2.580 | 2.383–2.590 | Ferroni faster in every run interval |
| `literal_end` | 2.361 | 2.304–2.413 | Ferroni faster in every run interval |
| `literal_absent` | 1.314 | 1.212–1.324 | Ferroni faster in every run interval |
| `ferrolink_markup_scan` | 0.942 | 0.936–0.947 | comparator faster in every run interval |
| `ferrolink_attribute_split` | 1.028 | 1.010–1.049 | inconclusive |

## pcre2 / compile

Common cases: 27; families: 14. Pair-specific family-weighted ratio: 0.068.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.071 | 0.070–0.073 | comparator faster in every run interval |
| `uuid_v4` | 0.078 | 0.076–0.087 | comparator faster in every run interval |
| `ipv4_validation` | 0.075 | 0.072–0.083 | comparator faster in every run interval |
| `ipv6_validation` | 0.078 | 0.075–0.078 | comparator faster in every run interval |
| `semver_version_parse` | 0.087 | 0.078–0.089 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.074 | 0.064–0.078 | comparator faster in every run interval |
| `jinja_string_token` | 0.047 | 0.047–0.048 | comparator faster in every run interval |
| `jinja_integer_token` | 0.073 | 0.072–0.076 | comparator faster in every run interval |
| `jinja_float_token` | 0.036 | 0.035–0.036 | comparator faster in every run interval |
| `django_email_local_part` | 0.121 | 0.120–0.122 | comparator faster in every run interval |
| `django_email_domain` | 0.029 | 0.029–0.031 | comparator faster in every run interval |
| `django_url_regex` | 0.030 | 0.029–0.032 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.041 | 0.040–0.045 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.044 | 0.044–0.046 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.227 | 0.208–0.228 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.075 | 0.073–0.076 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.063 | 0.062–0.064 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.048 | 0.045–0.057 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.084 | 0.081–0.084 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.031 | 0.030–0.033 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.029 | 0.028–0.030 | comparator faster in every run interval |
| `literal_first` | 0.157 | 0.150–0.158 | comparator faster in every run interval |
| `literal_middle` | 0.170 | 0.154–0.193 | comparator faster in every run interval |
| `literal_end` | 0.167 | 0.146–0.182 | comparator faster in every run interval |
| `literal_absent` | 0.152 | 0.139–0.164 | comparator faster in every run interval |
| `ferrolink_markup_scan` | 0.044 | 0.044–0.044 | comparator faster in every run interval |
| `ferrolink_attribute_split` | 0.107 | 0.105–0.116 | comparator faster in every run interval |

## pcre2 / first_use

Common cases: 27; families: 14. Pair-specific family-weighted ratio: 0.115.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.092 | 0.084–0.099 | comparator faster in every run interval |
| `uuid_v4` | 0.100 | 0.089–0.105 | comparator faster in every run interval |
| `ipv4_validation` | 0.114 | 0.105–0.118 | comparator faster in every run interval |
| `ipv6_validation` | 0.078 | 0.076–0.083 | comparator faster in every run interval |
| `semver_version_parse` | 0.109 | 0.102–0.117 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.089 | 0.068–0.096 | comparator faster in every run interval |
| `jinja_string_token` | 0.089 | 0.078–0.091 | comparator faster in every run interval |
| `jinja_integer_token` | 0.101 | 0.095–0.103 | comparator faster in every run interval |
| `jinja_float_token` | 0.054 | 0.051–0.059 | comparator faster in every run interval |
| `django_email_local_part` | 0.146 | 0.144–0.154 | comparator faster in every run interval |
| `django_email_domain` | 0.030 | 0.030–0.031 | comparator faster in every run interval |
| `django_url_regex` | 0.030 | 0.029–0.030 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.079 | 0.077–0.079 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.076 | 0.074–0.086 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.327 | 0.309–0.345 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.082 | 0.081–0.085 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.147 | 0.140–0.153 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.109 | 0.105–0.111 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.111 | 0.104–0.123 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.176 | 0.165–0.180 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.150 | 0.149–0.155 | comparator faster in every run interval |
| `literal_first` | 0.930 | 0.911–0.969 | inconclusive |
| `literal_middle` | 0.856 | 0.831–0.968 | inconclusive |
| `literal_end` | 0.813 | 0.711–1.003 | inconclusive |
| `literal_absent` | 0.826 | 0.819–0.890 | inconclusive |
| `ferrolink_markup_scan` | 0.098 | 0.094–0.099 | comparator faster in every run interval |
| `ferrolink_attribute_split` | 0.148 | 0.139–0.160 | comparator faster in every run interval |

## fancy_regex / steady

Common cases: 23; families: 12. Pair-specific family-weighted ratio: 2.770.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.204 | 1.164–1.257 | Ferroni faster in every run interval |
| `uuid_v4` | 1.199 | 1.163–1.320 | Ferroni faster in every run interval |
| `ipv4_validation` | 1.307 | 1.303–1.333 | Ferroni faster in every run interval |
| `ipv6_validation` | 1.378 | 1.362–1.379 | Ferroni faster in every run interval |
| `semver_version_parse` | 2.112 | 2.069–2.192 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.811 | 1.449–1.846 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.145 | 1.129–1.147 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.476 | 1.439–1.579 | Ferroni faster in every run interval |
| `jinja_float_token` | 2.671 | 2.553–2.700 | Ferroni faster in every run interval |
| `django_email_domain` | 9.990 | 9.634–10.066 | Ferroni faster in every run interval |
| `django_url_regex` | 27.330 | 27.255–28.139 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.690 | 1.674–1.746 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 2.020 | 1.938–2.113 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 3.187 | 3.133–3.235 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 2.927 | 2.879–3.031 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 4.622 | 4.524–4.785 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 1.945 | 1.889–1.965 | Ferroni faster in every run interval |
| `literal_first` | 1.208 | 1.158–1.238 | Ferroni faster in every run interval |
| `literal_middle` | 1.140 | 1.125–1.165 | Ferroni faster in every run interval |
| `literal_end` | 1.148 | 1.135–1.174 | Ferroni faster in every run interval |
| `literal_absent` | 1.168 | 1.119–1.237 | Ferroni faster in every run interval |
| `ferrolink_markup_scan` | 4.687 | 4.476–4.713 | Ferroni faster in every run interval |
| `ferrolink_attribute_split` | 1.814 | 1.774–2.148 | Ferroni faster in every run interval |

## fancy_regex / compile

Common cases: 23; families: 12. Pair-specific family-weighted ratio: 1.443.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.915 | 0.911–0.926 | comparator faster in every run interval |
| `uuid_v4` | 0.959 | 0.909–1.019 | inconclusive |
| `ipv4_validation` | 0.802 | 0.796–0.816 | comparator faster in every run interval |
| `ipv6_validation` | 0.901 | 0.854–0.916 | comparator faster in every run interval |
| `semver_version_parse` | 14.442 | 13.456–14.775 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 9.522 | 8.055–9.927 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.710 | 1.653–1.725 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.865 | 1.862–1.971 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.257 | 0.254–0.258 | comparator faster in every run interval |
| `django_email_domain` | 1.947 | 1.721–2.026 | Ferroni faster in every run interval |
| `django_url_regex` | 1.702 | 1.683–1.720 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.378 | 1.332–1.429 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.447 | 1.373–1.480 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.258 | 1.199–1.307 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.517 | 0.503–0.566 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.437 | 0.402–0.438 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 1.013 | 0.943–1.067 | inconclusive |
| `literal_first` | 1.179 | 1.127–1.209 | Ferroni faster in every run interval |
| `literal_middle` | 1.193 | 1.109–1.336 | Ferroni faster in every run interval |
| `literal_end` | 1.372 | 1.257–1.406 | Ferroni faster in every run interval |
| `literal_absent` | 1.157 | 1.150–1.278 | Ferroni faster in every run interval |
| `ferrolink_markup_scan` | 2.463 | 2.449–2.507 | Ferroni faster in every run interval |
| `ferrolink_attribute_split` | 2.922 | 2.780–3.242 | Ferroni faster in every run interval |

## fancy_regex / first_use

Common cases: 23; families: 12. Pair-specific family-weighted ratio: 1.487.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.984 | 0.918–0.988 | inconclusive |
| `uuid_v4` | 1.015 | 1.000–1.061 | inconclusive |
| `ipv4_validation` | 0.848 | 0.806–0.858 | comparator faster in every run interval |
| `ipv6_validation` | 0.926 | 0.866–0.951 | comparator faster in every run interval |
| `semver_version_parse` | 14.235 | 14.211–14.396 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 9.184 | 7.285–9.203 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.582 | 1.558–1.619 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.875 | 1.789–1.965 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.255 | 0.249–0.258 | comparator faster in every run interval |
| `django_email_domain` | 2.001 | 1.818–2.073 | Ferroni faster in every run interval |
| `django_url_regex` | 1.663 | 1.647–1.693 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.452 | 1.385–1.482 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.415 | 1.400–1.501 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.396 | 1.382–1.399 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.490 | 0.488–0.513 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.412 | 0.397–0.426 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 1.091 | 1.052–1.143 | Ferroni faster in every run interval |
| `literal_first` | 1.248 | 1.173–1.256 | Ferroni faster in every run interval |
| `literal_middle` | 1.151 | 1.061–1.380 | Ferroni faster in every run interval |
| `literal_end` | 1.374 | 1.098–1.470 | Ferroni faster in every run interval |
| `literal_absent` | 1.322 | 1.261–1.352 | Ferroni faster in every run interval |
| `ferrolink_markup_scan` | 2.888 | 2.717–3.032 | Ferroni faster in every run interval |
| `ferrolink_attribute_split` | 3.256 | 3.172–3.378 | Ferroni faster in every run interval |

## fancy_regex_seek / steady

Common cases: 23; families: 12. Pair-specific family-weighted ratio: 2.745.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.198 | 1.184–1.249 | Ferroni faster in every run interval |
| `uuid_v4` | 1.232 | 1.083–1.286 | Ferroni faster in every run interval |
| `ipv4_validation` | 1.310 | 1.298–1.323 | Ferroni faster in every run interval |
| `ipv6_validation` | 1.370 | 1.352–1.401 | Ferroni faster in every run interval |
| `semver_version_parse` | 2.125 | 2.102–2.226 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.738 | 1.476–1.777 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.134 | 1.127–1.178 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.490 | 1.428–1.531 | Ferroni faster in every run interval |
| `jinja_float_token` | 2.717 | 2.547–2.834 | Ferroni faster in every run interval |
| `django_email_domain` | 9.807 | 9.482–9.818 | Ferroni faster in every run interval |
| `django_url_regex` | 27.205 | 26.931–28.899 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.672 | 1.651–1.683 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 2.018 | 1.955–2.033 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 3.193 | 3.124–3.528 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 2.915 | 2.907–2.993 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 4.879 | 4.679–4.948 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 2.039 | 2.001–2.152 | Ferroni faster in every run interval |
| `literal_first` | 1.171 | 1.147–1.230 | Ferroni faster in every run interval |
| `literal_middle` | 1.143 | 1.101–1.164 | Ferroni faster in every run interval |
| `literal_end` | 1.175 | 1.112–1.184 | Ferroni faster in every run interval |
| `literal_absent` | 1.174 | 1.118–1.202 | Ferroni faster in every run interval |
| `ferrolink_markup_scan` | 2.898 | 2.855–2.960 | Ferroni faster in every run interval |
| `ferrolink_attribute_split` | 2.168 | 2.102–2.232 | Ferroni faster in every run interval |

## fancy_regex_seek / compile

Common cases: 23; families: 12. Pair-specific family-weighted ratio: 1.633.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.928 | 0.892–1.000 | inconclusive |
| `uuid_v4` | 0.946 | 0.886–1.019 | inconclusive |
| `ipv4_validation` | 0.812 | 0.772–0.859 | comparator faster in every run interval |
| `ipv6_validation` | 0.920 | 0.889–0.937 | comparator faster in every run interval |
| `semver_version_parse` | 13.743 | 13.433–15.150 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 9.370 | 7.987–10.056 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.717 | 1.668–1.717 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.886 | 1.845–1.959 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.250 | 0.248–0.268 | comparator faster in every run interval |
| `django_email_domain` | 1.919 | 1.735–2.014 | Ferroni faster in every run interval |
| `django_url_regex` | 1.703 | 1.685–1.798 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.383 | 1.382–1.429 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.422 | 1.378–1.452 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.237 | 1.196–1.259 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.541 | 0.495–0.545 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.402 | 0.392–0.433 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 3.184 | 3.000–3.371 | Ferroni faster in every run interval |
| `literal_first` | 1.179 | 1.129–1.209 | Ferroni faster in every run interval |
| `literal_middle` | 1.171 | 1.054–1.253 | inconclusive |
| `literal_end` | 1.264 | 1.197–1.328 | Ferroni faster in every run interval |
| `literal_absent` | 1.173 | 1.081–1.193 | Ferroni faster in every run interval |
| `ferrolink_markup_scan` | 3.756 | 3.605–3.761 | Ferroni faster in every run interval |
| `ferrolink_attribute_split` | 4.628 | 4.511–4.918 | Ferroni faster in every run interval |

## fancy_regex_seek / first_use

Common cases: 23; families: 12. Pair-specific family-weighted ratio: 1.723.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.984 | 0.898–1.012 | inconclusive |
| `uuid_v4` | 0.986 | 0.973–1.018 | inconclusive |
| `ipv4_validation` | 0.850 | 0.841–0.862 | comparator faster in every run interval |
| `ipv6_validation` | 0.936 | 0.907–0.983 | inconclusive |
| `semver_version_parse` | 14.172 | 13.663–14.186 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 9.251 | 6.961–9.595 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.631 | 1.498–1.766 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.883 | 1.845–1.949 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.253 | 0.253–0.268 | comparator faster in every run interval |
| `django_email_domain` | 2.009 | 1.862–2.174 | Ferroni faster in every run interval |
| `django_url_regex` | 1.807 | 1.664–1.823 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.407 | 1.331–1.462 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.434 | 1.424–1.450 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.400 | 1.395–1.406 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.490 | 0.477–0.492 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.408 | 0.377–0.435 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 3.806 | 3.627–3.846 | Ferroni faster in every run interval |
| `literal_first` | 1.242 | 1.222–1.302 | Ferroni faster in every run interval |
| `literal_middle` | 1.170 | 1.060–1.370 | Ferroni faster in every run interval |
| `literal_end` | 1.174 | 1.118–1.416 | Ferroni faster in every run interval |
| `literal_absent` | 1.253 | 1.252–1.336 | Ferroni faster in every run interval |
| `ferrolink_markup_scan` | 4.794 | 4.549–4.863 | Ferroni faster in every run interval |
| `ferrolink_attribute_split` | 5.160 | 5.141–5.749 | Ferroni faster in every run interval |

## regex / steady

Common cases: 15; families: 7. Pair-specific family-weighted ratio: 1.396.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.448 | 1.376–1.458 | Ferroni faster in every run interval |
| `uuid_v4` | 1.488 | 1.343–1.545 | Ferroni faster in every run interval |
| `ipv4_validation` | 1.551 | 1.531–1.580 | Ferroni faster in every run interval |
| `ipv6_validation` | 1.671 | 1.665–1.683 | Ferroni faster in every run interval |
| `semver_version_parse` | 1.906 | 1.837–1.980 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.405 | 1.191–1.468 | Ferroni faster in every run interval |
| `jinja_string_token` | 0.677 | 0.671–0.726 | comparator faster in every run interval |
| `jinja_integer_token` | 1.107 | 1.078–1.182 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.502 | 1.496–1.536 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.869 | 1.835–1.910 | Ferroni faster in every run interval |
| `literal_first` | 1.031 | 1.011–1.043 | inconclusive |
| `literal_middle` | 1.001 | 0.981–1.015 | inconclusive |
| `literal_end` | 0.981 | 0.975–1.029 | inconclusive |
| `literal_absent` | 1.024 | 1.000–1.055 | inconclusive |
| `ferrolink_attribute_split` | 1.821 | 1.753–1.830 | Ferroni faster in every run interval |

## regex / compile

Common cases: 15; families: 7. Pair-specific family-weighted ratio: 1.646.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.744 | 0.727–0.780 | comparator faster in every run interval |
| `uuid_v4` | 0.710 | 0.659–0.758 | comparator faster in every run interval |
| `ipv4_validation` | 0.725 | 0.709–0.745 | comparator faster in every run interval |
| `ipv6_validation` | 0.805 | 0.797–0.810 | comparator faster in every run interval |
| `semver_version_parse` | 14.100 | 13.385–14.765 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 9.147 | 8.366–9.663 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.643 | 1.592–1.694 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.679 | 1.652–1.704 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.342 | 1.277–1.348 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.407 | 1.361–1.432 | Ferroni faster in every run interval |
| `literal_first` | 1.163 | 1.160–1.165 | Ferroni faster in every run interval |
| `literal_middle` | 1.159 | 1.101–1.330 | Ferroni faster in every run interval |
| `literal_end` | 1.354 | 1.336–1.411 | Ferroni faster in every run interval |
| `literal_absent` | 1.161 | 1.143–1.198 | Ferroni faster in every run interval |
| `ferrolink_attribute_split` | 1.885 | 1.694–1.892 | Ferroni faster in every run interval |

## regex / first_use

Common cases: 15; families: 7. Pair-specific family-weighted ratio: 1.706.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.791 | 0.742–0.819 | comparator faster in every run interval |
| `uuid_v4` | 0.781 | 0.780–0.796 | comparator faster in every run interval |
| `ipv4_validation` | 0.758 | 0.727–0.801 | comparator faster in every run interval |
| `ipv6_validation` | 0.822 | 0.817–0.833 | comparator faster in every run interval |
| `semver_version_parse` | 14.369 | 13.766–14.405 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 8.793 | 7.035–8.936 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.545 | 1.539–1.607 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.670 | 1.626–1.713 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.363 | 1.309–1.387 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.412 | 1.406–1.415 | Ferroni faster in every run interval |
| `literal_first` | 1.268 | 1.243–1.346 | Ferroni faster in every run interval |
| `literal_middle` | 1.145 | 1.118–1.431 | Ferroni faster in every run interval |
| `literal_end` | 1.227 | 1.169–1.396 | Ferroni faster in every run interval |
| `literal_absent` | 1.299 | 1.278–1.346 | Ferroni faster in every run interval |
| `ferrolink_attribute_split` | 2.189 | 2.140–2.194 | Ferroni faster in every run interval |

Raw samples, estimates, confidence intervals, failures, eligibility reasons, corpus snapshot and execution order are retained beside this report.

Memory, where requested, is fresh-process peak RSS including the binary, runtime, parsed catalog, compilation, input/output and allocator. It is not isolated compiled-pattern memory.
