# Production regex comparison

Host: Linux-6.6.141-x86_64-with-glibc2.39; x86_64.

Publication candidate: review host stability, raw samples, coverage and run intervals before publishing.

Ratios are comparator / Ferroni. Compile and first-use times concern one pattern; steady times concern the complete fixture batch.

Each comparison below uses only its explicitly listed common tasks. Families have equal aggregate weight; architectures are never combined.

## Eligibility

| Case | Engine | Status |
| --- | --- | --- |
| `uuid_shape` | rust | eligible |
| `uuid_shape` | rust_erroraware | eligible |
| `uuid_shape` | c | eligible |
| `uuid_shape` | onigmo | eligible |
| `uuid_shape` | pcre2_jit | eligible |
| `uuid_shape` | pcre2 | eligible |
| `uuid_shape` | fancy_regex | eligible |
| `uuid_shape` | fancy_regex_seek | eligible |
| `uuid_shape` | regex | eligible |
| `uuid_v4` | rust | eligible |
| `uuid_v4` | rust_erroraware | eligible |
| `uuid_v4` | c | eligible |
| `uuid_v4` | onigmo | eligible |
| `uuid_v4` | pcre2_jit | eligible |
| `uuid_v4` | pcre2 | eligible |
| `uuid_v4` | fancy_regex | eligible |
| `uuid_v4` | fancy_regex_seek | eligible |
| `uuid_v4` | regex | eligible |
| `ipv4_validation` | rust | eligible |
| `ipv4_validation` | rust_erroraware | eligible |
| `ipv4_validation` | c | eligible |
| `ipv4_validation` | onigmo | eligible |
| `ipv4_validation` | pcre2_jit | eligible |
| `ipv4_validation` | pcre2 | eligible |
| `ipv4_validation` | fancy_regex | eligible |
| `ipv4_validation` | fancy_regex_seek | eligible |
| `ipv4_validation` | regex | eligible |
| `ipv6_validation` | rust | eligible |
| `ipv6_validation` | rust_erroraware | eligible |
| `ipv6_validation` | c | eligible |
| `ipv6_validation` | onigmo | eligible |
| `ipv6_validation` | pcre2_jit | eligible |
| `ipv6_validation` | pcre2 | eligible |
| `ipv6_validation` | fancy_regex | eligible |
| `ipv6_validation` | fancy_regex_seek | eligible |
| `ipv6_validation` | regex | eligible |
| `semver_version_parse` | rust | eligible |
| `semver_version_parse` | rust_erroraware | eligible |
| `semver_version_parse` | c | eligible |
| `semver_version_parse` | onigmo | eligible |
| `semver_version_parse` | pcre2_jit | eligible |
| `semver_version_parse` | pcre2 | eligible |
| `semver_version_parse` | fancy_regex | eligible |
| `semver_version_parse` | fancy_regex_seek | eligible |
| `semver_version_parse` | regex | eligible |
| `semver_hyphen_range_captures` | rust | eligible |
| `semver_hyphen_range_captures` | rust_erroraware | eligible |
| `semver_hyphen_range_captures` | c | eligible |
| `semver_hyphen_range_captures` | onigmo | eligible |
| `semver_hyphen_range_captures` | pcre2_jit | eligible |
| `semver_hyphen_range_captures` | pcre2 | eligible |
| `semver_hyphen_range_captures` | fancy_regex | eligible |
| `semver_hyphen_range_captures` | fancy_regex_seek | eligible |
| `semver_hyphen_range_captures` | regex | eligible |
| `jinja_string_token` | rust | eligible |
| `jinja_string_token` | rust_erroraware | eligible |
| `jinja_string_token` | c | eligible |
| `jinja_string_token` | onigmo | eligible |
| `jinja_string_token` | pcre2_jit | eligible |
| `jinja_string_token` | pcre2 | eligible |
| `jinja_string_token` | fancy_regex | eligible |
| `jinja_string_token` | fancy_regex_seek | eligible |
| `jinja_string_token` | regex | eligible |
| `jinja_integer_token` | rust | eligible |
| `jinja_integer_token` | rust_erroraware | eligible |
| `jinja_integer_token` | c | eligible |
| `jinja_integer_token` | onigmo | eligible |
| `jinja_integer_token` | pcre2_jit | eligible |
| `jinja_integer_token` | pcre2 | eligible |
| `jinja_integer_token` | fancy_regex | eligible |
| `jinja_integer_token` | fancy_regex_seek | eligible |
| `jinja_integer_token` | regex | eligible |
| `jinja_float_token` | rust | eligible |
| `jinja_float_token` | rust_erroraware | eligible |
| `jinja_float_token` | c | eligible |
| `jinja_float_token` | onigmo | eligible |
| `jinja_float_token` | pcre2_jit | eligible |
| `jinja_float_token` | pcre2 | eligible |
| `jinja_float_token` | fancy_regex | eligible |
| `jinja_float_token` | fancy_regex_seek | eligible |
| `jinja_float_token` | regex | syntax_rejected |
| `django_email_local_part` | rust | eligible |
| `django_email_local_part` | rust_erroraware | eligible |
| `django_email_local_part` | c | eligible |
| `django_email_local_part` | onigmo | eligible |
| `django_email_local_part` | pcre2_jit | eligible |
| `django_email_local_part` | pcre2 | eligible |
| `django_email_local_part` | fancy_regex | syntax_rejected |
| `django_email_local_part` | fancy_regex_seek | syntax_rejected |
| `django_email_local_part` | regex | syntax_rejected |
| `django_email_domain` | rust | eligible |
| `django_email_domain` | rust_erroraware | eligible |
| `django_email_domain` | c | eligible |
| `django_email_domain` | onigmo | eligible |
| `django_email_domain` | pcre2_jit | eligible |
| `django_email_domain` | pcre2 | eligible |
| `django_email_domain` | fancy_regex | eligible |
| `django_email_domain` | fancy_regex_seek | eligible |
| `django_email_domain` | regex | syntax_rejected |
| `django_url_regex` | rust | eligible |
| `django_url_regex` | rust_erroraware | eligible |
| `django_url_regex` | c | eligible |
| `django_url_regex` | onigmo | eligible |
| `django_url_regex` | pcre2_jit | eligible |
| `django_url_regex` | pcre2 | eligible |
| `django_url_regex` | fancy_regex | eligible |
| `django_url_regex` | fancy_regex_seek | eligible |
| `django_url_regex` | regex | syntax_rejected |
| `fluent_bit_apache` | rust | eligible |
| `fluent_bit_apache` | rust_erroraware | eligible |
| `fluent_bit_apache` | c | eligible |
| `fluent_bit_apache` | onigmo | eligible |
| `fluent_bit_apache` | pcre2_jit | eligible |
| `fluent_bit_apache` | pcre2 | eligible |
| `fluent_bit_apache` | fancy_regex | eligible |
| `fluent_bit_apache` | fancy_regex_seek | eligible |
| `fluent_bit_apache` | regex | eligible |
| `fluent_bit_nginx` | rust | eligible |
| `fluent_bit_nginx` | rust_erroraware | eligible |
| `fluent_bit_nginx` | c | eligible |
| `fluent_bit_nginx` | onigmo | eligible |
| `fluent_bit_nginx` | pcre2_jit | eligible |
| `fluent_bit_nginx` | pcre2 | eligible |
| `fluent_bit_nginx` | fancy_regex | eligible |
| `fluent_bit_nginx` | fancy_regex_seek | eligible |
| `fluent_bit_nginx` | regex | eligible |
| `rails_underscore_regex_step` | rust | eligible |
| `rails_underscore_regex_step` | rust_erroraware | eligible |
| `rails_underscore_regex_step` | c | eligible |
| `rails_underscore_regex_step` | onigmo | eligible |
| `rails_underscore_regex_step` | pcre2_jit | eligible |
| `rails_underscore_regex_step` | pcre2 | eligible |
| `rails_underscore_regex_step` | fancy_regex | eligible |
| `rails_underscore_regex_step` | fancy_regex_seek | eligible |
| `rails_underscore_regex_step` | regex | syntax_rejected |
| `mastodon_hashtag_regex_step` | rust | eligible |
| `mastodon_hashtag_regex_step` | rust_erroraware | eligible |
| `mastodon_hashtag_regex_step` | c | eligible |
| `mastodon_hashtag_regex_step` | onigmo | eligible |
| `mastodon_hashtag_regex_step` | pcre2_jit | eligible |
| `mastodon_hashtag_regex_step` | pcre2 | eligible |
| `mastodon_hashtag_regex_step` | fancy_regex | semantic_difference |
| `mastodon_hashtag_regex_step` | fancy_regex_seek | semantic_difference |
| `mastodon_hashtag_regex_step` | regex | syntax_rejected |
| `python_markdown_smart_emphasis_re` | rust | eligible |
| `python_markdown_smart_emphasis_re` | rust_erroraware | eligible |
| `python_markdown_smart_emphasis_re` | c | eligible |
| `python_markdown_smart_emphasis_re` | onigmo | eligible |
| `python_markdown_smart_emphasis_re` | pcre2_jit | eligible |
| `python_markdown_smart_emphasis_re` | pcre2 | eligible |
| `python_markdown_smart_emphasis_re` | fancy_regex | eligible |
| `python_markdown_smart_emphasis_re` | fancy_regex_seek | eligible |
| `python_markdown_smart_emphasis_re` | regex | syntax_rejected |
| `python_markdown_smart_strong_em_re` | rust | eligible |
| `python_markdown_smart_strong_em_re` | rust_erroraware | eligible |
| `python_markdown_smart_strong_em_re` | c | eligible |
| `python_markdown_smart_strong_em_re` | onigmo | eligible |
| `python_markdown_smart_strong_em_re` | pcre2_jit | eligible |
| `python_markdown_smart_strong_em_re` | pcre2 | eligible |
| `python_markdown_smart_strong_em_re` | fancy_regex | eligible |
| `python_markdown_smart_strong_em_re` | fancy_regex_seek | eligible |
| `python_markdown_smart_strong_em_re` | regex | syntax_rejected |
| `wordpress_shortcode_captures` | rust | eligible |
| `wordpress_shortcode_captures` | rust_erroraware | eligible |
| `wordpress_shortcode_captures` | c | eligible |
| `wordpress_shortcode_captures` | onigmo | eligible |
| `wordpress_shortcode_captures` | pcre2_jit | eligible |
| `wordpress_shortcode_captures` | pcre2 | eligible |
| `wordpress_shortcode_captures` | fancy_regex | eligible |
| `wordpress_shortcode_captures` | fancy_regex_seek | eligible |
| `wordpress_shortcode_captures` | regex | syntax_rejected |
| `symfony_grapheme_chunks_1` | rust | eligible |
| `symfony_grapheme_chunks_1` | rust_erroraware | eligible |
| `symfony_grapheme_chunks_1` | c | eligible |
| `symfony_grapheme_chunks_1` | onigmo | semantic_difference |
| `symfony_grapheme_chunks_1` | pcre2_jit | eligible |
| `symfony_grapheme_chunks_1` | pcre2 | eligible |
| `symfony_grapheme_chunks_1` | fancy_regex | syntax_rejected |
| `symfony_grapheme_chunks_1` | fancy_regex_seek | syntax_rejected |
| `symfony_grapheme_chunks_1` | regex | syntax_rejected |
| `symfony_grapheme_chunks_2` | rust | eligible |
| `symfony_grapheme_chunks_2` | rust_erroraware | eligible |
| `symfony_grapheme_chunks_2` | c | eligible |
| `symfony_grapheme_chunks_2` | onigmo | eligible |
| `symfony_grapheme_chunks_2` | pcre2_jit | eligible |
| `symfony_grapheme_chunks_2` | pcre2 | eligible |
| `symfony_grapheme_chunks_2` | fancy_regex | syntax_rejected |
| `symfony_grapheme_chunks_2` | fancy_regex_seek | syntax_rejected |
| `symfony_grapheme_chunks_2` | regex | syntax_rejected |
| `literal_first` | rust | eligible |
| `literal_first` | rust_erroraware | eligible |
| `literal_first` | c | eligible |
| `literal_first` | onigmo | eligible |
| `literal_first` | pcre2_jit | eligible |
| `literal_first` | pcre2 | eligible |
| `literal_first` | fancy_regex | eligible |
| `literal_first` | fancy_regex_seek | eligible |
| `literal_first` | regex | eligible |
| `literal_middle` | rust | eligible |
| `literal_middle` | rust_erroraware | eligible |
| `literal_middle` | c | eligible |
| `literal_middle` | onigmo | eligible |
| `literal_middle` | pcre2_jit | eligible |
| `literal_middle` | pcre2 | eligible |
| `literal_middle` | fancy_regex | eligible |
| `literal_middle` | fancy_regex_seek | eligible |
| `literal_middle` | regex | eligible |
| `literal_end` | rust | eligible |
| `literal_end` | rust_erroraware | eligible |
| `literal_end` | c | eligible |
| `literal_end` | onigmo | eligible |
| `literal_end` | pcre2_jit | eligible |
| `literal_end` | pcre2 | eligible |
| `literal_end` | fancy_regex | eligible |
| `literal_end` | fancy_regex_seek | eligible |
| `literal_end` | regex | eligible |
| `literal_absent` | rust | eligible |
| `literal_absent` | rust_erroraware | eligible |
| `literal_absent` | c | eligible |
| `literal_absent` | onigmo | eligible |
| `literal_absent` | pcre2_jit | eligible |
| `literal_absent` | pcre2 | eligible |
| `literal_absent` | fancy_regex | eligible |
| `literal_absent` | fancy_regex_seek | eligible |
| `literal_absent` | regex | eligible |
| `linkify_http_tail` | rust | pending |
| `linkify_http_tail` | rust_erroraware | pending |
| `linkify_http_tail` | c | pending |
| `linkify_http_tail` | onigmo | pending |
| `linkify_http_tail` | pcre2_jit | pending |
| `linkify_http_tail` | pcre2 | pending |
| `linkify_http_tail` | fancy_regex | pending |
| `linkify_http_tail` | fancy_regex_seek | pending |
| `linkify_http_tail` | regex | pending |
| `php_cs_fixer_recursive_types` | rust | pending |
| `php_cs_fixer_recursive_types` | rust_erroraware | pending |
| `php_cs_fixer_recursive_types` | c | pending |
| `php_cs_fixer_recursive_types` | onigmo | pending |
| `php_cs_fixer_recursive_types` | pcre2_jit | pending |
| `php_cs_fixer_recursive_types` | pcre2 | pending |
| `php_cs_fixer_recursive_types` | fancy_regex | pending |
| `php_cs_fixer_recursive_types` | fancy_regex_seek | pending |
| `php_cs_fixer_recursive_types` | regex | pending |

## rust_erroraware / steady

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 1.335.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.585 | 1.560–1.615 | Ferroni faster in every run interval |
| `uuid_v4` | 1.692 | 1.637–1.726 | Ferroni faster in every run interval |
| `ipv4_validation` | 1.437 | 1.413–1.474 | Ferroni faster in every run interval |
| `ipv6_validation` | 1.197 | 1.177–1.221 | Ferroni faster in every run interval |
| `semver_version_parse` | 1.180 | 1.100–1.255 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.309 | 1.300–1.391 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.418 | 1.377–1.500 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.523 | 1.447–1.527 | Ferroni faster in every run interval |
| `jinja_float_token` | 1.407 | 1.396–1.526 | Ferroni faster in every run interval |
| `django_email_local_part` | 1.811 | 1.767–1.875 | Ferroni faster in every run interval |
| `django_email_domain` | 1.002 | 1.001–1.015 | inconclusive |
| `django_url_regex` | 1.037 | 0.986–1.052 | inconclusive |
| `fluent_bit_apache` | 1.336 | 1.280–1.354 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.193 | 1.169–1.218 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.005 | 0.939–1.017 | inconclusive |
| `mastodon_hashtag_regex_step` | 1.265 | 1.219–1.266 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 1.183 | 1.127–1.190 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 1.049 | 1.033–1.080 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 1.521 | 1.464–1.523 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_1` | 1.353 | 1.326–1.379 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_2` | 1.418 | 1.392–1.452 | Ferroni faster in every run interval |
| `literal_first` | 1.878 | 1.860–2.075 | Ferroni faster in every run interval |
| `literal_middle` | 2.071 | 1.946–2.137 | Ferroni faster in every run interval |
| `literal_end` | 1.995 | 1.937–2.035 | Ferroni faster in every run interval |
| `literal_absent` | 2.495 | 2.339–2.511 | Ferroni faster in every run interval |

## rust_erroraware / compile

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 1.007.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.002 | 0.967–1.021 | inconclusive |
| `uuid_v4` | 0.964 | 0.963–0.968 | inconclusive |
| `ipv4_validation` | 1.015 | 0.994–1.100 | inconclusive |
| `ipv6_validation` | 0.993 | 0.978–1.002 | inconclusive |
| `semver_version_parse` | 0.985 | 0.970–1.004 | inconclusive |
| `semver_hyphen_range_captures` | 1.017 | 1.002–1.080 | inconclusive |
| `jinja_string_token` | 0.978 | 0.887–1.023 | inconclusive |
| `jinja_integer_token` | 1.034 | 0.978–1.168 | inconclusive |
| `jinja_float_token` | 1.004 | 0.965–1.030 | inconclusive |
| `django_email_local_part` | 0.997 | 0.960–1.005 | inconclusive |
| `django_email_domain` | 0.995 | 0.979–1.023 | inconclusive |
| `django_url_regex` | 1.039 | 0.941–1.049 | inconclusive |
| `fluent_bit_apache` | 1.026 | 1.004–1.058 | inconclusive |
| `fluent_bit_nginx` | 0.991 | 0.944–1.001 | inconclusive |
| `rails_underscore_regex_step` | 1.062 | 1.003–1.136 | inconclusive |
| `mastodon_hashtag_regex_step` | 0.951 | 0.946–1.009 | inconclusive |
| `python_markdown_smart_emphasis_re` | 0.988 | 0.968–1.032 | inconclusive |
| `python_markdown_smart_strong_em_re` | 1.023 | 0.961–1.038 | inconclusive |
| `wordpress_shortcode_captures` | 1.009 | 0.965–1.036 | inconclusive |
| `symfony_grapheme_chunks_1` | 1.022 | 1.020–1.034 | inconclusive |
| `symfony_grapheme_chunks_2` | 1.057 | 0.982–1.065 | inconclusive |
| `literal_first` | 1.098 | 1.009–1.098 | inconclusive |
| `literal_middle` | 0.999 | 0.919–1.070 | inconclusive |
| `literal_end` | 0.992 | 0.945–1.091 | inconclusive |
| `literal_absent` | 0.909 | 0.881–0.971 | inconclusive |

## rust_erroraware / first_use

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 1.031.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.015 | 0.981–1.072 | inconclusive |
| `uuid_v4` | 0.993 | 0.928–1.062 | inconclusive |
| `ipv4_validation` | 1.074 | 0.988–1.092 | inconclusive |
| `ipv6_validation` | 1.003 | 0.929–1.056 | inconclusive |
| `semver_version_parse` | 0.977 | 0.965–1.051 | inconclusive |
| `semver_hyphen_range_captures` | 1.019 | 1.010–1.094 | Ferroni faster in every run interval |
| `jinja_string_token` | 0.941 | 0.930–1.129 | inconclusive |
| `jinja_integer_token` | 1.083 | 1.005–1.099 | inconclusive |
| `jinja_float_token` | 0.986 | 0.976–0.998 | inconclusive |
| `django_email_local_part` | 0.979 | 0.978–1.053 | inconclusive |
| `django_email_domain` | 1.003 | 0.963–1.036 | inconclusive |
| `django_url_regex` | 0.992 | 0.958–1.064 | inconclusive |
| `fluent_bit_apache` | 1.000 | 0.998–1.045 | inconclusive |
| `fluent_bit_nginx` | 1.036 | 0.987–1.041 | inconclusive |
| `rails_underscore_regex_step` | 0.992 | 0.983–1.007 | inconclusive |
| `mastodon_hashtag_regex_step` | 1.037 | 0.976–1.062 | inconclusive |
| `python_markdown_smart_emphasis_re` | 1.003 | 0.962–1.115 | inconclusive |
| `python_markdown_smart_strong_em_re` | 1.026 | 0.987–1.058 | inconclusive |
| `wordpress_shortcode_captures` | 1.045 | 1.038–1.072 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_1` | 1.248 | 1.237–1.259 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_2` | 1.065 | 0.979–1.155 | inconclusive |
| `literal_first` | 1.152 | 1.143–1.214 | Ferroni faster in every run interval |
| `literal_middle` | 1.150 | 1.131–1.248 | Ferroni faster in every run interval |
| `literal_end` | 1.155 | 1.140–1.207 | Ferroni faster in every run interval |
| `literal_absent` | 1.074 | 0.975–1.117 | inconclusive |

## c / steady

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 1.156.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 2.131 | 1.886–2.135 | Ferroni faster in every run interval |
| `uuid_v4` | 1.460 | 1.378–1.597 | Ferroni faster in every run interval |
| `ipv4_validation` | 1.096 | 1.081–1.275 | Ferroni faster in every run interval |
| `ipv6_validation` | 0.852 | 0.849–0.876 | comparator faster in every run interval |
| `semver_version_parse` | 0.839 | 0.754–0.862 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 1.047 | 1.002–1.067 | inconclusive |
| `jinja_string_token` | 0.998 | 0.960–1.053 | inconclusive |
| `jinja_integer_token` | 0.925 | 0.912–0.939 | comparator faster in every run interval |
| `jinja_float_token` | 0.853 | 0.823–0.866 | comparator faster in every run interval |
| `django_email_local_part` | 1.610 | 1.580–1.648 | Ferroni faster in every run interval |
| `django_email_domain` | 1.628 | 1.601–1.645 | Ferroni faster in every run interval |
| `django_url_regex` | 1.440 | 1.349–1.447 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.287 | 1.259–1.318 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.369 | 1.258–1.378 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 0.851 | 0.780–0.882 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 1.342 | 1.332–1.395 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.952 | 0.921–1.003 | inconclusive |
| `python_markdown_smart_strong_em_re` | 0.686 | 0.670–0.735 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 1.005 | 0.975–1.058 | inconclusive |
| `symfony_grapheme_chunks_1` | 0.955 | 0.897–0.957 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 1.019 | 0.900–1.099 | inconclusive |
| `literal_first` | 1.385 | 1.353–1.601 | Ferroni faster in every run interval |
| `literal_middle` | 1.642 | 1.436–1.727 | Ferroni faster in every run interval |
| `literal_end` | 2.011 | 1.838–2.410 | Ferroni faster in every run interval |
| `literal_absent` | 1.349 | 1.305–1.469 | Ferroni faster in every run interval |

## c / compile

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.810.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 7.940 | 7.876–8.713 | Ferroni faster in every run interval |
| `uuid_v4` | 8.367 | 8.319–8.809 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.680 | 0.666–0.689 | comparator faster in every run interval |
| `ipv6_validation` | 0.551 | 0.538–0.552 | comparator faster in every run interval |
| `semver_version_parse` | 0.657 | 0.649–0.666 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.616 | 0.590–0.624 | comparator faster in every run interval |
| `jinja_string_token` | 0.450 | 0.418–0.463 | comparator faster in every run interval |
| `jinja_integer_token` | 5.460 | 5.423–5.548 | Ferroni faster in every run interval |
| `jinja_float_token` | 1.569 | 1.387–1.576 | Ferroni faster in every run interval |
| `django_email_local_part` | 4.565 | 4.429–4.865 | Ferroni faster in every run interval |
| `django_email_domain` | 0.320 | 0.311–0.330 | comparator faster in every run interval |
| `django_url_regex` | 0.647 | 0.593–0.652 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.445 | 0.423–0.449 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.424 | 0.413–0.447 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.878 | 0.818–0.893 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 1.400 | 1.369–1.549 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.443 | 0.420–0.458 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.428 | 0.418–0.450 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.594 | 0.579–0.597 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.348 | 0.341–0.349 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.323 | 0.317–0.328 | comparator faster in every run interval |
| `literal_first` | 0.356 | 0.323–0.381 | comparator faster in every run interval |
| `literal_middle` | 0.362 | 0.294–0.372 | comparator faster in every run interval |
| `literal_end` | 0.359 | 0.310–0.388 | comparator faster in every run interval |
| `literal_absent` | 0.355 | 0.302–0.370 | comparator faster in every run interval |

## c / first_use

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.893.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 7.815 | 7.810–8.035 | Ferroni faster in every run interval |
| `uuid_v4` | 8.185 | 7.584–9.326 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.679 | 0.662–0.705 | comparator faster in every run interval |
| `ipv6_validation` | 0.633 | 0.624–0.713 | comparator faster in every run interval |
| `semver_version_parse` | 0.686 | 0.673–0.689 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.634 | 0.627–0.677 | comparator faster in every run interval |
| `jinja_string_token` | 0.486 | 0.461–0.574 | comparator faster in every run interval |
| `jinja_integer_token` | 5.650 | 5.339–5.672 | Ferroni faster in every run interval |
| `jinja_float_token` | 1.524 | 1.488–1.563 | Ferroni faster in every run interval |
| `django_email_local_part` | 4.752 | 4.574–4.765 | Ferroni faster in every run interval |
| `django_email_domain` | 0.373 | 0.362–0.386 | comparator faster in every run interval |
| `django_url_regex` | 0.672 | 0.625–0.681 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.494 | 0.482–0.501 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.510 | 0.491–0.536 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.928 | 0.894–0.998 | inconclusive |
| `mastodon_hashtag_regex_step` | 1.390 | 1.355–1.548 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.539 | 0.523–0.576 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.464 | 0.450–0.526 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.623 | 0.604–0.652 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.551 | 0.516–0.568 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.483 | 0.441–0.499 | comparator faster in every run interval |
| `literal_first` | 0.457 | 0.443–0.457 | comparator faster in every run interval |
| `literal_middle` | 0.451 | 0.426–0.460 | comparator faster in every run interval |
| `literal_end` | 0.498 | 0.477–0.504 | comparator faster in every run interval |
| `literal_absent` | 0.370 | 0.333–0.373 | comparator faster in every run interval |

## onigmo / steady

Common cases: 24; families: 13. Pair-specific family-weighted ratio: 1.465.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 3.069 | 2.992–3.223 | Ferroni faster in every run interval |
| `uuid_v4` | 2.577 | 2.571–2.783 | Ferroni faster in every run interval |
| `ipv4_validation` | 1.004 | 0.947–1.027 | inconclusive |
| `ipv6_validation` | 1.377 | 1.316–1.400 | Ferroni faster in every run interval |
| `semver_version_parse` | 1.022 | 0.947–1.122 | inconclusive |
| `semver_hyphen_range_captures` | 1.080 | 1.040–1.172 | Ferroni faster in every run interval |
| `jinja_string_token` | 0.801 | 0.774–0.810 | comparator faster in every run interval |
| `jinja_integer_token` | 1.143 | 1.129–1.151 | Ferroni faster in every run interval |
| `jinja_float_token` | 1.584 | 1.584–1.618 | Ferroni faster in every run interval |
| `django_email_local_part` | 1.484 | 1.477–1.574 | Ferroni faster in every run interval |
| `django_email_domain` | 2.963 | 2.923–3.001 | Ferroni faster in every run interval |
| `django_url_regex` | 3.393 | 3.347–3.751 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.661 | 1.612–1.728 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.906 | 1.786–1.936 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 0.774 | 0.751–0.823 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 1.481 | 1.418–1.570 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.988 | 0.984–0.996 | inconclusive |
| `python_markdown_smart_strong_em_re` | 0.759 | 0.755–0.775 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 1.198 | 1.167–1.232 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_2` | 2.427 | 2.278–2.481 | Ferroni faster in every run interval |
| `literal_first` | 0.667 | 0.643–0.670 | comparator faster in every run interval |
| `literal_middle` | 0.878 | 0.767–0.896 | comparator faster in every run interval |
| `literal_end` | 1.256 | 1.138–1.281 | Ferroni faster in every run interval |
| `literal_absent` | 1.358 | 1.335–1.415 | Ferroni faster in every run interval |

## onigmo / compile

Common cases: 24; families: 13. Pair-specific family-weighted ratio: 0.992.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 8.470 | 8.288–8.767 | Ferroni faster in every run interval |
| `uuid_v4` | 8.521 | 8.367–9.164 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.610 | 0.601–0.628 | comparator faster in every run interval |
| `ipv6_validation` | 0.588 | 0.564–0.596 | comparator faster in every run interval |
| `semver_version_parse` | 0.602 | 0.598–0.644 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.654 | 0.623–0.678 | comparator faster in every run interval |
| `jinja_string_token` | 0.369 | 0.365–0.378 | comparator faster in every run interval |
| `jinja_integer_token` | 5.067 | 4.626–5.117 | Ferroni faster in every run interval |
| `jinja_float_token` | 1.606 | 1.466–1.693 | Ferroni faster in every run interval |
| `django_email_local_part` | 4.741 | 4.656–4.952 | Ferroni faster in every run interval |
| `django_email_domain` | 0.199 | 0.196–0.210 | comparator faster in every run interval |
| `django_url_regex` | 0.466 | 0.431–0.514 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.416 | 0.404–0.440 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.412 | 0.381–0.433 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.831 | 0.777–0.850 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 1.721 | 1.689–1.858 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.298 | 0.297–0.314 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.325 | 0.320–0.354 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.599 | 0.570–0.614 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 16.955 | 16.712–17.051 | Ferroni faster in every run interval |
| `literal_first` | 0.244 | 0.231–0.260 | comparator faster in every run interval |
| `literal_middle` | 0.230 | 0.218–0.231 | comparator faster in every run interval |
| `literal_end` | 0.236 | 0.215–0.314 | comparator faster in every run interval |
| `literal_absent` | 0.214 | 0.209–0.215 | comparator faster in every run interval |

## onigmo / first_use

Common cases: 24; families: 13. Pair-specific family-weighted ratio: 1.023.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 8.094 | 8.081–8.706 | Ferroni faster in every run interval |
| `uuid_v4` | 8.804 | 8.025–9.677 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.618 | 0.606–0.620 | comparator faster in every run interval |
| `ipv6_validation` | 0.595 | 0.562–0.668 | comparator faster in every run interval |
| `semver_version_parse` | 0.628 | 0.605–0.656 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.638 | 0.607–0.715 | comparator faster in every run interval |
| `jinja_string_token` | 0.388 | 0.387–0.396 | comparator faster in every run interval |
| `jinja_integer_token` | 5.115 | 4.572–5.122 | Ferroni faster in every run interval |
| `jinja_float_token` | 1.573 | 1.492–1.651 | Ferroni faster in every run interval |
| `django_email_local_part` | 4.690 | 4.659–4.800 | Ferroni faster in every run interval |
| `django_email_domain` | 0.209 | 0.202–0.216 | comparator faster in every run interval |
| `django_url_regex` | 0.460 | 0.453–0.503 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.448 | 0.448–0.454 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.468 | 0.450–0.486 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.837 | 0.810–0.841 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 1.754 | 1.732–1.856 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.360 | 0.343–0.368 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.361 | 0.351–0.401 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.638 | 0.578–0.644 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 13.452 | 13.241–14.034 | Ferroni faster in every run interval |
| `literal_first` | 0.288 | 0.276–0.304 | comparator faster in every run interval |
| `literal_middle` | 0.298 | 0.268–0.299 | comparator faster in every run interval |
| `literal_end` | 0.325 | 0.318–0.352 | comparator faster in every run interval |
| `literal_absent` | 0.290 | 0.281–0.321 | comparator faster in every run interval |

## pcre2_jit / steady

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.272.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.459 | 0.426–0.465 | comparator faster in every run interval |
| `uuid_v4` | 0.445 | 0.444–0.475 | comparator faster in every run interval |
| `ipv4_validation` | 0.249 | 0.245–0.257 | comparator faster in every run interval |
| `ipv6_validation` | 0.227 | 0.226–0.244 | comparator faster in every run interval |
| `semver_version_parse` | 0.250 | 0.222–0.255 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.394 | 0.391–0.411 | comparator faster in every run interval |
| `jinja_string_token` | 0.410 | 0.409–0.415 | comparator faster in every run interval |
| `jinja_integer_token` | 0.423 | 0.401–0.438 | comparator faster in every run interval |
| `jinja_float_token` | 0.416 | 0.411–0.448 | comparator faster in every run interval |
| `django_email_local_part` | 0.499 | 0.481–0.527 | comparator faster in every run interval |
| `django_email_domain` | 0.032 | 0.032–0.033 | comparator faster in every run interval |
| `django_url_regex` | 0.086 | 0.078–0.092 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.304 | 0.300–0.316 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.312 | 0.310–0.312 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.256 | 0.240–0.267 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.243 | 0.232–0.250 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.257 | 0.253–0.272 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.157 | 0.139–0.161 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.364 | 0.361–0.390 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.410 | 0.395–0.430 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.406 | 0.379–0.406 | comparator faster in every run interval |
| `literal_first` | 0.506 | 0.464–0.524 | comparator faster in every run interval |
| `literal_middle` | 0.501 | 0.499–0.512 | comparator faster in every run interval |
| `literal_end` | 0.506 | 0.476–0.543 | comparator faster in every run interval |
| `literal_absent` | 0.569 | 0.560–0.623 | comparator faster in every run interval |

## pcre2_jit / compile

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.710.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.517 | 0.491–0.532 | comparator faster in every run interval |
| `uuid_v4` | 0.501 | 0.470–0.520 | comparator faster in every run interval |
| `ipv4_validation` | 0.750 | 0.747–0.794 | comparator faster in every run interval |
| `ipv6_validation` | 0.636 | 0.633–0.640 | comparator faster in every run interval |
| `semver_version_parse` | 0.866 | 0.851–0.906 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.815 | 0.759–0.819 | comparator faster in every run interval |
| `jinja_string_token` | 0.865 | 0.825–0.921 | comparator faster in every run interval |
| `jinja_integer_token` | 0.697 | 0.683–0.747 | comparator faster in every run interval |
| `jinja_float_token` | 0.657 | 0.634–0.662 | comparator faster in every run interval |
| `django_email_local_part` | 0.589 | 0.585–0.637 | comparator faster in every run interval |
| `django_email_domain` | 0.062 | 0.061–0.062 | comparator faster in every run interval |
| `django_url_regex` | 0.074 | 0.069–0.081 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.738 | 0.709–0.742 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.745 | 0.733–0.800 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 1.943 | 1.809–1.977 | Ferroni faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.475 | 0.461–0.496 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 1.284 | 1.205–1.336 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 1.226 | 1.175–1.398 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 0.998 | 0.995–1.128 | inconclusive |
| `symfony_grapheme_chunks_1` | 1.165 | 1.131–1.263 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_2` | 1.164 | 1.106–1.218 | Ferroni faster in every run interval |
| `literal_first` | 4.032 | 3.744–4.059 | Ferroni faster in every run interval |
| `literal_middle` | 3.851 | 3.379–3.941 | Ferroni faster in every run interval |
| `literal_end` | 3.938 | 3.351–4.043 | Ferroni faster in every run interval |
| `literal_absent` | 3.497 | 3.326–3.614 | Ferroni faster in every run interval |

## pcre2_jit / first_use

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.784.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.531 | 0.516–0.557 | comparator faster in every run interval |
| `uuid_v4` | 0.483 | 0.450–0.544 | comparator faster in every run interval |
| `ipv4_validation` | 0.861 | 0.856–0.948 | inconclusive |
| `ipv6_validation` | 0.676 | 0.646–0.732 | comparator faster in every run interval |
| `semver_version_parse` | 1.031 | 0.875–1.068 | inconclusive |
| `semver_hyphen_range_captures` | 0.806 | 0.788–0.861 | comparator faster in every run interval |
| `jinja_string_token` | 1.017 | 1.004–1.021 | inconclusive |
| `jinja_integer_token` | 0.818 | 0.764–0.855 | comparator faster in every run interval |
| `jinja_float_token` | 0.702 | 0.679–0.767 | comparator faster in every run interval |
| `django_email_local_part` | 0.638 | 0.635–0.639 | comparator faster in every run interval |
| `django_email_domain` | 0.066 | 0.061–0.066 | comparator faster in every run interval |
| `django_url_regex` | 0.078 | 0.070–0.079 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.826 | 0.819–0.889 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.857 | 0.819–0.991 | inconclusive |
| `rails_underscore_regex_step` | 2.296 | 2.029–2.318 | Ferroni faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.529 | 0.512–0.588 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 1.601 | 1.520–1.636 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 1.406 | 1.320–1.791 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 1.152 | 1.111–1.156 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_1` | 1.451 | 1.408–1.846 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_2` | 1.388 | 1.233–1.613 | Ferroni faster in every run interval |
| `literal_first` | 3.626 | 3.498–3.773 | Ferroni faster in every run interval |
| `literal_middle` | 3.496 | 3.425–3.925 | Ferroni faster in every run interval |
| `literal_end` | 3.644 | 3.424–3.694 | Ferroni faster in every run interval |
| `literal_absent` | 3.554 | 3.122–3.663 | Ferroni faster in every run interval |

## pcre2 / steady

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.787.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.900 | 0.793–0.905 | comparator faster in every run interval |
| `uuid_v4` | 0.849 | 0.802–0.859 | comparator faster in every run interval |
| `ipv4_validation` | 1.448 | 1.370–1.532 | Ferroni faster in every run interval |
| `ipv6_validation` | 1.366 | 1.198–1.369 | Ferroni faster in every run interval |
| `semver_version_parse` | 0.751 | 0.674–0.764 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 1.630 | 1.578–1.683 | Ferroni faster in every run interval |
| `jinja_string_token` | 0.871 | 0.865–0.894 | comparator faster in every run interval |
| `jinja_integer_token` | 1.394 | 1.337–1.475 | Ferroni faster in every run interval |
| `jinja_float_token` | 1.340 | 1.305–1.359 | Ferroni faster in every run interval |
| `django_email_local_part` | 1.530 | 1.523–1.566 | Ferroni faster in every run interval |
| `django_email_domain` | 0.113 | 0.107–0.115 | comparator faster in every run interval |
| `django_url_regex` | 0.233 | 0.230–0.263 | comparator faster in every run interval |
| `fluent_bit_apache` | 1.021 | 1.014–1.057 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.106 | 1.086–1.128 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 0.786 | 0.757–0.795 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.521 | 0.511–0.529 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 1.352 | 1.340–1.359 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 1.210 | 1.160–1.349 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 1.074 | 1.058–1.104 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.611 | 0.564–0.630 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.554 | 0.522–0.560 | comparator faster in every run interval |
| `literal_first` | 0.863 | 0.835–0.887 | comparator faster in every run interval |
| `literal_middle` | 0.879 | 0.862–0.896 | comparator faster in every run interval |
| `literal_end` | 0.876 | 0.845–1.033 | inconclusive |
| `literal_absent` | 0.680 | 0.645–0.789 | comparator faster in every run interval |

## pcre2 / compile

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.167.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.174 | 0.164–0.175 | comparator faster in every run interval |
| `uuid_v4` | 0.161 | 0.151–0.169 | comparator faster in every run interval |
| `ipv4_validation` | 0.219 | 0.208–0.224 | comparator faster in every run interval |
| `ipv6_validation` | 0.195 | 0.173–0.196 | comparator faster in every run interval |
| `semver_version_parse` | 0.198 | 0.196–0.198 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.191 | 0.190–0.194 | comparator faster in every run interval |
| `jinja_string_token` | 0.148 | 0.147–0.155 | comparator faster in every run interval |
| `jinja_integer_token` | 0.175 | 0.174–0.193 | comparator faster in every run interval |
| `jinja_float_token` | 0.104 | 0.104–0.108 | comparator faster in every run interval |
| `django_email_local_part` | 0.238 | 0.233–0.249 | comparator faster in every run interval |
| `django_email_domain` | 0.054 | 0.052–0.058 | comparator faster in every run interval |
| `django_url_regex` | 0.058 | 0.055–0.061 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.126 | 0.122–0.128 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.134 | 0.127–0.139 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.480 | 0.461–0.519 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.227 | 0.227–0.237 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.161 | 0.159–0.164 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.169 | 0.162–0.178 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.230 | 0.221–0.258 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.122 | 0.122–0.127 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.114 | 0.104–0.118 | comparator faster in every run interval |
| `literal_first` | 0.200 | 0.194–0.206 | comparator faster in every run interval |
| `literal_middle` | 0.203 | 0.195–0.207 | comparator faster in every run interval |
| `literal_end` | 0.209 | 0.184–0.215 | comparator faster in every run interval |
| `literal_absent` | 0.193 | 0.186–0.200 | comparator faster in every run interval |

## pcre2 / first_use

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.297.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.290 | 0.289–0.305 | comparator faster in every run interval |
| `uuid_v4` | 0.253 | 0.245–0.271 | comparator faster in every run interval |
| `ipv4_validation` | 0.325 | 0.321–0.336 | comparator faster in every run interval |
| `ipv6_validation` | 0.203 | 0.183–0.226 | comparator faster in every run interval |
| `semver_version_parse` | 0.267 | 0.260–0.271 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.245 | 0.242–0.249 | comparator faster in every run interval |
| `jinja_string_token` | 0.313 | 0.294–0.328 | comparator faster in every run interval |
| `jinja_integer_token` | 0.247 | 0.238–0.278 | comparator faster in every run interval |
| `jinja_float_token` | 0.170 | 0.166–0.185 | comparator faster in every run interval |
| `django_email_local_part` | 0.293 | 0.291–0.322 | comparator faster in every run interval |
| `django_email_domain` | 0.055 | 0.053–0.062 | comparator faster in every run interval |
| `django_url_regex` | 0.058 | 0.055–0.059 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.246 | 0.240–0.253 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.257 | 0.245–0.322 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.789 | 0.734–0.863 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.275 | 0.271–0.284 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.443 | 0.390–0.462 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.366 | 0.338–0.445 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.334 | 0.302–0.344 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.638 | 0.547–0.654 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.469 | 0.468–0.582 | comparator faster in every run interval |
| `literal_first` | 1.171 | 1.142–1.192 | Ferroni faster in every run interval |
| `literal_middle` | 1.129 | 1.098–1.281 | inconclusive |
| `literal_end` | 1.175 | 1.135–1.183 | inconclusive |
| `literal_absent` | 1.001 | 0.965–1.125 | inconclusive |

## fancy_regex / steady

Common cases: 21; families: 11. Pair-specific family-weighted ratio: 0.929.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.635 | 0.573–0.636 | comparator faster in every run interval |
| `uuid_v4` | 0.596 | 0.509–0.606 | comparator faster in every run interval |
| `ipv4_validation` | 0.236 | 0.236–0.247 | comparator faster in every run interval |
| `ipv6_validation` | 0.112 | 0.096–0.114 | comparator faster in every run interval |
| `semver_version_parse` | 1.252 | 1.162–1.267 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.496 | 1.476–1.531 | Ferroni faster in every run interval |
| `jinja_string_token` | 0.935 | 0.905–1.006 | inconclusive |
| `jinja_integer_token` | 1.315 | 1.299–1.382 | Ferroni faster in every run interval |
| `jinja_float_token` | 2.125 | 2.096–2.143 | Ferroni faster in every run interval |
| `django_email_domain` | 0.409 | 0.386–0.409 | comparator faster in every run interval |
| `django_url_regex` | 1.794 | 1.689–1.967 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.197 | 1.127–1.200 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.209 | 1.180–1.254 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 2.436 | 2.214–2.521 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 1.295 | 1.279–1.296 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 1.407 | 1.349–1.421 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 1.794 | 1.709–1.911 | Ferroni faster in every run interval |
| `literal_first` | 0.408 | 0.402–0.416 | comparator faster in every run interval |
| `literal_middle` | 0.410 | 0.406–0.417 | comparator faster in every run interval |
| `literal_end` | 0.429 | 0.388–0.455 | comparator faster in every run interval |
| `literal_absent` | 0.588 | 0.562–0.633 | comparator faster in every run interval |

## fancy_regex / compile

Common cases: 21; families: 11. Pair-specific family-weighted ratio: 3.152.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 2.101 | 1.961–2.171 | Ferroni faster in every run interval |
| `uuid_v4` | 1.957 | 1.747–2.002 | Ferroni faster in every run interval |
| `ipv4_validation` | 2.220 | 2.052–2.345 | Ferroni faster in every run interval |
| `ipv6_validation` | 2.169 | 2.094–2.243 | Ferroni faster in every run interval |
| `semver_version_parse` | 35.681 | 35.319–37.257 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 24.212 | 23.587–24.617 | Ferroni faster in every run interval |
| `jinja_string_token` | 5.343 | 4.984–5.532 | Ferroni faster in every run interval |
| `jinja_integer_token` | 4.442 | 4.345–4.957 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.775 | 0.732–0.779 | comparator faster in every run interval |
| `django_email_domain` | 3.581 | 3.376–3.751 | Ferroni faster in every run interval |
| `django_url_regex` | 3.416 | 3.232–3.577 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 4.034 | 4.004–4.168 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 4.080 | 3.962–4.352 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 3.000 | 2.828–3.124 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 1.334 | 1.277–1.430 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 1.444 | 1.425–1.692 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 2.826 | 2.662–2.943 | Ferroni faster in every run interval |
| `literal_first` | 1.654 | 1.478–1.688 | Ferroni faster in every run interval |
| `literal_middle` | 1.439 | 1.382–1.530 | Ferroni faster in every run interval |
| `literal_end` | 1.497 | 1.428–1.563 | Ferroni faster in every run interval |
| `literal_absent` | 1.466 | 1.314–1.492 | Ferroni faster in every run interval |

## fancy_regex / first_use

Common cases: 21; families: 11. Pair-specific family-weighted ratio: 3.297.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 2.783 | 2.507–2.911 | Ferroni faster in every run interval |
| `uuid_v4` | 2.717 | 2.257–3.018 | Ferroni faster in every run interval |
| `ipv4_validation` | 2.418 | 2.308–2.631 | Ferroni faster in every run interval |
| `ipv6_validation` | 2.152 | 2.037–2.507 | Ferroni faster in every run interval |
| `semver_version_parse` | 35.592 | 35.175–36.060 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 24.277 | 23.324–24.803 | Ferroni faster in every run interval |
| `jinja_string_token` | 5.339 | 5.105–5.568 | Ferroni faster in every run interval |
| `jinja_integer_token` | 4.466 | 4.342–5.015 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.791 | 0.753–0.815 | comparator faster in every run interval |
| `django_email_domain` | 3.463 | 3.302–3.872 | Ferroni faster in every run interval |
| `django_url_regex` | 3.316 | 3.283–3.389 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 4.468 | 4.171–4.512 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 4.793 | 4.217–4.979 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 3.401 | 3.054–3.432 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 1.351 | 1.336–1.376 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 1.354 | 1.237–1.662 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 3.052 | 2.923–3.138 | Ferroni faster in every run interval |
| `literal_first` | 1.415 | 1.374–1.441 | Ferroni faster in every run interval |
| `literal_middle` | 1.324 | 1.258–1.406 | Ferroni faster in every run interval |
| `literal_end` | 1.396 | 1.363–1.435 | Ferroni faster in every run interval |
| `literal_absent` | 1.332 | 1.310–1.445 | Ferroni faster in every run interval |

## fancy_regex_seek / steady

Common cases: 21; families: 11. Pair-specific family-weighted ratio: 0.924.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.652 | 0.637–0.654 | comparator faster in every run interval |
| `uuid_v4` | 0.591 | 0.579–0.630 | comparator faster in every run interval |
| `ipv4_validation` | 0.232 | 0.231–0.246 | comparator faster in every run interval |
| `ipv6_validation` | 0.112 | 0.111–0.114 | comparator faster in every run interval |
| `semver_version_parse` | 1.259 | 1.162–1.271 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.443 | 1.399–1.460 | Ferroni faster in every run interval |
| `jinja_string_token` | 0.969 | 0.968–1.006 | inconclusive |
| `jinja_integer_token` | 1.306 | 1.273–1.376 | Ferroni faster in every run interval |
| `jinja_float_token` | 2.107 | 2.036–2.147 | Ferroni faster in every run interval |
| `django_email_domain` | 0.401 | 0.394–0.404 | comparator faster in every run interval |
| `django_url_regex` | 1.803 | 1.709–1.870 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.210 | 1.168–1.232 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.205 | 1.163–1.245 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 2.348 | 2.344–2.466 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 1.306 | 1.286–1.346 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 1.391 | 1.380–1.435 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 1.814 | 1.774–1.857 | Ferroni faster in every run interval |
| `literal_first` | 0.407 | 0.403–0.447 | comparator faster in every run interval |
| `literal_middle` | 0.400 | 0.397–0.429 | comparator faster in every run interval |
| `literal_end` | 0.417 | 0.411–0.428 | comparator faster in every run interval |
| `literal_absent` | 0.588 | 0.580–0.622 | comparator faster in every run interval |

## fancy_regex_seek / compile

Common cases: 21; families: 11. Pair-specific family-weighted ratio: 3.481.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 2.084 | 1.971–2.219 | Ferroni faster in every run interval |
| `uuid_v4` | 1.987 | 1.946–2.063 | Ferroni faster in every run interval |
| `ipv4_validation` | 2.126 | 2.114–2.256 | Ferroni faster in every run interval |
| `ipv6_validation` | 2.218 | 2.087–2.267 | Ferroni faster in every run interval |
| `semver_version_parse` | 36.260 | 34.932–36.570 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 23.255 | 22.566–25.761 | Ferroni faster in every run interval |
| `jinja_string_token` | 5.337 | 4.811–5.684 | Ferroni faster in every run interval |
| `jinja_integer_token` | 4.505 | 4.454–4.912 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.776 | 0.744–0.788 | comparator faster in every run interval |
| `django_email_domain` | 3.568 | 3.285–3.683 | Ferroni faster in every run interval |
| `django_url_regex` | 3.462 | 3.178–3.645 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 4.116 | 4.005–4.116 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 4.269 | 3.923–4.431 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 2.780 | 2.700–2.926 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 1.318 | 1.313–1.435 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 1.448 | 1.433–1.556 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 8.919 | 8.802–9.108 | Ferroni faster in every run interval |
| `literal_first` | 1.597 | 1.431–1.763 | Ferroni faster in every run interval |
| `literal_middle` | 1.461 | 1.373–1.499 | Ferroni faster in every run interval |
| `literal_end` | 1.546 | 1.356–1.556 | Ferroni faster in every run interval |
| `literal_absent` | 1.429 | 1.370–1.455 | Ferroni faster in every run interval |

## fancy_regex_seek / first_use

Common cases: 21; families: 11. Pair-specific family-weighted ratio: 3.714.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 2.721 | 2.560–2.939 | Ferroni faster in every run interval |
| `uuid_v4` | 2.830 | 2.741–2.838 | Ferroni faster in every run interval |
| `ipv4_validation` | 2.347 | 2.279–2.508 | Ferroni faster in every run interval |
| `ipv6_validation` | 2.254 | 2.156–2.405 | Ferroni faster in every run interval |
| `semver_version_parse` | 36.260 | 35.946–36.719 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 24.130 | 22.792–25.148 | Ferroni faster in every run interval |
| `jinja_string_token` | 5.533 | 4.872–5.574 | Ferroni faster in every run interval |
| `jinja_integer_token` | 4.599 | 4.508–4.905 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.806 | 0.747–0.814 | comparator faster in every run interval |
| `django_email_domain` | 3.491 | 3.477–3.795 | Ferroni faster in every run interval |
| `django_url_regex` | 3.395 | 3.252–3.748 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 4.442 | 4.430–4.452 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 4.854 | 4.244–4.879 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 3.277 | 3.119–3.470 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 1.351 | 1.252–1.422 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 1.377 | 1.357–1.608 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 10.490 | 10.094–10.737 | Ferroni faster in every run interval |
| `literal_first` | 1.450 | 1.448–1.490 | Ferroni faster in every run interval |
| `literal_middle` | 1.359 | 1.265–1.449 | Ferroni faster in every run interval |
| `literal_end` | 1.415 | 1.376–1.424 | Ferroni faster in every run interval |
| `literal_absent` | 1.345 | 1.313–1.415 | Ferroni faster in every run interval |

## regex / steady

Common cases: 14; families: 6. Pair-specific family-weighted ratio: 0.618.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.789 | 0.742–0.802 | comparator faster in every run interval |
| `uuid_v4` | 0.730 | 0.727–0.737 | comparator faster in every run interval |
| `ipv4_validation` | 0.267 | 0.257–0.270 | comparator faster in every run interval |
| `ipv6_validation` | 0.128 | 0.128–0.133 | comparator faster in every run interval |
| `semver_version_parse` | 1.079 | 1.034–1.080 | inconclusive |
| `semver_hyphen_range_captures` | 1.255 | 1.190–1.291 | Ferroni faster in every run interval |
| `jinja_string_token` | 0.609 | 0.592–0.623 | comparator faster in every run interval |
| `jinja_integer_token` | 0.998 | 0.961–1.028 | inconclusive |
| `fluent_bit_apache` | 1.046 | 1.046–1.121 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.112 | 1.072–1.143 | Ferroni faster in every run interval |
| `literal_first` | 0.369 | 0.359–0.391 | comparator faster in every run interval |
| `literal_middle` | 0.365 | 0.355–0.381 | comparator faster in every run interval |
| `literal_end` | 0.383 | 0.366–0.403 | comparator faster in every run interval |
| `literal_absent` | 0.538 | 0.492–0.544 | comparator faster in every run interval |

## regex / compile

Common cases: 14; families: 6. Pair-specific family-weighted ratio: 3.746.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.644 | 1.621–1.700 | Ferroni faster in every run interval |
| `uuid_v4` | 1.485 | 1.400–1.524 | Ferroni faster in every run interval |
| `ipv4_validation` | 1.955 | 1.880–2.008 | Ferroni faster in every run interval |
| `ipv6_validation` | 2.059 | 2.012–2.109 | Ferroni faster in every run interval |
| `semver_version_parse` | 35.561 | 34.865–35.723 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 24.578 | 24.258–25.486 | Ferroni faster in every run interval |
| `jinja_string_token` | 5.287 | 5.049–5.696 | Ferroni faster in every run interval |
| `jinja_integer_token` | 3.988 | 3.965–4.487 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 3.989 | 3.932–4.178 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 4.016 | 3.711–4.286 | Ferroni faster in every run interval |
| `literal_first` | 1.672 | 1.611–1.683 | Ferroni faster in every run interval |
| `literal_middle` | 1.656 | 1.474–1.791 | Ferroni faster in every run interval |
| `literal_end` | 1.632 | 1.476–1.671 | Ferroni faster in every run interval |
| `literal_absent` | 1.536 | 1.516–1.597 | Ferroni faster in every run interval |

## regex / first_use

Common cases: 14; families: 6. Pair-specific family-weighted ratio: 4.024.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 2.251 | 2.218–2.263 | Ferroni faster in every run interval |
| `uuid_v4` | 2.108 | 2.024–2.151 | Ferroni faster in every run interval |
| `ipv4_validation` | 2.143 | 2.097–2.194 | Ferroni faster in every run interval |
| `ipv6_validation` | 2.124 | 2.053–2.209 | Ferroni faster in every run interval |
| `semver_version_parse` | 35.693 | 35.661–38.074 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 22.942 | 22.809–24.539 | Ferroni faster in every run interval |
| `jinja_string_token` | 5.602 | 5.267–5.672 | Ferroni faster in every run interval |
| `jinja_integer_token` | 4.120 | 4.082–4.604 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 4.299 | 4.296–4.309 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 4.621 | 4.290–4.695 | Ferroni faster in every run interval |
| `literal_first` | 1.519 | 1.515–1.548 | Ferroni faster in every run interval |
| `literal_middle` | 1.424 | 1.386–1.519 | Ferroni faster in every run interval |
| `literal_end` | 1.528 | 1.518–1.594 | Ferroni faster in every run interval |
| `literal_absent` | 1.494 | 1.454–1.535 | Ferroni faster in every run interval |

Raw samples, estimates, confidence intervals, failures, eligibility reasons, corpus snapshot and execution order are retained beside this report.

Memory, where requested, is fresh-process peak RSS including the binary, runtime, parsed catalog, compilation, input/output and allocator. It is not isolated compiled-pattern memory.
