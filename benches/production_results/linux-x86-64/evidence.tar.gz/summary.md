# Production regex comparison

Host: Linux-6.6.141-x86_64-with-glibc2.39; x86_64.

Publication candidate: review host stability, raw samples, coverage and run intervals before publishing.

Ratios are comparator / Ferroni. Compile and first-use times concern one pattern; steady times concern the complete fixture batch.

Each comparison below uses only its explicitly listed common tasks. Families have equal aggregate weight; architectures are never combined.

## Eligibility

| Case | Engine | Status |
| --- | --- | --- |
| `uuid_shape` | rust | eligible |
| `uuid_shape` | rust_erroraware | eligible |
| `uuid_shape` | c | eligible |
| `uuid_shape` | onigmo | eligible |
| `uuid_shape` | pcre2_jit | eligible |
| `uuid_shape` | pcre2 | eligible |
| `uuid_shape` | fancy_regex | eligible |
| `uuid_shape` | fancy_regex_seek | eligible |
| `uuid_shape` | regex | eligible |
| `uuid_v4` | rust | eligible |
| `uuid_v4` | rust_erroraware | eligible |
| `uuid_v4` | c | eligible |
| `uuid_v4` | onigmo | eligible |
| `uuid_v4` | pcre2_jit | eligible |
| `uuid_v4` | pcre2 | eligible |
| `uuid_v4` | fancy_regex | eligible |
| `uuid_v4` | fancy_regex_seek | eligible |
| `uuid_v4` | regex | eligible |
| `ipv4_validation` | rust | eligible |
| `ipv4_validation` | rust_erroraware | eligible |
| `ipv4_validation` | c | eligible |
| `ipv4_validation` | onigmo | eligible |
| `ipv4_validation` | pcre2_jit | eligible |
| `ipv4_validation` | pcre2 | eligible |
| `ipv4_validation` | fancy_regex | eligible |
| `ipv4_validation` | fancy_regex_seek | eligible |
| `ipv4_validation` | regex | eligible |
| `ipv6_validation` | rust | eligible |
| `ipv6_validation` | rust_erroraware | eligible |
| `ipv6_validation` | c | eligible |
| `ipv6_validation` | onigmo | eligible |
| `ipv6_validation` | pcre2_jit | eligible |
| `ipv6_validation` | pcre2 | eligible |
| `ipv6_validation` | fancy_regex | eligible |
| `ipv6_validation` | fancy_regex_seek | eligible |
| `ipv6_validation` | regex | eligible |
| `semver_version_parse` | rust | eligible |
| `semver_version_parse` | rust_erroraware | eligible |
| `semver_version_parse` | c | eligible |
| `semver_version_parse` | onigmo | eligible |
| `semver_version_parse` | pcre2_jit | eligible |
| `semver_version_parse` | pcre2 | eligible |
| `semver_version_parse` | fancy_regex | eligible |
| `semver_version_parse` | fancy_regex_seek | eligible |
| `semver_version_parse` | regex | eligible |
| `semver_hyphen_range_captures` | rust | eligible |
| `semver_hyphen_range_captures` | rust_erroraware | eligible |
| `semver_hyphen_range_captures` | c | eligible |
| `semver_hyphen_range_captures` | onigmo | eligible |
| `semver_hyphen_range_captures` | pcre2_jit | eligible |
| `semver_hyphen_range_captures` | pcre2 | eligible |
| `semver_hyphen_range_captures` | fancy_regex | eligible |
| `semver_hyphen_range_captures` | fancy_regex_seek | eligible |
| `semver_hyphen_range_captures` | regex | eligible |
| `jinja_string_token` | rust | eligible |
| `jinja_string_token` | rust_erroraware | eligible |
| `jinja_string_token` | c | eligible |
| `jinja_string_token` | onigmo | eligible |
| `jinja_string_token` | pcre2_jit | eligible |
| `jinja_string_token` | pcre2 | eligible |
| `jinja_string_token` | fancy_regex | eligible |
| `jinja_string_token` | fancy_regex_seek | eligible |
| `jinja_string_token` | regex | eligible |
| `jinja_integer_token` | rust | eligible |
| `jinja_integer_token` | rust_erroraware | eligible |
| `jinja_integer_token` | c | eligible |
| `jinja_integer_token` | onigmo | eligible |
| `jinja_integer_token` | pcre2_jit | eligible |
| `jinja_integer_token` | pcre2 | eligible |
| `jinja_integer_token` | fancy_regex | eligible |
| `jinja_integer_token` | fancy_regex_seek | eligible |
| `jinja_integer_token` | regex | eligible |
| `jinja_float_token` | rust | eligible |
| `jinja_float_token` | rust_erroraware | eligible |
| `jinja_float_token` | c | eligible |
| `jinja_float_token` | onigmo | eligible |
| `jinja_float_token` | pcre2_jit | eligible |
| `jinja_float_token` | pcre2 | eligible |
| `jinja_float_token` | fancy_regex | eligible |
| `jinja_float_token` | fancy_regex_seek | eligible |
| `jinja_float_token` | regex | syntax_rejected |
| `django_email_local_part` | rust | eligible |
| `django_email_local_part` | rust_erroraware | eligible |
| `django_email_local_part` | c | eligible |
| `django_email_local_part` | onigmo | eligible |
| `django_email_local_part` | pcre2_jit | eligible |
| `django_email_local_part` | pcre2 | eligible |
| `django_email_local_part` | fancy_regex | syntax_rejected |
| `django_email_local_part` | fancy_regex_seek | syntax_rejected |
| `django_email_local_part` | regex | syntax_rejected |
| `django_email_domain` | rust | eligible |
| `django_email_domain` | rust_erroraware | eligible |
| `django_email_domain` | c | eligible |
| `django_email_domain` | onigmo | eligible |
| `django_email_domain` | pcre2_jit | eligible |
| `django_email_domain` | pcre2 | eligible |
| `django_email_domain` | fancy_regex | eligible |
| `django_email_domain` | fancy_regex_seek | eligible |
| `django_email_domain` | regex | syntax_rejected |
| `django_url_regex` | rust | eligible |
| `django_url_regex` | rust_erroraware | eligible |
| `django_url_regex` | c | eligible |
| `django_url_regex` | onigmo | eligible |
| `django_url_regex` | pcre2_jit | eligible |
| `django_url_regex` | pcre2 | eligible |
| `django_url_regex` | fancy_regex | eligible |
| `django_url_regex` | fancy_regex_seek | eligible |
| `django_url_regex` | regex | syntax_rejected |
| `fluent_bit_apache` | rust | eligible |
| `fluent_bit_apache` | rust_erroraware | eligible |
| `fluent_bit_apache` | c | eligible |
| `fluent_bit_apache` | onigmo | eligible |
| `fluent_bit_apache` | pcre2_jit | eligible |
| `fluent_bit_apache` | pcre2 | eligible |
| `fluent_bit_apache` | fancy_regex | eligible |
| `fluent_bit_apache` | fancy_regex_seek | eligible |
| `fluent_bit_apache` | regex | eligible |
| `fluent_bit_nginx` | rust | eligible |
| `fluent_bit_nginx` | rust_erroraware | eligible |
| `fluent_bit_nginx` | c | eligible |
| `fluent_bit_nginx` | onigmo | eligible |
| `fluent_bit_nginx` | pcre2_jit | eligible |
| `fluent_bit_nginx` | pcre2 | eligible |
| `fluent_bit_nginx` | fancy_regex | eligible |
| `fluent_bit_nginx` | fancy_regex_seek | eligible |
| `fluent_bit_nginx` | regex | eligible |
| `rails_underscore_regex_step` | rust | eligible |
| `rails_underscore_regex_step` | rust_erroraware | eligible |
| `rails_underscore_regex_step` | c | eligible |
| `rails_underscore_regex_step` | onigmo | eligible |
| `rails_underscore_regex_step` | pcre2_jit | eligible |
| `rails_underscore_regex_step` | pcre2 | eligible |
| `rails_underscore_regex_step` | fancy_regex | eligible |
| `rails_underscore_regex_step` | fancy_regex_seek | eligible |
| `rails_underscore_regex_step` | regex | syntax_rejected |
| `mastodon_hashtag_regex_step` | rust | eligible |
| `mastodon_hashtag_regex_step` | rust_erroraware | eligible |
| `mastodon_hashtag_regex_step` | c | eligible |
| `mastodon_hashtag_regex_step` | onigmo | eligible |
| `mastodon_hashtag_regex_step` | pcre2_jit | eligible |
| `mastodon_hashtag_regex_step` | pcre2 | eligible |
| `mastodon_hashtag_regex_step` | fancy_regex | semantic_difference |
| `mastodon_hashtag_regex_step` | fancy_regex_seek | semantic_difference |
| `mastodon_hashtag_regex_step` | regex | syntax_rejected |
| `python_markdown_smart_emphasis_re` | rust | eligible |
| `python_markdown_smart_emphasis_re` | rust_erroraware | eligible |
| `python_markdown_smart_emphasis_re` | c | eligible |
| `python_markdown_smart_emphasis_re` | onigmo | eligible |
| `python_markdown_smart_emphasis_re` | pcre2_jit | eligible |
| `python_markdown_smart_emphasis_re` | pcre2 | eligible |
| `python_markdown_smart_emphasis_re` | fancy_regex | eligible |
| `python_markdown_smart_emphasis_re` | fancy_regex_seek | eligible |
| `python_markdown_smart_emphasis_re` | regex | syntax_rejected |
| `python_markdown_smart_strong_em_re` | rust | eligible |
| `python_markdown_smart_strong_em_re` | rust_erroraware | eligible |
| `python_markdown_smart_strong_em_re` | c | eligible |
| `python_markdown_smart_strong_em_re` | onigmo | eligible |
| `python_markdown_smart_strong_em_re` | pcre2_jit | eligible |
| `python_markdown_smart_strong_em_re` | pcre2 | eligible |
| `python_markdown_smart_strong_em_re` | fancy_regex | eligible |
| `python_markdown_smart_strong_em_re` | fancy_regex_seek | eligible |
| `python_markdown_smart_strong_em_re` | regex | syntax_rejected |
| `wordpress_shortcode_captures` | rust | eligible |
| `wordpress_shortcode_captures` | rust_erroraware | eligible |
| `wordpress_shortcode_captures` | c | eligible |
| `wordpress_shortcode_captures` | onigmo | eligible |
| `wordpress_shortcode_captures` | pcre2_jit | eligible |
| `wordpress_shortcode_captures` | pcre2 | eligible |
| `wordpress_shortcode_captures` | fancy_regex | eligible |
| `wordpress_shortcode_captures` | fancy_regex_seek | eligible |
| `wordpress_shortcode_captures` | regex | syntax_rejected |
| `symfony_grapheme_chunks_1` | rust | eligible |
| `symfony_grapheme_chunks_1` | rust_erroraware | eligible |
| `symfony_grapheme_chunks_1` | c | eligible |
| `symfony_grapheme_chunks_1` | onigmo | semantic_difference |
| `symfony_grapheme_chunks_1` | pcre2_jit | eligible |
| `symfony_grapheme_chunks_1` | pcre2 | eligible |
| `symfony_grapheme_chunks_1` | fancy_regex | syntax_rejected |
| `symfony_grapheme_chunks_1` | fancy_regex_seek | syntax_rejected |
| `symfony_grapheme_chunks_1` | regex | syntax_rejected |
| `symfony_grapheme_chunks_2` | rust | eligible |
| `symfony_grapheme_chunks_2` | rust_erroraware | eligible |
| `symfony_grapheme_chunks_2` | c | eligible |
| `symfony_grapheme_chunks_2` | onigmo | eligible |
| `symfony_grapheme_chunks_2` | pcre2_jit | eligible |
| `symfony_grapheme_chunks_2` | pcre2 | eligible |
| `symfony_grapheme_chunks_2` | fancy_regex | syntax_rejected |
| `symfony_grapheme_chunks_2` | fancy_regex_seek | syntax_rejected |
| `symfony_grapheme_chunks_2` | regex | syntax_rejected |
| `literal_first` | rust | eligible |
| `literal_first` | rust_erroraware | eligible |
| `literal_first` | c | eligible |
| `literal_first` | onigmo | eligible |
| `literal_first` | pcre2_jit | eligible |
| `literal_first` | pcre2 | eligible |
| `literal_first` | fancy_regex | eligible |
| `literal_first` | fancy_regex_seek | eligible |
| `literal_first` | regex | eligible |
| `literal_middle` | rust | eligible |
| `literal_middle` | rust_erroraware | eligible |
| `literal_middle` | c | eligible |
| `literal_middle` | onigmo | eligible |
| `literal_middle` | pcre2_jit | eligible |
| `literal_middle` | pcre2 | eligible |
| `literal_middle` | fancy_regex | eligible |
| `literal_middle` | fancy_regex_seek | eligible |
| `literal_middle` | regex | eligible |
| `literal_end` | rust | eligible |
| `literal_end` | rust_erroraware | eligible |
| `literal_end` | c | eligible |
| `literal_end` | onigmo | eligible |
| `literal_end` | pcre2_jit | eligible |
| `literal_end` | pcre2 | eligible |
| `literal_end` | fancy_regex | eligible |
| `literal_end` | fancy_regex_seek | eligible |
| `literal_end` | regex | eligible |
| `literal_absent` | rust | eligible |
| `literal_absent` | rust_erroraware | eligible |
| `literal_absent` | c | eligible |
| `literal_absent` | onigmo | eligible |
| `literal_absent` | pcre2_jit | eligible |
| `literal_absent` | pcre2 | eligible |
| `literal_absent` | fancy_regex | eligible |
| `literal_absent` | fancy_regex_seek | eligible |
| `literal_absent` | regex | eligible |
| `linkify_http_tail` | rust | pending |
| `linkify_http_tail` | rust_erroraware | pending |
| `linkify_http_tail` | c | pending |
| `linkify_http_tail` | onigmo | pending |
| `linkify_http_tail` | pcre2_jit | pending |
| `linkify_http_tail` | pcre2 | pending |
| `linkify_http_tail` | fancy_regex | pending |
| `linkify_http_tail` | fancy_regex_seek | pending |
| `linkify_http_tail` | regex | pending |
| `php_cs_fixer_recursive_types` | rust | pending |
| `php_cs_fixer_recursive_types` | rust_erroraware | pending |
| `php_cs_fixer_recursive_types` | c | pending |
| `php_cs_fixer_recursive_types` | onigmo | pending |
| `php_cs_fixer_recursive_types` | pcre2_jit | pending |
| `php_cs_fixer_recursive_types` | pcre2 | pending |
| `php_cs_fixer_recursive_types` | fancy_regex | pending |
| `php_cs_fixer_recursive_types` | fancy_regex_seek | pending |
| `php_cs_fixer_recursive_types` | regex | pending |

## rust_erroraware / steady

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 1.770.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.941 | 1.581–2.274 | Ferroni faster in every run interval |
| `uuid_v4` | 1.900 | 1.771–2.227 | Ferroni faster in every run interval |
| `ipv4_validation` | 5.243 | 5.067–5.376 | Ferroni faster in every run interval |
| `ipv6_validation` | 11.599 | 10.080–12.628 | Ferroni faster in every run interval |
| `semver_version_parse` | 1.032 | 1.010–1.166 | inconclusive |
| `semver_hyphen_range_captures` | 0.953 | 0.945–1.001 | inconclusive |
| `jinja_string_token` | 1.078 | 0.978–1.082 | inconclusive |
| `jinja_integer_token` | 1.027 | 0.888–1.060 | inconclusive |
| `jinja_float_token` | 1.221 | 1.061–1.285 | inconclusive |
| `django_email_local_part` | 3.320 | 3.000–3.363 | Ferroni faster in every run interval |
| `django_email_domain` | 9.212 | 7.888–10.841 | Ferroni faster in every run interval |
| `django_url_regex` | 7.534 | 7.170–8.919 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.241 | 1.134–1.309 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.472 | 1.469–1.680 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.032 | 1.005–1.265 | inconclusive |
| `mastodon_hashtag_regex_step` | 1.162 | 1.012–1.280 | inconclusive |
| `python_markdown_smart_emphasis_re` | 1.063 | 1.052–1.345 | inconclusive |
| `python_markdown_smart_strong_em_re` | 1.042 | 1.005–1.198 | inconclusive |
| `wordpress_shortcode_captures` | 1.008 | 1.007–1.135 | inconclusive |
| `symfony_grapheme_chunks_1` | 1.064 | 0.917–1.089 | inconclusive |
| `symfony_grapheme_chunks_2` | 1.043 | 1.032–1.213 | inconclusive |
| `literal_first` | 1.341 | 1.266–1.452 | Ferroni faster in every run interval |
| `literal_middle` | 1.312 | 1.275–1.346 | Ferroni faster in every run interval |
| `literal_end` | 1.315 | 1.313–1.325 | Ferroni faster in every run interval |
| `literal_absent` | 1.417 | 1.358–1.450 | Ferroni faster in every run interval |

## rust_erroraware / compile

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 1.002.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.972 | 0.918–1.255 | inconclusive |
| `uuid_v4` | 0.977 | 0.900–1.150 | inconclusive |
| `ipv4_validation` | 0.970 | 0.870–1.061 | inconclusive |
| `ipv6_validation` | 0.971 | 0.935–1.022 | inconclusive |
| `semver_version_parse` | 1.016 | 0.910–1.198 | inconclusive |
| `semver_hyphen_range_captures` | 0.983 | 0.952–1.049 | inconclusive |
| `jinja_string_token` | 1.105 | 1.049–1.232 | inconclusive |
| `jinja_integer_token` | 0.911 | 0.808–1.109 | inconclusive |
| `jinja_float_token` | 0.984 | 0.910–0.986 | inconclusive |
| `django_email_local_part` | 0.952 | 0.901–1.026 | inconclusive |
| `django_email_domain` | 0.989 | 0.920–1.354 | inconclusive |
| `django_url_regex` | 0.995 | 0.890–1.150 | inconclusive |
| `fluent_bit_apache` | 0.995 | 0.975–1.353 | inconclusive |
| `fluent_bit_nginx` | 1.008 | 0.992–1.080 | inconclusive |
| `rails_underscore_regex_step` | 0.994 | 0.951–1.101 | inconclusive |
| `mastodon_hashtag_regex_step` | 1.080 | 0.833–1.141 | inconclusive |
| `python_markdown_smart_emphasis_re` | 1.027 | 1.015–1.408 | inconclusive |
| `python_markdown_smart_strong_em_re` | 1.063 | 1.019–1.149 | inconclusive |
| `wordpress_shortcode_captures` | 0.934 | 0.856–0.989 | inconclusive |
| `symfony_grapheme_chunks_1` | 1.160 | 0.982–1.318 | inconclusive |
| `symfony_grapheme_chunks_2` | 1.168 | 1.032–1.195 | inconclusive |
| `literal_first` | 0.855 | 0.664–1.078 | inconclusive |
| `literal_middle` | 0.979 | 0.790–1.052 | inconclusive |
| `literal_end` | 0.976 | 0.734–1.065 | inconclusive |
| `literal_absent` | 0.896 | 0.865–0.943 | inconclusive |

## rust_erroraware / first_use

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.935.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.711 | 0.585–0.838 | comparator faster in every run interval |
| `uuid_v4` | 0.647 | 0.641–0.675 | comparator faster in every run interval |
| `ipv4_validation` | 0.891 | 0.874–0.892 | comparator faster in every run interval |
| `ipv6_validation` | 0.915 | 0.911–1.363 | inconclusive |
| `semver_version_parse` | 0.935 | 0.877–0.936 | inconclusive |
| `semver_hyphen_range_captures` | 1.004 | 0.961–1.017 | inconclusive |
| `jinja_string_token` | 0.944 | 0.917–1.067 | inconclusive |
| `jinja_integer_token` | 0.940 | 0.852–0.963 | inconclusive |
| `jinja_float_token` | 1.127 | 0.991–1.279 | inconclusive |
| `django_email_local_part` | 0.918 | 0.912–0.950 | inconclusive |
| `django_email_domain` | 1.069 | 0.992–1.161 | inconclusive |
| `django_url_regex` | 0.983 | 0.888–1.064 | inconclusive |
| `fluent_bit_apache` | 0.860 | 0.757–0.884 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.945 | 0.896–0.967 | inconclusive |
| `rails_underscore_regex_step` | 0.992 | 0.979–1.141 | inconclusive |
| `mastodon_hashtag_regex_step` | 1.011 | 0.909–1.081 | inconclusive |
| `python_markdown_smart_emphasis_re` | 0.997 | 0.850–1.033 | inconclusive |
| `python_markdown_smart_strong_em_re` | 0.930 | 0.878–1.056 | inconclusive |
| `wordpress_shortcode_captures` | 0.893 | 0.787–0.991 | inconclusive |
| `symfony_grapheme_chunks_1` | 0.913 | 0.834–1.035 | inconclusive |
| `symfony_grapheme_chunks_2` | 0.936 | 0.838–0.997 | inconclusive |
| `literal_first` | 1.123 | 1.078–1.134 | inconclusive |
| `literal_middle` | 1.014 | 0.876–1.115 | inconclusive |
| `literal_end` | 0.915 | 0.795–1.192 | inconclusive |
| `literal_absent` | 0.988 | 0.877–1.204 | inconclusive |

## c / steady

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 2.812.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 3.798 | 3.498–3.935 | Ferroni faster in every run interval |
| `uuid_v4` | 3.115 | 2.665–3.203 | Ferroni faster in every run interval |
| `ipv4_validation` | 6.470 | 6.459–6.603 | Ferroni faster in every run interval |
| `ipv6_validation` | 10.689 | 10.015–10.753 | Ferroni faster in every run interval |
| `semver_version_parse` | 1.342 | 1.332–1.379 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.014 | 0.913–1.059 | inconclusive |
| `jinja_string_token` | 1.156 | 1.036–1.254 | inconclusive |
| `jinja_integer_token` | 0.960 | 0.876–0.999 | inconclusive |
| `jinja_float_token` | 1.051 | 1.011–1.101 | inconclusive |
| `django_email_local_part` | 5.565 | 5.341–6.657 | Ferroni faster in every run interval |
| `django_email_domain` | 45.402 | 40.859–46.777 | Ferroni faster in every run interval |
| `django_url_regex` | 22.359 | 21.868–22.600 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.929 | 1.889–2.309 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 2.248 | 2.204–2.746 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.156 | 1.067–1.164 | inconclusive |
| `mastodon_hashtag_regex_step` | 1.841 | 1.555–2.269 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 2.241 | 2.175–2.314 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 2.241 | 2.188–2.247 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 1.028 | 0.920–1.195 | inconclusive |
| `symfony_grapheme_chunks_1` | 1.099 | 1.073–1.180 | inconclusive |
| `symfony_grapheme_chunks_2` | 1.127 | 1.117–1.198 | Ferroni faster in every run interval |
| `literal_first` | 4.713 | 4.154–5.981 | Ferroni faster in every run interval |
| `literal_middle` | 5.262 | 4.715–6.106 | Ferroni faster in every run interval |
| `literal_end` | 6.591 | 6.150–7.106 | Ferroni faster in every run interval |
| `literal_absent` | 3.379 | 2.999–3.747 | Ferroni faster in every run interval |

## c / compile

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.323.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 3.843 | 3.440–4.158 | Ferroni faster in every run interval |
| `uuid_v4` | 3.894 | 3.138–4.381 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.253 | 0.239–0.262 | comparator faster in every run interval |
| `ipv6_validation` | 0.238 | 0.219–0.244 | comparator faster in every run interval |
| `semver_version_parse` | 0.255 | 0.252–0.273 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.209 | 0.205–0.271 | comparator faster in every run interval |
| `jinja_string_token` | 0.144 | 0.138–0.170 | comparator faster in every run interval |
| `jinja_integer_token` | 2.098 | 2.004–2.319 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.494 | 0.478–0.508 | comparator faster in every run interval |
| `django_email_local_part` | 2.491 | 2.461–3.448 | Ferroni faster in every run interval |
| `django_email_domain` | 0.208 | 0.185–0.244 | comparator faster in every run interval |
| `django_url_regex` | 0.319 | 0.268–0.334 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.160 | 0.149–0.163 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.151 | 0.149–0.156 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.347 | 0.279–0.397 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.449 | 0.338–0.483 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.187 | 0.169–0.209 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.134 | 0.121–0.140 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.203 | 0.178–0.227 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.095 | 0.091–0.104 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.076 | 0.076–0.082 | comparator faster in every run interval |
| `literal_first` | 0.215 | 0.213–0.223 | comparator faster in every run interval |
| `literal_middle` | 0.268 | 0.239–0.315 | comparator faster in every run interval |
| `literal_end` | 0.233 | 0.189–0.275 | comparator faster in every run interval |
| `literal_absent` | 0.229 | 0.220–0.247 | comparator faster in every run interval |

## c / first_use

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.347.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 2.488 | 2.413–3.655 | Ferroni faster in every run interval |
| `uuid_v4` | 2.466 | 2.246–2.671 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.242 | 0.241–0.244 | comparator faster in every run interval |
| `ipv6_validation` | 0.245 | 0.215–0.292 | comparator faster in every run interval |
| `semver_version_parse` | 0.255 | 0.251–0.262 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.230 | 0.219–0.323 | comparator faster in every run interval |
| `jinja_string_token` | 0.160 | 0.132–0.161 | comparator faster in every run interval |
| `jinja_integer_token` | 2.186 | 2.054–2.518 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.510 | 0.462–0.534 | comparator faster in every run interval |
| `django_email_local_part` | 2.458 | 2.278–2.659 | Ferroni faster in every run interval |
| `django_email_domain` | 0.211 | 0.186–0.225 | comparator faster in every run interval |
| `django_url_regex` | 0.335 | 0.333–0.365 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.155 | 0.124–0.196 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.168 | 0.163–0.182 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.390 | 0.349–0.424 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.422 | 0.385–0.501 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.228 | 0.187–0.230 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.137 | 0.116–0.169 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.181 | 0.169–0.213 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.190 | 0.156–0.191 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.146 | 0.132–0.160 | comparator faster in every run interval |
| `literal_first` | 0.373 | 0.347–0.408 | comparator faster in every run interval |
| `literal_middle` | 0.396 | 0.391–0.480 | comparator faster in every run interval |
| `literal_end` | 0.443 | 0.373–0.486 | comparator faster in every run interval |
| `literal_absent` | 0.315 | 0.290–0.371 | comparator faster in every run interval |

## onigmo / steady

Common cases: 24; families: 13. Pair-specific family-weighted ratio: 3.491.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 6.274 | 4.612–7.091 | Ferroni faster in every run interval |
| `uuid_v4` | 5.672 | 5.544–5.896 | Ferroni faster in every run interval |
| `ipv4_validation` | 5.894 | 5.255–6.298 | Ferroni faster in every run interval |
| `ipv6_validation` | 14.922 | 14.775–16.871 | Ferroni faster in every run interval |
| `semver_version_parse` | 1.779 | 1.738–1.883 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 0.968 | 0.959–1.088 | inconclusive |
| `jinja_string_token` | 0.842 | 0.784–0.851 | comparator faster in every run interval |
| `jinja_integer_token` | 1.164 | 1.079–1.192 | Ferroni faster in every run interval |
| `jinja_float_token` | 1.863 | 1.739–2.508 | Ferroni faster in every run interval |
| `django_email_local_part` | 4.576 | 4.134–5.316 | Ferroni faster in every run interval |
| `django_email_domain` | 71.613 | 68.683–92.627 | Ferroni faster in every run interval |
| `django_url_regex` | 54.923 | 52.385–58.972 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 2.396 | 2.321–2.461 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 3.221 | 3.213–3.611 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 0.994 | 0.903–1.079 | inconclusive |
| `mastodon_hashtag_regex_step` | 2.264 | 1.738–2.266 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 2.334 | 2.176–2.358 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 2.341 | 2.271–2.572 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 1.130 | 1.122–1.186 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_2` | 2.693 | 2.671–2.907 | Ferroni faster in every run interval |
| `literal_first` | 2.210 | 2.124–2.280 | Ferroni faster in every run interval |
| `literal_middle` | 2.464 | 2.356–3.308 | Ferroni faster in every run interval |
| `literal_end` | 3.933 | 3.736–4.500 | Ferroni faster in every run interval |
| `literal_absent` | 3.220 | 2.877–3.610 | Ferroni faster in every run interval |

## onigmo / compile

Common cases: 24; families: 13. Pair-specific family-weighted ratio: 0.384.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 3.752 | 3.328–4.949 | Ferroni faster in every run interval |
| `uuid_v4` | 4.461 | 3.562–5.079 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.230 | 0.201–0.236 | comparator faster in every run interval |
| `ipv6_validation` | 0.224 | 0.158–0.229 | comparator faster in every run interval |
| `semver_version_parse` | 0.298 | 0.257–0.324 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.220 | 0.217–0.271 | comparator faster in every run interval |
| `jinja_string_token` | 0.131 | 0.115–0.147 | comparator faster in every run interval |
| `jinja_integer_token` | 1.864 | 1.621–2.094 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.500 | 0.499–0.599 | comparator faster in every run interval |
| `django_email_local_part` | 2.202 | 2.174–2.469 | Ferroni faster in every run interval |
| `django_email_domain` | 0.115 | 0.107–0.146 | comparator faster in every run interval |
| `django_url_regex` | 0.233 | 0.211–0.251 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.139 | 0.139–0.152 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.144 | 0.130–0.157 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.301 | 0.247–0.343 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.506 | 0.432–0.519 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.126 | 0.116–0.143 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.097 | 0.090–0.099 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.201 | 0.199–0.208 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 3.454 | 3.444–3.705 | Ferroni faster in every run interval |
| `literal_first` | 0.167 | 0.157–0.173 | comparator faster in every run interval |
| `literal_middle` | 0.184 | 0.178–0.206 | comparator faster in every run interval |
| `literal_end` | 0.167 | 0.144–0.198 | comparator faster in every run interval |
| `literal_absent` | 0.180 | 0.167–0.195 | comparator faster in every run interval |

## onigmo / first_use

Common cases: 24; families: 13. Pair-specific family-weighted ratio: 0.397.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 2.573 | 1.943–4.582 | Ferroni faster in every run interval |
| `uuid_v4` | 2.737 | 2.588–4.230 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.221 | 0.200–0.236 | comparator faster in every run interval |
| `ipv6_validation` | 0.217 | 0.195–0.228 | comparator faster in every run interval |
| `semver_version_parse` | 0.235 | 0.217–0.257 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.239 | 0.209–0.270 | comparator faster in every run interval |
| `jinja_string_token` | 0.120 | 0.103–0.156 | comparator faster in every run interval |
| `jinja_integer_token` | 2.057 | 1.925–2.469 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.558 | 0.500–0.585 | comparator faster in every run interval |
| `django_email_local_part` | 2.222 | 2.128–2.391 | Ferroni faster in every run interval |
| `django_email_domain` | 0.111 | 0.107–0.115 | comparator faster in every run interval |
| `django_url_regex` | 0.227 | 0.213–0.260 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.134 | 0.127–0.136 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.150 | 0.122–0.158 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.352 | 0.306–0.373 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.540 | 0.433–0.613 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.141 | 0.125–0.149 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.106 | 0.100–0.111 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.202 | 0.195–0.215 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 3.882 | 3.199–4.097 | Ferroni faster in every run interval |
| `literal_first` | 0.288 | 0.228–0.306 | comparator faster in every run interval |
| `literal_middle` | 0.301 | 0.257–0.355 | comparator faster in every run interval |
| `literal_end` | 0.333 | 0.228–0.358 | comparator faster in every run interval |
| `literal_absent` | 0.261 | 0.250–0.273 | comparator faster in every run interval |

## pcre2_jit / steady

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.665.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.773 | 0.759–1.059 | inconclusive |
| `uuid_v4` | 0.898 | 0.850–0.953 | inconclusive |
| `ipv4_validation` | 1.470 | 1.435–1.565 | Ferroni faster in every run interval |
| `ipv6_validation` | 2.629 | 2.355–2.876 | Ferroni faster in every run interval |
| `semver_version_parse` | 0.400 | 0.385–0.409 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.350 | 0.334–0.390 | comparator faster in every run interval |
| `jinja_string_token` | 0.486 | 0.437–0.587 | comparator faster in every run interval |
| `jinja_integer_token` | 0.448 | 0.445–0.452 | comparator faster in every run interval |
| `jinja_float_token` | 0.544 | 0.512–0.586 | comparator faster in every run interval |
| `django_email_local_part` | 1.631 | 1.398–1.828 | Ferroni faster in every run interval |
| `django_email_domain` | 0.848 | 0.783–0.901 | comparator faster in every run interval |
| `django_url_regex` | 1.410 | 1.302–1.534 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 0.458 | 0.446–0.480 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.541 | 0.508–0.644 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.353 | 0.322–0.363 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.343 | 0.277–0.381 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.623 | 0.585–0.678 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.503 | 0.434–0.548 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.404 | 0.399–0.408 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.531 | 0.424–0.565 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.427 | 0.416–0.454 | comparator faster in every run interval |
| `literal_first` | 1.484 | 1.384–1.735 | Ferroni faster in every run interval |
| `literal_middle` | 1.710 | 1.501–1.920 | Ferroni faster in every run interval |
| `literal_end` | 1.508 | 1.404–1.745 | Ferroni faster in every run interval |
| `literal_absent` | 1.492 | 1.315–1.633 | Ferroni faster in every run interval |

## pcre2_jit / compile

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.296.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.235 | 0.210–0.279 | comparator faster in every run interval |
| `uuid_v4` | 0.266 | 0.204–0.273 | comparator faster in every run interval |
| `ipv4_validation` | 0.302 | 0.279–0.309 | comparator faster in every run interval |
| `ipv6_validation` | 0.247 | 0.193–0.307 | comparator faster in every run interval |
| `semver_version_parse` | 0.430 | 0.358–0.529 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.261 | 0.250–0.409 | comparator faster in every run interval |
| `jinja_string_token` | 0.310 | 0.309–0.335 | comparator faster in every run interval |
| `jinja_integer_token` | 0.270 | 0.253–0.348 | comparator faster in every run interval |
| `jinja_float_token` | 0.220 | 0.207–0.267 | comparator faster in every run interval |
| `django_email_local_part` | 0.291 | 0.287–0.299 | comparator faster in every run interval |
| `django_email_domain` | 0.035 | 0.032–0.035 | comparator faster in every run interval |
| `django_url_regex` | 0.041 | 0.032–0.043 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.286 | 0.238–0.305 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.261 | 0.242–0.302 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.775 | 0.688–0.784 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.148 | 0.116–0.154 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.537 | 0.486–0.606 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.428 | 0.380–0.457 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.439 | 0.352–0.479 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.301 | 0.272–0.430 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.256 | 0.237–0.257 | comparator faster in every run interval |
| `literal_first` | 2.687 | 2.650–2.814 | Ferroni faster in every run interval |
| `literal_middle` | 3.334 | 2.956–3.550 | Ferroni faster in every run interval |
| `literal_end` | 2.695 | 2.362–3.320 | Ferroni faster in every run interval |
| `literal_absent` | 2.981 | 2.473–3.050 | Ferroni faster in every run interval |

## pcre2_jit / first_use

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.303.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.225 | 0.138–0.256 | comparator faster in every run interval |
| `uuid_v4` | 0.158 | 0.158–0.159 | comparator faster in every run interval |
| `ipv4_validation` | 0.317 | 0.316–0.346 | comparator faster in every run interval |
| `ipv6_validation` | 0.240 | 0.237–0.246 | comparator faster in every run interval |
| `semver_version_parse` | 0.400 | 0.348–0.433 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.272 | 0.242–0.315 | comparator faster in every run interval |
| `jinja_string_token` | 0.313 | 0.279–0.347 | comparator faster in every run interval |
| `jinja_integer_token` | 0.337 | 0.322–0.343 | comparator faster in every run interval |
| `jinja_float_token` | 0.250 | 0.232–0.302 | comparator faster in every run interval |
| `django_email_local_part` | 0.310 | 0.294–0.318 | comparator faster in every run interval |
| `django_email_domain` | 0.037 | 0.035–0.049 | comparator faster in every run interval |
| `django_url_regex` | 0.035 | 0.034–0.041 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.238 | 0.233–0.306 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.241 | 0.226–0.335 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 1.076 | 1.072–1.191 | inconclusive |
| `mastodon_hashtag_regex_step` | 0.153 | 0.127–0.207 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.563 | 0.503–0.898 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.424 | 0.368–0.439 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.344 | 0.302–0.457 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.519 | 0.448–0.568 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.392 | 0.392–0.424 | comparator faster in every run interval |
| `literal_first` | 3.041 | 2.470–3.283 | Ferroni faster in every run interval |
| `literal_middle` | 3.158 | 2.935–3.850 | Ferroni faster in every run interval |
| `literal_end` | 3.194 | 2.430–3.725 | Ferroni faster in every run interval |
| `literal_absent` | 3.148 | 2.575–3.400 | Ferroni faster in every run interval |

## pcre2 / steady

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 1.860.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.559 | 1.406–2.021 | Ferroni faster in every run interval |
| `uuid_v4` | 1.537 | 1.384–1.781 | Ferroni faster in every run interval |
| `ipv4_validation` | 8.242 | 7.868–8.664 | Ferroni faster in every run interval |
| `ipv6_validation` | 15.262 | 14.695–17.173 | Ferroni faster in every run interval |
| `semver_version_parse` | 1.356 | 1.257–1.422 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.359 | 1.349–1.432 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.034 | 0.980–1.210 | inconclusive |
| `jinja_integer_token` | 1.474 | 1.394–1.649 | Ferroni faster in every run interval |
| `jinja_float_token` | 1.540 | 1.304–1.668 | Ferroni faster in every run interval |
| `django_email_local_part` | 5.676 | 4.773–5.708 | Ferroni faster in every run interval |
| `django_email_domain` | 2.991 | 2.632–3.076 | Ferroni faster in every run interval |
| `django_url_regex` | 3.883 | 3.500–4.238 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.541 | 1.457–1.583 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.734 | 1.682–1.789 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.009 | 0.944–1.076 | inconclusive |
| `mastodon_hashtag_regex_step` | 0.636 | 0.618–0.826 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 2.962 | 2.782–3.374 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 3.504 | 3.181–4.154 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 1.173 | 1.157–1.287 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.744 | 0.684–0.763 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.565 | 0.543–0.630 | comparator faster in every run interval |
| `literal_first` | 2.914 | 2.776–2.942 | Ferroni faster in every run interval |
| `literal_middle` | 3.004 | 2.641–3.813 | Ferroni faster in every run interval |
| `literal_end` | 2.778 | 2.584–3.034 | Ferroni faster in every run interval |
| `literal_absent` | 1.535 | 1.357–1.865 | Ferroni faster in every run interval |

## pcre2 / compile

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.067.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.079 | 0.070–0.082 | comparator faster in every run interval |
| `uuid_v4` | 0.068 | 0.062–0.075 | comparator faster in every run interval |
| `ipv4_validation` | 0.077 | 0.065–0.081 | comparator faster in every run interval |
| `ipv6_validation` | 0.075 | 0.057–0.079 | comparator faster in every run interval |
| `semver_version_parse` | 0.084 | 0.083–0.094 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.070 | 0.068–0.073 | comparator faster in every run interval |
| `jinja_string_token` | 0.061 | 0.057–0.076 | comparator faster in every run interval |
| `jinja_integer_token` | 0.078 | 0.072–0.090 | comparator faster in every run interval |
| `jinja_float_token` | 0.034 | 0.034–0.038 | comparator faster in every run interval |
| `django_email_local_part` | 0.116 | 0.115–0.120 | comparator faster in every run interval |
| `django_email_domain` | 0.030 | 0.027–0.031 | comparator faster in every run interval |
| `django_url_regex` | 0.030 | 0.025–0.036 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.042 | 0.038–0.042 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.047 | 0.045–0.057 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.246 | 0.148–0.254 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.061 | 0.060–0.066 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.069 | 0.064–0.080 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.049 | 0.047–0.051 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.091 | 0.078–0.092 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.030 | 0.029–0.031 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.024 | 0.020–0.027 | comparator faster in every run interval |
| `literal_first` | 0.143 | 0.136–0.156 | comparator faster in every run interval |
| `literal_middle` | 0.176 | 0.156–0.180 | comparator faster in every run interval |
| `literal_end` | 0.146 | 0.134–0.177 | comparator faster in every run interval |
| `literal_absent` | 0.138 | 0.130–0.163 | comparator faster in every run interval |

## pcre2 / first_use

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.112.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.101 | 0.076–0.116 | comparator faster in every run interval |
| `uuid_v4` | 0.074 | 0.064–0.105 | comparator faster in every run interval |
| `ipv4_validation` | 0.104 | 0.096–0.106 | comparator faster in every run interval |
| `ipv6_validation` | 0.074 | 0.068–0.080 | comparator faster in every run interval |
| `semver_version_parse` | 0.109 | 0.101–0.131 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.084 | 0.081–0.100 | comparator faster in every run interval |
| `jinja_string_token` | 0.105 | 0.076–0.119 | comparator faster in every run interval |
| `jinja_integer_token` | 0.109 | 0.088–0.114 | comparator faster in every run interval |
| `jinja_float_token` | 0.066 | 0.055–0.066 | comparator faster in every run interval |
| `django_email_local_part` | 0.142 | 0.140–0.158 | comparator faster in every run interval |
| `django_email_domain` | 0.030 | 0.029–0.031 | comparator faster in every run interval |
| `django_url_regex` | 0.029 | 0.025–0.036 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.068 | 0.068–0.072 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.082 | 0.071–0.086 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.331 | 0.314–0.381 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.082 | 0.072–0.083 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.146 | 0.134–0.178 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.121 | 0.115–0.140 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.109 | 0.095–0.123 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.172 | 0.152–0.176 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.123 | 0.119–0.125 | comparator faster in every run interval |
| `literal_first` | 0.901 | 0.830–0.959 | inconclusive |
| `literal_middle` | 0.779 | 0.668–1.218 | inconclusive |
| `literal_end` | 0.864 | 0.712–0.979 | inconclusive |
| `literal_absent` | 0.737 | 0.709–1.075 | inconclusive |

## fancy_regex / steady

Common cases: 21; families: 11. Pair-specific family-weighted ratio: 2.747.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.171 | 1.147–1.443 | Ferroni faster in every run interval |
| `uuid_v4` | 1.249 | 0.920–1.262 | inconclusive |
| `ipv4_validation` | 1.326 | 1.235–1.400 | Ferroni faster in every run interval |
| `ipv6_validation` | 1.304 | 1.166–1.385 | Ferroni faster in every run interval |
| `semver_version_parse` | 2.053 | 1.930–2.475 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.429 | 1.279–1.606 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.036 | 0.991–1.074 | inconclusive |
| `jinja_integer_token` | 1.522 | 1.239–1.586 | Ferroni faster in every run interval |
| `jinja_float_token` | 2.411 | 2.204–2.515 | Ferroni faster in every run interval |
| `django_email_domain` | 10.463 | 10.150–10.546 | Ferroni faster in every run interval |
| `django_url_regex` | 28.556 | 24.636–38.358 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.680 | 1.444–1.766 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.974 | 1.890–2.029 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 3.089 | 2.430–3.763 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 2.910 | 2.603–2.917 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 4.883 | 3.842–4.944 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 1.854 | 1.828–2.027 | Ferroni faster in every run interval |
| `literal_first` | 1.297 | 1.255–1.446 | Ferroni faster in every run interval |
| `literal_middle` | 1.468 | 1.194–1.528 | Ferroni faster in every run interval |
| `literal_end` | 1.380 | 1.344–1.531 | Ferroni faster in every run interval |
| `literal_absent` | 1.246 | 1.160–1.471 | Ferroni faster in every run interval |

## fancy_regex / compile

Common cases: 21; families: 11. Pair-specific family-weighted ratio: 1.366.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.976 | 0.907–1.155 | inconclusive |
| `uuid_v4` | 0.804 | 0.802–0.833 | comparator faster in every run interval |
| `ipv4_validation` | 0.839 | 0.727–0.858 | comparator faster in every run interval |
| `ipv6_validation` | 0.896 | 0.656–0.929 | comparator faster in every run interval |
| `semver_version_parse` | 15.359 | 14.752–16.542 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 8.160 | 8.078–10.258 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.940 | 1.531–2.280 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.787 | 1.706–1.802 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.273 | 0.242–0.276 | comparator faster in every run interval |
| `django_email_domain` | 1.946 | 1.903–2.066 | Ferroni faster in every run interval |
| `django_url_regex` | 1.933 | 1.863–1.961 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.397 | 1.294–1.435 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.364 | 1.176–1.450 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.109 | 1.095–1.426 | inconclusive |
| `python_markdown_smart_emphasis_re` | 0.552 | 0.506–0.568 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.438 | 0.370–0.475 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 1.112 | 1.097–1.138 | inconclusive |
| `literal_first` | 1.220 | 1.108–1.241 | Ferroni faster in every run interval |
| `literal_middle` | 1.221 | 1.171–1.291 | Ferroni faster in every run interval |
| `literal_end` | 1.186 | 1.114–1.470 | inconclusive |
| `literal_absent` | 1.044 | 0.912–1.303 | inconclusive |

## fancy_regex / first_use

Common cases: 21; families: 11. Pair-specific family-weighted ratio: 1.428.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.111 | 0.785–1.229 | inconclusive |
| `uuid_v4` | 0.797 | 0.739–0.934 | inconclusive |
| `ipv4_validation` | 0.848 | 0.795–0.864 | comparator faster in every run interval |
| `ipv6_validation` | 0.821 | 0.772–0.926 | comparator faster in every run interval |
| `semver_version_parse` | 14.365 | 14.003–16.960 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 8.884 | 8.355–9.633 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.678 | 1.338–2.074 | Ferroni faster in every run interval |
| `jinja_integer_token` | 2.066 | 1.666–2.130 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.257 | 0.241–0.279 | comparator faster in every run interval |
| `django_email_domain` | 2.391 | 2.070–2.467 | Ferroni faster in every run interval |
| `django_url_regex` | 1.848 | 1.537–1.902 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.356 | 1.021–1.360 | inconclusive |
| `fluent_bit_nginx` | 1.440 | 1.273–1.488 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.476 | 1.407–1.542 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.518 | 0.460–0.541 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.432 | 0.410–0.568 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 1.054 | 1.051–1.176 | inconclusive |
| `literal_first` | 1.316 | 1.092–1.342 | inconclusive |
| `literal_middle` | 1.346 | 1.264–1.597 | Ferroni faster in every run interval |
| `literal_end` | 1.327 | 1.045–1.459 | inconclusive |
| `literal_absent` | 1.202 | 1.092–1.227 | Ferroni faster in every run interval |

## fancy_regex_seek / steady

Common cases: 21; families: 11. Pair-specific family-weighted ratio: 2.786.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.266 | 1.240–1.420 | Ferroni faster in every run interval |
| `uuid_v4` | 1.195 | 0.962–1.426 | inconclusive |
| `ipv4_validation` | 1.317 | 1.161–1.371 | Ferroni faster in every run interval |
| `ipv6_validation` | 1.181 | 1.157–1.440 | Ferroni faster in every run interval |
| `semver_version_parse` | 2.111 | 1.854–2.366 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.635 | 1.369–1.697 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.049 | 1.031–1.064 | inconclusive |
| `jinja_integer_token` | 1.292 | 1.251–1.587 | Ferroni faster in every run interval |
| `jinja_float_token` | 2.323 | 2.271–2.429 | Ferroni faster in every run interval |
| `django_email_domain` | 9.988 | 9.609–10.234 | Ferroni faster in every run interval |
| `django_url_regex` | 28.696 | 25.184–41.506 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.711 | 1.545–1.920 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 2.021 | 1.717–2.105 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 3.716 | 2.446–3.741 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 2.723 | 2.463–2.893 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 4.798 | 3.507–4.837 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 2.022 | 1.834–2.112 | Ferroni faster in every run interval |
| `literal_first` | 1.272 | 1.186–1.400 | Ferroni faster in every run interval |
| `literal_middle` | 1.289 | 1.193–1.330 | Ferroni faster in every run interval |
| `literal_end` | 1.346 | 1.153–1.354 | Ferroni faster in every run interval |
| `literal_absent` | 1.294 | 1.220–1.532 | Ferroni faster in every run interval |

## fancy_regex_seek / compile

Common cases: 21; families: 11. Pair-specific family-weighted ratio: 1.504.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.046 | 0.907–1.094 | inconclusive |
| `uuid_v4` | 0.952 | 0.747–1.130 | inconclusive |
| `ipv4_validation` | 0.809 | 0.673–0.849 | comparator faster in every run interval |
| `ipv6_validation` | 0.926 | 0.628–0.941 | comparator faster in every run interval |
| `semver_version_parse` | 14.985 | 14.158–15.276 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 9.524 | 8.251–11.286 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.672 | 1.664–2.335 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.813 | 1.670–1.815 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.249 | 0.240–0.251 | comparator faster in every run interval |
| `django_email_domain` | 2.005 | 1.837–2.036 | Ferroni faster in every run interval |
| `django_url_regex` | 1.853 | 1.796–2.050 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.376 | 1.371–1.393 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.434 | 1.223–1.499 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.082 | 1.011–1.591 | inconclusive |
| `python_markdown_smart_emphasis_re` | 0.530 | 0.516–0.626 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.410 | 0.403–0.608 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 3.261 | 3.194–3.357 | Ferroni faster in every run interval |
| `literal_first` | 1.015 | 0.780–1.061 | inconclusive |
| `literal_middle` | 1.227 | 1.155–1.361 | Ferroni faster in every run interval |
| `literal_end` | 1.115 | 0.836–1.372 | inconclusive |
| `literal_absent` | 1.087 | 0.891–1.235 | inconclusive |

## fancy_regex_seek / first_use

Common cases: 21; families: 11. Pair-specific family-weighted ratio: 1.562.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.107 | 0.748–1.157 | inconclusive |
| `uuid_v4` | 0.887 | 0.743–0.975 | inconclusive |
| `ipv4_validation` | 0.874 | 0.819–0.878 | comparator faster in every run interval |
| `ipv6_validation` | 0.836 | 0.761–0.898 | comparator faster in every run interval |
| `semver_version_parse` | 13.326 | 12.841–13.928 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 9.353 | 8.580–10.714 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.822 | 1.352–2.228 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.865 | 1.663–2.414 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.258 | 0.244–0.263 | comparator faster in every run interval |
| `django_email_domain` | 1.963 | 1.856–2.483 | Ferroni faster in every run interval |
| `django_url_regex` | 1.747 | 1.554–2.154 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.384 | 1.055–1.465 | inconclusive |
| `fluent_bit_nginx` | 1.482 | 1.205–1.543 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.430 | 1.382–1.655 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.487 | 0.455–0.526 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.397 | 0.383–0.562 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 3.849 | 2.839–4.191 | Ferroni faster in every run interval |
| `literal_first` | 1.172 | 1.078–1.272 | inconclusive |
| `literal_middle` | 1.255 | 1.070–1.402 | inconclusive |
| `literal_end` | 1.432 | 1.026–1.483 | inconclusive |
| `literal_absent` | 1.182 | 1.164–1.624 | Ferroni faster in every run interval |

## regex / steady

Common cases: 14; families: 6. Pair-specific family-weighted ratio: 1.319.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.380 | 1.170–1.579 | Ferroni faster in every run interval |
| `uuid_v4` | 1.350 | 1.199–1.482 | Ferroni faster in every run interval |
| `ipv4_validation` | 1.570 | 1.411–1.700 | Ferroni faster in every run interval |
| `ipv6_validation` | 1.417 | 1.375–1.820 | Ferroni faster in every run interval |
| `semver_version_parse` | 1.806 | 1.685–2.007 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.300 | 1.249–1.586 | Ferroni faster in every run interval |
| `jinja_string_token` | 0.632 | 0.616–0.666 | comparator faster in every run interval |
| `jinja_integer_token` | 1.165 | 0.944–1.231 | inconclusive |
| `fluent_bit_apache` | 1.534 | 1.478–1.561 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 2.028 | 1.810–2.080 | Ferroni faster in every run interval |
| `literal_first` | 1.113 | 1.053–1.123 | Ferroni faster in every run interval |
| `literal_middle` | 1.115 | 1.054–1.200 | Ferroni faster in every run interval |
| `literal_end` | 1.155 | 1.015–1.166 | inconclusive |
| `literal_absent` | 1.084 | 1.024–1.203 | Ferroni faster in every run interval |

## regex / compile

Common cases: 14; families: 6. Pair-specific family-weighted ratio: 1.574.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.777 | 0.717–0.814 | comparator faster in every run interval |
| `uuid_v4` | 0.652 | 0.627–0.667 | comparator faster in every run interval |
| `ipv4_validation` | 0.679 | 0.589–0.828 | comparator faster in every run interval |
| `ipv6_validation` | 0.780 | 0.599–0.814 | comparator faster in every run interval |
| `semver_version_parse` | 13.309 | 13.053–14.004 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 9.552 | 9.316–9.684 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.697 | 1.571–1.921 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.583 | 1.481–1.593 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.305 | 1.261–1.371 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.403 | 1.124–1.468 | Ferroni faster in every run interval |
| `literal_first` | 1.157 | 1.131–1.198 | Ferroni faster in every run interval |
| `literal_middle` | 1.215 | 1.152–1.415 | Ferroni faster in every run interval |
| `literal_end` | 1.197 | 1.061–1.302 | inconclusive |
| `literal_absent` | 1.124 | 0.968–1.452 | inconclusive |

## regex / first_use

Common cases: 14; families: 6. Pair-specific family-weighted ratio: 1.632.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.821 | 0.594–1.052 | inconclusive |
| `uuid_v4` | 0.655 | 0.602–0.746 | comparator faster in every run interval |
| `ipv4_validation` | 0.756 | 0.686–0.804 | comparator faster in every run interval |
| `ipv6_validation` | 0.801 | 0.662–0.821 | comparator faster in every run interval |
| `semver_version_parse` | 12.864 | 12.309–14.093 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 9.949 | 9.166–10.359 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.777 | 1.428–1.839 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.628 | 1.503–1.786 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.244 | 1.143–1.330 | inconclusive |
| `fluent_bit_nginx` | 1.445 | 1.114–1.495 | Ferroni faster in every run interval |
| `literal_first` | 1.294 | 1.258–1.562 | Ferroni faster in every run interval |
| `literal_middle` | 1.273 | 1.052–1.402 | Ferroni faster in every run interval |
| `literal_end` | 1.327 | 1.015–1.463 | inconclusive |
| `literal_absent` | 1.237 | 1.123–1.444 | Ferroni faster in every run interval |

Raw samples, estimates, confidence intervals, failures, eligibility reasons, corpus snapshot and execution order are retained beside this report.

Memory, where requested, is fresh-process peak RSS including the binary, runtime, parsed catalog, compilation, input/output and allocator. It is not isolated compiled-pattern memory.
