# Production regex comparison

Host: Linux-6.6.141-x86_64-with-glibc2.39; x86_64.

Publication candidate: review host stability, raw samples, coverage and run intervals before publishing.

Ratios are comparator / Ferroni. Compile and first-use times concern one pattern; steady times concern the complete fixture batch.

Each comparison below uses only its explicitly listed common tasks. Families have equal aggregate weight; architectures are never combined.

## Eligibility

| Case | Engine | Status |
| --- | --- | --- |
| `uuid_shape` | rust | eligible |
| `uuid_shape` | rust_erroraware | eligible |
| `uuid_shape` | c | eligible |
| `uuid_shape` | onigmo | eligible |
| `uuid_shape` | pcre2_jit | eligible |
| `uuid_shape` | pcre2 | eligible |
| `uuid_shape` | fancy_regex | eligible |
| `uuid_shape` | fancy_regex_seek | eligible |
| `uuid_shape` | regex | eligible |
| `uuid_v4` | rust | eligible |
| `uuid_v4` | rust_erroraware | eligible |
| `uuid_v4` | c | eligible |
| `uuid_v4` | onigmo | eligible |
| `uuid_v4` | pcre2_jit | eligible |
| `uuid_v4` | pcre2 | eligible |
| `uuid_v4` | fancy_regex | eligible |
| `uuid_v4` | fancy_regex_seek | eligible |
| `uuid_v4` | regex | eligible |
| `ipv4_validation` | rust | eligible |
| `ipv4_validation` | rust_erroraware | eligible |
| `ipv4_validation` | c | eligible |
| `ipv4_validation` | onigmo | eligible |
| `ipv4_validation` | pcre2_jit | eligible |
| `ipv4_validation` | pcre2 | eligible |
| `ipv4_validation` | fancy_regex | eligible |
| `ipv4_validation` | fancy_regex_seek | eligible |
| `ipv4_validation` | regex | eligible |
| `ipv6_validation` | rust | eligible |
| `ipv6_validation` | rust_erroraware | eligible |
| `ipv6_validation` | c | eligible |
| `ipv6_validation` | onigmo | eligible |
| `ipv6_validation` | pcre2_jit | eligible |
| `ipv6_validation` | pcre2 | eligible |
| `ipv6_validation` | fancy_regex | eligible |
| `ipv6_validation` | fancy_regex_seek | eligible |
| `ipv6_validation` | regex | eligible |
| `semver_version_parse` | rust | eligible |
| `semver_version_parse` | rust_erroraware | eligible |
| `semver_version_parse` | c | eligible |
| `semver_version_parse` | onigmo | eligible |
| `semver_version_parse` | pcre2_jit | eligible |
| `semver_version_parse` | pcre2 | eligible |
| `semver_version_parse` | fancy_regex | eligible |
| `semver_version_parse` | fancy_regex_seek | eligible |
| `semver_version_parse` | regex | eligible |
| `semver_hyphen_range_captures` | rust | eligible |
| `semver_hyphen_range_captures` | rust_erroraware | eligible |
| `semver_hyphen_range_captures` | c | eligible |
| `semver_hyphen_range_captures` | onigmo | eligible |
| `semver_hyphen_range_captures` | pcre2_jit | eligible |
| `semver_hyphen_range_captures` | pcre2 | eligible |
| `semver_hyphen_range_captures` | fancy_regex | eligible |
| `semver_hyphen_range_captures` | fancy_regex_seek | eligible |
| `semver_hyphen_range_captures` | regex | eligible |
| `jinja_string_token` | rust | eligible |
| `jinja_string_token` | rust_erroraware | eligible |
| `jinja_string_token` | c | eligible |
| `jinja_string_token` | onigmo | eligible |
| `jinja_string_token` | pcre2_jit | eligible |
| `jinja_string_token` | pcre2 | eligible |
| `jinja_string_token` | fancy_regex | eligible |
| `jinja_string_token` | fancy_regex_seek | eligible |
| `jinja_string_token` | regex | eligible |
| `jinja_integer_token` | rust | eligible |
| `jinja_integer_token` | rust_erroraware | eligible |
| `jinja_integer_token` | c | eligible |
| `jinja_integer_token` | onigmo | eligible |
| `jinja_integer_token` | pcre2_jit | eligible |
| `jinja_integer_token` | pcre2 | eligible |
| `jinja_integer_token` | fancy_regex | eligible |
| `jinja_integer_token` | fancy_regex_seek | eligible |
| `jinja_integer_token` | regex | eligible |
| `jinja_float_token` | rust | eligible |
| `jinja_float_token` | rust_erroraware | eligible |
| `jinja_float_token` | c | eligible |
| `jinja_float_token` | onigmo | eligible |
| `jinja_float_token` | pcre2_jit | eligible |
| `jinja_float_token` | pcre2 | eligible |
| `jinja_float_token` | fancy_regex | eligible |
| `jinja_float_token` | fancy_regex_seek | eligible |
| `jinja_float_token` | regex | syntax_rejected |
| `django_email_local_part` | rust | eligible |
| `django_email_local_part` | rust_erroraware | eligible |
| `django_email_local_part` | c | eligible |
| `django_email_local_part` | onigmo | eligible |
| `django_email_local_part` | pcre2_jit | eligible |
| `django_email_local_part` | pcre2 | eligible |
| `django_email_local_part` | fancy_regex | syntax_rejected |
| `django_email_local_part` | fancy_regex_seek | syntax_rejected |
| `django_email_local_part` | regex | syntax_rejected |
| `django_email_domain` | rust | eligible |
| `django_email_domain` | rust_erroraware | eligible |
| `django_email_domain` | c | eligible |
| `django_email_domain` | onigmo | eligible |
| `django_email_domain` | pcre2_jit | eligible |
| `django_email_domain` | pcre2 | eligible |
| `django_email_domain` | fancy_regex | eligible |
| `django_email_domain` | fancy_regex_seek | eligible |
| `django_email_domain` | regex | syntax_rejected |
| `django_url_regex` | rust | eligible |
| `django_url_regex` | rust_erroraware | eligible |
| `django_url_regex` | c | eligible |
| `django_url_regex` | onigmo | eligible |
| `django_url_regex` | pcre2_jit | eligible |
| `django_url_regex` | pcre2 | eligible |
| `django_url_regex` | fancy_regex | eligible |
| `django_url_regex` | fancy_regex_seek | eligible |
| `django_url_regex` | regex | syntax_rejected |
| `fluent_bit_apache` | rust | eligible |
| `fluent_bit_apache` | rust_erroraware | eligible |
| `fluent_bit_apache` | c | eligible |
| `fluent_bit_apache` | onigmo | eligible |
| `fluent_bit_apache` | pcre2_jit | eligible |
| `fluent_bit_apache` | pcre2 | eligible |
| `fluent_bit_apache` | fancy_regex | eligible |
| `fluent_bit_apache` | fancy_regex_seek | eligible |
| `fluent_bit_apache` | regex | eligible |
| `fluent_bit_nginx` | rust | eligible |
| `fluent_bit_nginx` | rust_erroraware | eligible |
| `fluent_bit_nginx` | c | eligible |
| `fluent_bit_nginx` | onigmo | eligible |
| `fluent_bit_nginx` | pcre2_jit | eligible |
| `fluent_bit_nginx` | pcre2 | eligible |
| `fluent_bit_nginx` | fancy_regex | eligible |
| `fluent_bit_nginx` | fancy_regex_seek | eligible |
| `fluent_bit_nginx` | regex | eligible |
| `rails_underscore_regex_step` | rust | eligible |
| `rails_underscore_regex_step` | rust_erroraware | eligible |
| `rails_underscore_regex_step` | c | eligible |
| `rails_underscore_regex_step` | onigmo | eligible |
| `rails_underscore_regex_step` | pcre2_jit | eligible |
| `rails_underscore_regex_step` | pcre2 | eligible |
| `rails_underscore_regex_step` | fancy_regex | eligible |
| `rails_underscore_regex_step` | fancy_regex_seek | eligible |
| `rails_underscore_regex_step` | regex | syntax_rejected |
| `mastodon_hashtag_regex_step` | rust | eligible |
| `mastodon_hashtag_regex_step` | rust_erroraware | eligible |
| `mastodon_hashtag_regex_step` | c | eligible |
| `mastodon_hashtag_regex_step` | onigmo | eligible |
| `mastodon_hashtag_regex_step` | pcre2_jit | eligible |
| `mastodon_hashtag_regex_step` | pcre2 | eligible |
| `mastodon_hashtag_regex_step` | fancy_regex | semantic_difference |
| `mastodon_hashtag_regex_step` | fancy_regex_seek | semantic_difference |
| `mastodon_hashtag_regex_step` | regex | syntax_rejected |
| `python_markdown_smart_emphasis_re` | rust | eligible |
| `python_markdown_smart_emphasis_re` | rust_erroraware | eligible |
| `python_markdown_smart_emphasis_re` | c | eligible |
| `python_markdown_smart_emphasis_re` | onigmo | eligible |
| `python_markdown_smart_emphasis_re` | pcre2_jit | eligible |
| `python_markdown_smart_emphasis_re` | pcre2 | eligible |
| `python_markdown_smart_emphasis_re` | fancy_regex | eligible |
| `python_markdown_smart_emphasis_re` | fancy_regex_seek | eligible |
| `python_markdown_smart_emphasis_re` | regex | syntax_rejected |
| `python_markdown_smart_strong_em_re` | rust | eligible |
| `python_markdown_smart_strong_em_re` | rust_erroraware | eligible |
| `python_markdown_smart_strong_em_re` | c | eligible |
| `python_markdown_smart_strong_em_re` | onigmo | eligible |
| `python_markdown_smart_strong_em_re` | pcre2_jit | eligible |
| `python_markdown_smart_strong_em_re` | pcre2 | eligible |
| `python_markdown_smart_strong_em_re` | fancy_regex | eligible |
| `python_markdown_smart_strong_em_re` | fancy_regex_seek | eligible |
| `python_markdown_smart_strong_em_re` | regex | syntax_rejected |
| `wordpress_shortcode_captures` | rust | eligible |
| `wordpress_shortcode_captures` | rust_erroraware | eligible |
| `wordpress_shortcode_captures` | c | eligible |
| `wordpress_shortcode_captures` | onigmo | eligible |
| `wordpress_shortcode_captures` | pcre2_jit | eligible |
| `wordpress_shortcode_captures` | pcre2 | eligible |
| `wordpress_shortcode_captures` | fancy_regex | eligible |
| `wordpress_shortcode_captures` | fancy_regex_seek | eligible |
| `wordpress_shortcode_captures` | regex | syntax_rejected |
| `symfony_grapheme_chunks_1` | rust | eligible |
| `symfony_grapheme_chunks_1` | rust_erroraware | eligible |
| `symfony_grapheme_chunks_1` | c | eligible |
| `symfony_grapheme_chunks_1` | onigmo | semantic_difference |
| `symfony_grapheme_chunks_1` | pcre2_jit | eligible |
| `symfony_grapheme_chunks_1` | pcre2 | eligible |
| `symfony_grapheme_chunks_1` | fancy_regex | syntax_rejected |
| `symfony_grapheme_chunks_1` | fancy_regex_seek | syntax_rejected |
| `symfony_grapheme_chunks_1` | regex | syntax_rejected |
| `symfony_grapheme_chunks_2` | rust | eligible |
| `symfony_grapheme_chunks_2` | rust_erroraware | eligible |
| `symfony_grapheme_chunks_2` | c | eligible |
| `symfony_grapheme_chunks_2` | onigmo | eligible |
| `symfony_grapheme_chunks_2` | pcre2_jit | eligible |
| `symfony_grapheme_chunks_2` | pcre2 | eligible |
| `symfony_grapheme_chunks_2` | fancy_regex | syntax_rejected |
| `symfony_grapheme_chunks_2` | fancy_regex_seek | syntax_rejected |
| `symfony_grapheme_chunks_2` | regex | syntax_rejected |
| `literal_first` | rust | eligible |
| `literal_first` | rust_erroraware | eligible |
| `literal_first` | c | eligible |
| `literal_first` | onigmo | eligible |
| `literal_first` | pcre2_jit | eligible |
| `literal_first` | pcre2 | eligible |
| `literal_first` | fancy_regex | eligible |
| `literal_first` | fancy_regex_seek | eligible |
| `literal_first` | regex | eligible |
| `literal_middle` | rust | eligible |
| `literal_middle` | rust_erroraware | eligible |
| `literal_middle` | c | eligible |
| `literal_middle` | onigmo | eligible |
| `literal_middle` | pcre2_jit | eligible |
| `literal_middle` | pcre2 | eligible |
| `literal_middle` | fancy_regex | eligible |
| `literal_middle` | fancy_regex_seek | eligible |
| `literal_middle` | regex | eligible |
| `literal_end` | rust | eligible |
| `literal_end` | rust_erroraware | eligible |
| `literal_end` | c | eligible |
| `literal_end` | onigmo | eligible |
| `literal_end` | pcre2_jit | eligible |
| `literal_end` | pcre2 | eligible |
| `literal_end` | fancy_regex | eligible |
| `literal_end` | fancy_regex_seek | eligible |
| `literal_end` | regex | eligible |
| `literal_absent` | rust | eligible |
| `literal_absent` | rust_erroraware | eligible |
| `literal_absent` | c | eligible |
| `literal_absent` | onigmo | eligible |
| `literal_absent` | pcre2_jit | eligible |
| `literal_absent` | pcre2 | eligible |
| `literal_absent` | fancy_regex | eligible |
| `literal_absent` | fancy_regex_seek | eligible |
| `literal_absent` | regex | eligible |
| `linkify_http_tail` | rust | pending |
| `linkify_http_tail` | rust_erroraware | pending |
| `linkify_http_tail` | c | pending |
| `linkify_http_tail` | onigmo | pending |
| `linkify_http_tail` | pcre2_jit | pending |
| `linkify_http_tail` | pcre2 | pending |
| `linkify_http_tail` | fancy_regex | pending |
| `linkify_http_tail` | fancy_regex_seek | pending |
| `linkify_http_tail` | regex | pending |
| `php_cs_fixer_recursive_types` | rust | pending |
| `php_cs_fixer_recursive_types` | rust_erroraware | pending |
| `php_cs_fixer_recursive_types` | c | pending |
| `php_cs_fixer_recursive_types` | onigmo | pending |
| `php_cs_fixer_recursive_types` | pcre2_jit | pending |
| `php_cs_fixer_recursive_types` | pcre2 | pending |
| `php_cs_fixer_recursive_types` | fancy_regex | pending |
| `php_cs_fixer_recursive_types` | fancy_regex_seek | pending |
| `php_cs_fixer_recursive_types` | regex | pending |

## rust_erroraware / steady

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 1.172.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.563 | 1.550–1.805 | Ferroni faster in every run interval |
| `uuid_v4` | 1.822 | 1.811–1.952 | Ferroni faster in every run interval |
| `ipv4_validation` | 5.178 | 5.052–5.451 | Ferroni faster in every run interval |
| `ipv6_validation` | 1.606 | 1.594–1.620 | Ferroni faster in every run interval |
| `semver_version_parse` | 1.016 | 0.979–1.047 | inconclusive |
| `semver_hyphen_range_captures` | 1.002 | 0.993–1.041 | inconclusive |
| `jinja_string_token` | 1.109 | 1.064–1.203 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.083 | 1.071–1.085 | Ferroni faster in every run interval |
| `jinja_float_token` | 1.029 | 1.029–1.084 | Ferroni faster in every run interval |
| `django_email_local_part` | 0.949 | 0.936–0.955 | comparator faster in every run interval |
| `django_email_domain` | 1.011 | 0.978–1.014 | inconclusive |
| `django_url_regex` | 1.012 | 0.930–1.026 | inconclusive |
| `fluent_bit_apache` | 1.005 | 0.982–1.139 | inconclusive |
| `fluent_bit_nginx` | 0.988 | 0.977–1.007 | inconclusive |
| `rails_underscore_regex_step` | 0.975 | 0.967–1.005 | inconclusive |
| `mastodon_hashtag_regex_step` | 1.049 | 1.048–1.083 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 1.043 | 0.991–1.131 | inconclusive |
| `python_markdown_smart_strong_em_re` | 0.987 | 0.986–0.995 | inconclusive |
| `wordpress_shortcode_captures` | 1.052 | 1.001–1.072 | inconclusive |
| `symfony_grapheme_chunks_1` | 0.993 | 0.992–1.051 | inconclusive |
| `symfony_grapheme_chunks_2` | 1.083 | 1.024–1.090 | inconclusive |
| `literal_first` | 1.338 | 1.320–1.470 | Ferroni faster in every run interval |
| `literal_middle` | 1.326 | 1.286–1.329 | Ferroni faster in every run interval |
| `literal_end` | 1.316 | 1.201–1.328 | Ferroni faster in every run interval |
| `literal_absent` | 1.381 | 1.303–1.384 | Ferroni faster in every run interval |

## rust_erroraware / compile

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 1.000.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.004 | 0.961–1.039 | inconclusive |
| `uuid_v4` | 1.027 | 1.018–1.059 | inconclusive |
| `ipv4_validation` | 0.989 | 0.955–0.994 | inconclusive |
| `ipv6_validation` | 0.994 | 0.938–1.029 | inconclusive |
| `semver_version_parse` | 1.005 | 0.976–1.070 | inconclusive |
| `semver_hyphen_range_captures` | 0.994 | 0.874–1.012 | inconclusive |
| `jinja_string_token` | 1.003 | 0.989–1.033 | inconclusive |
| `jinja_integer_token` | 1.005 | 0.993–1.040 | inconclusive |
| `jinja_float_token` | 0.939 | 0.935–1.002 | inconclusive |
| `django_email_local_part` | 0.957 | 0.919–0.996 | inconclusive |
| `django_email_domain` | 1.011 | 0.983–1.093 | inconclusive |
| `django_url_regex` | 1.030 | 0.984–1.060 | inconclusive |
| `fluent_bit_apache` | 1.007 | 1.000–1.014 | inconclusive |
| `fluent_bit_nginx` | 1.008 | 1.005–1.010 | inconclusive |
| `rails_underscore_regex_step` | 0.952 | 0.945–0.983 | inconclusive |
| `mastodon_hashtag_regex_step` | 1.053 | 1.021–1.053 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.996 | 0.952–1.063 | inconclusive |
| `python_markdown_smart_strong_em_re` | 0.992 | 0.990–0.996 | inconclusive |
| `wordpress_shortcode_captures` | 0.951 | 0.924–0.998 | inconclusive |
| `symfony_grapheme_chunks_1` | 0.978 | 0.950–0.990 | inconclusive |
| `symfony_grapheme_chunks_2` | 0.999 | 0.982–1.001 | inconclusive |
| `literal_first` | 1.015 | 0.940–1.044 | inconclusive |
| `literal_middle` | 1.017 | 1.008–1.152 | inconclusive |
| `literal_end` | 1.069 | 0.987–1.093 | inconclusive |
| `literal_absent` | 1.159 | 1.080–1.330 | inconclusive |

## rust_erroraware / first_use

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.976.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.767 | 0.729–0.781 | comparator faster in every run interval |
| `uuid_v4` | 0.851 | 0.784–0.870 | comparator faster in every run interval |
| `ipv4_validation` | 0.937 | 0.902–0.945 | comparator faster in every run interval |
| `ipv6_validation` | 0.981 | 0.894–1.002 | inconclusive |
| `semver_version_parse` | 1.004 | 0.995–1.014 | inconclusive |
| `semver_hyphen_range_captures` | 0.977 | 0.937–0.995 | inconclusive |
| `jinja_string_token` | 0.960 | 0.918–1.050 | inconclusive |
| `jinja_integer_token` | 1.000 | 0.989–1.002 | inconclusive |
| `jinja_float_token` | 0.997 | 0.991–1.028 | inconclusive |
| `django_email_local_part` | 0.958 | 0.949–0.991 | inconclusive |
| `django_email_domain` | 0.998 | 0.960–1.010 | inconclusive |
| `django_url_regex` | 1.008 | 1.008–1.037 | inconclusive |
| `fluent_bit_apache` | 0.997 | 0.965–1.031 | inconclusive |
| `fluent_bit_nginx` | 1.000 | 0.995–1.042 | inconclusive |
| `rails_underscore_regex_step` | 0.968 | 0.965–0.981 | inconclusive |
| `mastodon_hashtag_regex_step` | 1.019 | 0.920–1.058 | inconclusive |
| `python_markdown_smart_emphasis_re` | 0.997 | 0.993–1.032 | inconclusive |
| `python_markdown_smart_strong_em_re` | 0.999 | 0.999–1.010 | inconclusive |
| `wordpress_shortcode_captures` | 0.965 | 0.963–1.009 | inconclusive |
| `symfony_grapheme_chunks_1` | 0.995 | 0.986–1.014 | inconclusive |
| `symfony_grapheme_chunks_2` | 0.995 | 0.895–1.064 | inconclusive |
| `literal_first` | 0.983 | 0.930–1.041 | inconclusive |
| `literal_middle` | 1.009 | 0.982–1.117 | inconclusive |
| `literal_end` | 1.066 | 0.945–1.103 | inconclusive |
| `literal_absent` | 1.071 | 1.043–1.224 | inconclusive |

## c / steady

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 1.581.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 3.302 | 3.248–3.864 | Ferroni faster in every run interval |
| `uuid_v4` | 3.013 | 2.779–3.404 | Ferroni faster in every run interval |
| `ipv4_validation` | 6.354 | 6.151–6.612 | Ferroni faster in every run interval |
| `ipv6_validation` | 1.530 | 1.460–1.604 | Ferroni faster in every run interval |
| `semver_version_parse` | 0.907 | 0.880–0.956 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 1.074 | 1.057–1.109 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.102 | 1.084–1.124 | Ferroni faster in every run interval |
| `jinja_integer_token` | 0.940 | 0.918–0.961 | comparator faster in every run interval |
| `jinja_float_token` | 0.920 | 0.917–0.995 | inconclusive |
| `django_email_local_part` | 1.495 | 1.440–1.652 | Ferroni faster in every run interval |
| `django_email_domain` | 4.947 | 4.929–5.092 | Ferroni faster in every run interval |
| `django_url_regex` | 1.924 | 1.802–1.959 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.429 | 1.213–1.431 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.388 | 1.350–1.484 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 0.950 | 0.868–0.969 | inconclusive |
| `mastodon_hashtag_regex_step` | 1.370 | 1.326–1.452 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 1.054 | 0.981–1.083 | inconclusive |
| `python_markdown_smart_strong_em_re` | 1.195 | 1.139–1.195 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 0.960 | 0.919–1.025 | inconclusive |
| `symfony_grapheme_chunks_1` | 0.860 | 0.840–0.950 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.898 | 0.887–0.955 | comparator faster in every run interval |
| `literal_first` | 4.232 | 4.165–4.589 | Ferroni faster in every run interval |
| `literal_middle` | 5.011 | 4.744–5.275 | Ferroni faster in every run interval |
| `literal_end` | 5.892 | 5.569–6.033 | Ferroni faster in every run interval |
| `literal_absent` | 3.120 | 2.839–3.394 | Ferroni faster in every run interval |

## c / compile

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.336.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 3.600 | 3.490–3.762 | Ferroni faster in every run interval |
| `uuid_v4` | 4.110 | 4.075–4.225 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.251 | 0.240–0.264 | comparator faster in every run interval |
| `ipv6_validation` | 0.237 | 0.235–0.249 | comparator faster in every run interval |
| `semver_version_parse` | 0.259 | 0.251–0.270 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.231 | 0.208–0.236 | comparator faster in every run interval |
| `jinja_string_token` | 0.141 | 0.141–0.143 | comparator faster in every run interval |
| `jinja_integer_token` | 2.222 | 2.221–2.346 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.508 | 0.504–0.528 | comparator faster in every run interval |
| `django_email_local_part` | 2.278 | 2.163–2.316 | Ferroni faster in every run interval |
| `django_email_domain` | 0.229 | 0.225–0.233 | comparator faster in every run interval |
| `django_url_regex` | 0.392 | 0.391–0.427 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.149 | 0.138–0.149 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.155 | 0.149–0.158 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.355 | 0.337–0.372 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.456 | 0.450–0.520 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.177 | 0.166–0.183 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.131 | 0.130–0.136 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.207 | 0.205–0.216 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.094 | 0.093–0.101 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.084 | 0.084–0.091 | comparator faster in every run interval |
| `literal_first` | 0.267 | 0.246–0.289 | comparator faster in every run interval |
| `literal_middle` | 0.289 | 0.276–0.297 | comparator faster in every run interval |
| `literal_end` | 0.297 | 0.290–0.298 | comparator faster in every run interval |
| `literal_absent` | 0.282 | 0.277–0.293 | comparator faster in every run interval |

## c / first_use

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.383.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 2.891 | 2.880–3.017 | Ferroni faster in every run interval |
| `uuid_v4` | 3.298 | 2.969–3.596 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.235 | 0.233–0.246 | comparator faster in every run interval |
| `ipv6_validation` | 0.263 | 0.244–0.272 | comparator faster in every run interval |
| `semver_version_parse` | 0.284 | 0.271–0.293 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.239 | 0.238–0.265 | comparator faster in every run interval |
| `jinja_string_token` | 0.154 | 0.146–0.160 | comparator faster in every run interval |
| `jinja_integer_token` | 2.398 | 2.272–2.410 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.527 | 0.486–0.589 | comparator faster in every run interval |
| `django_email_local_part` | 2.348 | 2.256–2.453 | Ferroni faster in every run interval |
| `django_email_domain` | 0.253 | 0.247–0.261 | comparator faster in every run interval |
| `django_url_regex` | 0.435 | 0.408–0.458 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.176 | 0.175–0.191 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.195 | 0.185–0.200 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.382 | 0.378–0.396 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.464 | 0.444–0.491 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.236 | 0.229–0.237 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.158 | 0.156–0.168 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.224 | 0.216–0.227 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.182 | 0.169–0.186 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.154 | 0.138–0.155 | comparator faster in every run interval |
| `literal_first` | 0.421 | 0.400–0.448 | comparator faster in every run interval |
| `literal_middle` | 0.429 | 0.428–0.448 | comparator faster in every run interval |
| `literal_end` | 0.455 | 0.450–0.494 | comparator faster in every run interval |
| `literal_absent` | 0.358 | 0.324–0.366 | comparator faster in every run interval |

## onigmo / steady

Common cases: 24; families: 13. Pair-specific family-weighted ratio: 1.982.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 5.412 | 4.990–5.635 | Ferroni faster in every run interval |
| `uuid_v4` | 5.371 | 4.907–5.482 | Ferroni faster in every run interval |
| `ipv4_validation` | 5.936 | 5.612–5.996 | Ferroni faster in every run interval |
| `ipv6_validation` | 2.410 | 2.194–2.509 | Ferroni faster in every run interval |
| `semver_version_parse` | 1.122 | 1.107–1.134 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.082 | 1.066–1.147 | Ferroni faster in every run interval |
| `jinja_string_token` | 0.803 | 0.802–0.843 | comparator faster in every run interval |
| `jinja_integer_token` | 1.128 | 1.087–1.137 | Ferroni faster in every run interval |
| `jinja_float_token` | 1.697 | 1.661–1.739 | Ferroni faster in every run interval |
| `django_email_local_part` | 1.382 | 1.360–1.396 | Ferroni faster in every run interval |
| `django_email_domain` | 8.952 | 8.732–9.430 | Ferroni faster in every run interval |
| `django_url_regex` | 5.111 | 5.077–5.286 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.685 | 1.581–1.711 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.937 | 1.809–2.007 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 0.807 | 0.800–0.816 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 1.498 | 1.493–1.627 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.987 | 0.972–1.071 | inconclusive |
| `python_markdown_smart_strong_em_re` | 1.234 | 1.184–1.253 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 1.096 | 1.076–1.097 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_2` | 2.109 | 2.092–2.182 | Ferroni faster in every run interval |
| `literal_first` | 1.912 | 1.754–1.950 | Ferroni faster in every run interval |
| `literal_middle` | 2.814 | 2.608–2.838 | Ferroni faster in every run interval |
| `literal_end` | 3.534 | 3.165–3.634 | Ferroni faster in every run interval |
| `literal_absent` | 3.212 | 2.878–3.224 | Ferroni faster in every run interval |

## onigmo / compile

Common cases: 24; families: 13. Pair-specific family-weighted ratio: 0.416.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 3.881 | 3.755–3.980 | Ferroni faster in every run interval |
| `uuid_v4` | 4.392 | 4.217–4.453 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.225 | 0.221–0.243 | comparator faster in every run interval |
| `ipv6_validation` | 0.249 | 0.231–0.256 | comparator faster in every run interval |
| `semver_version_parse` | 0.249 | 0.245–0.254 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.246 | 0.237–0.261 | comparator faster in every run interval |
| `jinja_string_token` | 0.124 | 0.124–0.124 | comparator faster in every run interval |
| `jinja_integer_token` | 2.003 | 1.908–2.086 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.540 | 0.537–0.561 | comparator faster in every run interval |
| `django_email_local_part` | 2.407 | 2.306–2.555 | Ferroni faster in every run interval |
| `django_email_domain` | 0.142 | 0.139–0.162 | comparator faster in every run interval |
| `django_url_regex` | 0.308 | 0.305–0.326 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.144 | 0.130–0.145 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.148 | 0.142–0.149 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.336 | 0.325–0.378 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.548 | 0.519–0.556 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.121 | 0.106–0.128 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.102 | 0.101–0.102 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.208 | 0.197–0.218 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 4.020 | 3.948–4.021 | Ferroni faster in every run interval |
| `literal_first` | 0.189 | 0.178–0.201 | comparator faster in every run interval |
| `literal_middle` | 0.204 | 0.199–0.233 | comparator faster in every run interval |
| `literal_end` | 0.208 | 0.202–0.212 | comparator faster in every run interval |
| `literal_absent` | 0.200 | 0.196–0.219 | comparator faster in every run interval |

## onigmo / first_use

Common cases: 24; families: 13. Pair-specific family-weighted ratio: 0.427.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 2.935 | 2.756–2.950 | Ferroni faster in every run interval |
| `uuid_v4` | 3.347 | 3.143–3.369 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.216 | 0.212–0.234 | comparator faster in every run interval |
| `ipv6_validation` | 0.234 | 0.208–0.255 | comparator faster in every run interval |
| `semver_version_parse` | 0.253 | 0.245–0.256 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.241 | 0.237–0.265 | comparator faster in every run interval |
| `jinja_string_token` | 0.130 | 0.122–0.137 | comparator faster in every run interval |
| `jinja_integer_token` | 2.040 | 1.951–2.046 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.548 | 0.546–0.589 | comparator faster in every run interval |
| `django_email_local_part` | 2.396 | 2.381–2.492 | Ferroni faster in every run interval |
| `django_email_domain` | 0.138 | 0.133–0.171 | comparator faster in every run interval |
| `django_url_regex` | 0.312 | 0.308–0.330 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.155 | 0.152–0.158 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.172 | 0.169–0.173 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.349 | 0.349–0.408 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.505 | 0.472–0.555 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.154 | 0.150–0.161 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.123 | 0.120–0.128 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.224 | 0.210–0.227 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 3.870 | 3.817–4.157 | Ferroni faster in every run interval |
| `literal_first` | 0.262 | 0.236–0.263 | comparator faster in every run interval |
| `literal_middle` | 0.275 | 0.269–0.279 | comparator faster in every run interval |
| `literal_end` | 0.289 | 0.286–0.370 | comparator faster in every run interval |
| `literal_absent` | 0.304 | 0.276–0.312 | comparator faster in every run interval |

## pcre2_jit / steady

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.372.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.786 | 0.758–0.844 | comparator faster in every run interval |
| `uuid_v4` | 0.903 | 0.884–1.012 | inconclusive |
| `ipv4_validation` | 1.459 | 1.453–1.461 | Ferroni faster in every run interval |
| `ipv6_validation` | 0.407 | 0.401–0.413 | comparator faster in every run interval |
| `semver_version_parse` | 0.270 | 0.263–0.281 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.426 | 0.392–0.435 | comparator faster in every run interval |
| `jinja_string_token` | 0.434 | 0.417–0.454 | comparator faster in every run interval |
| `jinja_integer_token` | 0.431 | 0.409–0.432 | comparator faster in every run interval |
| `jinja_float_token` | 0.466 | 0.460–0.492 | comparator faster in every run interval |
| `django_email_local_part` | 0.481 | 0.475–0.484 | comparator faster in every run interval |
| `django_email_domain` | 0.097 | 0.095–0.100 | comparator faster in every run interval |
| `django_url_regex` | 0.126 | 0.123–0.137 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.305 | 0.301–0.326 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.316 | 0.304–0.329 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.275 | 0.272–0.293 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.231 | 0.226–0.242 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.300 | 0.280–0.321 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.245 | 0.239–0.251 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.363 | 0.335–0.371 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.365 | 0.360–0.391 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.358 | 0.352–0.383 | comparator faster in every run interval |
| `literal_first` | 1.474 | 1.425–1.648 | Ferroni faster in every run interval |
| `literal_middle` | 1.484 | 1.402–1.561 | Ferroni faster in every run interval |
| `literal_end` | 1.376 | 1.277–1.591 | Ferroni faster in every run interval |
| `literal_absent` | 1.368 | 1.241–1.381 | Ferroni faster in every run interval |

## pcre2_jit / compile

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.308.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.243 | 0.238–0.244 | comparator faster in every run interval |
| `uuid_v4` | 0.241 | 0.238–0.252 | comparator faster in every run interval |
| `ipv4_validation` | 0.272 | 0.260–0.283 | comparator faster in every run interval |
| `ipv6_validation` | 0.258 | 0.244–0.267 | comparator faster in every run interval |
| `semver_version_parse` | 0.366 | 0.333–0.369 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.301 | 0.272–0.319 | comparator faster in every run interval |
| `jinja_string_token` | 0.282 | 0.279–0.301 | comparator faster in every run interval |
| `jinja_integer_token` | 0.309 | 0.293–0.342 | comparator faster in every run interval |
| `jinja_float_token` | 0.210 | 0.207–0.237 | comparator faster in every run interval |
| `django_email_local_part` | 0.302 | 0.302–0.312 | comparator faster in every run interval |
| `django_email_domain` | 0.047 | 0.043–0.052 | comparator faster in every run interval |
| `django_url_regex` | 0.056 | 0.053–0.059 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.244 | 0.228–0.253 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.251 | 0.243–0.267 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.825 | 0.741–0.935 | inconclusive |
| `mastodon_hashtag_regex_step` | 0.154 | 0.139–0.157 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.583 | 0.563–0.602 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.409 | 0.399–0.415 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.395 | 0.387–0.401 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.324 | 0.315–0.329 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.295 | 0.294–0.314 | comparator faster in every run interval |
| `literal_first` | 3.282 | 2.744–3.341 | Ferroni faster in every run interval |
| `literal_middle` | 3.195 | 3.127–3.395 | Ferroni faster in every run interval |
| `literal_end` | 3.412 | 3.304–3.522 | Ferroni faster in every run interval |
| `literal_absent` | 3.303 | 3.230–3.614 | Ferroni faster in every run interval |

## pcre2_jit / first_use

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.336.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.196 | 0.188–0.203 | comparator faster in every run interval |
| `uuid_v4` | 0.206 | 0.187–0.207 | comparator faster in every run interval |
| `ipv4_validation` | 0.293 | 0.287–0.378 | comparator faster in every run interval |
| `ipv6_validation` | 0.253 | 0.235–0.270 | comparator faster in every run interval |
| `semver_version_parse` | 0.411 | 0.392–0.415 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.308 | 0.306–0.329 | comparator faster in every run interval |
| `jinja_string_token` | 0.320 | 0.317–0.368 | comparator faster in every run interval |
| `jinja_integer_token` | 0.334 | 0.330–0.343 | comparator faster in every run interval |
| `jinja_float_token` | 0.258 | 0.249–0.273 | comparator faster in every run interval |
| `django_email_local_part` | 0.342 | 0.327–0.346 | comparator faster in every run interval |
| `django_email_domain` | 0.045 | 0.043–0.047 | comparator faster in every run interval |
| `django_url_regex` | 0.055 | 0.053–0.059 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.288 | 0.255–0.290 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.290 | 0.277–0.301 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 1.010 | 0.924–1.116 | inconclusive |
| `mastodon_hashtag_regex_step` | 0.168 | 0.147–0.178 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.691 | 0.664–0.735 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.484 | 0.466–0.497 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.423 | 0.402–0.434 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.451 | 0.448–0.503 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.429 | 0.411–0.482 | comparator faster in every run interval |
| `literal_first` | 3.208 | 3.159–3.294 | Ferroni faster in every run interval |
| `literal_middle` | 3.116 | 3.039–3.347 | Ferroni faster in every run interval |
| `literal_end` | 3.318 | 3.293–3.555 | Ferroni faster in every run interval |
| `literal_absent` | 3.425 | 3.046–3.728 | Ferroni faster in every run interval |

## pcre2 / steady

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 1.059.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.420 | 1.417–1.614 | Ferroni faster in every run interval |
| `uuid_v4` | 1.824 | 1.629–1.960 | Ferroni faster in every run interval |
| `ipv4_validation` | 8.131 | 7.978–8.352 | Ferroni faster in every run interval |
| `ipv6_validation` | 2.330 | 2.281–2.459 | Ferroni faster in every run interval |
| `semver_version_parse` | 0.885 | 0.801–0.942 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 1.562 | 1.545–1.679 | Ferroni faster in every run interval |
| `jinja_string_token` | 0.957 | 0.883–0.965 | comparator faster in every run interval |
| `jinja_integer_token` | 1.439 | 1.366–1.477 | Ferroni faster in every run interval |
| `jinja_float_token` | 1.393 | 1.385–1.402 | Ferroni faster in every run interval |
| `django_email_local_part` | 1.454 | 1.401–1.476 | Ferroni faster in every run interval |
| `django_email_domain` | 0.338 | 0.329–0.342 | comparator faster in every run interval |
| `django_url_regex` | 0.341 | 0.319–0.380 | comparator faster in every run interval |
| `fluent_bit_apache` | 1.003 | 0.984–1.008 | inconclusive |
| `fluent_bit_nginx` | 1.073 | 1.022–1.123 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 0.849 | 0.761–0.884 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.528 | 0.492–0.530 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 1.393 | 1.343–1.453 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 1.912 | 1.908–1.961 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 0.988 | 0.959–1.008 | inconclusive |
| `symfony_grapheme_chunks_1` | 0.560 | 0.531–0.562 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.504 | 0.467–0.504 | comparator faster in every run interval |
| `literal_first` | 2.554 | 2.545–2.752 | Ferroni faster in every run interval |
| `literal_middle` | 2.595 | 2.548–2.689 | Ferroni faster in every run interval |
| `literal_end` | 2.394 | 2.232–2.574 | Ferroni faster in every run interval |
| `literal_absent` | 1.359 | 1.345–1.381 | Ferroni faster in every run interval |

## pcre2 / compile

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.072.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.076 | 0.076–0.082 | comparator faster in every run interval |
| `uuid_v4` | 0.082 | 0.073–0.085 | comparator faster in every run interval |
| `ipv4_validation` | 0.075 | 0.075–0.076 | comparator faster in every run interval |
| `ipv6_validation` | 0.075 | 0.073–0.079 | comparator faster in every run interval |
| `semver_version_parse` | 0.085 | 0.080–0.086 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.074 | 0.064–0.081 | comparator faster in every run interval |
| `jinja_string_token` | 0.048 | 0.045–0.049 | comparator faster in every run interval |
| `jinja_integer_token` | 0.080 | 0.078–0.081 | comparator faster in every run interval |
| `jinja_float_token` | 0.036 | 0.035–0.038 | comparator faster in every run interval |
| `django_email_local_part` | 0.124 | 0.114–0.131 | comparator faster in every run interval |
| `django_email_domain` | 0.042 | 0.037–0.043 | comparator faster in every run interval |
| `django_url_regex` | 0.044 | 0.038–0.046 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.040 | 0.040–0.046 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.044 | 0.042–0.045 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.215 | 0.207–0.231 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.077 | 0.073–0.079 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.065 | 0.060–0.073 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.050 | 0.046–0.050 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.088 | 0.088–0.090 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.031 | 0.029–0.032 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.026 | 0.025–0.029 | comparator faster in every run interval |
| `literal_first` | 0.169 | 0.143–0.171 | comparator faster in every run interval |
| `literal_middle` | 0.174 | 0.172–0.177 | comparator faster in every run interval |
| `literal_end` | 0.178 | 0.175–0.182 | comparator faster in every run interval |
| `literal_absent` | 0.172 | 0.169–0.178 | comparator faster in every run interval |

## pcre2 / first_use

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.121.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.090 | 0.088–0.097 | comparator faster in every run interval |
| `uuid_v4` | 0.093 | 0.091–0.099 | comparator faster in every run interval |
| `ipv4_validation` | 0.107 | 0.105–0.111 | comparator faster in every run interval |
| `ipv6_validation` | 0.079 | 0.067–0.080 | comparator faster in every run interval |
| `semver_version_parse` | 0.107 | 0.104–0.109 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.085 | 0.082–0.099 | comparator faster in every run interval |
| `jinja_string_token` | 0.089 | 0.087–0.097 | comparator faster in every run interval |
| `jinja_integer_token` | 0.115 | 0.112–0.116 | comparator faster in every run interval |
| `jinja_float_token` | 0.058 | 0.055–0.058 | comparator faster in every run interval |
| `django_email_local_part` | 0.149 | 0.147–0.157 | comparator faster in every run interval |
| `django_email_domain` | 0.041 | 0.036–0.047 | comparator faster in every run interval |
| `django_url_regex` | 0.040 | 0.039–0.048 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.082 | 0.075–0.087 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.085 | 0.083–0.085 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.336 | 0.313–0.356 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.084 | 0.076–0.089 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.182 | 0.169–0.182 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.122 | 0.109–0.127 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.116 | 0.114–0.118 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.176 | 0.159–0.176 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.135 | 0.129–0.140 | comparator faster in every run interval |
| `literal_first` | 0.941 | 0.890–0.954 | inconclusive |
| `literal_middle` | 0.895 | 0.850–0.940 | inconclusive |
| `literal_end` | 0.900 | 0.892–0.981 | inconclusive |
| `literal_absent` | 0.891 | 0.861–1.014 | inconclusive |

## fancy_regex / steady

Common cases: 21; families: 11. Pair-specific family-weighted ratio: 1.387.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.072 | 1.063–1.202 | Ferroni faster in every run interval |
| `uuid_v4` | 1.147 | 1.137–1.206 | Ferroni faster in every run interval |
| `ipv4_validation` | 1.279 | 1.274–1.368 | Ferroni faster in every run interval |
| `ipv6_validation` | 0.187 | 0.185–0.194 | comparator faster in every run interval |
| `semver_version_parse` | 1.430 | 1.305–1.515 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.557 | 1.477–1.737 | Ferroni faster in every run interval |
| `jinja_string_token` | 0.995 | 0.989–1.009 | inconclusive |
| `jinja_integer_token` | 1.303 | 1.240–1.314 | Ferroni faster in every run interval |
| `jinja_float_token` | 2.171 | 2.062–2.267 | Ferroni faster in every run interval |
| `django_email_domain` | 1.187 | 1.041–1.216 | Ferroni faster in every run interval |
| `django_url_regex` | 2.462 | 2.194–2.563 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.235 | 1.173–1.245 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.314 | 1.143–1.389 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 2.420 | 2.357–2.448 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 1.343 | 1.235–1.395 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 2.278 | 2.159–2.328 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 1.648 | 1.622–1.714 | Ferroni faster in every run interval |
| `literal_first` | 1.230 | 1.193–1.295 | Ferroni faster in every run interval |
| `literal_middle` | 1.220 | 1.209–1.277 | Ferroni faster in every run interval |
| `literal_end` | 1.205 | 1.090–1.209 | Ferroni faster in every run interval |
| `literal_absent` | 1.280 | 1.230–1.313 | Ferroni faster in every run interval |

## fancy_regex / compile

Common cases: 21; families: 11. Pair-specific family-weighted ratio: 1.445.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.986 | 0.922–1.049 | inconclusive |
| `uuid_v4` | 0.897 | 0.866–1.003 | inconclusive |
| `ipv4_validation` | 0.802 | 0.776–0.861 | comparator faster in every run interval |
| `ipv6_validation` | 0.889 | 0.871–0.925 | comparator faster in every run interval |
| `semver_version_parse` | 14.402 | 14.260–14.928 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 9.508 | 8.251–9.664 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.746 | 1.739–1.802 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.961 | 1.944–2.108 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.260 | 0.258–0.262 | comparator faster in every run interval |
| `django_email_domain` | 2.598 | 2.466–2.736 | Ferroni faster in every run interval |
| `django_url_regex` | 2.287 | 2.269–2.304 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.392 | 1.373–1.417 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.430 | 1.393–1.556 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.157 | 1.122–1.210 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.553 | 0.532–0.565 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.434 | 0.420–0.454 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 1.052 | 1.010–1.088 | inconclusive |
| `literal_first` | 1.240 | 1.095–1.304 | Ferroni faster in every run interval |
| `literal_middle` | 1.311 | 1.256–1.322 | Ferroni faster in every run interval |
| `literal_end` | 1.296 | 1.257–1.383 | Ferroni faster in every run interval |
| `literal_absent` | 1.308 | 1.229–1.312 | Ferroni faster in every run interval |

## fancy_regex / first_use

Common cases: 21; families: 11. Pair-specific family-weighted ratio: 1.520.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.995 | 0.979–0.995 | inconclusive |
| `uuid_v4` | 0.995 | 0.939–1.155 | inconclusive |
| `ipv4_validation` | 0.859 | 0.820–0.870 | comparator faster in every run interval |
| `ipv6_validation` | 0.877 | 0.865–0.954 | comparator faster in every run interval |
| `semver_version_parse` | 14.950 | 14.249–15.664 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 9.321 | 8.711–9.783 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.787 | 1.624–1.828 | Ferroni faster in every run interval |
| `jinja_integer_token` | 2.104 | 1.932–2.140 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.275 | 0.273–0.278 | comparator faster in every run interval |
| `django_email_domain` | 2.514 | 2.394–2.569 | Ferroni faster in every run interval |
| `django_url_regex` | 2.264 | 2.249–2.296 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.570 | 1.487–1.578 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.648 | 1.637–1.777 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.374 | 1.323–1.420 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.576 | 0.562–0.585 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.457 | 0.440–0.464 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 1.156 | 1.124–1.193 | Ferroni faster in every run interval |
| `literal_first` | 1.307 | 1.237–1.327 | Ferroni faster in every run interval |
| `literal_middle` | 1.236 | 1.202–1.342 | Ferroni faster in every run interval |
| `literal_end` | 1.329 | 1.278–1.457 | Ferroni faster in every run interval |
| `literal_absent` | 1.350 | 1.319–1.634 | Ferroni faster in every run interval |

## fancy_regex_seek / steady

Common cases: 21; families: 11. Pair-specific family-weighted ratio: 1.402.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.131 | 1.072–1.271 | Ferroni faster in every run interval |
| `uuid_v4` | 1.137 | 1.095–1.255 | Ferroni faster in every run interval |
| `ipv4_validation` | 1.323 | 1.289–1.342 | Ferroni faster in every run interval |
| `ipv6_validation` | 0.189 | 0.185–0.195 | comparator faster in every run interval |
| `semver_version_parse` | 1.441 | 1.347–1.590 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.536 | 1.490–1.742 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.004 | 0.979–1.087 | inconclusive |
| `jinja_integer_token` | 1.287 | 1.284–1.356 | Ferroni faster in every run interval |
| `jinja_float_token` | 2.256 | 2.071–2.301 | Ferroni faster in every run interval |
| `django_email_domain` | 1.163 | 1.013–1.167 | inconclusive |
| `django_url_regex` | 2.511 | 2.162–2.545 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.233 | 1.172–1.258 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.300 | 1.202–1.343 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 2.413 | 2.358–2.520 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 1.367 | 1.257–1.407 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 2.192 | 2.179–2.216 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 1.783 | 1.766–1.839 | Ferroni faster in every run interval |
| `literal_first` | 1.263 | 1.199–1.321 | Ferroni faster in every run interval |
| `literal_middle` | 1.262 | 1.196–1.297 | Ferroni faster in every run interval |
| `literal_end` | 1.213 | 1.127–1.217 | Ferroni faster in every run interval |
| `literal_absent` | 1.244 | 1.199–1.259 | Ferroni faster in every run interval |

## fancy_regex_seek / compile

Common cases: 21; families: 11. Pair-specific family-weighted ratio: 1.609.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.928 | 0.907–0.954 | comparator faster in every run interval |
| `uuid_v4` | 0.902 | 0.841–1.029 | inconclusive |
| `ipv4_validation` | 0.801 | 0.768–0.835 | comparator faster in every run interval |
| `ipv6_validation` | 0.876 | 0.875–0.947 | comparator faster in every run interval |
| `semver_version_parse` | 14.894 | 14.454–15.239 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 9.466 | 7.938–9.762 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.781 | 1.770–2.092 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.964 | 1.912–2.017 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.258 | 0.258–0.260 | comparator faster in every run interval |
| `django_email_domain` | 2.479 | 2.346–2.561 | Ferroni faster in every run interval |
| `django_url_regex` | 2.338 | 2.250–2.347 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.421 | 1.371–1.433 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.488 | 1.462–1.526 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.196 | 1.163–1.221 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.570 | 0.561–0.589 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.448 | 0.417–0.449 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 3.271 | 3.149–3.416 | Ferroni faster in every run interval |
| `literal_first` | 1.176 | 1.165–1.297 | Ferroni faster in every run interval |
| `literal_middle` | 1.361 | 1.227–1.386 | Ferroni faster in every run interval |
| `literal_end` | 1.331 | 1.243–1.343 | Ferroni faster in every run interval |
| `literal_absent` | 1.253 | 1.234–1.472 | Ferroni faster in every run interval |

## fancy_regex_seek / first_use

Common cases: 21; families: 11. Pair-specific family-weighted ratio: 1.678.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.005 | 0.963–1.013 | inconclusive |
| `uuid_v4` | 1.022 | 0.941–1.031 | inconclusive |
| `ipv4_validation` | 0.859 | 0.836–0.871 | comparator faster in every run interval |
| `ipv6_validation` | 0.867 | 0.856–0.952 | comparator faster in every run interval |
| `semver_version_parse` | 14.610 | 14.596–14.731 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 9.159 | 8.210–9.759 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.734 | 1.634–1.971 | Ferroni faster in every run interval |
| `jinja_integer_token` | 2.022 | 1.886–2.091 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.266 | 0.266–0.280 | comparator faster in every run interval |
| `django_email_domain` | 2.350 | 2.271–2.580 | Ferroni faster in every run interval |
| `django_url_regex` | 2.265 | 2.245–2.295 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.553 | 1.470–1.559 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.664 | 1.601–1.720 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.412 | 1.410–1.430 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.564 | 0.561–0.595 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.462 | 0.451–0.466 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 3.767 | 3.653–3.785 | Ferroni faster in every run interval |
| `literal_first` | 1.342 | 1.155–1.542 | Ferroni faster in every run interval |
| `literal_middle` | 1.253 | 1.243–1.291 | Ferroni faster in every run interval |
| `literal_end` | 1.259 | 1.241–1.330 | Ferroni faster in every run interval |
| `literal_absent` | 1.324 | 1.266–1.499 | Ferroni faster in every run interval |

## regex / steady

Common cases: 14; families: 6. Pair-specific family-weighted ratio: 1.015.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.387 | 1.361–1.558 | Ferroni faster in every run interval |
| `uuid_v4` | 1.507 | 1.397–1.520 | Ferroni faster in every run interval |
| `ipv4_validation` | 1.617 | 1.607–1.659 | Ferroni faster in every run interval |
| `ipv6_validation` | 0.225 | 0.224–0.237 | comparator faster in every run interval |
| `semver_version_parse` | 1.242 | 1.148–1.366 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.332 | 1.294–1.503 | Ferroni faster in every run interval |
| `jinja_string_token` | 0.628 | 0.609–0.640 | comparator faster in every run interval |
| `jinja_integer_token` | 0.997 | 0.977–1.021 | inconclusive |
| `fluent_bit_apache` | 1.063 | 1.058–1.088 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.237 | 1.225–1.272 | Ferroni faster in every run interval |
| `literal_first` | 1.084 | 1.069–1.136 | Ferroni faster in every run interval |
| `literal_middle` | 1.075 | 1.053–1.122 | Ferroni faster in every run interval |
| `literal_end` | 1.059 | 0.983–1.096 | inconclusive |
| `literal_absent` | 1.088 | 1.057–1.097 | Ferroni faster in every run interval |

## regex / compile

Common cases: 14; families: 6. Pair-specific family-weighted ratio: 1.680.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.738 | 0.726–0.755 | comparator faster in every run interval |
| `uuid_v4` | 0.702 | 0.651–0.730 | comparator faster in every run interval |
| `ipv4_validation` | 0.769 | 0.705–0.790 | comparator faster in every run interval |
| `ipv6_validation` | 0.808 | 0.789–0.823 | comparator faster in every run interval |
| `semver_version_parse` | 14.390 | 14.152–14.555 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 9.973 | 8.071–10.489 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.706 | 1.694–1.816 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.816 | 1.703–1.948 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.370 | 1.320–1.414 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.446 | 1.412–1.472 | Ferroni faster in every run interval |
| `literal_first` | 1.266 | 1.129–1.312 | Ferroni faster in every run interval |
| `literal_middle` | 1.369 | 1.217–1.395 | Ferroni faster in every run interval |
| `literal_end` | 1.421 | 1.279–1.427 | Ferroni faster in every run interval |
| `literal_absent` | 1.302 | 1.234–1.307 | Ferroni faster in every run interval |

## regex / first_use

Common cases: 14; families: 6. Pair-specific family-weighted ratio: 1.753.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.810 | 0.782–0.836 | comparator faster in every run interval |
| `uuid_v4` | 0.780 | 0.764–0.835 | comparator faster in every run interval |
| `ipv4_validation` | 0.765 | 0.755–0.767 | comparator faster in every run interval |
| `ipv6_validation` | 0.829 | 0.754–0.837 | comparator faster in every run interval |
| `semver_version_parse` | 14.715 | 14.479–14.722 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 9.672 | 8.832–10.078 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.775 | 1.768–1.817 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.853 | 1.809–1.937 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.526 | 1.404–1.558 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.611 | 1.609–1.719 | Ferroni faster in every run interval |
| `literal_first` | 1.324 | 1.243–1.339 | Ferroni faster in every run interval |
| `literal_middle` | 1.311 | 1.267–1.367 | Ferroni faster in every run interval |
| `literal_end` | 1.424 | 1.355–1.452 | Ferroni faster in every run interval |
| `literal_absent` | 1.351 | 1.307–1.689 | Ferroni faster in every run interval |

Raw samples, estimates, confidence intervals, failures, eligibility reasons, corpus snapshot and execution order are retained beside this report.

Memory, where requested, is fresh-process peak RSS including the binary, runtime, parsed catalog, compilation, input/output and allocator. It is not isolated compiled-pattern memory.
