# Production regex comparison

Host: Linux-6.6.141-x86_64-with-glibc2.39; x86_64.

Publication candidate: review host stability, raw samples, coverage and run intervals before publishing.

Ratios are comparator / Ferroni. Compile and first-use times concern one pattern; steady times concern the complete fixture batch.

Each comparison below uses only its explicitly listed common tasks. Families have equal aggregate weight; architectures are never combined.

## Eligibility

| Case | Engine | Status |
| --- | --- | --- |
| `uuid_shape` | rust | eligible |
| `uuid_shape` | rust_erroraware | eligible |
| `uuid_shape` | c | eligible |
| `uuid_shape` | onigmo | eligible |
| `uuid_shape` | pcre2_jit | eligible |
| `uuid_shape` | pcre2 | eligible |
| `uuid_shape` | fancy_regex | eligible |
| `uuid_shape` | fancy_regex_seek | eligible |
| `uuid_shape` | regex | eligible |
| `uuid_v4` | rust | eligible |
| `uuid_v4` | rust_erroraware | eligible |
| `uuid_v4` | c | eligible |
| `uuid_v4` | onigmo | eligible |
| `uuid_v4` | pcre2_jit | eligible |
| `uuid_v4` | pcre2 | eligible |
| `uuid_v4` | fancy_regex | eligible |
| `uuid_v4` | fancy_regex_seek | eligible |
| `uuid_v4` | regex | eligible |
| `ipv4_validation` | rust | eligible |
| `ipv4_validation` | rust_erroraware | eligible |
| `ipv4_validation` | c | eligible |
| `ipv4_validation` | onigmo | eligible |
| `ipv4_validation` | pcre2_jit | eligible |
| `ipv4_validation` | pcre2 | eligible |
| `ipv4_validation` | fancy_regex | eligible |
| `ipv4_validation` | fancy_regex_seek | eligible |
| `ipv4_validation` | regex | eligible |
| `ipv6_validation` | rust | eligible |
| `ipv6_validation` | rust_erroraware | eligible |
| `ipv6_validation` | c | eligible |
| `ipv6_validation` | onigmo | eligible |
| `ipv6_validation` | pcre2_jit | eligible |
| `ipv6_validation` | pcre2 | eligible |
| `ipv6_validation` | fancy_regex | eligible |
| `ipv6_validation` | fancy_regex_seek | eligible |
| `ipv6_validation` | regex | eligible |
| `semver_version_parse` | rust | eligible |
| `semver_version_parse` | rust_erroraware | eligible |
| `semver_version_parse` | c | eligible |
| `semver_version_parse` | onigmo | eligible |
| `semver_version_parse` | pcre2_jit | eligible |
| `semver_version_parse` | pcre2 | eligible |
| `semver_version_parse` | fancy_regex | eligible |
| `semver_version_parse` | fancy_regex_seek | eligible |
| `semver_version_parse` | regex | eligible |
| `semver_hyphen_range_captures` | rust | eligible |
| `semver_hyphen_range_captures` | rust_erroraware | eligible |
| `semver_hyphen_range_captures` | c | eligible |
| `semver_hyphen_range_captures` | onigmo | eligible |
| `semver_hyphen_range_captures` | pcre2_jit | eligible |
| `semver_hyphen_range_captures` | pcre2 | eligible |
| `semver_hyphen_range_captures` | fancy_regex | eligible |
| `semver_hyphen_range_captures` | fancy_regex_seek | eligible |
| `semver_hyphen_range_captures` | regex | eligible |
| `jinja_string_token` | rust | eligible |
| `jinja_string_token` | rust_erroraware | eligible |
| `jinja_string_token` | c | eligible |
| `jinja_string_token` | onigmo | eligible |
| `jinja_string_token` | pcre2_jit | eligible |
| `jinja_string_token` | pcre2 | eligible |
| `jinja_string_token` | fancy_regex | eligible |
| `jinja_string_token` | fancy_regex_seek | eligible |
| `jinja_string_token` | regex | eligible |
| `jinja_integer_token` | rust | eligible |
| `jinja_integer_token` | rust_erroraware | eligible |
| `jinja_integer_token` | c | eligible |
| `jinja_integer_token` | onigmo | eligible |
| `jinja_integer_token` | pcre2_jit | eligible |
| `jinja_integer_token` | pcre2 | eligible |
| `jinja_integer_token` | fancy_regex | eligible |
| `jinja_integer_token` | fancy_regex_seek | eligible |
| `jinja_integer_token` | regex | eligible |
| `jinja_float_token` | rust | eligible |
| `jinja_float_token` | rust_erroraware | eligible |
| `jinja_float_token` | c | eligible |
| `jinja_float_token` | onigmo | eligible |
| `jinja_float_token` | pcre2_jit | eligible |
| `jinja_float_token` | pcre2 | eligible |
| `jinja_float_token` | fancy_regex | eligible |
| `jinja_float_token` | fancy_regex_seek | eligible |
| `jinja_float_token` | regex | syntax_rejected |
| `django_email_local_part` | rust | eligible |
| `django_email_local_part` | rust_erroraware | eligible |
| `django_email_local_part` | c | eligible |
| `django_email_local_part` | onigmo | eligible |
| `django_email_local_part` | pcre2_jit | eligible |
| `django_email_local_part` | pcre2 | eligible |
| `django_email_local_part` | fancy_regex | syntax_rejected |
| `django_email_local_part` | fancy_regex_seek | syntax_rejected |
| `django_email_local_part` | regex | syntax_rejected |
| `django_email_domain` | rust | eligible |
| `django_email_domain` | rust_erroraware | eligible |
| `django_email_domain` | c | eligible |
| `django_email_domain` | onigmo | eligible |
| `django_email_domain` | pcre2_jit | eligible |
| `django_email_domain` | pcre2 | eligible |
| `django_email_domain` | fancy_regex | eligible |
| `django_email_domain` | fancy_regex_seek | eligible |
| `django_email_domain` | regex | syntax_rejected |
| `django_url_regex` | rust | eligible |
| `django_url_regex` | rust_erroraware | eligible |
| `django_url_regex` | c | eligible |
| `django_url_regex` | onigmo | eligible |
| `django_url_regex` | pcre2_jit | eligible |
| `django_url_regex` | pcre2 | eligible |
| `django_url_regex` | fancy_regex | eligible |
| `django_url_regex` | fancy_regex_seek | eligible |
| `django_url_regex` | regex | syntax_rejected |
| `fluent_bit_apache` | rust | eligible |
| `fluent_bit_apache` | rust_erroraware | eligible |
| `fluent_bit_apache` | c | eligible |
| `fluent_bit_apache` | onigmo | eligible |
| `fluent_bit_apache` | pcre2_jit | eligible |
| `fluent_bit_apache` | pcre2 | eligible |
| `fluent_bit_apache` | fancy_regex | eligible |
| `fluent_bit_apache` | fancy_regex_seek | eligible |
| `fluent_bit_apache` | regex | eligible |
| `fluent_bit_nginx` | rust | eligible |
| `fluent_bit_nginx` | rust_erroraware | eligible |
| `fluent_bit_nginx` | c | eligible |
| `fluent_bit_nginx` | onigmo | eligible |
| `fluent_bit_nginx` | pcre2_jit | eligible |
| `fluent_bit_nginx` | pcre2 | eligible |
| `fluent_bit_nginx` | fancy_regex | eligible |
| `fluent_bit_nginx` | fancy_regex_seek | eligible |
| `fluent_bit_nginx` | regex | eligible |
| `rails_underscore_regex_step` | rust | eligible |
| `rails_underscore_regex_step` | rust_erroraware | eligible |
| `rails_underscore_regex_step` | c | eligible |
| `rails_underscore_regex_step` | onigmo | eligible |
| `rails_underscore_regex_step` | pcre2_jit | eligible |
| `rails_underscore_regex_step` | pcre2 | eligible |
| `rails_underscore_regex_step` | fancy_regex | eligible |
| `rails_underscore_regex_step` | fancy_regex_seek | eligible |
| `rails_underscore_regex_step` | regex | syntax_rejected |
| `mastodon_hashtag_regex_step` | rust | eligible |
| `mastodon_hashtag_regex_step` | rust_erroraware | eligible |
| `mastodon_hashtag_regex_step` | c | eligible |
| `mastodon_hashtag_regex_step` | onigmo | eligible |
| `mastodon_hashtag_regex_step` | pcre2_jit | eligible |
| `mastodon_hashtag_regex_step` | pcre2 | eligible |
| `mastodon_hashtag_regex_step` | fancy_regex | semantic_difference |
| `mastodon_hashtag_regex_step` | fancy_regex_seek | semantic_difference |
| `mastodon_hashtag_regex_step` | regex | syntax_rejected |
| `python_markdown_smart_emphasis_re` | rust | eligible |
| `python_markdown_smart_emphasis_re` | rust_erroraware | eligible |
| `python_markdown_smart_emphasis_re` | c | eligible |
| `python_markdown_smart_emphasis_re` | onigmo | eligible |
| `python_markdown_smart_emphasis_re` | pcre2_jit | eligible |
| `python_markdown_smart_emphasis_re` | pcre2 | eligible |
| `python_markdown_smart_emphasis_re` | fancy_regex | eligible |
| `python_markdown_smart_emphasis_re` | fancy_regex_seek | eligible |
| `python_markdown_smart_emphasis_re` | regex | syntax_rejected |
| `python_markdown_smart_strong_em_re` | rust | eligible |
| `python_markdown_smart_strong_em_re` | rust_erroraware | eligible |
| `python_markdown_smart_strong_em_re` | c | eligible |
| `python_markdown_smart_strong_em_re` | onigmo | eligible |
| `python_markdown_smart_strong_em_re` | pcre2_jit | eligible |
| `python_markdown_smart_strong_em_re` | pcre2 | eligible |
| `python_markdown_smart_strong_em_re` | fancy_regex | eligible |
| `python_markdown_smart_strong_em_re` | fancy_regex_seek | eligible |
| `python_markdown_smart_strong_em_re` | regex | syntax_rejected |
| `wordpress_shortcode_captures` | rust | eligible |
| `wordpress_shortcode_captures` | rust_erroraware | eligible |
| `wordpress_shortcode_captures` | c | eligible |
| `wordpress_shortcode_captures` | onigmo | eligible |
| `wordpress_shortcode_captures` | pcre2_jit | eligible |
| `wordpress_shortcode_captures` | pcre2 | eligible |
| `wordpress_shortcode_captures` | fancy_regex | eligible |
| `wordpress_shortcode_captures` | fancy_regex_seek | eligible |
| `wordpress_shortcode_captures` | regex | syntax_rejected |
| `symfony_grapheme_chunks_1` | rust | eligible |
| `symfony_grapheme_chunks_1` | rust_erroraware | eligible |
| `symfony_grapheme_chunks_1` | c | eligible |
| `symfony_grapheme_chunks_1` | onigmo | semantic_difference |
| `symfony_grapheme_chunks_1` | pcre2_jit | eligible |
| `symfony_grapheme_chunks_1` | pcre2 | eligible |
| `symfony_grapheme_chunks_1` | fancy_regex | syntax_rejected |
| `symfony_grapheme_chunks_1` | fancy_regex_seek | syntax_rejected |
| `symfony_grapheme_chunks_1` | regex | syntax_rejected |
| `symfony_grapheme_chunks_2` | rust | eligible |
| `symfony_grapheme_chunks_2` | rust_erroraware | eligible |
| `symfony_grapheme_chunks_2` | c | eligible |
| `symfony_grapheme_chunks_2` | onigmo | eligible |
| `symfony_grapheme_chunks_2` | pcre2_jit | eligible |
| `symfony_grapheme_chunks_2` | pcre2 | eligible |
| `symfony_grapheme_chunks_2` | fancy_regex | syntax_rejected |
| `symfony_grapheme_chunks_2` | fancy_regex_seek | syntax_rejected |
| `symfony_grapheme_chunks_2` | regex | syntax_rejected |
| `literal_first` | rust | eligible |
| `literal_first` | rust_erroraware | eligible |
| `literal_first` | c | eligible |
| `literal_first` | onigmo | eligible |
| `literal_first` | pcre2_jit | eligible |
| `literal_first` | pcre2 | eligible |
| `literal_first` | fancy_regex | eligible |
| `literal_first` | fancy_regex_seek | eligible |
| `literal_first` | regex | eligible |
| `literal_middle` | rust | eligible |
| `literal_middle` | rust_erroraware | eligible |
| `literal_middle` | c | eligible |
| `literal_middle` | onigmo | eligible |
| `literal_middle` | pcre2_jit | eligible |
| `literal_middle` | pcre2 | eligible |
| `literal_middle` | fancy_regex | eligible |
| `literal_middle` | fancy_regex_seek | eligible |
| `literal_middle` | regex | eligible |
| `literal_end` | rust | eligible |
| `literal_end` | rust_erroraware | eligible |
| `literal_end` | c | eligible |
| `literal_end` | onigmo | eligible |
| `literal_end` | pcre2_jit | eligible |
| `literal_end` | pcre2 | eligible |
| `literal_end` | fancy_regex | eligible |
| `literal_end` | fancy_regex_seek | eligible |
| `literal_end` | regex | eligible |
| `literal_absent` | rust | eligible |
| `literal_absent` | rust_erroraware | eligible |
| `literal_absent` | c | eligible |
| `literal_absent` | onigmo | eligible |
| `literal_absent` | pcre2_jit | eligible |
| `literal_absent` | pcre2 | eligible |
| `literal_absent` | fancy_regex | eligible |
| `literal_absent` | fancy_regex_seek | eligible |
| `literal_absent` | regex | eligible |
| `linkify_http_tail` | rust | pending |
| `linkify_http_tail` | rust_erroraware | pending |
| `linkify_http_tail` | c | pending |
| `linkify_http_tail` | onigmo | pending |
| `linkify_http_tail` | pcre2_jit | pending |
| `linkify_http_tail` | pcre2 | pending |
| `linkify_http_tail` | fancy_regex | pending |
| `linkify_http_tail` | fancy_regex_seek | pending |
| `linkify_http_tail` | regex | pending |
| `php_cs_fixer_recursive_types` | rust | pending |
| `php_cs_fixer_recursive_types` | rust_erroraware | pending |
| `php_cs_fixer_recursive_types` | c | pending |
| `php_cs_fixer_recursive_types` | onigmo | pending |
| `php_cs_fixer_recursive_types` | pcre2_jit | pending |
| `php_cs_fixer_recursive_types` | pcre2 | pending |
| `php_cs_fixer_recursive_types` | fancy_regex | pending |
| `php_cs_fixer_recursive_types` | fancy_regex_seek | pending |
| `php_cs_fixer_recursive_types` | regex | pending |

## rust_erroraware / steady

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 1.768.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.685 | 1.407–1.897 | Ferroni faster in every run interval |
| `uuid_v4` | 1.937 | 1.817–2.273 | Ferroni faster in every run interval |
| `ipv4_validation` | 4.386 | 3.935–5.416 | Ferroni faster in every run interval |
| `ipv6_validation` | 10.741 | 10.340–14.122 | Ferroni faster in every run interval |
| `semver_version_parse` | 1.129 | 1.047–1.187 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.122 | 1.114–1.166 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.137 | 0.853–1.209 | inconclusive |
| `jinja_integer_token` | 1.224 | 1.046–1.342 | inconclusive |
| `jinja_float_token` | 1.251 | 1.102–1.311 | Ferroni faster in every run interval |
| `django_email_local_part` | 3.246 | 3.026–3.731 | Ferroni faster in every run interval |
| `django_email_domain` | 8.646 | 8.254–8.814 | Ferroni faster in every run interval |
| `django_url_regex` | 8.364 | 7.726–9.881 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.282 | 1.153–1.291 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.470 | 1.415–1.497 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 0.959 | 0.932–1.102 | inconclusive |
| `mastodon_hashtag_regex_step` | 0.979 | 0.960–1.036 | inconclusive |
| `python_markdown_smart_emphasis_re` | 1.043 | 0.983–1.191 | inconclusive |
| `python_markdown_smart_strong_em_re` | 1.152 | 0.887–1.184 | inconclusive |
| `wordpress_shortcode_captures` | 1.071 | 1.025–1.115 | inconclusive |
| `symfony_grapheme_chunks_1` | 1.085 | 1.058–1.180 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.992 | 0.967–1.005 | inconclusive |
| `literal_first` | 1.400 | 1.329–1.509 | Ferroni faster in every run interval |
| `literal_middle` | 1.495 | 1.448–1.500 | Ferroni faster in every run interval |
| `literal_end` | 1.423 | 1.244–1.455 | Ferroni faster in every run interval |
| `literal_absent` | 1.338 | 1.311–1.433 | Ferroni faster in every run interval |

## rust_erroraware / compile

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.992.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.999 | 0.931–1.116 | inconclusive |
| `uuid_v4` | 1.005 | 0.953–1.043 | inconclusive |
| `ipv4_validation` | 0.927 | 0.862–1.058 | inconclusive |
| `ipv6_validation` | 0.957 | 0.785–1.078 | inconclusive |
| `semver_version_parse` | 1.138 | 1.051–1.198 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 0.962 | 0.856–1.276 | inconclusive |
| `jinja_string_token` | 0.734 | 0.707–0.996 | inconclusive |
| `jinja_integer_token` | 0.920 | 0.888–1.132 | inconclusive |
| `jinja_float_token` | 0.878 | 0.868–1.082 | inconclusive |
| `django_email_local_part` | 1.071 | 0.990–1.185 | inconclusive |
| `django_email_domain` | 0.970 | 0.969–1.010 | inconclusive |
| `django_url_regex` | 1.054 | 1.010–1.060 | inconclusive |
| `fluent_bit_apache` | 0.957 | 0.796–1.005 | inconclusive |
| `fluent_bit_nginx` | 0.906 | 0.880–1.021 | inconclusive |
| `rails_underscore_regex_step` | 0.973 | 0.915–1.104 | inconclusive |
| `mastodon_hashtag_regex_step` | 0.961 | 0.856–1.183 | inconclusive |
| `python_markdown_smart_emphasis_re` | 1.041 | 0.898–1.042 | inconclusive |
| `python_markdown_smart_strong_em_re` | 1.031 | 0.961–1.081 | inconclusive |
| `wordpress_shortcode_captures` | 1.055 | 0.971–1.175 | inconclusive |
| `symfony_grapheme_chunks_1` | 0.925 | 0.883–1.143 | inconclusive |
| `symfony_grapheme_chunks_2` | 1.021 | 0.981–1.028 | inconclusive |
| `literal_first` | 1.095 | 0.740–1.173 | inconclusive |
| `literal_middle` | 0.976 | 0.788–1.042 | inconclusive |
| `literal_end` | 1.231 | 0.905–1.233 | inconclusive |
| `literal_absent` | 1.084 | 0.697–1.141 | inconclusive |

## rust_erroraware / first_use

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.942.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.795 | 0.792–0.893 | comparator faster in every run interval |
| `uuid_v4` | 0.834 | 0.786–0.840 | comparator faster in every run interval |
| `ipv4_validation` | 0.942 | 0.890–1.128 | inconclusive |
| `ipv6_validation` | 0.823 | 0.795–0.918 | inconclusive |
| `semver_version_parse` | 0.995 | 0.952–1.016 | inconclusive |
| `semver_hyphen_range_captures` | 0.988 | 0.820–1.082 | inconclusive |
| `jinja_string_token` | 0.904 | 0.662–1.047 | inconclusive |
| `jinja_integer_token` | 0.864 | 0.850–0.910 | inconclusive |
| `jinja_float_token` | 0.895 | 0.809–1.032 | inconclusive |
| `django_email_local_part` | 0.967 | 0.938–1.146 | inconclusive |
| `django_email_domain` | 0.847 | 0.815–0.944 | inconclusive |
| `django_url_regex` | 1.066 | 1.049–1.070 | inconclusive |
| `fluent_bit_apache` | 0.754 | 0.696–1.038 | inconclusive |
| `fluent_bit_nginx` | 0.852 | 0.810–0.862 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 1.046 | 0.957–1.063 | inconclusive |
| `mastodon_hashtag_regex_step` | 0.991 | 0.851–1.072 | inconclusive |
| `python_markdown_smart_emphasis_re` | 0.979 | 0.856–1.019 | inconclusive |
| `python_markdown_smart_strong_em_re` | 0.885 | 0.857–0.945 | inconclusive |
| `wordpress_shortcode_captures` | 1.025 | 1.019–1.199 | inconclusive |
| `symfony_grapheme_chunks_1` | 0.903 | 0.885–1.112 | inconclusive |
| `symfony_grapheme_chunks_2` | 0.954 | 0.825–1.105 | inconclusive |
| `literal_first` | 1.127 | 0.861–1.165 | inconclusive |
| `literal_middle` | 0.968 | 0.764–1.324 | inconclusive |
| `literal_end` | 0.997 | 0.845–1.113 | inconclusive |
| `literal_absent` | 1.040 | 0.753–1.142 | inconclusive |

## c / steady

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 2.858.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 3.390 | 3.197–3.978 | Ferroni faster in every run interval |
| `uuid_v4` | 3.352 | 3.315–3.478 | Ferroni faster in every run interval |
| `ipv4_validation` | 5.339 | 4.869–6.212 | Ferroni faster in every run interval |
| `ipv6_validation` | 10.134 | 9.461–10.963 | Ferroni faster in every run interval |
| `semver_version_parse` | 1.427 | 1.361–1.500 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.179 | 1.065–1.181 | inconclusive |
| `jinja_string_token` | 1.072 | 0.786–1.192 | inconclusive |
| `jinja_integer_token` | 1.091 | 0.913–1.222 | inconclusive |
| `jinja_float_token` | 1.076 | 1.055–1.221 | inconclusive |
| `django_email_local_part` | 5.733 | 5.676–5.873 | Ferroni faster in every run interval |
| `django_email_domain` | 44.245 | 41.893–46.092 | Ferroni faster in every run interval |
| `django_url_regex` | 23.592 | 22.176–24.432 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.656 | 1.605–2.002 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 2.505 | 2.462–2.659 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.283 | 0.839–1.331 | inconclusive |
| `mastodon_hashtag_regex_step` | 1.677 | 1.602–2.031 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 2.316 | 1.916–2.396 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 2.110 | 1.847–2.671 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 1.091 | 1.076–1.186 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_1` | 1.335 | 1.292–1.352 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_2` | 1.379 | 1.210–1.411 | Ferroni faster in every run interval |
| `literal_first` | 4.172 | 3.789–4.985 | Ferroni faster in every run interval |
| `literal_middle` | 5.702 | 5.012–6.555 | Ferroni faster in every run interval |
| `literal_end` | 5.762 | 4.896–6.087 | Ferroni faster in every run interval |
| `literal_absent` | 3.098 | 2.600–3.409 | Ferroni faster in every run interval |

## c / compile

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.314.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 3.505 | 2.867–4.045 | Ferroni faster in every run interval |
| `uuid_v4` | 4.070 | 3.363–4.477 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.223 | 0.201–0.241 | comparator faster in every run interval |
| `ipv6_validation` | 0.202 | 0.172–0.229 | comparator faster in every run interval |
| `semver_version_parse` | 0.253 | 0.250–0.323 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.221 | 0.210–0.231 | comparator faster in every run interval |
| `jinja_string_token` | 0.103 | 0.100–0.136 | comparator faster in every run interval |
| `jinja_integer_token` | 2.157 | 1.818–2.486 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.474 | 0.459–0.559 | comparator faster in every run interval |
| `django_email_local_part` | 2.442 | 2.383–2.510 | Ferroni faster in every run interval |
| `django_email_domain` | 0.169 | 0.158–0.230 | comparator faster in every run interval |
| `django_url_regex` | 0.332 | 0.280–0.344 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.125 | 0.116–0.154 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.161 | 0.151–0.162 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.412 | 0.344–0.432 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.406 | 0.386–0.436 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.142 | 0.136–0.150 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.124 | 0.122–0.125 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.212 | 0.192–0.229 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.093 | 0.088–0.101 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.083 | 0.083–0.086 | comparator faster in every run interval |
| `literal_first` | 0.256 | 0.180–0.269 | comparator faster in every run interval |
| `literal_middle` | 0.278 | 0.258–0.301 | comparator faster in every run interval |
| `literal_end` | 0.300 | 0.226–0.308 | comparator faster in every run interval |
| `literal_absent` | 0.217 | 0.202–0.252 | comparator faster in every run interval |

## c / first_use

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.343.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 2.431 | 2.110–2.885 | Ferroni faster in every run interval |
| `uuid_v4` | 3.235 | 2.980–3.623 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.217 | 0.200–0.307 | comparator faster in every run interval |
| `ipv6_validation` | 0.211 | 0.190–0.233 | comparator faster in every run interval |
| `semver_version_parse` | 0.282 | 0.227–0.299 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.238 | 0.233–0.247 | comparator faster in every run interval |
| `jinja_string_token` | 0.135 | 0.092–0.157 | comparator faster in every run interval |
| `jinja_integer_token` | 2.062 | 1.684–2.304 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.471 | 0.429–0.512 | comparator faster in every run interval |
| `django_email_local_part` | 2.474 | 2.331–2.484 | Ferroni faster in every run interval |
| `django_email_domain` | 0.157 | 0.156–0.196 | comparator faster in every run interval |
| `django_url_regex` | 0.325 | 0.305–0.383 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.131 | 0.119–0.144 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.169 | 0.157–0.194 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.379 | 0.363–0.403 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.450 | 0.375–0.516 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.184 | 0.175–0.203 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.147 | 0.141–0.156 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.233 | 0.215–0.239 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.179 | 0.175–0.236 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.141 | 0.138–0.151 | comparator faster in every run interval |
| `literal_first` | 0.376 | 0.357–0.435 | comparator faster in every run interval |
| `literal_middle` | 0.515 | 0.477–0.592 | comparator faster in every run interval |
| `literal_end` | 0.372 | 0.320–0.432 | comparator faster in every run interval |
| `literal_absent` | 0.267 | 0.242–0.342 | comparator faster in every run interval |

## onigmo / steady

Common cases: 24; families: 13. Pair-specific family-weighted ratio: 3.548.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 5.005 | 4.771–5.782 | Ferroni faster in every run interval |
| `uuid_v4` | 5.934 | 5.509–6.369 | Ferroni faster in every run interval |
| `ipv4_validation` | 5.749 | 4.707–6.286 | Ferroni faster in every run interval |
| `ipv6_validation` | 14.573 | 13.707–16.066 | Ferroni faster in every run interval |
| `semver_version_parse` | 1.756 | 1.723–2.037 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.173 | 1.153–1.226 | Ferroni faster in every run interval |
| `jinja_string_token` | 0.877 | 0.698–0.962 | inconclusive |
| `jinja_integer_token` | 1.181 | 1.127–1.521 | Ferroni faster in every run interval |
| `jinja_float_token` | 2.243 | 2.166–2.623 | Ferroni faster in every run interval |
| `django_email_local_part` | 5.025 | 4.734–5.374 | Ferroni faster in every run interval |
| `django_email_domain` | 80.692 | 74.497–94.563 | Ferroni faster in every run interval |
| `django_url_regex` | 67.183 | 57.881–72.249 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 2.075 | 1.869–2.490 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 3.185 | 3.093–3.197 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 0.929 | 0.833–1.348 | inconclusive |
| `mastodon_hashtag_regex_step` | 1.839 | 1.757–2.164 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 2.535 | 1.961–2.757 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 2.124 | 1.914–2.728 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 1.280 | 1.177–1.458 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_2` | 2.953 | 2.922–2.996 | Ferroni faster in every run interval |
| `literal_first` | 1.965 | 1.775–2.531 | Ferroni faster in every run interval |
| `literal_middle` | 3.444 | 3.224–3.584 | Ferroni faster in every run interval |
| `literal_end` | 3.423 | 3.087–4.076 | Ferroni faster in every run interval |
| `literal_absent` | 2.897 | 2.642–2.965 | Ferroni faster in every run interval |

## onigmo / compile

Common cases: 24; families: 13. Pair-specific family-weighted ratio: 0.396.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 3.932 | 3.549–5.058 | Ferroni faster in every run interval |
| `uuid_v4` | 4.294 | 3.716–5.307 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.236 | 0.193–0.237 | comparator faster in every run interval |
| `ipv6_validation` | 0.219 | 0.185–0.263 | comparator faster in every run interval |
| `semver_version_parse` | 0.302 | 0.280–0.321 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.272 | 0.222–0.277 | comparator faster in every run interval |
| `jinja_string_token` | 0.086 | 0.086–0.118 | comparator faster in every run interval |
| `jinja_integer_token` | 1.798 | 1.682–2.468 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.557 | 0.548–0.652 | comparator faster in every run interval |
| `django_email_local_part` | 2.504 | 2.461–2.547 | Ferroni faster in every run interval |
| `django_email_domain` | 0.110 | 0.108–0.120 | comparator faster in every run interval |
| `django_url_regex` | 0.271 | 0.227–0.295 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.117 | 0.105–0.141 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.161 | 0.146–0.167 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.341 | 0.333–0.370 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.481 | 0.466–0.639 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.114 | 0.092–0.141 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.100 | 0.091–0.105 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.213 | 0.197–0.232 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 3.576 | 3.412–3.957 | Ferroni faster in every run interval |
| `literal_first` | 0.191 | 0.189–0.201 | comparator faster in every run interval |
| `literal_middle` | 0.216 | 0.204–0.220 | comparator faster in every run interval |
| `literal_end` | 0.222 | 0.175–0.222 | comparator faster in every run interval |
| `literal_absent` | 0.149 | 0.130–0.203 | comparator faster in every run interval |

## onigmo / first_use

Common cases: 24; families: 13. Pair-specific family-weighted ratio: 0.408.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 2.742 | 2.520–3.246 | Ferroni faster in every run interval |
| `uuid_v4` | 3.888 | 3.533–4.128 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.223 | 0.219–0.244 | comparator faster in every run interval |
| `ipv6_validation` | 0.213 | 0.193–0.259 | comparator faster in every run interval |
| `semver_version_parse` | 0.267 | 0.231–0.273 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.245 | 0.225–0.265 | comparator faster in every run interval |
| `jinja_string_token` | 0.106 | 0.077–0.134 | comparator faster in every run interval |
| `jinja_integer_token` | 1.814 | 1.486–1.857 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.622 | 0.482–0.699 | comparator faster in every run interval |
| `django_email_local_part` | 2.386 | 2.385–2.409 | Ferroni faster in every run interval |
| `django_email_domain` | 0.107 | 0.093–0.115 | comparator faster in every run interval |
| `django_url_regex` | 0.255 | 0.230–0.288 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.119 | 0.091–0.131 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.180 | 0.151–0.203 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.353 | 0.336–0.372 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.483 | 0.445–0.603 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.134 | 0.120–0.156 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.112 | 0.102–0.125 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.238 | 0.206–0.284 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 3.769 | 3.191–3.851 | Ferroni faster in every run interval |
| `literal_first` | 0.276 | 0.265–0.287 | comparator faster in every run interval |
| `literal_middle` | 0.381 | 0.299–0.420 | comparator faster in every run interval |
| `literal_end` | 0.254 | 0.210–0.275 | comparator faster in every run interval |
| `literal_absent` | 0.207 | 0.197–0.262 | comparator faster in every run interval |

## pcre2_jit / steady

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.663.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.976 | 0.748–1.017 | inconclusive |
| `uuid_v4` | 1.030 | 0.927–1.048 | inconclusive |
| `ipv4_validation` | 1.168 | 1.124–1.687 | Ferroni faster in every run interval |
| `ipv6_validation` | 2.467 | 2.267–2.918 | Ferroni faster in every run interval |
| `semver_version_parse` | 0.391 | 0.380–0.401 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.404 | 0.392–0.421 | comparator faster in every run interval |
| `jinja_string_token` | 0.480 | 0.329–0.494 | comparator faster in every run interval |
| `jinja_integer_token` | 0.426 | 0.418–0.592 | comparator faster in every run interval |
| `jinja_float_token` | 0.606 | 0.571–0.628 | comparator faster in every run interval |
| `django_email_local_part` | 1.750 | 1.592–1.803 | Ferroni faster in every run interval |
| `django_email_domain` | 0.878 | 0.834–1.005 | inconclusive |
| `django_url_regex` | 1.514 | 1.389–1.578 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 0.362 | 0.352–0.540 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.578 | 0.464–0.649 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.314 | 0.309–0.382 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.317 | 0.267–0.359 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.664 | 0.524–0.677 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.438 | 0.407–0.595 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.396 | 0.369–0.466 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.584 | 0.547–0.633 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.572 | 0.504–0.582 | comparator faster in every run interval |
| `literal_first` | 1.362 | 1.289–1.789 | Ferroni faster in every run interval |
| `literal_middle` | 1.379 | 1.265–1.689 | Ferroni faster in every run interval |
| `literal_end` | 1.385 | 1.282–1.564 | Ferroni faster in every run interval |
| `literal_absent` | 1.299 | 1.251–1.337 | Ferroni faster in every run interval |

## pcre2_jit / compile

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.293.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.261 | 0.216–0.387 | comparator faster in every run interval |
| `uuid_v4` | 0.228 | 0.204–0.280 | comparator faster in every run interval |
| `ipv4_validation` | 0.274 | 0.264–0.308 | comparator faster in every run interval |
| `ipv6_validation` | 0.221 | 0.193–0.246 | comparator faster in every run interval |
| `semver_version_parse` | 0.382 | 0.367–0.410 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.313 | 0.278–0.342 | comparator faster in every run interval |
| `jinja_string_token` | 0.213 | 0.212–0.322 | comparator faster in every run interval |
| `jinja_integer_token` | 0.312 | 0.232–0.348 | comparator faster in every run interval |
| `jinja_float_token` | 0.241 | 0.198–0.269 | comparator faster in every run interval |
| `django_email_local_part` | 0.302 | 0.285–0.334 | comparator faster in every run interval |
| `django_email_domain` | 0.036 | 0.031–0.037 | comparator faster in every run interval |
| `django_url_regex` | 0.044 | 0.042–0.045 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.224 | 0.188–0.299 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.265 | 0.231–0.284 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.909 | 0.763–1.072 | inconclusive |
| `mastodon_hashtag_regex_step` | 0.148 | 0.143–0.182 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.496 | 0.435–0.505 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.384 | 0.368–0.437 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.362 | 0.348–0.416 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.347 | 0.327–0.414 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.299 | 0.294–0.315 | comparator faster in every run interval |
| `literal_first` | 3.121 | 2.756–3.301 | Ferroni faster in every run interval |
| `literal_middle` | 2.431 | 2.074–3.088 | Ferroni faster in every run interval |
| `literal_end` | 3.493 | 3.105–4.013 | Ferroni faster in every run interval |
| `literal_absent` | 2.690 | 1.982–2.941 | Ferroni faster in every run interval |

## pcre2_jit / first_use

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.323.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.207 | 0.163–0.269 | comparator faster in every run interval |
| `uuid_v4` | 0.191 | 0.183–0.228 | comparator faster in every run interval |
| `ipv4_validation` | 0.316 | 0.309–0.347 | comparator faster in every run interval |
| `ipv6_validation` | 0.233 | 0.198–0.253 | comparator faster in every run interval |
| `semver_version_parse` | 0.404 | 0.395–0.462 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.312 | 0.230–0.313 | comparator faster in every run interval |
| `jinja_string_token` | 0.326 | 0.268–0.369 | comparator faster in every run interval |
| `jinja_integer_token` | 0.356 | 0.263–0.421 | comparator faster in every run interval |
| `jinja_float_token` | 0.274 | 0.205–0.288 | comparator faster in every run interval |
| `django_email_local_part` | 0.380 | 0.310–0.406 | comparator faster in every run interval |
| `django_email_domain` | 0.031 | 0.030–0.036 | comparator faster in every run interval |
| `django_url_regex` | 0.044 | 0.041–0.050 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.225 | 0.174–0.301 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.278 | 0.270–0.295 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.986 | 0.897–1.107 | inconclusive |
| `mastodon_hashtag_regex_step` | 0.168 | 0.163–0.224 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.604 | 0.547–0.622 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.447 | 0.432–0.586 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.424 | 0.408–0.452 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.602 | 0.572–0.658 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.485 | 0.381–0.498 | comparator faster in every run interval |
| `literal_first` | 3.618 | 2.653–4.519 | Ferroni faster in every run interval |
| `literal_middle` | 2.416 | 2.317–4.114 | Ferroni faster in every run interval |
| `literal_end` | 2.971 | 2.829–3.098 | Ferroni faster in every run interval |
| `literal_absent` | 2.688 | 2.679–2.832 | Ferroni faster in every run interval |

## pcre2 / steady

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 1.885.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.479 | 1.353–1.774 | Ferroni faster in every run interval |
| `uuid_v4` | 1.841 | 1.748–2.741 | Ferroni faster in every run interval |
| `ipv4_validation` | 7.267 | 6.977–8.545 | Ferroni faster in every run interval |
| `ipv6_validation` | 14.488 | 13.595–15.923 | Ferroni faster in every run interval |
| `semver_version_parse` | 1.271 | 1.123–1.473 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.601 | 1.511–1.744 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.023 | 1.006–1.056 | inconclusive |
| `jinja_integer_token` | 1.393 | 1.300–1.620 | Ferroni faster in every run interval |
| `jinja_float_token` | 1.887 | 1.596–1.930 | Ferroni faster in every run interval |
| `django_email_local_part` | 4.857 | 4.659–5.186 | Ferroni faster in every run interval |
| `django_email_domain` | 3.133 | 2.987–3.393 | Ferroni faster in every run interval |
| `django_url_regex` | 4.342 | 4.165–4.378 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.181 | 1.127–1.705 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.823 | 1.774–2.113 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 0.960 | 0.899–1.194 | inconclusive |
| `mastodon_hashtag_regex_step` | 0.619 | 0.613–0.714 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 3.119 | 2.913–3.310 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 3.065 | 2.665–4.144 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 1.273 | 1.156–1.306 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.952 | 0.836–1.039 | inconclusive |
| `symfony_grapheme_chunks_2` | 0.740 | 0.673–0.800 | comparator faster in every run interval |
| `literal_first` | 2.531 | 2.396–2.683 | Ferroni faster in every run interval |
| `literal_middle` | 2.654 | 2.270–3.415 | Ferroni faster in every run interval |
| `literal_end` | 2.677 | 2.282–2.989 | Ferroni faster in every run interval |
| `literal_absent` | 1.588 | 1.495–1.623 | Ferroni faster in every run interval |

## pcre2 / compile

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.068.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.080 | 0.071–0.084 | comparator faster in every run interval |
| `uuid_v4` | 0.089 | 0.072–0.092 | comparator faster in every run interval |
| `ipv4_validation` | 0.068 | 0.059–0.072 | comparator faster in every run interval |
| `ipv6_validation` | 0.081 | 0.057–0.097 | comparator faster in every run interval |
| `semver_version_parse` | 0.092 | 0.086–0.105 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.071 | 0.067–0.090 | comparator faster in every run interval |
| `jinja_string_token` | 0.049 | 0.038–0.053 | comparator faster in every run interval |
| `jinja_integer_token` | 0.072 | 0.065–0.089 | comparator faster in every run interval |
| `jinja_float_token` | 0.046 | 0.039–0.056 | comparator faster in every run interval |
| `django_email_local_part` | 0.119 | 0.117–0.123 | comparator faster in every run interval |
| `django_email_domain` | 0.033 | 0.026–0.038 | comparator faster in every run interval |
| `django_url_regex` | 0.029 | 0.028–0.033 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.037 | 0.030–0.052 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.046 | 0.045–0.052 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.203 | 0.189–0.239 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.071 | 0.071–0.102 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.065 | 0.052–0.066 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.041 | 0.038–0.057 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.094 | 0.089–0.097 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.037 | 0.033–0.038 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.028 | 0.025–0.034 | comparator faster in every run interval |
| `literal_first` | 0.151 | 0.120–0.166 | comparator faster in every run interval |
| `literal_middle` | 0.133 | 0.114–0.180 | comparator faster in every run interval |
| `literal_end` | 0.197 | 0.141–0.222 | comparator faster in every run interval |
| `literal_absent` | 0.126 | 0.109–0.243 | comparator faster in every run interval |

## pcre2 / first_use

Common cases: 25; families: 13. Pair-specific family-weighted ratio: 0.116.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.092 | 0.088–0.101 | comparator faster in every run interval |
| `uuid_v4` | 0.100 | 0.099–0.105 | comparator faster in every run interval |
| `ipv4_validation` | 0.114 | 0.106–0.150 | comparator faster in every run interval |
| `ipv6_validation` | 0.079 | 0.061–0.080 | comparator faster in every run interval |
| `semver_version_parse` | 0.121 | 0.119–0.130 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.087 | 0.079–0.092 | comparator faster in every run interval |
| `jinja_string_token` | 0.089 | 0.075–0.106 | comparator faster in every run interval |
| `jinja_integer_token` | 0.107 | 0.085–0.118 | comparator faster in every run interval |
| `jinja_float_token` | 0.062 | 0.050–0.063 | comparator faster in every run interval |
| `django_email_local_part` | 0.141 | 0.140–0.149 | comparator faster in every run interval |
| `django_email_domain` | 0.027 | 0.026–0.032 | comparator faster in every run interval |
| `django_url_regex` | 0.029 | 0.026–0.038 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.066 | 0.053–0.071 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.093 | 0.073–0.099 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.317 | 0.303–0.330 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.088 | 0.075–0.094 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.146 | 0.136–0.171 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.106 | 0.098–0.131 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.128 | 0.119–0.139 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.190 | 0.181–0.221 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.153 | 0.120–0.210 | comparator faster in every run interval |
| `literal_first` | 0.847 | 0.762–0.898 | inconclusive |
| `literal_middle` | 0.684 | 0.566–1.201 | inconclusive |
| `literal_end` | 0.942 | 0.844–0.954 | inconclusive |
| `literal_absent` | 0.702 | 0.682–1.042 | inconclusive |

## fancy_regex / steady

Common cases: 21; families: 11. Pair-specific family-weighted ratio: 2.687.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.969 | 0.874–1.234 | inconclusive |
| `uuid_v4` | 1.297 | 1.246–1.299 | Ferroni faster in every run interval |
| `ipv4_validation` | 1.081 | 0.993–1.480 | inconclusive |
| `ipv6_validation` | 1.293 | 1.132–1.308 | Ferroni faster in every run interval |
| `semver_version_parse` | 2.095 | 2.034–2.235 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.509 | 1.355–1.778 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.039 | 0.981–1.058 | inconclusive |
| `jinja_integer_token` | 1.290 | 1.239–1.467 | Ferroni faster in every run interval |
| `jinja_float_token` | 2.991 | 2.859–3.311 | Ferroni faster in every run interval |
| `django_email_domain` | 10.808 | 10.407–10.851 | Ferroni faster in every run interval |
| `django_url_regex` | 30.636 | 29.130–35.341 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.394 | 1.338–2.000 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.915 | 1.891–2.045 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 2.768 | 2.417–3.585 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 2.987 | 2.970–3.060 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 3.890 | 3.403–4.863 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 2.284 | 2.055–2.352 | Ferroni faster in every run interval |
| `literal_first` | 1.182 | 1.018–1.210 | inconclusive |
| `literal_middle` | 1.139 | 1.076–1.181 | Ferroni faster in every run interval |
| `literal_end` | 1.282 | 1.043–1.330 | inconclusive |
| `literal_absent` | 1.233 | 1.165–1.280 | Ferroni faster in every run interval |

## fancy_regex / compile

Common cases: 21; families: 11. Pair-specific family-weighted ratio: 1.339.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.930 | 0.636–0.994 | inconclusive |
| `uuid_v4` | 0.958 | 0.818–0.961 | inconclusive |
| `ipv4_validation` | 0.867 | 0.716–0.884 | comparator faster in every run interval |
| `ipv6_validation` | 0.838 | 0.823–0.962 | inconclusive |
| `semver_version_parse` | 16.521 | 14.290–16.768 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 9.554 | 9.156–9.664 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.612 | 1.198–1.687 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.636 | 1.608–1.719 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.261 | 0.186–0.374 | comparator faster in every run interval |
| `django_email_domain` | 1.904 | 1.744–1.977 | Ferroni faster in every run interval |
| `django_url_regex` | 1.760 | 1.742–1.777 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.441 | 1.124–1.609 | inconclusive |
| `fluent_bit_nginx` | 1.473 | 1.430–1.762 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.106 | 1.039–1.279 | inconclusive |
| `python_markdown_smart_emphasis_re` | 0.487 | 0.486–0.565 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.363 | 0.353–0.398 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 1.093 | 1.086–1.169 | Ferroni faster in every run interval |
| `literal_first` | 1.232 | 0.961–1.274 | inconclusive |
| `literal_middle` | 1.056 | 0.831–1.244 | inconclusive |
| `literal_end` | 1.369 | 1.029–1.879 | inconclusive |
| `literal_absent` | 0.896 | 0.871–1.080 | inconclusive |

## fancy_regex / first_use

Common cases: 21; families: 11. Pair-specific family-weighted ratio: 1.385.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.879 | 0.688–1.115 | inconclusive |
| `uuid_v4` | 1.031 | 0.933–1.042 | inconclusive |
| `ipv4_validation` | 0.836 | 0.802–0.973 | inconclusive |
| `ipv6_validation` | 0.842 | 0.764–0.965 | inconclusive |
| `semver_version_parse` | 12.973 | 12.487–14.532 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 9.307 | 6.805–9.426 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.467 | 1.452–1.679 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.750 | 1.638–1.866 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.268 | 0.225–0.276 | comparator faster in every run interval |
| `django_email_domain` | 1.913 | 1.562–2.295 | Ferroni faster in every run interval |
| `django_url_regex` | 1.911 | 1.748–2.144 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.467 | 1.078–1.560 | inconclusive |
| `fluent_bit_nginx` | 1.497 | 1.415–1.668 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.310 | 1.172–1.631 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.498 | 0.437–0.500 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.440 | 0.372–0.444 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 1.242 | 1.235–1.414 | Ferroni faster in every run interval |
| `literal_first` | 1.222 | 1.205–1.314 | Ferroni faster in every run interval |
| `literal_middle` | 1.089 | 1.011–2.057 | inconclusive |
| `literal_end` | 1.219 | 1.176–1.355 | Ferroni faster in every run interval |
| `literal_absent` | 1.004 | 0.977–1.290 | inconclusive |

## fancy_regex_seek / steady

Common cases: 21; families: 11. Pair-specific family-weighted ratio: 2.740.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.050 | 0.927–1.273 | inconclusive |
| `uuid_v4` | 1.261 | 1.228–1.320 | Ferroni faster in every run interval |
| `ipv4_validation` | 1.235 | 1.126–1.446 | Ferroni faster in every run interval |
| `ipv6_validation` | 1.376 | 1.200–1.452 | Ferroni faster in every run interval |
| `semver_version_parse` | 1.900 | 1.883–2.033 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.614 | 1.484–1.691 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.011 | 0.929–1.084 | inconclusive |
| `jinja_integer_token` | 1.249 | 1.247–1.428 | Ferroni faster in every run interval |
| `jinja_float_token` | 2.701 | 2.463–3.490 | Ferroni faster in every run interval |
| `django_email_domain` | 10.689 | 10.223–11.669 | Ferroni faster in every run interval |
| `django_url_regex` | 31.471 | 29.446–34.992 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.489 | 1.459–1.966 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 2.085 | 1.815–2.194 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 3.329 | 2.828–3.768 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 2.949 | 2.806–3.188 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 3.765 | 3.350–5.820 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 2.147 | 2.087–2.353 | Ferroni faster in every run interval |
| `literal_first` | 1.159 | 0.992–1.261 | inconclusive |
| `literal_middle` | 1.143 | 1.079–1.198 | Ferroni faster in every run interval |
| `literal_end` | 1.157 | 1.052–1.251 | inconclusive |
| `literal_absent` | 1.227 | 1.110–1.293 | Ferroni faster in every run interval |

## fancy_regex_seek / compile

Common cases: 21; families: 11. Pair-specific family-weighted ratio: 1.511.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.938 | 0.651–0.944 | inconclusive |
| `uuid_v4` | 0.907 | 0.883–1.049 | inconclusive |
| `ipv4_validation` | 0.833 | 0.696–0.877 | comparator faster in every run interval |
| `ipv6_validation` | 0.858 | 0.753–0.898 | comparator faster in every run interval |
| `semver_version_parse` | 15.554 | 13.995–16.457 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 8.979 | 8.470–11.219 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.468 | 1.352–1.670 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.659 | 1.533–1.703 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.259 | 0.214–0.340 | comparator faster in every run interval |
| `django_email_domain` | 1.840 | 1.801–2.183 | Ferroni faster in every run interval |
| `django_url_regex` | 1.867 | 1.736–2.105 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.204 | 1.167–1.768 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.526 | 1.260–1.546 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.498 | 1.136–1.595 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.486 | 0.437–0.549 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.425 | 0.378–0.467 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 3.293 | 3.192–3.514 | Ferroni faster in every run interval |
| `literal_first` | 1.152 | 0.819–1.351 | inconclusive |
| `literal_middle` | 1.109 | 0.804–1.466 | inconclusive |
| `literal_end` | 1.195 | 1.127–1.481 | inconclusive |
| `literal_absent` | 1.083 | 0.899–1.104 | inconclusive |

## fancy_regex_seek / first_use

Common cases: 21; families: 11. Pair-specific family-weighted ratio: 1.520.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.905 | 0.694–1.005 | inconclusive |
| `uuid_v4` | 1.155 | 0.914–1.157 | inconclusive |
| `ipv4_validation` | 0.883 | 0.773–0.910 | comparator faster in every run interval |
| `ipv6_validation` | 0.760 | 0.708–0.883 | comparator faster in every run interval |
| `semver_version_parse` | 14.214 | 12.665–16.447 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 8.757 | 8.623–8.919 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.492 | 1.295–1.740 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.670 | 1.553–2.042 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.221 | 0.210–0.273 | comparator faster in every run interval |
| `django_email_domain` | 1.835 | 1.759–1.862 | Ferroni faster in every run interval |
| `django_url_regex` | 1.864 | 1.683–1.955 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.225 | 1.154–1.540 | inconclusive |
| `fluent_bit_nginx` | 1.452 | 1.436–1.620 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.428 | 1.306–1.487 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.476 | 0.459–0.518 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.392 | 0.361–0.471 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 4.251 | 3.480–5.227 | Ferroni faster in every run interval |
| `literal_first` | 1.283 | 0.914–1.348 | inconclusive |
| `literal_middle` | 0.995 | 0.990–1.651 | inconclusive |
| `literal_end` | 1.171 | 0.964–1.238 | inconclusive |
| `literal_absent` | 0.955 | 0.945–1.349 | inconclusive |

## regex / steady

Common cases: 14; families: 6. Pair-specific family-weighted ratio: 1.234.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.040 | 1.037–1.317 | inconclusive |
| `uuid_v4` | 1.479 | 1.465–1.485 | Ferroni faster in every run interval |
| `ipv4_validation` | 1.170 | 1.126–1.542 | Ferroni faster in every run interval |
| `ipv6_validation` | 1.407 | 1.351–1.514 | Ferroni faster in every run interval |
| `semver_version_parse` | 1.800 | 1.722–1.814 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.451 | 1.353–1.558 | Ferroni faster in every run interval |
| `jinja_string_token` | 0.616 | 0.579–0.664 | comparator faster in every run interval |
| `jinja_integer_token` | 1.096 | 0.965–1.291 | inconclusive |
| `fluent_bit_apache` | 1.331 | 1.298–1.564 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.964 | 1.768–1.964 | Ferroni faster in every run interval |
| `literal_first` | 0.997 | 0.875–1.094 | inconclusive |
| `literal_middle` | 1.158 | 1.087–1.216 | Ferroni faster in every run interval |
| `literal_end` | 0.975 | 0.872–1.060 | inconclusive |
| `literal_absent` | 1.011 | 1.003–1.085 | inconclusive |

## regex / compile

Common cases: 14; families: 6. Pair-specific family-weighted ratio: 1.575.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.700 | 0.689–0.720 | comparator faster in every run interval |
| `uuid_v4` | 0.681 | 0.602–0.738 | comparator faster in every run interval |
| `ipv4_validation` | 0.652 | 0.577–0.737 | comparator faster in every run interval |
| `ipv6_validation` | 0.820 | 0.736–0.863 | comparator faster in every run interval |
| `semver_version_parse` | 15.325 | 13.841–15.829 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 9.227 | 8.382–9.488 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.483 | 1.328–1.621 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.571 | 1.393–1.609 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.406 | 1.212–1.540 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.387 | 1.286–1.542 | Ferroni faster in every run interval |
| `literal_first` | 1.198 | 0.787–1.257 | inconclusive |
| `literal_middle` | 1.043 | 0.896–1.395 | inconclusive |
| `literal_end` | 1.534 | 1.130–1.637 | Ferroni faster in every run interval |
| `literal_absent` | 1.064 | 1.045–1.127 | inconclusive |

## regex / first_use

Common cases: 14; families: 6. Pair-specific family-weighted ratio: 1.572.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.797 | 0.728–0.852 | comparator faster in every run interval |
| `uuid_v4` | 0.831 | 0.708–0.888 | comparator faster in every run interval |
| `ipv4_validation` | 0.771 | 0.720–0.877 | comparator faster in every run interval |
| `ipv6_validation` | 0.740 | 0.693–0.870 | comparator faster in every run interval |
| `semver_version_parse` | 13.296 | 13.142–14.334 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 7.905 | 7.424–8.922 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.533 | 1.332–1.639 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.411 | 1.298–1.764 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.219 | 1.168–1.306 | inconclusive |
| `fluent_bit_nginx` | 1.385 | 1.315–1.543 | Ferroni faster in every run interval |
| `literal_first` | 1.189 | 1.053–1.281 | inconclusive |
| `literal_middle` | 1.323 | 1.261–1.428 | Ferroni faster in every run interval |
| `literal_end` | 1.189 | 1.110–1.234 | inconclusive |
| `literal_absent` | 1.313 | 0.950–1.587 | inconclusive |

Raw samples, estimates, confidence intervals, failures, eligibility reasons, corpus snapshot and execution order are retained beside this report.

Memory, where requested, is fresh-process peak RSS including the binary, runtime, parsed catalog, compilation, input/output and allocator. It is not isolated compiled-pattern memory.
