# Production regex comparison

Host: Linux-6.6.141-x86_64-with-glibc2.39; x86_64.

Publication candidate: review host stability, raw samples, coverage and run intervals before publishing.

Ratios are comparator / Ferroni. Compile and first-use times concern one pattern; steady times concern the complete fixture batch.

Each comparison below uses only its explicitly listed common tasks. Families have equal aggregate weight; architectures are never combined.

## Eligibility

| Case | Engine | Status |
| --- | --- | --- |
| `uuid_shape` | rust | eligible |
| `uuid_shape` | rust_erroraware | eligible |
| `uuid_shape` | c | eligible |
| `uuid_shape` | onigmo | eligible |
| `uuid_shape` | pcre2_jit | eligible |
| `uuid_shape` | pcre2 | eligible |
| `uuid_shape` | fancy_regex | eligible |
| `uuid_shape` | fancy_regex_seek | eligible |
| `uuid_shape` | regex | eligible |
| `uuid_v4` | rust | eligible |
| `uuid_v4` | rust_erroraware | eligible |
| `uuid_v4` | c | eligible |
| `uuid_v4` | onigmo | eligible |
| `uuid_v4` | pcre2_jit | eligible |
| `uuid_v4` | pcre2 | eligible |
| `uuid_v4` | fancy_regex | eligible |
| `uuid_v4` | fancy_regex_seek | eligible |
| `uuid_v4` | regex | eligible |
| `ipv4_validation` | rust | eligible |
| `ipv4_validation` | rust_erroraware | eligible |
| `ipv4_validation` | c | eligible |
| `ipv4_validation` | onigmo | eligible |
| `ipv4_validation` | pcre2_jit | eligible |
| `ipv4_validation` | pcre2 | eligible |
| `ipv4_validation` | fancy_regex | eligible |
| `ipv4_validation` | fancy_regex_seek | eligible |
| `ipv4_validation` | regex | eligible |
| `ipv6_validation` | rust | eligible |
| `ipv6_validation` | rust_erroraware | eligible |
| `ipv6_validation` | c | eligible |
| `ipv6_validation` | onigmo | eligible |
| `ipv6_validation` | pcre2_jit | eligible |
| `ipv6_validation` | pcre2 | eligible |
| `ipv6_validation` | fancy_regex | eligible |
| `ipv6_validation` | fancy_regex_seek | eligible |
| `ipv6_validation` | regex | eligible |
| `semver_version_parse` | rust | eligible |
| `semver_version_parse` | rust_erroraware | eligible |
| `semver_version_parse` | c | eligible |
| `semver_version_parse` | onigmo | eligible |
| `semver_version_parse` | pcre2_jit | eligible |
| `semver_version_parse` | pcre2 | eligible |
| `semver_version_parse` | fancy_regex | eligible |
| `semver_version_parse` | fancy_regex_seek | eligible |
| `semver_version_parse` | regex | eligible |
| `semver_hyphen_range_captures` | rust | eligible |
| `semver_hyphen_range_captures` | rust_erroraware | eligible |
| `semver_hyphen_range_captures` | c | eligible |
| `semver_hyphen_range_captures` | onigmo | eligible |
| `semver_hyphen_range_captures` | pcre2_jit | eligible |
| `semver_hyphen_range_captures` | pcre2 | eligible |
| `semver_hyphen_range_captures` | fancy_regex | eligible |
| `semver_hyphen_range_captures` | fancy_regex_seek | eligible |
| `semver_hyphen_range_captures` | regex | eligible |
| `jinja_string_token` | rust | eligible |
| `jinja_string_token` | rust_erroraware | eligible |
| `jinja_string_token` | c | eligible |
| `jinja_string_token` | onigmo | eligible |
| `jinja_string_token` | pcre2_jit | eligible |
| `jinja_string_token` | pcre2 | eligible |
| `jinja_string_token` | fancy_regex | eligible |
| `jinja_string_token` | fancy_regex_seek | eligible |
| `jinja_string_token` | regex | eligible |
| `jinja_integer_token` | rust | eligible |
| `jinja_integer_token` | rust_erroraware | eligible |
| `jinja_integer_token` | c | eligible |
| `jinja_integer_token` | onigmo | eligible |
| `jinja_integer_token` | pcre2_jit | eligible |
| `jinja_integer_token` | pcre2 | eligible |
| `jinja_integer_token` | fancy_regex | eligible |
| `jinja_integer_token` | fancy_regex_seek | eligible |
| `jinja_integer_token` | regex | eligible |
| `jinja_float_token` | rust | eligible |
| `jinja_float_token` | rust_erroraware | eligible |
| `jinja_float_token` | c | eligible |
| `jinja_float_token` | onigmo | eligible |
| `jinja_float_token` | pcre2_jit | eligible |
| `jinja_float_token` | pcre2 | eligible |
| `jinja_float_token` | fancy_regex | eligible |
| `jinja_float_token` | fancy_regex_seek | eligible |
| `jinja_float_token` | regex | syntax_rejected |
| `django_email_local_part` | rust | eligible |
| `django_email_local_part` | rust_erroraware | eligible |
| `django_email_local_part` | c | eligible |
| `django_email_local_part` | onigmo | eligible |
| `django_email_local_part` | pcre2_jit | eligible |
| `django_email_local_part` | pcre2 | eligible |
| `django_email_local_part` | fancy_regex | syntax_rejected |
| `django_email_local_part` | fancy_regex_seek | syntax_rejected |
| `django_email_local_part` | regex | syntax_rejected |
| `django_email_domain` | rust | eligible |
| `django_email_domain` | rust_erroraware | eligible |
| `django_email_domain` | c | eligible |
| `django_email_domain` | onigmo | eligible |
| `django_email_domain` | pcre2_jit | eligible |
| `django_email_domain` | pcre2 | eligible |
| `django_email_domain` | fancy_regex | eligible |
| `django_email_domain` | fancy_regex_seek | eligible |
| `django_email_domain` | regex | syntax_rejected |
| `django_url_regex` | rust | eligible |
| `django_url_regex` | rust_erroraware | eligible |
| `django_url_regex` | c | eligible |
| `django_url_regex` | onigmo | eligible |
| `django_url_regex` | pcre2_jit | eligible |
| `django_url_regex` | pcre2 | eligible |
| `django_url_regex` | fancy_regex | eligible |
| `django_url_regex` | fancy_regex_seek | eligible |
| `django_url_regex` | regex | syntax_rejected |
| `fluent_bit_apache` | rust | eligible |
| `fluent_bit_apache` | rust_erroraware | eligible |
| `fluent_bit_apache` | c | eligible |
| `fluent_bit_apache` | onigmo | eligible |
| `fluent_bit_apache` | pcre2_jit | eligible |
| `fluent_bit_apache` | pcre2 | eligible |
| `fluent_bit_apache` | fancy_regex | eligible |
| `fluent_bit_apache` | fancy_regex_seek | eligible |
| `fluent_bit_apache` | regex | eligible |
| `fluent_bit_nginx` | rust | eligible |
| `fluent_bit_nginx` | rust_erroraware | eligible |
| `fluent_bit_nginx` | c | eligible |
| `fluent_bit_nginx` | onigmo | eligible |
| `fluent_bit_nginx` | pcre2_jit | eligible |
| `fluent_bit_nginx` | pcre2 | eligible |
| `fluent_bit_nginx` | fancy_regex | eligible |
| `fluent_bit_nginx` | fancy_regex_seek | eligible |
| `fluent_bit_nginx` | regex | eligible |
| `rails_underscore_regex_step` | rust | eligible |
| `rails_underscore_regex_step` | rust_erroraware | eligible |
| `rails_underscore_regex_step` | c | eligible |
| `rails_underscore_regex_step` | onigmo | eligible |
| `rails_underscore_regex_step` | pcre2_jit | eligible |
| `rails_underscore_regex_step` | pcre2 | eligible |
| `rails_underscore_regex_step` | fancy_regex | eligible |
| `rails_underscore_regex_step` | fancy_regex_seek | eligible |
| `rails_underscore_regex_step` | regex | syntax_rejected |
| `mastodon_hashtag_regex_step` | rust | eligible |
| `mastodon_hashtag_regex_step` | rust_erroraware | eligible |
| `mastodon_hashtag_regex_step` | c | eligible |
| `mastodon_hashtag_regex_step` | onigmo | eligible |
| `mastodon_hashtag_regex_step` | pcre2_jit | eligible |
| `mastodon_hashtag_regex_step` | pcre2 | eligible |
| `mastodon_hashtag_regex_step` | fancy_regex | semantic_difference |
| `mastodon_hashtag_regex_step` | fancy_regex_seek | semantic_difference |
| `mastodon_hashtag_regex_step` | regex | syntax_rejected |
| `python_markdown_smart_emphasis_re` | rust | eligible |
| `python_markdown_smart_emphasis_re` | rust_erroraware | eligible |
| `python_markdown_smart_emphasis_re` | c | eligible |
| `python_markdown_smart_emphasis_re` | onigmo | eligible |
| `python_markdown_smart_emphasis_re` | pcre2_jit | eligible |
| `python_markdown_smart_emphasis_re` | pcre2 | eligible |
| `python_markdown_smart_emphasis_re` | fancy_regex | eligible |
| `python_markdown_smart_emphasis_re` | fancy_regex_seek | eligible |
| `python_markdown_smart_emphasis_re` | regex | syntax_rejected |
| `python_markdown_smart_strong_em_re` | rust | eligible |
| `python_markdown_smart_strong_em_re` | rust_erroraware | eligible |
| `python_markdown_smart_strong_em_re` | c | eligible |
| `python_markdown_smart_strong_em_re` | onigmo | eligible |
| `python_markdown_smart_strong_em_re` | pcre2_jit | eligible |
| `python_markdown_smart_strong_em_re` | pcre2 | eligible |
| `python_markdown_smart_strong_em_re` | fancy_regex | eligible |
| `python_markdown_smart_strong_em_re` | fancy_regex_seek | eligible |
| `python_markdown_smart_strong_em_re` | regex | syntax_rejected |
| `wordpress_shortcode_captures` | rust | eligible |
| `wordpress_shortcode_captures` | rust_erroraware | eligible |
| `wordpress_shortcode_captures` | c | eligible |
| `wordpress_shortcode_captures` | onigmo | eligible |
| `wordpress_shortcode_captures` | pcre2_jit | eligible |
| `wordpress_shortcode_captures` | pcre2 | eligible |
| `wordpress_shortcode_captures` | fancy_regex | eligible |
| `wordpress_shortcode_captures` | fancy_regex_seek | eligible |
| `wordpress_shortcode_captures` | regex | syntax_rejected |
| `symfony_grapheme_chunks_1` | rust | eligible |
| `symfony_grapheme_chunks_1` | rust_erroraware | eligible |
| `symfony_grapheme_chunks_1` | c | eligible |
| `symfony_grapheme_chunks_1` | onigmo | semantic_difference |
| `symfony_grapheme_chunks_1` | pcre2_jit | eligible |
| `symfony_grapheme_chunks_1` | pcre2 | eligible |
| `symfony_grapheme_chunks_1` | fancy_regex | syntax_rejected |
| `symfony_grapheme_chunks_1` | fancy_regex_seek | syntax_rejected |
| `symfony_grapheme_chunks_1` | regex | syntax_rejected |
| `symfony_grapheme_chunks_2` | rust | eligible |
| `symfony_grapheme_chunks_2` | rust_erroraware | eligible |
| `symfony_grapheme_chunks_2` | c | eligible |
| `symfony_grapheme_chunks_2` | onigmo | eligible |
| `symfony_grapheme_chunks_2` | pcre2_jit | eligible |
| `symfony_grapheme_chunks_2` | pcre2 | eligible |
| `symfony_grapheme_chunks_2` | fancy_regex | syntax_rejected |
| `symfony_grapheme_chunks_2` | fancy_regex_seek | syntax_rejected |
| `symfony_grapheme_chunks_2` | regex | syntax_rejected |
| `literal_first` | rust | eligible |
| `literal_first` | rust_erroraware | eligible |
| `literal_first` | c | eligible |
| `literal_first` | onigmo | eligible |
| `literal_first` | pcre2_jit | eligible |
| `literal_first` | pcre2 | eligible |
| `literal_first` | fancy_regex | eligible |
| `literal_first` | fancy_regex_seek | eligible |
| `literal_first` | regex | eligible |
| `literal_middle` | rust | eligible |
| `literal_middle` | rust_erroraware | eligible |
| `literal_middle` | c | eligible |
| `literal_middle` | onigmo | eligible |
| `literal_middle` | pcre2_jit | eligible |
| `literal_middle` | pcre2 | eligible |
| `literal_middle` | fancy_regex | eligible |
| `literal_middle` | fancy_regex_seek | eligible |
| `literal_middle` | regex | eligible |
| `literal_end` | rust | eligible |
| `literal_end` | rust_erroraware | eligible |
| `literal_end` | c | eligible |
| `literal_end` | onigmo | eligible |
| `literal_end` | pcre2_jit | eligible |
| `literal_end` | pcre2 | eligible |
| `literal_end` | fancy_regex | eligible |
| `literal_end` | fancy_regex_seek | eligible |
| `literal_end` | regex | eligible |
| `literal_absent` | rust | eligible |
| `literal_absent` | rust_erroraware | eligible |
| `literal_absent` | c | eligible |
| `literal_absent` | onigmo | eligible |
| `literal_absent` | pcre2_jit | eligible |
| `literal_absent` | pcre2 | eligible |
| `literal_absent` | fancy_regex | eligible |
| `literal_absent` | fancy_regex_seek | eligible |
| `literal_absent` | regex | eligible |
| `linkify_http_tail` | rust | pending |
| `linkify_http_tail` | rust_erroraware | pending |
| `linkify_http_tail` | c | pending |
| `linkify_http_tail` | onigmo | pending |
| `linkify_http_tail` | pcre2_jit | pending |
| `linkify_http_tail` | pcre2 | pending |
| `linkify_http_tail` | fancy_regex | pending |
| `linkify_http_tail` | fancy_regex_seek | pending |
| `linkify_http_tail` | regex | pending |
| `php_cs_fixer_recursive_types` | rust | pending |
| `php_cs_fixer_recursive_types` | rust_erroraware | pending |
| `php_cs_fixer_recursive_types` | c | pending |
| `php_cs_fixer_recursive_types` | onigmo | pending |
| `php_cs_fixer_recursive_types` | pcre2_jit | pending |
| `php_cs_fixer_recursive_types` | pcre2 | pending |
| `php_cs_fixer_recursive_types` | fancy_regex | pending |
| `php_cs_fixer_recursive_types` | fancy_regex_seek | pending |
| `php_cs_fixer_recursive_types` | regex | pending |
| `ferrolink_markup_scan` | rust | eligible |
| `ferrolink_markup_scan` | rust_erroraware | eligible |
| `ferrolink_markup_scan` | c | eligible |
| `ferrolink_markup_scan` | onigmo | eligible |
| `ferrolink_markup_scan` | pcre2_jit | eligible |
| `ferrolink_markup_scan` | pcre2 | eligible |
| `ferrolink_markup_scan` | fancy_regex | eligible |
| `ferrolink_markup_scan` | fancy_regex_seek | eligible |
| `ferrolink_markup_scan` | regex | syntax_rejected |
| `ferrolink_attribute_split` | rust | eligible |
| `ferrolink_attribute_split` | rust_erroraware | eligible |
| `ferrolink_attribute_split` | c | eligible |
| `ferrolink_attribute_split` | onigmo | eligible |
| `ferrolink_attribute_split` | pcre2_jit | eligible |
| `ferrolink_attribute_split` | pcre2 | eligible |
| `ferrolink_attribute_split` | fancy_regex | eligible |
| `ferrolink_attribute_split` | fancy_regex_seek | eligible |
| `ferrolink_attribute_split` | regex | eligible |

## rust_erroraware / steady

Common cases: 27; families: 14. Pair-specific family-weighted ratio: 1.762.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.846 | 1.843–2.065 | Ferroni faster in every run interval |
| `uuid_v4` | 1.972 | 1.859–2.078 | Ferroni faster in every run interval |
| `ipv4_validation` | 5.544 | 3.573–5.571 | Ferroni faster in every run interval |
| `ipv6_validation` | 13.275 | 11.407–15.527 | Ferroni faster in every run interval |
| `semver_version_parse` | 1.116 | 1.099–1.818 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.032 | 0.941–1.107 | inconclusive |
| `jinja_string_token` | 1.243 | 1.237–1.257 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.191 | 1.156–1.192 | Ferroni faster in every run interval |
| `jinja_float_token` | 1.076 | 0.998–1.234 | inconclusive |
| `django_email_local_part` | 3.361 | 3.061–3.560 | Ferroni faster in every run interval |
| `django_email_domain` | 8.020 | 7.766–8.698 | Ferroni faster in every run interval |
| `django_url_regex` | 9.853 | 7.375–10.428 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.090 | 0.967–1.703 | inconclusive |
| `fluent_bit_nginx` | 1.543 | 1.438–1.661 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.040 | 0.951–1.119 | inconclusive |
| `mastodon_hashtag_regex_step` | 1.146 | 1.025–1.161 | inconclusive |
| `python_markdown_smart_emphasis_re` | 1.070 | 1.039–1.071 | inconclusive |
| `python_markdown_smart_strong_em_re` | 1.010 | 0.701–1.105 | inconclusive |
| `wordpress_shortcode_captures` | 0.986 | 0.826–1.140 | inconclusive |
| `symfony_grapheme_chunks_1` | 1.076 | 1.060–1.635 | inconclusive |
| `symfony_grapheme_chunks_2` | 1.031 | 0.943–1.181 | inconclusive |
| `literal_first` | 1.542 | 1.308–1.599 | Ferroni faster in every run interval |
| `literal_middle` | 1.574 | 1.462–1.639 | Ferroni faster in every run interval |
| `literal_end` | 1.528 | 1.254–1.538 | Ferroni faster in every run interval |
| `literal_absent` | 1.415 | 1.348–1.425 | Ferroni faster in every run interval |
| `ferrolink_markup_scan` | 1.029 | 1.007–1.078 | inconclusive |
| `ferrolink_attribute_split` | 1.074 | 0.967–1.163 | inconclusive |

## rust_erroraware / compile

Common cases: 27; families: 14. Pair-specific family-weighted ratio: 0.998.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.994 | 0.988–1.657 | inconclusive |
| `uuid_v4` | 0.952 | 0.939–1.483 | inconclusive |
| `ipv4_validation` | 0.905 | 0.729–1.154 | inconclusive |
| `ipv6_validation` | 0.982 | 0.962–1.230 | inconclusive |
| `semver_version_parse` | 1.050 | 1.019–1.155 | inconclusive |
| `semver_hyphen_range_captures` | 1.009 | 0.928–1.071 | inconclusive |
| `jinja_string_token` | 0.997 | 0.951–1.032 | inconclusive |
| `jinja_integer_token` | 1.093 | 0.901–1.227 | inconclusive |
| `jinja_float_token` | 0.828 | 0.678–0.973 | comparator faster in every run interval |
| `django_email_local_part` | 0.890 | 0.597–1.068 | inconclusive |
| `django_email_domain` | 0.992 | 0.977–1.026 | inconclusive |
| `django_url_regex` | 0.869 | 0.857–0.922 | comparator faster in every run interval |
| `fluent_bit_apache` | 1.157 | 1.048–1.207 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.008 | 0.975–1.049 | inconclusive |
| `rails_underscore_regex_step` | 1.122 | 0.945–1.592 | inconclusive |
| `mastodon_hashtag_regex_step` | 0.997 | 0.936–1.034 | inconclusive |
| `python_markdown_smart_emphasis_re` | 1.083 | 0.966–1.264 | inconclusive |
| `python_markdown_smart_strong_em_re` | 0.969 | 0.578–1.016 | inconclusive |
| `wordpress_shortcode_captures` | 1.014 | 1.010–1.057 | inconclusive |
| `symfony_grapheme_chunks_1` | 1.125 | 1.052–1.217 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_2` | 1.062 | 0.850–1.069 | inconclusive |
| `literal_first` | 1.054 | 0.904–1.673 | inconclusive |
| `literal_middle` | 1.026 | 0.932–1.096 | inconclusive |
| `literal_end` | 1.027 | 0.979–1.788 | inconclusive |
| `literal_absent` | 0.970 | 0.885–0.988 | inconclusive |
| `ferrolink_markup_scan` | 0.889 | 0.837–1.015 | inconclusive |
| `ferrolink_attribute_split` | 0.969 | 0.583–1.042 | inconclusive |

## rust_erroraware / first_use

Common cases: 27; families: 14. Pair-specific family-weighted ratio: 0.755.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.549 | 0.521–0.700 | comparator faster in every run interval |
| `uuid_v4` | 0.540 | 0.532–0.826 | comparator faster in every run interval |
| `ipv4_validation` | 0.745 | 0.574–1.022 | inconclusive |
| `ipv6_validation` | 0.649 | 0.602–0.666 | comparator faster in every run interval |
| `semver_version_parse` | 0.704 | 0.638–0.719 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.747 | 0.582–0.749 | comparator faster in every run interval |
| `jinja_string_token` | 0.477 | 0.459–0.525 | comparator faster in every run interval |
| `jinja_integer_token` | 0.681 | 0.650–1.001 | inconclusive |
| `jinja_float_token` | 0.626 | 0.450–0.633 | comparator faster in every run interval |
| `django_email_local_part` | 0.775 | 0.437–0.831 | comparator faster in every run interval |
| `django_email_domain` | 0.668 | 0.654–0.923 | inconclusive |
| `django_url_regex` | 0.657 | 0.558–0.681 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.640 | 0.526–0.757 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.505 | 0.495–0.528 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 1.015 | 0.927–1.154 | inconclusive |
| `mastodon_hashtag_regex_step` | 0.981 | 0.968–1.101 | inconclusive |
| `python_markdown_smart_emphasis_re` | 0.478 | 0.453–0.750 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.399 | 0.255–0.607 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.996 | 0.964–1.007 | inconclusive |
| `symfony_grapheme_chunks_1` | 1.062 | 0.962–1.536 | inconclusive |
| `symfony_grapheme_chunks_2` | 1.107 | 0.897–1.999 | inconclusive |
| `literal_first` | 0.896 | 0.497–0.949 | inconclusive |
| `literal_middle` | 0.990 | 0.632–1.093 | inconclusive |
| `literal_end` | 0.962 | 0.926–1.108 | inconclusive |
| `literal_absent` | 1.054 | 0.732–1.496 | inconclusive |
| `ferrolink_markup_scan` | 0.995 | 0.710–1.069 | inconclusive |
| `ferrolink_attribute_split` | 0.981 | 0.550–1.075 | inconclusive |

## c / steady

Common cases: 27; families: 14. Pair-specific family-weighted ratio: 2.630.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 3.753 | 3.546–4.192 | Ferroni faster in every run interval |
| `uuid_v4` | 3.351 | 3.158–4.229 | Ferroni faster in every run interval |
| `ipv4_validation` | 5.864 | 3.906–5.875 | Ferroni faster in every run interval |
| `ipv6_validation` | 12.342 | 9.631–14.612 | Ferroni faster in every run interval |
| `semver_version_parse` | 1.367 | 1.365–2.624 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.066 | 1.061–1.146 | inconclusive |
| `jinja_string_token` | 1.193 | 1.118–1.254 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.124 | 1.046–1.127 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.828 | 0.777–0.851 | comparator faster in every run interval |
| `django_email_local_part` | 5.075 | 3.912–5.760 | Ferroni faster in every run interval |
| `django_email_domain` | 42.893 | 42.384–46.681 | Ferroni faster in every run interval |
| `django_url_regex` | 20.518 | 19.458–21.253 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.893 | 1.793–2.106 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 2.603 | 2.445–3.838 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.102 | 1.026–1.955 | inconclusive |
| `mastodon_hashtag_regex_step` | 1.914 | 1.842–1.930 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 1.831 | 1.762–2.299 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 2.190 | 1.702–2.284 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 0.898 | 0.738–1.042 | inconclusive |
| `symfony_grapheme_chunks_1` | 1.288 | 1.215–1.588 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_2` | 1.233 | 1.134–2.277 | Ferroni faster in every run interval |
| `literal_first` | 4.475 | 4.133–4.807 | Ferroni faster in every run interval |
| `literal_middle` | 5.108 | 4.868–9.235 | Ferroni faster in every run interval |
| `literal_end` | 5.132 | 5.029–8.059 | Ferroni faster in every run interval |
| `literal_absent` | 2.784 | 2.773–3.170 | Ferroni faster in every run interval |
| `ferrolink_markup_scan` | 1.599 | 1.061–2.018 | Ferroni faster in every run interval |
| `ferrolink_attribute_split` | 1.355 | 1.131–1.450 | Ferroni faster in every run interval |

## c / compile

Common cases: 27; families: 14. Pair-specific family-weighted ratio: 0.454.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 5.090 | 4.971–5.403 | Ferroni faster in every run interval |
| `uuid_v4` | 5.637 | 4.238–6.830 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.313 | 0.294–0.347 | comparator faster in every run interval |
| `ipv6_validation` | 0.370 | 0.313–0.440 | comparator faster in every run interval |
| `semver_version_parse` | 0.346 | 0.344–0.356 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.273 | 0.254–0.324 | comparator faster in every run interval |
| `jinja_string_token` | 0.243 | 0.202–0.255 | comparator faster in every run interval |
| `jinja_integer_token` | 2.559 | 2.444–3.048 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.477 | 0.448–0.579 | comparator faster in every run interval |
| `django_email_local_part` | 2.371 | 1.772–3.884 | Ferroni faster in every run interval |
| `django_email_domain` | 0.398 | 0.261–0.410 | comparator faster in every run interval |
| `django_url_regex` | 0.549 | 0.545–0.620 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.265 | 0.198–0.293 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.249 | 0.236–0.274 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.502 | 0.428–0.738 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.700 | 0.558–0.712 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.289 | 0.167–0.345 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.206 | 0.158–0.219 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.364 | 0.322–0.417 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.195 | 0.098–0.206 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.171 | 0.161–0.211 | comparator faster in every run interval |
| `literal_first` | 0.240 | 0.229–0.430 | comparator faster in every run interval |
| `literal_middle` | 0.268 | 0.247–0.466 | comparator faster in every run interval |
| `literal_end` | 0.264 | 0.238–0.344 | comparator faster in every run interval |
| `literal_absent` | 0.218 | 0.212–0.243 | comparator faster in every run interval |
| `ferrolink_markup_scan` | 0.235 | 0.165–0.246 | comparator faster in every run interval |
| `ferrolink_attribute_split` | 0.210 | 0.116–0.223 | comparator faster in every run interval |

## c / first_use

Common cases: 27; families: 14. Pair-specific family-weighted ratio: 0.404.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 2.817 | 2.492–2.845 | Ferroni faster in every run interval |
| `uuid_v4` | 2.963 | 2.908–3.647 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.227 | 0.205–0.246 | comparator faster in every run interval |
| `ipv6_validation` | 0.253 | 0.216–0.266 | comparator faster in every run interval |
| `semver_version_parse` | 0.234 | 0.160–0.245 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.230 | 0.146–0.251 | comparator faster in every run interval |
| `jinja_string_token` | 0.131 | 0.108–0.149 | comparator faster in every run interval |
| `jinja_integer_token` | 2.032 | 1.871–2.426 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.379 | 0.290–0.419 | comparator faster in every run interval |
| `django_email_local_part` | 2.086 | 1.898–2.385 | Ferroni faster in every run interval |
| `django_email_domain` | 0.286 | 0.239–0.297 | comparator faster in every run interval |
| `django_url_regex` | 0.437 | 0.428–0.634 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.159 | 0.158–0.168 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.136 | 0.125–0.148 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.530 | 0.524–0.595 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.742 | 0.720–0.823 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.173 | 0.140–0.188 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.128 | 0.096–0.156 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.356 | 0.326–0.396 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.359 | 0.355–0.382 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.431 | 0.365–0.543 | comparator faster in every run interval |
| `literal_first` | 0.349 | 0.205–0.376 | comparator faster in every run interval |
| `literal_middle` | 0.378 | 0.262–0.423 | comparator faster in every run interval |
| `literal_end` | 0.392 | 0.322–0.505 | comparator faster in every run interval |
| `literal_absent` | 0.307 | 0.242–0.343 | comparator faster in every run interval |
| `ferrolink_markup_scan` | 0.331 | 0.174–0.383 | comparator faster in every run interval |
| `ferrolink_attribute_split` | 0.238 | 0.121–0.246 | comparator faster in every run interval |

## onigmo / steady

Common cases: 26; families: 14. Pair-specific family-weighted ratio: 3.431.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 6.162 | 5.427–7.369 | Ferroni faster in every run interval |
| `uuid_v4` | 6.193 | 6.054–6.242 | Ferroni faster in every run interval |
| `ipv4_validation` | 5.778 | 5.070–5.867 | Ferroni faster in every run interval |
| `ipv6_validation` | 19.875 | 15.337–21.137 | Ferroni faster in every run interval |
| `semver_version_parse` | 1.981 | 1.722–2.878 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.199 | 1.085–1.335 | Ferroni faster in every run interval |
| `jinja_string_token` | 0.911 | 0.869–1.026 | inconclusive |
| `jinja_integer_token` | 1.255 | 1.248–1.405 | Ferroni faster in every run interval |
| `jinja_float_token` | 1.380 | 1.270–1.464 | Ferroni faster in every run interval |
| `django_email_local_part` | 4.959 | 3.534–5.010 | Ferroni faster in every run interval |
| `django_email_domain` | 71.655 | 59.985–83.802 | Ferroni faster in every run interval |
| `django_url_regex` | 62.608 | 60.072–86.888 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 2.165 | 2.047–2.577 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 3.470 | 3.455–3.472 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 0.969 | 0.908–1.066 | inconclusive |
| `mastodon_hashtag_regex_step` | 2.131 | 2.029–2.400 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 2.003 | 1.696–2.446 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 2.552 | 2.489–2.553 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 1.101 | 0.765–1.111 | inconclusive |
| `symfony_grapheme_chunks_2` | 3.233 | 2.662–3.983 | Ferroni faster in every run interval |
| `literal_first` | 1.983 | 1.894–2.202 | Ferroni faster in every run interval |
| `literal_middle` | 3.067 | 2.187–3.349 | Ferroni faster in every run interval |
| `literal_end` | 3.286 | 2.929–3.810 | Ferroni faster in every run interval |
| `literal_absent` | 2.727 | 2.430–2.728 | Ferroni faster in every run interval |
| `ferrolink_markup_scan` | 2.291 | 1.592–2.710 | Ferroni faster in every run interval |
| `ferrolink_attribute_split` | 1.421 | 1.227–1.423 | Ferroni faster in every run interval |

## onigmo / compile

Common cases: 26; families: 14. Pair-specific family-weighted ratio: 0.576.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 6.009 | 5.406–6.969 | Ferroni faster in every run interval |
| `uuid_v4` | 7.503 | 5.527–7.951 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.319 | 0.283–0.363 | comparator faster in every run interval |
| `ipv6_validation` | 0.350 | 0.346–0.354 | comparator faster in every run interval |
| `semver_version_parse` | 0.324 | 0.317–0.443 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.320 | 0.313–0.357 | comparator faster in every run interval |
| `jinja_string_token` | 0.197 | 0.164–0.227 | comparator faster in every run interval |
| `jinja_integer_token` | 2.322 | 2.157–2.882 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.562 | 0.503–0.623 | comparator faster in every run interval |
| `django_email_local_part` | 3.060 | 1.783–3.661 | Ferroni faster in every run interval |
| `django_email_domain` | 0.230 | 0.145–0.255 | comparator faster in every run interval |
| `django_url_regex` | 0.540 | 0.478–0.659 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.241 | 0.230–0.246 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.232 | 0.208–0.248 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.481 | 0.415–0.671 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.767 | 0.765–0.876 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.212 | 0.124–0.217 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.158 | 0.125–0.161 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.342 | 0.251–0.400 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 8.784 | 7.367–9.288 | Ferroni faster in every run interval |
| `literal_first` | 0.169 | 0.160–0.323 | comparator faster in every run interval |
| `literal_middle` | 0.201 | 0.200–0.212 | comparator faster in every run interval |
| `literal_end` | 0.238 | 0.187–0.358 | comparator faster in every run interval |
| `literal_absent` | 0.196 | 0.170–0.198 | comparator faster in every run interval |
| `ferrolink_markup_scan` | 0.225 | 0.157–0.250 | comparator faster in every run interval |
| `ferrolink_attribute_split` | 0.224 | 0.156–0.243 | comparator faster in every run interval |

## onigmo / first_use

Common cases: 26; families: 14. Pair-specific family-weighted ratio: 0.464.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 3.062 | 2.460–3.323 | Ferroni faster in every run interval |
| `uuid_v4` | 3.905 | 3.360–4.898 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.215 | 0.191–0.296 | comparator faster in every run interval |
| `ipv6_validation` | 0.240 | 0.226–0.256 | comparator faster in every run interval |
| `semver_version_parse` | 0.248 | 0.205–0.272 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.219 | 0.217–0.287 | comparator faster in every run interval |
| `jinja_string_token` | 0.112 | 0.084–0.114 | comparator faster in every run interval |
| `jinja_integer_token` | 1.845 | 1.332–2.010 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.406 | 0.323–0.599 | comparator faster in every run interval |
| `django_email_local_part` | 2.323 | 1.288–2.410 | Ferroni faster in every run interval |
| `django_email_domain` | 0.170 | 0.140–0.171 | comparator faster in every run interval |
| `django_url_regex` | 0.322 | 0.286–0.346 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.108 | 0.105–0.133 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.144 | 0.116–0.147 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.493 | 0.410–0.495 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.773 | 0.569–0.784 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.126 | 0.126–0.143 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.088 | 0.052–0.104 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.380 | 0.181–0.406 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 8.978 | 7.758–15.977 | Ferroni faster in every run interval |
| `literal_first` | 0.197 | 0.188–0.243 | comparator faster in every run interval |
| `literal_middle` | 0.279 | 0.274–0.289 | comparator faster in every run interval |
| `literal_end` | 0.258 | 0.245–0.273 | comparator faster in every run interval |
| `literal_absent` | 0.293 | 0.218–0.297 | comparator faster in every run interval |
| `ferrolink_markup_scan` | 0.348 | 0.167–0.362 | comparator faster in every run interval |
| `ferrolink_attribute_split` | 0.262 | 0.126–0.275 | comparator faster in every run interval |

## pcre2_jit / steady

Common cases: 27; families: 14. Pair-specific family-weighted ratio: 0.641.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.925 | 0.722–0.954 | inconclusive |
| `uuid_v4` | 1.026 | 0.736–1.239 | inconclusive |
| `ipv4_validation` | 1.344 | 0.931–1.441 | inconclusive |
| `ipv6_validation` | 3.384 | 2.599–6.800 | Ferroni faster in every run interval |
| `semver_version_parse` | 0.462 | 0.425–0.531 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.430 | 0.415–0.442 | comparator faster in every run interval |
| `jinja_string_token` | 0.471 | 0.460–0.516 | comparator faster in every run interval |
| `jinja_integer_token` | 0.453 | 0.443–0.519 | comparator faster in every run interval |
| `jinja_float_token` | 0.382 | 0.376–0.400 | comparator faster in every run interval |
| `django_email_local_part` | 1.463 | 1.054–1.945 | inconclusive |
| `django_email_domain` | 0.867 | 0.834–0.879 | comparator faster in every run interval |
| `django_url_regex` | 1.804 | 1.306–1.909 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 0.396 | 0.388–0.431 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.564 | 0.527–0.632 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.315 | 0.308–0.331 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.333 | 0.309–0.345 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.616 | 0.543–0.651 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.459 | 0.447–0.475 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.353 | 0.344–0.430 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.542 | 0.481–0.735 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.500 | 0.452–0.519 | comparator faster in every run interval |
| `literal_first` | 1.379 | 1.357–1.444 | Ferroni faster in every run interval |
| `literal_middle` | 1.643 | 1.590–2.457 | Ferroni faster in every run interval |
| `literal_end` | 1.415 | 1.296–1.513 | Ferroni faster in every run interval |
| `literal_absent` | 1.285 | 1.189–1.373 | Ferroni faster in every run interval |
| `ferrolink_markup_scan` | 0.279 | 0.193–0.372 | comparator faster in every run interval |
| `ferrolink_attribute_split` | 0.448 | 0.348–0.452 | comparator faster in every run interval |

## pcre2_jit / compile

Common cases: 27; families: 14. Pair-specific family-weighted ratio: 0.462.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.424 | 0.359–0.466 | comparator faster in every run interval |
| `uuid_v4` | 0.338 | 0.300–0.371 | comparator faster in every run interval |
| `ipv4_validation` | 0.412 | 0.331–0.422 | comparator faster in every run interval |
| `ipv6_validation` | 0.393 | 0.370–0.442 | comparator faster in every run interval |
| `semver_version_parse` | 0.462 | 0.377–0.603 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.412 | 0.385–0.509 | comparator faster in every run interval |
| `jinja_string_token` | 0.480 | 0.435–0.492 | comparator faster in every run interval |
| `jinja_integer_token` | 0.377 | 0.358–0.429 | comparator faster in every run interval |
| `jinja_float_token` | 0.222 | 0.218–0.342 | comparator faster in every run interval |
| `django_email_local_part` | 0.387 | 0.273–0.446 | comparator faster in every run interval |
| `django_email_domain` | 0.084 | 0.052–0.085 | comparator faster in every run interval |
| `django_url_regex` | 0.083 | 0.079–0.134 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.451 | 0.416–0.521 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.430 | 0.367–0.484 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 1.010 | 0.940–1.287 | inconclusive |
| `mastodon_hashtag_regex_step` | 0.264 | 0.262–0.269 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 1.078 | 1.062–1.155 | inconclusive |
| `python_markdown_smart_strong_em_re` | 0.601 | 0.503–0.629 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.675 | 0.663–0.779 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.717 | 0.662–0.862 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.546 | 0.397–0.831 | comparator faster in every run interval |
| `literal_first` | 2.940 | 2.790–5.203 | Ferroni faster in every run interval |
| `literal_middle` | 4.117 | 3.737–6.174 | Ferroni faster in every run interval |
| `literal_end` | 3.264 | 2.721–6.248 | Ferroni faster in every run interval |
| `literal_absent` | 2.821 | 2.785–2.944 | Ferroni faster in every run interval |
| `ferrolink_markup_scan` | 0.370 | 0.276–0.377 | comparator faster in every run interval |
| `ferrolink_attribute_split` | 0.585 | 0.394–0.621 | comparator faster in every run interval |

## pcre2_jit / first_use

Common cases: 27; families: 14. Pair-specific family-weighted ratio: 0.415.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.207 | 0.194–0.213 | comparator faster in every run interval |
| `uuid_v4` | 0.207 | 0.187–0.283 | comparator faster in every run interval |
| `ipv4_validation` | 0.291 | 0.281–0.554 | comparator faster in every run interval |
| `ipv6_validation` | 0.258 | 0.254–0.284 | comparator faster in every run interval |
| `semver_version_parse` | 0.376 | 0.313–0.441 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.309 | 0.302–0.376 | comparator faster in every run interval |
| `jinja_string_token` | 0.308 | 0.303–0.315 | comparator faster in every run interval |
| `jinja_integer_token` | 0.356 | 0.309–0.487 | comparator faster in every run interval |
| `jinja_float_token` | 0.199 | 0.162–0.358 | comparator faster in every run interval |
| `django_email_local_part` | 0.313 | 0.207–0.363 | comparator faster in every run interval |
| `django_email_domain` | 0.054 | 0.045–0.056 | comparator faster in every run interval |
| `django_url_regex` | 0.061 | 0.059–0.065 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.280 | 0.222–0.331 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.270 | 0.250–0.460 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 1.345 | 1.257–1.400 | Ferroni faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.317 | 0.279–0.333 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.675 | 0.672–1.055 | inconclusive |
| `python_markdown_smart_strong_em_re` | 0.440 | 0.382–0.473 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.761 | 0.676–0.819 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 1.753 | 0.936–1.839 | inconclusive |
| `symfony_grapheme_chunks_2` | 1.142 | 0.964–1.257 | inconclusive |
| `literal_first` | 2.472 | 2.452–2.816 | Ferroni faster in every run interval |
| `literal_middle` | 3.634 | 3.303–3.918 | Ferroni faster in every run interval |
| `literal_end` | 2.473 | 1.983–3.817 | Ferroni faster in every run interval |
| `literal_absent` | 3.110 | 2.768–3.307 | Ferroni faster in every run interval |
| `ferrolink_markup_scan` | 0.455 | 0.240–0.488 | comparator faster in every run interval |
| `ferrolink_attribute_split` | 0.613 | 0.370–0.715 | comparator faster in every run interval |

## pcre2 / steady

Common cases: 27; families: 14. Pair-specific family-weighted ratio: 1.829.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.698 | 1.586–1.740 | Ferroni faster in every run interval |
| `uuid_v4` | 1.851 | 1.815–2.151 | Ferroni faster in every run interval |
| `ipv4_validation` | 8.315 | 8.119–8.638 | Ferroni faster in every run interval |
| `ipv6_validation` | 19.898 | 14.951–20.358 | Ferroni faster in every run interval |
| `semver_version_parse` | 1.465 | 1.392–2.392 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.765 | 1.536–1.916 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.107 | 1.007–1.134 | inconclusive |
| `jinja_integer_token` | 1.595 | 1.547–1.601 | Ferroni faster in every run interval |
| `jinja_float_token` | 1.191 | 1.180–1.195 | Ferroni faster in every run interval |
| `django_email_local_part` | 5.023 | 3.524–5.307 | Ferroni faster in every run interval |
| `django_email_domain` | 2.560 | 2.550–2.775 | Ferroni faster in every run interval |
| `django_url_regex` | 4.327 | 3.415–4.767 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.578 | 1.188–1.808 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 2.080 | 1.904–2.279 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 0.977 | 0.865–0.993 | inconclusive |
| `mastodon_hashtag_regex_step` | 0.756 | 0.751–0.761 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 3.203 | 2.812–3.265 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 3.672 | 3.373–3.800 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 0.958 | 0.826–1.085 | inconclusive |
| `symfony_grapheme_chunks_1` | 0.738 | 0.734–0.896 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.704 | 0.676–0.918 | inconclusive |
| `literal_first` | 2.503 | 1.594–2.538 | Ferroni faster in every run interval |
| `literal_middle` | 2.874 | 2.864–2.914 | Ferroni faster in every run interval |
| `literal_end` | 2.391 | 2.154–2.954 | Ferroni faster in every run interval |
| `literal_absent` | 1.384 | 1.314–1.752 | Ferroni faster in every run interval |
| `ferrolink_markup_scan` | 0.838 | 0.685–1.039 | inconclusive |
| `ferrolink_attribute_split` | 1.001 | 0.905–1.039 | inconclusive |

## pcre2 / compile

Common cases: 27; families: 14. Pair-specific family-weighted ratio: 0.108.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.122 | 0.110–0.127 | comparator faster in every run interval |
| `uuid_v4` | 0.132 | 0.097–0.144 | comparator faster in every run interval |
| `ipv4_validation` | 0.090 | 0.066–0.105 | comparator faster in every run interval |
| `ipv6_validation` | 0.111 | 0.104–0.122 | comparator faster in every run interval |
| `semver_version_parse` | 0.118 | 0.112–0.122 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.117 | 0.105–0.121 | comparator faster in every run interval |
| `jinja_string_token` | 0.084 | 0.077–0.092 | comparator faster in every run interval |
| `jinja_integer_token` | 0.102 | 0.095–0.107 | comparator faster in every run interval |
| `jinja_float_token` | 0.040 | 0.037–0.045 | comparator faster in every run interval |
| `django_email_local_part` | 0.136 | 0.105–0.163 | comparator faster in every run interval |
| `django_email_domain` | 0.064 | 0.038–0.068 | comparator faster in every run interval |
| `django_url_regex` | 0.058 | 0.053–0.061 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.073 | 0.071–0.074 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.075 | 0.065–0.103 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.269 | 0.245–0.339 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.133 | 0.131–0.148 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.114 | 0.112–0.128 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.071 | 0.069–0.076 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.165 | 0.154–0.205 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.073 | 0.036–0.079 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.056 | 0.049–0.081 | comparator faster in every run interval |
| `literal_first` | 0.149 | 0.140–0.281 | comparator faster in every run interval |
| `literal_middle` | 0.203 | 0.161–0.220 | comparator faster in every run interval |
| `literal_end` | 0.160 | 0.139–0.305 | comparator faster in every run interval |
| `literal_absent` | 0.160 | 0.139–0.364 | comparator faster in every run interval |
| `ferrolink_markup_scan` | 0.070 | 0.052–0.070 | comparator faster in every run interval |
| `ferrolink_attribute_split` | 0.204 | 0.114–0.206 | comparator faster in every run interval |

## pcre2 / first_use

Common cases: 27; families: 14. Pair-specific family-weighted ratio: 0.151.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.097 | 0.094–0.108 | comparator faster in every run interval |
| `uuid_v4` | 0.104 | 0.082–0.111 | comparator faster in every run interval |
| `ipv4_validation` | 0.104 | 0.094–0.107 | comparator faster in every run interval |
| `ipv6_validation` | 0.074 | 0.072–0.086 | comparator faster in every run interval |
| `semver_version_parse` | 0.102 | 0.090–0.122 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.100 | 0.099–0.109 | comparator faster in every run interval |
| `jinja_string_token` | 0.076 | 0.073–0.093 | comparator faster in every run interval |
| `jinja_integer_token` | 0.099 | 0.087–0.109 | comparator faster in every run interval |
| `jinja_float_token` | 0.050 | 0.034–0.067 | comparator faster in every run interval |
| `django_email_local_part` | 0.147 | 0.106–0.161 | comparator faster in every run interval |
| `django_email_domain` | 0.043 | 0.038–0.044 | comparator faster in every run interval |
| `django_url_regex` | 0.048 | 0.046–0.070 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.077 | 0.071–0.079 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.093 | 0.074–0.127 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.474 | 0.448–0.485 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.187 | 0.137–0.194 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.158 | 0.142–0.160 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.092 | 0.076–0.136 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.213 | 0.201–0.225 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.379 | 0.355–0.645 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.397 | 0.307–0.938 | inconclusive |
| `literal_first` | 0.768 | 0.625–1.127 | inconclusive |
| `literal_middle` | 0.935 | 0.812–1.708 | inconclusive |
| `literal_end` | 0.766 | 0.680–0.842 | comparator faster in every run interval |
| `literal_absent` | 0.792 | 0.735–0.977 | inconclusive |
| `ferrolink_markup_scan` | 0.158 | 0.130–0.182 | comparator faster in every run interval |
| `ferrolink_attribute_split` | 0.269 | 0.121–0.284 | comparator faster in every run interval |

## fancy_regex / steady

Common cases: 23; families: 12. Pair-specific family-weighted ratio: 2.677.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.163 | 0.830–1.209 | inconclusive |
| `uuid_v4` | 1.214 | 0.757–1.239 | inconclusive |
| `ipv4_validation` | 1.203 | 0.723–1.323 | inconclusive |
| `ipv6_validation` | 1.285 | 1.208–1.476 | Ferroni faster in every run interval |
| `semver_version_parse` | 2.534 | 2.028–5.561 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.642 | 1.015–1.987 | inconclusive |
| `jinja_string_token` | 1.078 | 1.009–1.159 | inconclusive |
| `jinja_integer_token` | 1.582 | 1.539–2.230 | Ferroni faster in every run interval |
| `jinja_float_token` | 1.987 | 1.396–2.275 | Ferroni faster in every run interval |
| `django_email_domain` | 9.097 | 8.940–10.937 | Ferroni faster in every run interval |
| `django_url_regex` | 29.622 | 28.785–43.043 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.663 | 1.341–2.128 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 2.209 | 1.870–2.531 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 3.067 | 2.911–3.581 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 3.105 | 2.674–4.056 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 4.025 | 3.674–4.802 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 1.775 | 1.762–2.129 | Ferroni faster in every run interval |
| `literal_first` | 1.138 | 0.790–1.216 | inconclusive |
| `literal_middle` | 1.233 | 1.035–1.296 | inconclusive |
| `literal_end` | 1.031 | 1.001–1.117 | inconclusive |
| `literal_absent` | 1.144 | 1.098–1.153 | Ferroni faster in every run interval |
| `ferrolink_markup_scan` | 4.097 | 3.042–4.879 | Ferroni faster in every run interval |
| `ferrolink_attribute_split` | 1.722 | 1.621–2.248 | Ferroni faster in every run interval |

## fancy_regex / compile

Common cases: 23; families: 12. Pair-specific family-weighted ratio: 2.182.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.547 | 1.471–1.960 | Ferroni faster in every run interval |
| `uuid_v4` | 1.520 | 1.187–1.696 | Ferroni faster in every run interval |
| `ipv4_validation` | 1.016 | 0.978–1.122 | inconclusive |
| `ipv6_validation` | 1.255 | 1.236–1.312 | Ferroni faster in every run interval |
| `semver_version_parse` | 18.264 | 12.617–25.489 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 12.981 | 11.027–15.593 | Ferroni faster in every run interval |
| `jinja_string_token` | 2.906 | 2.766–3.292 | Ferroni faster in every run interval |
| `jinja_integer_token` | 2.636 | 2.448–3.903 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.251 | 0.232–0.296 | comparator faster in every run interval |
| `django_email_domain` | 3.990 | 2.533–4.307 | Ferroni faster in every run interval |
| `django_url_regex` | 3.291 | 3.231–3.993 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 2.457 | 2.446–2.621 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 2.252 | 2.073–2.863 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.639 | 1.382–2.441 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.951 | 0.933–1.050 | inconclusive |
| `python_markdown_smart_strong_em_re` | 0.725 | 0.563–0.813 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 1.921 | 1.828–2.326 | Ferroni faster in every run interval |
| `literal_first` | 1.127 | 1.053–1.313 | inconclusive |
| `literal_middle` | 1.202 | 1.133–1.265 | Ferroni faster in every run interval |
| `literal_end` | 1.464 | 1.114–2.057 | Ferroni faster in every run interval |
| `literal_absent` | 1.100 | 1.032–1.208 | inconclusive |
| `ferrolink_markup_scan` | 3.048 | 2.725–3.390 | Ferroni faster in every run interval |
| `ferrolink_attribute_split` | 4.176 | 4.162–4.351 | Ferroni faster in every run interval |

## fancy_regex / first_use

Common cases: 23; families: 12. Pair-specific family-weighted ratio: 1.674.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.109 | 0.960–1.488 | inconclusive |
| `uuid_v4` | 1.049 | 0.964–1.534 | inconclusive |
| `ipv4_validation` | 0.745 | 0.742–0.897 | comparator faster in every run interval |
| `ipv6_validation` | 0.866 | 0.846–0.877 | comparator faster in every run interval |
| `semver_version_parse` | 12.512 | 11.701–18.064 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 8.760 | 8.029–10.027 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.511 | 1.404–1.714 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.988 | 1.953–2.438 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.199 | 0.174–0.232 | comparator faster in every run interval |
| `django_email_domain` | 2.633 | 2.322–2.724 | Ferroni faster in every run interval |
| `django_url_regex` | 2.817 | 2.536–2.989 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.413 | 1.343–1.431 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.333 | 1.227–1.514 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.816 | 1.686–1.899 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.451 | 0.365–0.494 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.312 | 0.288–0.447 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 1.801 | 1.736–2.078 | Ferroni faster in every run interval |
| `literal_first` | 0.966 | 0.441–1.022 | inconclusive |
| `literal_middle` | 1.152 | 0.939–1.448 | inconclusive |
| `literal_end` | 1.220 | 1.149–1.227 | Ferroni faster in every run interval |
| `literal_absent` | 1.338 | 1.002–1.607 | inconclusive |
| `ferrolink_markup_scan` | 3.964 | 2.512–4.125 | Ferroni faster in every run interval |
| `ferrolink_attribute_split` | 4.852 | 2.784–4.949 | Ferroni faster in every run interval |

## fancy_regex_seek / steady

Common cases: 23; families: 12. Pair-specific family-weighted ratio: 2.706.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.095 | 0.973–1.149 | inconclusive |
| `uuid_v4` | 1.314 | 1.256–1.317 | Ferroni faster in every run interval |
| `ipv4_validation` | 1.175 | 0.723–1.275 | inconclusive |
| `ipv6_validation` | 1.266 | 1.251–1.477 | Ferroni faster in every run interval |
| `semver_version_parse` | 2.385 | 2.002–3.887 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.848 | 1.550–2.009 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.065 | 1.015–1.233 | inconclusive |
| `jinja_integer_token` | 1.498 | 1.419–1.524 | Ferroni faster in every run interval |
| `jinja_float_token` | 1.851 | 1.473–1.972 | Ferroni faster in every run interval |
| `django_email_domain` | 9.960 | 9.534–10.356 | Ferroni faster in every run interval |
| `django_url_regex` | 30.227 | 28.622–42.320 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.690 | 1.243–1.786 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 2.401 | 1.878–2.500 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 3.058 | 2.731–3.325 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 2.651 | 2.363–2.992 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 4.204 | 3.911–4.476 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 2.060 | 1.830–2.134 | Ferroni faster in every run interval |
| `literal_first` | 1.142 | 0.818–1.147 | inconclusive |
| `literal_middle` | 1.196 | 1.022–1.240 | inconclusive |
| `literal_end` | 1.097 | 1.057–1.123 | inconclusive |
| `literal_absent` | 1.226 | 1.225–1.861 | Ferroni faster in every run interval |
| `ferrolink_markup_scan` | 2.791 | 1.958–3.092 | Ferroni faster in every run interval |
| `ferrolink_attribute_split` | 1.986 | 1.755–2.016 | Ferroni faster in every run interval |

## fancy_regex_seek / compile

Common cases: 23; families: 12. Pair-specific family-weighted ratio: 2.534.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.358 | 1.291–2.171 | Ferroni faster in every run interval |
| `uuid_v4` | 1.346 | 1.130–1.356 | inconclusive |
| `ipv4_validation` | 0.964 | 0.661–1.097 | inconclusive |
| `ipv6_validation` | 1.310 | 1.265–1.381 | Ferroni faster in every run interval |
| `semver_version_parse` | 18.460 | 12.218–22.184 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 14.172 | 10.739–15.027 | Ferroni faster in every run interval |
| `jinja_string_token` | 2.961 | 2.590–3.061 | Ferroni faster in every run interval |
| `jinja_integer_token` | 2.995 | 2.438–3.748 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.319 | 0.276–0.338 | comparator faster in every run interval |
| `django_email_domain` | 4.281 | 2.985–4.757 | Ferroni faster in every run interval |
| `django_url_regex` | 3.295 | 3.101–4.186 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 2.289 | 2.274–2.639 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 2.928 | 2.159–3.552 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.437 | 1.346–1.732 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.993 | 0.679–1.015 | inconclusive |
| `python_markdown_smart_strong_em_re` | 0.721 | 0.689–0.722 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 6.107 | 5.431–6.742 | Ferroni faster in every run interval |
| `literal_first` | 1.231 | 1.058–1.720 | inconclusive |
| `literal_middle` | 1.208 | 1.145–1.380 | Ferroni faster in every run interval |
| `literal_end` | 1.211 | 1.003–1.280 | inconclusive |
| `literal_absent` | 1.230 | 1.107–1.885 | inconclusive |
| `ferrolink_markup_scan` | 5.221 | 4.758–5.550 | Ferroni faster in every run interval |
| `ferrolink_attribute_split` | 7.105 | 6.894–7.107 | Ferroni faster in every run interval |

## fancy_regex_seek / first_use

Common cases: 23; families: 12. Pair-specific family-weighted ratio: 1.958.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.030 | 0.953–1.102 | inconclusive |
| `uuid_v4` | 0.962 | 0.943–1.032 | inconclusive |
| `ipv4_validation` | 0.758 | 0.730–0.886 | comparator faster in every run interval |
| `ipv6_validation` | 0.840 | 0.769–0.878 | comparator faster in every run interval |
| `semver_version_parse` | 12.781 | 8.330–15.936 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 9.058 | 8.284–10.553 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.503 | 1.477–1.753 | Ferroni faster in every run interval |
| `jinja_integer_token` | 2.033 | 1.699–2.120 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.263 | 0.217–0.323 | comparator faster in every run interval |
| `django_email_domain` | 2.743 | 2.297–2.785 | Ferroni faster in every run interval |
| `django_url_regex` | 2.377 | 2.176–2.413 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.612 | 1.325–1.622 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.348 | 1.278–1.379 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.838 | 1.702–2.106 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.481 | 0.442–0.510 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.364 | 0.319–0.448 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 6.270 | 5.412–6.943 | Ferroni faster in every run interval |
| `literal_first` | 0.962 | 0.470–1.445 | inconclusive |
| `literal_middle` | 1.286 | 1.043–1.296 | inconclusive |
| `literal_end` | 1.045 | 1.018–1.247 | inconclusive |
| `literal_absent` | 1.310 | 0.968–2.281 | inconclusive |
| `ferrolink_markup_scan` | 7.278 | 3.993–7.313 | Ferroni faster in every run interval |
| `ferrolink_attribute_split` | 7.838 | 4.857–8.453 | Ferroni faster in every run interval |

## regex / steady

Common cases: 15; families: 7. Pair-specific family-weighted ratio: 1.378.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.270 | 1.213–1.381 | Ferroni faster in every run interval |
| `uuid_v4` | 1.403 | 1.209–1.425 | Ferroni faster in every run interval |
| `ipv4_validation` | 1.403 | 1.122–1.485 | Ferroni faster in every run interval |
| `ipv6_validation` | 1.634 | 1.395–1.645 | Ferroni faster in every run interval |
| `semver_version_parse` | 1.943 | 1.766–2.241 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.281 | 0.969–1.405 | inconclusive |
| `jinja_string_token` | 0.719 | 0.675–0.980 | inconclusive |
| `jinja_integer_token` | 1.131 | 1.058–2.090 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.423 | 1.305–1.638 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 2.206 | 1.664–2.229 | Ferroni faster in every run interval |
| `literal_first` | 1.022 | 0.757–1.038 | inconclusive |
| `literal_middle` | 1.155 | 1.050–1.233 | Ferroni faster in every run interval |
| `literal_end` | 0.974 | 0.972–0.998 | inconclusive |
| `literal_absent` | 1.037 | 1.019–1.492 | inconclusive |
| `ferrolink_attribute_split` | 1.774 | 1.567–1.829 | Ferroni faster in every run interval |

## regex / compile

Common cases: 15; families: 7. Pair-specific family-weighted ratio: 2.235.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.093 | 1.074–1.369 | Ferroni faster in every run interval |
| `uuid_v4` | 0.917 | 0.857–0.996 | inconclusive |
| `ipv4_validation` | 0.908 | 0.656–1.017 | inconclusive |
| `ipv6_validation` | 1.124 | 1.106–1.264 | Ferroni faster in every run interval |
| `semver_version_parse` | 17.874 | 11.350–22.174 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 11.818 | 10.786–15.087 | Ferroni faster in every run interval |
| `jinja_string_token` | 2.947 | 2.639–3.647 | Ferroni faster in every run interval |
| `jinja_integer_token` | 2.049 | 1.964–3.354 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 2.302 | 2.286–2.472 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 2.190 | 2.100–2.529 | Ferroni faster in every run interval |
| `literal_first` | 1.244 | 1.232–1.576 | Ferroni faster in every run interval |
| `literal_middle` | 1.308 | 1.143–1.321 | Ferroni faster in every run interval |
| `literal_end` | 1.230 | 1.160–1.324 | Ferroni faster in every run interval |
| `literal_absent` | 1.222 | 1.203–1.277 | Ferroni faster in every run interval |
| `ferrolink_attribute_split` | 2.744 | 1.710–2.922 | Ferroni faster in every run interval |

## regex / first_use

Common cases: 15; families: 7. Pair-specific family-weighted ratio: 1.775.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.845 | 0.790–1.249 | inconclusive |
| `uuid_v4` | 0.814 | 0.774–1.231 | inconclusive |
| `ipv4_validation` | 0.687 | 0.678–0.737 | comparator faster in every run interval |
| `ipv6_validation` | 0.839 | 0.701–0.874 | comparator faster in every run interval |
| `semver_version_parse` | 12.319 | 8.354–13.588 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 8.847 | 8.447–9.148 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.542 | 1.401–1.616 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.568 | 1.342–1.688 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.339 | 1.240–1.355 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.251 | 1.227–1.318 | Ferroni faster in every run interval |
| `literal_first` | 1.069 | 0.661–1.188 | inconclusive |
| `literal_middle` | 1.198 | 1.146–1.294 | Ferroni faster in every run interval |
| `literal_end` | 1.214 | 0.709–1.306 | inconclusive |
| `literal_absent` | 1.287 | 1.055–1.743 | inconclusive |
| `ferrolink_attribute_split` | 3.525 | 3.014–3.689 | Ferroni faster in every run interval |

Raw samples, estimates, confidence intervals, failures, eligibility reasons, corpus snapshot and execution order are retained beside this report.

Memory, where requested, is fresh-process peak RSS including the binary, runtime, parsed catalog, compilation, input/output and allocator. It is not isolated compiled-pattern memory.
