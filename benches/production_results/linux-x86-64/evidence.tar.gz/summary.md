# Production regex comparison

Host: Linux-6.6.141-x86_64-with-glibc2.39; x86_64.

Publication candidate: review host stability, raw samples, coverage and run intervals before publishing.

Ratios are comparator / Ferroni. Compile and first-use times concern one pattern; steady times concern the complete fixture batch.

Each comparison below uses only its explicitly listed common tasks. Families have equal aggregate weight; architectures are never combined.

## Eligibility

| Case | Engine | Status |
| --- | --- | --- |
| `uuid_shape` | rust | eligible |
| `uuid_shape` | rust_erroraware | eligible |
| `uuid_shape` | c | eligible |
| `uuid_shape` | onigmo | eligible |
| `uuid_shape` | pcre2_jit | eligible |
| `uuid_shape` | pcre2 | eligible |
| `uuid_shape` | fancy_regex | eligible |
| `uuid_shape` | fancy_regex_seek | eligible |
| `uuid_shape` | regex | eligible |
| `uuid_v4` | rust | eligible |
| `uuid_v4` | rust_erroraware | eligible |
| `uuid_v4` | c | eligible |
| `uuid_v4` | onigmo | eligible |
| `uuid_v4` | pcre2_jit | eligible |
| `uuid_v4` | pcre2 | eligible |
| `uuid_v4` | fancy_regex | eligible |
| `uuid_v4` | fancy_regex_seek | eligible |
| `uuid_v4` | regex | eligible |
| `ipv4_validation` | rust | eligible |
| `ipv4_validation` | rust_erroraware | eligible |
| `ipv4_validation` | c | eligible |
| `ipv4_validation` | onigmo | eligible |
| `ipv4_validation` | pcre2_jit | eligible |
| `ipv4_validation` | pcre2 | eligible |
| `ipv4_validation` | fancy_regex | eligible |
| `ipv4_validation` | fancy_regex_seek | eligible |
| `ipv4_validation` | regex | eligible |
| `ipv6_validation` | rust | eligible |
| `ipv6_validation` | rust_erroraware | eligible |
| `ipv6_validation` | c | eligible |
| `ipv6_validation` | onigmo | eligible |
| `ipv6_validation` | pcre2_jit | eligible |
| `ipv6_validation` | pcre2 | eligible |
| `ipv6_validation` | fancy_regex | eligible |
| `ipv6_validation` | fancy_regex_seek | eligible |
| `ipv6_validation` | regex | eligible |
| `semver_version_parse` | rust | eligible |
| `semver_version_parse` | rust_erroraware | eligible |
| `semver_version_parse` | c | eligible |
| `semver_version_parse` | onigmo | eligible |
| `semver_version_parse` | pcre2_jit | eligible |
| `semver_version_parse` | pcre2 | eligible |
| `semver_version_parse` | fancy_regex | eligible |
| `semver_version_parse` | fancy_regex_seek | eligible |
| `semver_version_parse` | regex | eligible |
| `semver_hyphen_range_captures` | rust | eligible |
| `semver_hyphen_range_captures` | rust_erroraware | eligible |
| `semver_hyphen_range_captures` | c | eligible |
| `semver_hyphen_range_captures` | onigmo | eligible |
| `semver_hyphen_range_captures` | pcre2_jit | eligible |
| `semver_hyphen_range_captures` | pcre2 | eligible |
| `semver_hyphen_range_captures` | fancy_regex | eligible |
| `semver_hyphen_range_captures` | fancy_regex_seek | eligible |
| `semver_hyphen_range_captures` | regex | eligible |
| `jinja_string_token` | rust | eligible |
| `jinja_string_token` | rust_erroraware | eligible |
| `jinja_string_token` | c | eligible |
| `jinja_string_token` | onigmo | eligible |
| `jinja_string_token` | pcre2_jit | eligible |
| `jinja_string_token` | pcre2 | eligible |
| `jinja_string_token` | fancy_regex | eligible |
| `jinja_string_token` | fancy_regex_seek | eligible |
| `jinja_string_token` | regex | eligible |
| `jinja_integer_token` | rust | eligible |
| `jinja_integer_token` | rust_erroraware | eligible |
| `jinja_integer_token` | c | eligible |
| `jinja_integer_token` | onigmo | eligible |
| `jinja_integer_token` | pcre2_jit | eligible |
| `jinja_integer_token` | pcre2 | eligible |
| `jinja_integer_token` | fancy_regex | eligible |
| `jinja_integer_token` | fancy_regex_seek | eligible |
| `jinja_integer_token` | regex | eligible |
| `jinja_float_token` | rust | eligible |
| `jinja_float_token` | rust_erroraware | eligible |
| `jinja_float_token` | c | eligible |
| `jinja_float_token` | onigmo | eligible |
| `jinja_float_token` | pcre2_jit | eligible |
| `jinja_float_token` | pcre2 | eligible |
| `jinja_float_token` | fancy_regex | eligible |
| `jinja_float_token` | fancy_regex_seek | eligible |
| `jinja_float_token` | regex | syntax_rejected |
| `django_email_local_part` | rust | eligible |
| `django_email_local_part` | rust_erroraware | eligible |
| `django_email_local_part` | c | eligible |
| `django_email_local_part` | onigmo | eligible |
| `django_email_local_part` | pcre2_jit | eligible |
| `django_email_local_part` | pcre2 | eligible |
| `django_email_local_part` | fancy_regex | syntax_rejected |
| `django_email_local_part` | fancy_regex_seek | syntax_rejected |
| `django_email_local_part` | regex | syntax_rejected |
| `django_email_domain` | rust | eligible |
| `django_email_domain` | rust_erroraware | eligible |
| `django_email_domain` | c | eligible |
| `django_email_domain` | onigmo | eligible |
| `django_email_domain` | pcre2_jit | eligible |
| `django_email_domain` | pcre2 | eligible |
| `django_email_domain` | fancy_regex | eligible |
| `django_email_domain` | fancy_regex_seek | eligible |
| `django_email_domain` | regex | syntax_rejected |
| `django_url_regex` | rust | eligible |
| `django_url_regex` | rust_erroraware | eligible |
| `django_url_regex` | c | eligible |
| `django_url_regex` | onigmo | eligible |
| `django_url_regex` | pcre2_jit | eligible |
| `django_url_regex` | pcre2 | eligible |
| `django_url_regex` | fancy_regex | eligible |
| `django_url_regex` | fancy_regex_seek | eligible |
| `django_url_regex` | regex | syntax_rejected |
| `fluent_bit_apache` | rust | eligible |
| `fluent_bit_apache` | rust_erroraware | eligible |
| `fluent_bit_apache` | c | eligible |
| `fluent_bit_apache` | onigmo | eligible |
| `fluent_bit_apache` | pcre2_jit | eligible |
| `fluent_bit_apache` | pcre2 | eligible |
| `fluent_bit_apache` | fancy_regex | eligible |
| `fluent_bit_apache` | fancy_regex_seek | eligible |
| `fluent_bit_apache` | regex | eligible |
| `fluent_bit_nginx` | rust | eligible |
| `fluent_bit_nginx` | rust_erroraware | eligible |
| `fluent_bit_nginx` | c | eligible |
| `fluent_bit_nginx` | onigmo | eligible |
| `fluent_bit_nginx` | pcre2_jit | eligible |
| `fluent_bit_nginx` | pcre2 | eligible |
| `fluent_bit_nginx` | fancy_regex | eligible |
| `fluent_bit_nginx` | fancy_regex_seek | eligible |
| `fluent_bit_nginx` | regex | eligible |
| `rails_underscore_regex_step` | rust | eligible |
| `rails_underscore_regex_step` | rust_erroraware | eligible |
| `rails_underscore_regex_step` | c | eligible |
| `rails_underscore_regex_step` | onigmo | eligible |
| `rails_underscore_regex_step` | pcre2_jit | eligible |
| `rails_underscore_regex_step` | pcre2 | eligible |
| `rails_underscore_regex_step` | fancy_regex | eligible |
| `rails_underscore_regex_step` | fancy_regex_seek | eligible |
| `rails_underscore_regex_step` | regex | syntax_rejected |
| `mastodon_hashtag_regex_step` | rust | eligible |
| `mastodon_hashtag_regex_step` | rust_erroraware | eligible |
| `mastodon_hashtag_regex_step` | c | eligible |
| `mastodon_hashtag_regex_step` | onigmo | eligible |
| `mastodon_hashtag_regex_step` | pcre2_jit | eligible |
| `mastodon_hashtag_regex_step` | pcre2 | eligible |
| `mastodon_hashtag_regex_step` | fancy_regex | semantic_difference |
| `mastodon_hashtag_regex_step` | fancy_regex_seek | semantic_difference |
| `mastodon_hashtag_regex_step` | regex | syntax_rejected |
| `python_markdown_smart_emphasis_re` | rust | eligible |
| `python_markdown_smart_emphasis_re` | rust_erroraware | eligible |
| `python_markdown_smart_emphasis_re` | c | eligible |
| `python_markdown_smart_emphasis_re` | onigmo | eligible |
| `python_markdown_smart_emphasis_re` | pcre2_jit | eligible |
| `python_markdown_smart_emphasis_re` | pcre2 | eligible |
| `python_markdown_smart_emphasis_re` | fancy_regex | eligible |
| `python_markdown_smart_emphasis_re` | fancy_regex_seek | eligible |
| `python_markdown_smart_emphasis_re` | regex | syntax_rejected |
| `python_markdown_smart_strong_em_re` | rust | eligible |
| `python_markdown_smart_strong_em_re` | rust_erroraware | eligible |
| `python_markdown_smart_strong_em_re` | c | eligible |
| `python_markdown_smart_strong_em_re` | onigmo | eligible |
| `python_markdown_smart_strong_em_re` | pcre2_jit | eligible |
| `python_markdown_smart_strong_em_re` | pcre2 | eligible |
| `python_markdown_smart_strong_em_re` | fancy_regex | eligible |
| `python_markdown_smart_strong_em_re` | fancy_regex_seek | eligible |
| `python_markdown_smart_strong_em_re` | regex | syntax_rejected |
| `wordpress_shortcode_captures` | rust | eligible |
| `wordpress_shortcode_captures` | rust_erroraware | eligible |
| `wordpress_shortcode_captures` | c | eligible |
| `wordpress_shortcode_captures` | onigmo | eligible |
| `wordpress_shortcode_captures` | pcre2_jit | eligible |
| `wordpress_shortcode_captures` | pcre2 | eligible |
| `wordpress_shortcode_captures` | fancy_regex | eligible |
| `wordpress_shortcode_captures` | fancy_regex_seek | eligible |
| `wordpress_shortcode_captures` | regex | syntax_rejected |
| `symfony_grapheme_chunks_1` | rust | eligible |
| `symfony_grapheme_chunks_1` | rust_erroraware | eligible |
| `symfony_grapheme_chunks_1` | c | eligible |
| `symfony_grapheme_chunks_1` | onigmo | semantic_difference |
| `symfony_grapheme_chunks_1` | pcre2_jit | eligible |
| `symfony_grapheme_chunks_1` | pcre2 | eligible |
| `symfony_grapheme_chunks_1` | fancy_regex | syntax_rejected |
| `symfony_grapheme_chunks_1` | fancy_regex_seek | syntax_rejected |
| `symfony_grapheme_chunks_1` | regex | syntax_rejected |
| `symfony_grapheme_chunks_2` | rust | eligible |
| `symfony_grapheme_chunks_2` | rust_erroraware | eligible |
| `symfony_grapheme_chunks_2` | c | eligible |
| `symfony_grapheme_chunks_2` | onigmo | eligible |
| `symfony_grapheme_chunks_2` | pcre2_jit | eligible |
| `symfony_grapheme_chunks_2` | pcre2 | eligible |
| `symfony_grapheme_chunks_2` | fancy_regex | syntax_rejected |
| `symfony_grapheme_chunks_2` | fancy_regex_seek | syntax_rejected |
| `symfony_grapheme_chunks_2` | regex | syntax_rejected |
| `literal_first` | rust | eligible |
| `literal_first` | rust_erroraware | eligible |
| `literal_first` | c | eligible |
| `literal_first` | onigmo | eligible |
| `literal_first` | pcre2_jit | eligible |
| `literal_first` | pcre2 | eligible |
| `literal_first` | fancy_regex | eligible |
| `literal_first` | fancy_regex_seek | eligible |
| `literal_first` | regex | eligible |
| `literal_middle` | rust | eligible |
| `literal_middle` | rust_erroraware | eligible |
| `literal_middle` | c | eligible |
| `literal_middle` | onigmo | eligible |
| `literal_middle` | pcre2_jit | eligible |
| `literal_middle` | pcre2 | eligible |
| `literal_middle` | fancy_regex | eligible |
| `literal_middle` | fancy_regex_seek | eligible |
| `literal_middle` | regex | eligible |
| `literal_end` | rust | eligible |
| `literal_end` | rust_erroraware | eligible |
| `literal_end` | c | eligible |
| `literal_end` | onigmo | eligible |
| `literal_end` | pcre2_jit | eligible |
| `literal_end` | pcre2 | eligible |
| `literal_end` | fancy_regex | eligible |
| `literal_end` | fancy_regex_seek | eligible |
| `literal_end` | regex | eligible |
| `literal_absent` | rust | eligible |
| `literal_absent` | rust_erroraware | eligible |
| `literal_absent` | c | eligible |
| `literal_absent` | onigmo | eligible |
| `literal_absent` | pcre2_jit | eligible |
| `literal_absent` | pcre2 | eligible |
| `literal_absent` | fancy_regex | eligible |
| `literal_absent` | fancy_regex_seek | eligible |
| `literal_absent` | regex | eligible |
| `linkify_http_tail` | rust | pending |
| `linkify_http_tail` | rust_erroraware | pending |
| `linkify_http_tail` | c | pending |
| `linkify_http_tail` | onigmo | pending |
| `linkify_http_tail` | pcre2_jit | pending |
| `linkify_http_tail` | pcre2 | pending |
| `linkify_http_tail` | fancy_regex | pending |
| `linkify_http_tail` | fancy_regex_seek | pending |
| `linkify_http_tail` | regex | pending |
| `php_cs_fixer_recursive_types` | rust | pending |
| `php_cs_fixer_recursive_types` | rust_erroraware | pending |
| `php_cs_fixer_recursive_types` | c | pending |
| `php_cs_fixer_recursive_types` | onigmo | pending |
| `php_cs_fixer_recursive_types` | pcre2_jit | pending |
| `php_cs_fixer_recursive_types` | pcre2 | pending |
| `php_cs_fixer_recursive_types` | fancy_regex | pending |
| `php_cs_fixer_recursive_types` | fancy_regex_seek | pending |
| `php_cs_fixer_recursive_types` | regex | pending |
| `ferrolink_markup_scan` | rust | eligible |
| `ferrolink_markup_scan` | rust_erroraware | eligible |
| `ferrolink_markup_scan` | c | eligible |
| `ferrolink_markup_scan` | onigmo | eligible |
| `ferrolink_markup_scan` | pcre2_jit | eligible |
| `ferrolink_markup_scan` | pcre2 | eligible |
| `ferrolink_markup_scan` | fancy_regex | eligible |
| `ferrolink_markup_scan` | fancy_regex_seek | eligible |
| `ferrolink_markup_scan` | regex | syntax_rejected |
| `ferrolink_attribute_split` | rust | eligible |
| `ferrolink_attribute_split` | rust_erroraware | eligible |
| `ferrolink_attribute_split` | c | eligible |
| `ferrolink_attribute_split` | onigmo | eligible |
| `ferrolink_attribute_split` | pcre2_jit | eligible |
| `ferrolink_attribute_split` | pcre2 | eligible |
| `ferrolink_attribute_split` | fancy_regex | eligible |
| `ferrolink_attribute_split` | fancy_regex_seek | eligible |
| `ferrolink_attribute_split` | regex | eligible |

## rust_erroraware / steady

Common cases: 27; families: 14. Pair-specific family-weighted ratio: 1.860.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.715 | 1.502–1.832 | Ferroni faster in every run interval |
| `uuid_v4` | 2.198 | 1.841–2.425 | Ferroni faster in every run interval |
| `ipv4_validation` | 7.727 | 6.532–8.188 | Ferroni faster in every run interval |
| `ipv6_validation` | 11.925 | 10.549–12.640 | Ferroni faster in every run interval |
| `semver_version_parse` | 1.153 | 1.096–1.267 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.103 | 0.962–1.310 | inconclusive |
| `jinja_string_token` | 1.226 | 1.145–1.331 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.170 | 1.139–1.365 | Ferroni faster in every run interval |
| `jinja_float_token` | 1.622 | 1.331–1.671 | Ferroni faster in every run interval |
| `django_email_local_part` | 5.268 | 4.719–5.636 | Ferroni faster in every run interval |
| `django_email_domain` | 10.360 | 8.828–12.664 | Ferroni faster in every run interval |
| `django_url_regex` | 9.907 | 8.416–10.400 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.169 | 0.913–1.269 | inconclusive |
| `fluent_bit_nginx` | 1.693 | 1.489–1.717 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.038 | 0.993–1.056 | inconclusive |
| `mastodon_hashtag_regex_step` | 0.966 | 0.929–1.011 | inconclusive |
| `python_markdown_smart_emphasis_re` | 1.231 | 1.163–1.239 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 1.060 | 0.704–1.249 | inconclusive |
| `wordpress_shortcode_captures` | 1.051 | 0.953–1.329 | inconclusive |
| `symfony_grapheme_chunks_1` | 1.186 | 1.097–1.299 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_2` | 1.025 | 0.980–1.118 | inconclusive |
| `literal_first` | 1.669 | 1.610–1.741 | Ferroni faster in every run interval |
| `literal_middle` | 1.713 | 1.624–1.728 | Ferroni faster in every run interval |
| `literal_end` | 1.457 | 1.334–1.485 | Ferroni faster in every run interval |
| `literal_absent` | 1.420 | 1.353–1.476 | Ferroni faster in every run interval |
| `ferrolink_markup_scan` | 1.027 | 1.001–1.110 | inconclusive |
| `ferrolink_attribute_split` | 0.968 | 0.913–1.154 | inconclusive |

## rust_erroraware / compile

Common cases: 27; families: 14. Pair-specific family-weighted ratio: 1.022.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.070 | 0.931–1.168 | inconclusive |
| `uuid_v4` | 0.965 | 0.947–1.283 | inconclusive |
| `ipv4_validation` | 0.958 | 0.873–1.059 | inconclusive |
| `ipv6_validation` | 1.042 | 0.936–1.087 | inconclusive |
| `semver_version_parse` | 1.059 | 1.027–1.173 | inconclusive |
| `semver_hyphen_range_captures` | 0.953 | 0.935–0.990 | inconclusive |
| `jinja_string_token` | 0.984 | 0.949–1.041 | inconclusive |
| `jinja_integer_token` | 1.012 | 0.775–1.014 | inconclusive |
| `jinja_float_token` | 1.133 | 1.028–1.172 | inconclusive |
| `django_email_local_part` | 1.110 | 0.978–1.125 | inconclusive |
| `django_email_domain` | 1.110 | 1.050–1.192 | inconclusive |
| `django_url_regex` | 1.095 | 0.984–1.290 | inconclusive |
| `fluent_bit_apache` | 0.955 | 0.922–1.010 | inconclusive |
| `fluent_bit_nginx` | 1.151 | 0.915–1.165 | inconclusive |
| `rails_underscore_regex_step` | 0.980 | 0.817–1.076 | inconclusive |
| `mastodon_hashtag_regex_step` | 0.936 | 0.917–1.041 | inconclusive |
| `python_markdown_smart_emphasis_re` | 1.025 | 1.003–1.197 | inconclusive |
| `python_markdown_smart_strong_em_re` | 1.079 | 0.903–1.167 | inconclusive |
| `wordpress_shortcode_captures` | 0.932 | 0.814–1.082 | inconclusive |
| `symfony_grapheme_chunks_1` | 1.061 | 0.997–1.141 | inconclusive |
| `symfony_grapheme_chunks_2` | 1.019 | 0.873–1.051 | inconclusive |
| `literal_first` | 0.947 | 0.837–1.126 | inconclusive |
| `literal_middle` | 1.086 | 0.779–1.153 | inconclusive |
| `literal_end` | 1.033 | 0.934–1.088 | inconclusive |
| `literal_absent` | 0.945 | 0.850–1.187 | inconclusive |
| `ferrolink_markup_scan` | 1.038 | 0.924–1.100 | inconclusive |
| `ferrolink_attribute_split` | 1.105 | 0.990–1.278 | inconclusive |

## rust_erroraware / first_use

Common cases: 27; families: 14. Pair-specific family-weighted ratio: 0.755.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.517 | 0.459–0.525 | comparator faster in every run interval |
| `uuid_v4` | 0.574 | 0.523–0.594 | comparator faster in every run interval |
| `ipv4_validation` | 0.638 | 0.638–0.701 | comparator faster in every run interval |
| `ipv6_validation` | 0.579 | 0.568–0.625 | comparator faster in every run interval |
| `semver_version_parse` | 0.722 | 0.603–0.849 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.725 | 0.719–0.776 | comparator faster in every run interval |
| `jinja_string_token` | 0.498 | 0.488–0.503 | comparator faster in every run interval |
| `jinja_integer_token` | 0.667 | 0.605–0.771 | comparator faster in every run interval |
| `jinja_float_token` | 0.707 | 0.674–0.840 | comparator faster in every run interval |
| `django_email_local_part` | 0.731 | 0.716–0.768 | comparator faster in every run interval |
| `django_email_domain` | 0.632 | 0.549–0.694 | comparator faster in every run interval |
| `django_url_regex` | 0.820 | 0.704–0.834 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.482 | 0.380–0.522 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.602 | 0.485–0.622 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 1.025 | 0.904–1.125 | inconclusive |
| `mastodon_hashtag_regex_step` | 0.963 | 0.864–1.074 | inconclusive |
| `python_markdown_smart_emphasis_re` | 0.532 | 0.496–0.580 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.483 | 0.322–0.558 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.877 | 0.832–0.998 | inconclusive |
| `symfony_grapheme_chunks_1` | 1.081 | 0.809–1.185 | inconclusive |
| `symfony_grapheme_chunks_2` | 1.094 | 0.996–1.129 | inconclusive |
| `literal_first` | 1.035 | 0.933–1.067 | inconclusive |
| `literal_middle` | 0.858 | 0.693–0.950 | inconclusive |
| `literal_end` | 0.954 | 0.951–1.092 | inconclusive |
| `literal_absent` | 1.021 | 0.991–1.022 | inconclusive |
| `ferrolink_markup_scan` | 0.967 | 0.868–1.064 | inconclusive |
| `ferrolink_attribute_split` | 0.953 | 0.921–1.306 | inconclusive |

## c / steady

Common cases: 27; families: 14. Pair-specific family-weighted ratio: 2.760.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 3.242 | 3.107–3.520 | Ferroni faster in every run interval |
| `uuid_v4` | 3.286 | 3.160–4.130 | Ferroni faster in every run interval |
| `ipv4_validation` | 8.601 | 7.865–9.335 | Ferroni faster in every run interval |
| `ipv6_validation` | 8.344 | 8.046–11.022 | Ferroni faster in every run interval |
| `semver_version_parse` | 1.467 | 1.434–1.581 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.036 | 1.026–1.261 | inconclusive |
| `jinja_string_token` | 1.217 | 1.133–1.279 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.033 | 0.926–1.208 | inconclusive |
| `jinja_float_token` | 1.177 | 1.170–1.441 | Ferroni faster in every run interval |
| `django_email_local_part` | 8.851 | 8.794–9.501 | Ferroni faster in every run interval |
| `django_email_domain` | 45.244 | 42.850–46.480 | Ferroni faster in every run interval |
| `django_url_regex` | 25.036 | 22.772–25.758 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.587 | 1.133–1.786 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 2.583 | 2.331–2.859 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.040 | 0.974–1.080 | inconclusive |
| `mastodon_hashtag_regex_step` | 1.772 | 1.348–1.851 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 2.096 | 2.041–2.285 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 2.257 | 1.475–2.658 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 1.006 | 0.884–1.339 | inconclusive |
| `symfony_grapheme_chunks_1` | 1.353 | 1.340–1.384 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_2` | 1.228 | 1.127–1.420 | Ferroni faster in every run interval |
| `literal_first` | 4.453 | 4.271–4.650 | Ferroni faster in every run interval |
| `literal_middle` | 5.748 | 4.841–5.833 | Ferroni faster in every run interval |
| `literal_end` | 5.575 | 5.418–5.926 | Ferroni faster in every run interval |
| `literal_absent` | 2.857 | 2.835–2.886 | Ferroni faster in every run interval |
| `ferrolink_markup_scan` | 1.937 | 1.872–2.061 | Ferroni faster in every run interval |
| `ferrolink_attribute_split` | 1.352 | 1.163–1.702 | Ferroni faster in every run interval |

## c / compile

Common cases: 27; families: 14. Pair-specific family-weighted ratio: 0.480.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 5.169 | 4.684–5.308 | Ferroni faster in every run interval |
| `uuid_v4` | 5.792 | 5.782–7.158 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.364 | 0.274–0.387 | comparator faster in every run interval |
| `ipv6_validation` | 0.335 | 0.274–0.359 | comparator faster in every run interval |
| `semver_version_parse` | 0.399 | 0.326–0.428 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.306 | 0.289–0.337 | comparator faster in every run interval |
| `jinja_string_token` | 0.220 | 0.210–0.238 | comparator faster in every run interval |
| `jinja_integer_token` | 2.733 | 2.634–2.829 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.800 | 0.706–0.916 | inconclusive |
| `django_email_local_part` | 3.459 | 2.894–3.792 | Ferroni faster in every run interval |
| `django_email_domain` | 0.394 | 0.355–0.490 | comparator faster in every run interval |
| `django_url_regex` | 0.797 | 0.713–0.903 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.229 | 0.168–0.238 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.227 | 0.219–0.256 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.402 | 0.393–0.477 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.642 | 0.580–0.896 | inconclusive |
| `python_markdown_smart_emphasis_re` | 0.278 | 0.275–0.391 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.202 | 0.188–0.203 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.408 | 0.337–0.449 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.204 | 0.194–0.248 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.221 | 0.185–0.232 | comparator faster in every run interval |
| `literal_first` | 0.236 | 0.215–0.264 | comparator faster in every run interval |
| `literal_middle` | 0.222 | 0.182–0.259 | comparator faster in every run interval |
| `literal_end` | 0.241 | 0.236–0.268 | comparator faster in every run interval |
| `literal_absent` | 0.249 | 0.181–0.296 | comparator faster in every run interval |
| `ferrolink_markup_scan` | 0.248 | 0.244–0.271 | comparator faster in every run interval |
| `ferrolink_attribute_split` | 0.242 | 0.222–0.256 | comparator faster in every run interval |

## c / first_use

Common cases: 27; families: 14. Pair-specific family-weighted ratio: 0.428.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 2.763 | 2.605–2.984 | Ferroni faster in every run interval |
| `uuid_v4` | 2.999 | 2.433–3.543 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.238 | 0.233–0.240 | comparator faster in every run interval |
| `ipv6_validation` | 0.211 | 0.186–0.245 | comparator faster in every run interval |
| `semver_version_parse` | 0.262 | 0.238–0.293 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.284 | 0.253–0.305 | comparator faster in every run interval |
| `jinja_string_token` | 0.133 | 0.133–0.134 | comparator faster in every run interval |
| `jinja_integer_token` | 2.115 | 1.988–2.265 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.497 | 0.471–0.601 | comparator faster in every run interval |
| `django_email_local_part` | 2.226 | 2.091–2.249 | Ferroni faster in every run interval |
| `django_email_domain` | 0.313 | 0.247–0.331 | comparator faster in every run interval |
| `django_url_regex` | 0.632 | 0.553–0.659 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.110 | 0.107–0.128 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.160 | 0.141–0.168 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.503 | 0.463–0.592 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.672 | 0.669–1.102 | inconclusive |
| `python_markdown_smart_emphasis_re` | 0.199 | 0.174–0.245 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.138 | 0.090–0.139 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.399 | 0.358–0.439 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.400 | 0.382–0.479 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.370 | 0.367–0.439 | comparator faster in every run interval |
| `literal_first` | 0.415 | 0.381–0.505 | comparator faster in every run interval |
| `literal_middle` | 0.381 | 0.260–0.451 | comparator faster in every run interval |
| `literal_end` | 0.422 | 0.408–0.443 | comparator faster in every run interval |
| `literal_absent` | 0.375 | 0.261–0.430 | comparator faster in every run interval |
| `ferrolink_markup_scan` | 0.356 | 0.326–0.362 | comparator faster in every run interval |
| `ferrolink_attribute_split` | 0.282 | 0.237–0.327 | comparator faster in every run interval |

## onigmo / steady

Common cases: 26; families: 14. Pair-specific family-weighted ratio: 3.536.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 5.385 | 4.492–5.435 | Ferroni faster in every run interval |
| `uuid_v4` | 6.044 | 5.665–7.285 | Ferroni faster in every run interval |
| `ipv4_validation` | 8.586 | 7.876–9.789 | Ferroni faster in every run interval |
| `ipv6_validation` | 18.261 | 17.786–19.007 | Ferroni faster in every run interval |
| `semver_version_parse` | 1.631 | 1.626–1.796 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.297 | 1.073–1.352 | inconclusive |
| `jinja_string_token` | 0.939 | 0.828–0.968 | inconclusive |
| `jinja_integer_token` | 1.229 | 1.218–1.297 | Ferroni faster in every run interval |
| `jinja_float_token` | 2.612 | 2.403–2.868 | Ferroni faster in every run interval |
| `django_email_local_part` | 7.646 | 7.422–8.109 | Ferroni faster in every run interval |
| `django_email_domain` | 79.882 | 75.251–96.756 | Ferroni faster in every run interval |
| `django_url_regex` | 60.626 | 54.773–79.400 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 2.255 | 1.462–2.298 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 3.170 | 3.155–3.507 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 0.920 | 0.820–0.987 | inconclusive |
| `mastodon_hashtag_regex_step` | 1.789 | 1.520–1.897 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 2.402 | 2.250–2.773 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 2.309 | 1.639–2.876 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 1.230 | 1.126–1.419 | Ferroni faster in every run interval |
| `symfony_grapheme_chunks_2` | 3.109 | 2.961–3.313 | Ferroni faster in every run interval |
| `literal_first` | 1.795 | 1.730–1.950 | Ferroni faster in every run interval |
| `literal_middle` | 2.871 | 2.383–3.530 | Ferroni faster in every run interval |
| `literal_end` | 3.553 | 3.439–3.609 | Ferroni faster in every run interval |
| `literal_absent` | 2.831 | 2.770–3.425 | Ferroni faster in every run interval |
| `ferrolink_markup_scan` | 2.835 | 2.329–2.841 | Ferroni faster in every run interval |
| `ferrolink_attribute_split` | 1.405 | 1.146–1.705 | Ferroni faster in every run interval |

## onigmo / compile

Common cases: 26; families: 14. Pair-specific family-weighted ratio: 0.609.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 5.724 | 5.012–7.696 | Ferroni faster in every run interval |
| `uuid_v4` | 7.265 | 5.884–7.708 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.323 | 0.306–0.358 | comparator faster in every run interval |
| `ipv6_validation` | 0.384 | 0.321–0.399 | comparator faster in every run interval |
| `semver_version_parse` | 0.355 | 0.346–0.372 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.344 | 0.340–0.374 | comparator faster in every run interval |
| `jinja_string_token` | 0.191 | 0.190–0.217 | comparator faster in every run interval |
| `jinja_integer_token` | 2.393 | 2.192–2.596 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.908 | 0.794–0.975 | inconclusive |
| `django_email_local_part` | 3.195 | 3.157–3.470 | Ferroni faster in every run interval |
| `django_email_domain` | 0.256 | 0.234–0.257 | comparator faster in every run interval |
| `django_url_regex` | 0.631 | 0.454–0.734 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.211 | 0.179–0.250 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.229 | 0.222–0.242 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.466 | 0.412–0.485 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.732 | 0.565–1.052 | inconclusive |
| `python_markdown_smart_emphasis_re` | 0.234 | 0.219–0.246 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.150 | 0.146–0.230 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.406 | 0.336–0.448 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 8.947 | 8.536–14.662 | Ferroni faster in every run interval |
| `literal_first` | 0.235 | 0.200–0.244 | comparator faster in every run interval |
| `literal_middle` | 0.192 | 0.123–0.247 | comparator faster in every run interval |
| `literal_end` | 0.198 | 0.189–0.243 | comparator faster in every run interval |
| `literal_absent` | 0.217 | 0.149–0.224 | comparator faster in every run interval |
| `ferrolink_markup_scan` | 0.284 | 0.235–0.343 | comparator faster in every run interval |
| `ferrolink_attribute_split` | 0.258 | 0.236–0.277 | comparator faster in every run interval |

## onigmo / first_use

Common cases: 26; families: 14. Pair-specific family-weighted ratio: 0.471.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 2.874 | 2.376–2.993 | Ferroni faster in every run interval |
| `uuid_v4` | 3.265 | 2.637–4.187 | Ferroni faster in every run interval |
| `ipv4_validation` | 0.242 | 0.205–0.252 | comparator faster in every run interval |
| `ipv6_validation` | 0.211 | 0.207–0.260 | comparator faster in every run interval |
| `semver_version_parse` | 0.224 | 0.213–0.230 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.236 | 0.230–0.280 | comparator faster in every run interval |
| `jinja_string_token` | 0.111 | 0.107–0.126 | comparator faster in every run interval |
| `jinja_integer_token` | 1.965 | 1.534–2.051 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.654 | 0.544–0.727 | comparator faster in every run interval |
| `django_email_local_part` | 2.128 | 2.035–2.296 | Ferroni faster in every run interval |
| `django_email_domain` | 0.168 | 0.158–0.175 | comparator faster in every run interval |
| `django_url_regex` | 0.423 | 0.338–0.556 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.095 | 0.088–0.115 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.130 | 0.121–0.145 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.476 | 0.404–0.490 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.715 | 0.605–0.827 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.124 | 0.097–0.149 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.099 | 0.070–0.106 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.344 | 0.334–0.384 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 10.056 | 8.580–12.986 | Ferroni faster in every run interval |
| `literal_first` | 0.275 | 0.232–0.331 | comparator faster in every run interval |
| `literal_middle` | 0.202 | 0.194–0.261 | comparator faster in every run interval |
| `literal_end` | 0.292 | 0.279–0.305 | comparator faster in every run interval |
| `literal_absent` | 0.284 | 0.215–0.361 | comparator faster in every run interval |
| `ferrolink_markup_scan` | 0.400 | 0.386–0.427 | comparator faster in every run interval |
| `ferrolink_attribute_split` | 0.277 | 0.248–0.278 | comparator faster in every run interval |

## pcre2_jit / steady

Common cases: 27; families: 14. Pair-specific family-weighted ratio: 0.656.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.769 | 0.663–0.820 | comparator faster in every run interval |
| `uuid_v4` | 0.967 | 0.962–1.205 | inconclusive |
| `ipv4_validation` | 2.112 | 2.056–2.401 | Ferroni faster in every run interval |
| `ipv6_validation` | 3.005 | 2.559–3.088 | Ferroni faster in every run interval |
| `semver_version_parse` | 0.425 | 0.385–0.453 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.398 | 0.391–0.442 | comparator faster in every run interval |
| `jinja_string_token` | 0.494 | 0.484–0.556 | comparator faster in every run interval |
| `jinja_integer_token` | 0.472 | 0.374–0.506 | comparator faster in every run interval |
| `jinja_float_token` | 0.572 | 0.560–0.792 | comparator faster in every run interval |
| `django_email_local_part` | 2.812 | 2.757–3.078 | Ferroni faster in every run interval |
| `django_email_domain` | 0.880 | 0.805–1.203 | inconclusive |
| `django_url_regex` | 1.493 | 1.237–2.096 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 0.427 | 0.254–0.499 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.495 | 0.471–0.615 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.303 | 0.295–0.374 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.288 | 0.288–0.359 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.647 | 0.570–0.654 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.493 | 0.435–0.565 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.410 | 0.341–0.484 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.530 | 0.524–0.543 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.510 | 0.487–0.685 | comparator faster in every run interval |
| `literal_first` | 1.445 | 1.429–1.609 | Ferroni faster in every run interval |
| `literal_middle` | 1.654 | 1.396–1.773 | Ferroni faster in every run interval |
| `literal_end` | 1.485 | 1.388–1.526 | Ferroni faster in every run interval |
| `literal_absent` | 1.267 | 1.219–1.334 | Ferroni faster in every run interval |
| `ferrolink_markup_scan` | 0.322 | 0.283–0.353 | comparator faster in every run interval |
| `ferrolink_attribute_split` | 0.401 | 0.346–0.492 | comparator faster in every run interval |

## pcre2_jit / compile

Common cases: 27; families: 14. Pair-specific family-weighted ratio: 0.473.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.380 | 0.324–0.415 | comparator faster in every run interval |
| `uuid_v4` | 0.295 | 0.276–0.402 | comparator faster in every run interval |
| `ipv4_validation` | 0.401 | 0.392–0.419 | comparator faster in every run interval |
| `ipv6_validation` | 0.383 | 0.369–0.473 | comparator faster in every run interval |
| `semver_version_parse` | 0.506 | 0.503–0.597 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.412 | 0.368–0.539 | comparator faster in every run interval |
| `jinja_string_token` | 0.499 | 0.427–0.530 | comparator faster in every run interval |
| `jinja_integer_token` | 0.326 | 0.289–0.339 | comparator faster in every run interval |
| `jinja_float_token` | 0.385 | 0.300–0.442 | comparator faster in every run interval |
| `django_email_local_part` | 0.403 | 0.402–0.524 | comparator faster in every run interval |
| `django_email_domain` | 0.075 | 0.073–0.083 | comparator faster in every run interval |
| `django_url_regex` | 0.089 | 0.071–0.129 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.388 | 0.269–0.415 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.376 | 0.358–0.422 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 1.029 | 0.847–1.103 | inconclusive |
| `mastodon_hashtag_regex_step` | 0.260 | 0.227–0.290 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.926 | 0.877–1.334 | inconclusive |
| `python_markdown_smart_strong_em_re` | 0.653 | 0.566–0.697 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.863 | 0.570–0.871 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.746 | 0.733–0.752 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.778 | 0.752–0.792 | comparator faster in every run interval |
| `literal_first` | 3.190 | 2.536–3.222 | Ferroni faster in every run interval |
| `literal_middle` | 2.943 | 2.088–3.354 | Ferroni faster in every run interval |
| `literal_end` | 3.019 | 2.914–3.996 | Ferroni faster in every run interval |
| `literal_absent` | 3.143 | 2.487–3.840 | Ferroni faster in every run interval |
| `ferrolink_markup_scan` | 0.377 | 0.335–0.402 | comparator faster in every run interval |
| `ferrolink_attribute_split` | 0.604 | 0.593–0.684 | comparator faster in every run interval |

## pcre2_jit / first_use

Common cases: 27; families: 14. Pair-specific family-weighted ratio: 0.385.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.181 | 0.146–0.210 | comparator faster in every run interval |
| `uuid_v4` | 0.176 | 0.157–0.208 | comparator faster in every run interval |
| `ipv4_validation` | 0.323 | 0.276–0.374 | comparator faster in every run interval |
| `ipv6_validation` | 0.235 | 0.200–0.328 | comparator faster in every run interval |
| `semver_version_parse` | 0.430 | 0.317–0.464 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.291 | 0.272–0.435 | comparator faster in every run interval |
| `jinja_string_token` | 0.312 | 0.263–0.330 | comparator faster in every run interval |
| `jinja_integer_token` | 0.274 | 0.260–0.284 | comparator faster in every run interval |
| `jinja_float_token` | 0.235 | 0.227–0.317 | comparator faster in every run interval |
| `django_email_local_part` | 0.333 | 0.314–0.337 | comparator faster in every run interval |
| `django_email_domain` | 0.050 | 0.043–0.064 | comparator faster in every run interval |
| `django_url_regex` | 0.051 | 0.047–0.087 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.210 | 0.159–0.228 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.264 | 0.198–0.288 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 1.290 | 1.118–1.481 | Ferroni faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.303 | 0.268–0.307 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.632 | 0.585–0.651 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.382 | 0.302–0.443 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.632 | 0.621–0.807 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.990 | 0.987–1.066 | inconclusive |
| `symfony_grapheme_chunks_2` | 1.313 | 0.943–1.532 | inconclusive |
| `literal_first` | 3.271 | 2.818–3.876 | Ferroni faster in every run interval |
| `literal_middle` | 2.409 | 1.893–2.490 | Ferroni faster in every run interval |
| `literal_end` | 2.928 | 2.688–3.790 | Ferroni faster in every run interval |
| `literal_absent` | 2.993 | 2.525–3.607 | Ferroni faster in every run interval |
| `ferrolink_markup_scan` | 0.428 | 0.378–0.496 | comparator faster in every run interval |
| `ferrolink_attribute_split` | 0.664 | 0.626–0.725 | comparator faster in every run interval |

## pcre2 / steady

Common cases: 27; families: 14. Pair-specific family-weighted ratio: 1.944.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.695 | 1.579–1.733 | Ferroni faster in every run interval |
| `uuid_v4` | 1.956 | 1.650–2.006 | Ferroni faster in every run interval |
| `ipv4_validation` | 12.054 | 12.047–13.626 | Ferroni faster in every run interval |
| `ipv6_validation` | 16.497 | 13.574–18.748 | Ferroni faster in every run interval |
| `semver_version_parse` | 1.185 | 1.180–1.315 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.603 | 1.306–1.630 | Ferroni faster in every run interval |
| `jinja_string_token` | 0.970 | 0.970–1.071 | inconclusive |
| `jinja_integer_token` | 1.451 | 1.386–1.640 | Ferroni faster in every run interval |
| `jinja_float_token` | 1.998 | 1.986–2.012 | Ferroni faster in every run interval |
| `django_email_local_part` | 8.065 | 7.313–8.423 | Ferroni faster in every run interval |
| `django_email_domain` | 3.526 | 2.896–3.846 | Ferroni faster in every run interval |
| `django_url_regex` | 4.569 | 3.553–5.747 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.371 | 0.743–1.470 | inconclusive |
| `fluent_bit_nginx` | 1.823 | 1.626–1.824 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.075 | 0.925–1.105 | inconclusive |
| `mastodon_hashtag_regex_step` | 0.701 | 0.581–0.715 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 2.898 | 2.854–3.208 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 3.870 | 2.815–4.136 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 1.136 | 1.002–1.507 | inconclusive |
| `symfony_grapheme_chunks_1` | 0.934 | 0.742–0.978 | inconclusive |
| `symfony_grapheme_chunks_2` | 0.741 | 0.527–0.975 | inconclusive |
| `literal_first` | 2.964 | 2.657–3.233 | Ferroni faster in every run interval |
| `literal_middle` | 3.070 | 2.516–3.184 | Ferroni faster in every run interval |
| `literal_end` | 2.444 | 2.367–2.677 | Ferroni faster in every run interval |
| `literal_absent` | 1.454 | 1.452–1.474 | Ferroni faster in every run interval |
| `ferrolink_markup_scan` | 0.970 | 0.946–1.187 | inconclusive |
| `ferrolink_attribute_split` | 1.041 | 0.729–1.128 | inconclusive |

## pcre2 / compile

Common cases: 27; families: 14. Pair-specific family-weighted ratio: 0.112.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.123 | 0.106–0.128 | comparator faster in every run interval |
| `uuid_v4` | 0.099 | 0.092–0.114 | comparator faster in every run interval |
| `ipv4_validation` | 0.113 | 0.106–0.116 | comparator faster in every run interval |
| `ipv6_validation` | 0.133 | 0.106–0.138 | comparator faster in every run interval |
| `semver_version_parse` | 0.121 | 0.096–0.130 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.093 | 0.091–0.110 | comparator faster in every run interval |
| `jinja_string_token` | 0.085 | 0.071–0.092 | comparator faster in every run interval |
| `jinja_integer_token` | 0.091 | 0.079–0.092 | comparator faster in every run interval |
| `jinja_float_token` | 0.052 | 0.051–0.053 | comparator faster in every run interval |
| `django_email_local_part` | 0.147 | 0.139–0.159 | comparator faster in every run interval |
| `django_email_domain` | 0.070 | 0.059–0.077 | comparator faster in every run interval |
| `django_url_regex` | 0.057 | 0.056–0.077 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.068 | 0.043–0.074 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.069 | 0.059–0.072 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.295 | 0.266–0.309 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.118 | 0.100–0.124 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.149 | 0.106–0.173 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.093 | 0.066–0.106 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.198 | 0.150–0.225 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.068 | 0.068–0.082 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.070 | 0.052–0.081 | comparator faster in every run interval |
| `literal_first` | 0.157 | 0.153–0.203 | comparator faster in every run interval |
| `literal_middle` | 0.160 | 0.112–0.163 | comparator faster in every run interval |
| `literal_end` | 0.181 | 0.152–0.191 | comparator faster in every run interval |
| `literal_absent` | 0.161 | 0.139–0.251 | comparator faster in every run interval |
| `ferrolink_markup_scan` | 0.075 | 0.073–0.077 | comparator faster in every run interval |
| `ferrolink_attribute_split` | 0.224 | 0.198–0.245 | comparator faster in every run interval |

## pcre2 / first_use

Common cases: 27; families: 14. Pair-specific family-weighted ratio: 0.145.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.095 | 0.072–0.100 | comparator faster in every run interval |
| `uuid_v4` | 0.085 | 0.077–0.096 | comparator faster in every run interval |
| `ipv4_validation` | 0.107 | 0.104–0.151 | comparator faster in every run interval |
| `ipv6_validation` | 0.084 | 0.072–0.099 | comparator faster in every run interval |
| `semver_version_parse` | 0.118 | 0.081–0.146 | comparator faster in every run interval |
| `semver_hyphen_range_captures` | 0.090 | 0.079–0.123 | comparator faster in every run interval |
| `jinja_string_token` | 0.082 | 0.072–0.094 | comparator faster in every run interval |
| `jinja_integer_token` | 0.090 | 0.077–0.091 | comparator faster in every run interval |
| `jinja_float_token` | 0.056 | 0.050–0.060 | comparator faster in every run interval |
| `django_email_local_part` | 0.137 | 0.135–0.150 | comparator faster in every run interval |
| `django_email_domain` | 0.048 | 0.035–0.055 | comparator faster in every run interval |
| `django_url_regex` | 0.052 | 0.039–0.059 | comparator faster in every run interval |
| `fluent_bit_apache` | 0.048 | 0.045–0.071 | comparator faster in every run interval |
| `fluent_bit_nginx` | 0.080 | 0.057–0.091 | comparator faster in every run interval |
| `rails_underscore_regex_step` | 0.455 | 0.435–0.524 | comparator faster in every run interval |
| `mastodon_hashtag_regex_step` | 0.145 | 0.132–0.159 | comparator faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.140 | 0.134–0.202 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.097 | 0.069–0.103 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 0.215 | 0.212–0.253 | comparator faster in every run interval |
| `symfony_grapheme_chunks_1` | 0.328 | 0.326–0.368 | comparator faster in every run interval |
| `symfony_grapheme_chunks_2` | 0.421 | 0.302–0.474 | comparator faster in every run interval |
| `literal_first` | 1.015 | 0.964–1.046 | inconclusive |
| `literal_middle` | 0.835 | 0.823–0.989 | inconclusive |
| `literal_end` | 0.798 | 0.753–1.012 | inconclusive |
| `literal_absent` | 0.788 | 0.742–0.861 | inconclusive |
| `ferrolink_markup_scan` | 0.153 | 0.139–0.168 | comparator faster in every run interval |
| `ferrolink_attribute_split` | 0.260 | 0.246–0.281 | comparator faster in every run interval |

## fancy_regex / steady

Common cases: 23; families: 12. Pair-specific family-weighted ratio: 2.871.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.072 | 0.976–1.179 | inconclusive |
| `uuid_v4` | 1.124 | 1.065–1.399 | Ferroni faster in every run interval |
| `ipv4_validation` | 1.931 | 1.718–1.947 | Ferroni faster in every run interval |
| `ipv6_validation` | 1.283 | 1.172–1.350 | Ferroni faster in every run interval |
| `semver_version_parse` | 1.942 | 1.828–2.001 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.648 | 1.219–1.788 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.111 | 0.937–1.237 | inconclusive |
| `jinja_integer_token` | 1.409 | 1.219–1.488 | Ferroni faster in every run interval |
| `jinja_float_token` | 2.827 | 2.686–3.645 | Ferroni faster in every run interval |
| `django_email_domain` | 13.394 | 10.387–13.403 | Ferroni faster in every run interval |
| `django_url_regex` | 28.947 | 26.045–39.540 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.536 | 1.284–1.719 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 1.930 | 1.861–2.193 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 3.032 | 2.938–3.160 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 3.241 | 2.908–3.455 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 4.960 | 4.451–5.025 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 2.015 | 1.756–2.499 | Ferroni faster in every run interval |
| `literal_first` | 1.262 | 1.126–1.268 | Ferroni faster in every run interval |
| `literal_middle` | 1.386 | 1.159–1.431 | Ferroni faster in every run interval |
| `literal_end` | 1.222 | 1.112–1.329 | Ferroni faster in every run interval |
| `literal_absent` | 1.243 | 1.117–1.396 | Ferroni faster in every run interval |
| `ferrolink_markup_scan` | 4.716 | 4.163–5.128 | Ferroni faster in every run interval |
| `ferrolink_attribute_split` | 1.857 | 1.291–1.858 | Ferroni faster in every run interval |

## fancy_regex / compile

Common cases: 23; families: 12. Pair-specific family-weighted ratio: 2.179.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.034 | 0.970–1.129 | inconclusive |
| `uuid_v4` | 0.896 | 0.741–0.931 | inconclusive |
| `ipv4_validation` | 1.192 | 0.934–1.342 | inconclusive |
| `ipv6_validation` | 1.497 | 1.230–1.607 | Ferroni faster in every run interval |
| `semver_version_parse` | 18.434 | 15.029–21.137 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 11.453 | 9.091–13.660 | Ferroni faster in every run interval |
| `jinja_string_token` | 2.666 | 2.446–3.143 | Ferroni faster in every run interval |
| `jinja_integer_token` | 2.115 | 2.016–2.318 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.418 | 0.391–0.443 | comparator faster in every run interval |
| `django_email_domain` | 3.791 | 3.768–4.469 | Ferroni faster in every run interval |
| `django_url_regex` | 4.022 | 3.010–4.902 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 2.105 | 2.103–2.392 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 2.175 | 2.087–2.478 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.481 | 1.115–1.970 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 1.064 | 1.022–1.125 | inconclusive |
| `python_markdown_smart_strong_em_re` | 0.811 | 0.615–0.857 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 1.800 | 1.656–2.159 | Ferroni faster in every run interval |
| `literal_first` | 1.235 | 1.195–1.344 | Ferroni faster in every run interval |
| `literal_middle` | 1.320 | 0.776–1.384 | inconclusive |
| `literal_end` | 1.237 | 1.205–1.270 | Ferroni faster in every run interval |
| `literal_absent` | 1.426 | 1.097–1.540 | inconclusive |
| `ferrolink_markup_scan` | 3.763 | 3.614–4.101 | Ferroni faster in every run interval |
| `ferrolink_attribute_split` | 5.058 | 4.914–5.321 | Ferroni faster in every run interval |

## fancy_regex / first_use

Common cases: 23; families: 12. Pair-specific family-weighted ratio: 1.719.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.786 | 0.735–0.793 | comparator faster in every run interval |
| `uuid_v4` | 0.708 | 0.693–0.742 | comparator faster in every run interval |
| `ipv4_validation` | 0.837 | 0.825–0.861 | comparator faster in every run interval |
| `ipv6_validation` | 0.786 | 0.775–0.838 | comparator faster in every run interval |
| `semver_version_parse` | 12.266 | 11.144–12.502 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 8.104 | 7.426–11.028 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.552 | 1.364–1.717 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.564 | 1.450–1.827 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.251 | 0.249–0.256 | comparator faster in every run interval |
| `django_email_domain` | 3.221 | 2.472–3.283 | Ferroni faster in every run interval |
| `django_url_regex` | 2.621 | 2.349–3.331 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.172 | 0.917–1.215 | inconclusive |
| `fluent_bit_nginx` | 1.530 | 1.118–1.549 | inconclusive |
| `rails_underscore_regex_step` | 2.076 | 1.481–2.106 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.550 | 0.454–0.557 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.373 | 0.357–0.443 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 1.813 | 1.689–2.190 | Ferroni faster in every run interval |
| `literal_first` | 1.492 | 1.414–1.641 | Ferroni faster in every run interval |
| `literal_middle` | 1.399 | 0.971–1.546 | inconclusive |
| `literal_end` | 1.259 | 1.171–1.338 | Ferroni faster in every run interval |
| `literal_absent` | 1.277 | 1.063–1.463 | inconclusive |
| `ferrolink_markup_scan` | 4.833 | 4.033–5.226 | Ferroni faster in every run interval |
| `ferrolink_attribute_split` | 5.134 | 4.715–5.390 | Ferroni faster in every run interval |

## fancy_regex_seek / steady

Common cases: 23; families: 12. Pair-specific family-weighted ratio: 2.757.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.111 | 1.075–1.254 | Ferroni faster in every run interval |
| `uuid_v4` | 1.362 | 1.358–1.380 | Ferroni faster in every run interval |
| `ipv4_validation` | 1.940 | 1.649–2.006 | Ferroni faster in every run interval |
| `ipv6_validation` | 1.246 | 1.041–1.376 | inconclusive |
| `semver_version_parse` | 1.856 | 1.819–2.060 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.641 | 1.359–1.668 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.036 | 0.914–1.113 | inconclusive |
| `jinja_integer_token` | 1.412 | 1.304–1.687 | Ferroni faster in every run interval |
| `jinja_float_token` | 2.656 | 2.650–3.101 | Ferroni faster in every run interval |
| `django_email_domain` | 11.916 | 11.510–12.612 | Ferroni faster in every run interval |
| `django_url_regex` | 26.538 | 25.285–29.865 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.549 | 1.163–1.661 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 2.023 | 2.009–2.105 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 2.941 | 2.401–3.659 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 2.847 | 2.462–3.480 | Ferroni faster in every run interval |
| `python_markdown_smart_strong_em_re` | 4.790 | 3.959–5.085 | Ferroni faster in every run interval |
| `wordpress_shortcode_captures` | 1.967 | 1.610–2.691 | Ferroni faster in every run interval |
| `literal_first` | 1.290 | 1.265–1.335 | Ferroni faster in every run interval |
| `literal_middle` | 1.311 | 1.255–1.411 | Ferroni faster in every run interval |
| `literal_end` | 1.116 | 1.040–1.123 | inconclusive |
| `literal_absent` | 1.241 | 1.184–1.298 | Ferroni faster in every run interval |
| `ferrolink_markup_scan` | 3.098 | 2.635–3.409 | Ferroni faster in every run interval |
| `ferrolink_attribute_split` | 2.003 | 1.323–2.007 | Ferroni faster in every run interval |

## fancy_regex_seek / compile

Common cases: 23; families: 12. Pair-specific family-weighted ratio: 2.473.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.995 | 0.987–1.107 | inconclusive |
| `uuid_v4` | 1.018 | 0.901–1.099 | inconclusive |
| `ipv4_validation` | 1.134 | 0.970–1.200 | inconclusive |
| `ipv6_validation` | 1.250 | 1.126–1.315 | Ferroni faster in every run interval |
| `semver_version_parse` | 16.286 | 15.303–20.194 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 11.421 | 8.783–12.902 | Ferroni faster in every run interval |
| `jinja_string_token` | 2.819 | 2.717–2.834 | Ferroni faster in every run interval |
| `jinja_integer_token` | 2.193 | 2.182–2.320 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.386 | 0.385–0.420 | comparator faster in every run interval |
| `django_email_domain` | 3.868 | 3.828–4.048 | Ferroni faster in every run interval |
| `django_url_regex` | 3.692 | 2.899–4.146 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 2.263 | 1.678–2.340 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 2.289 | 2.071–2.436 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.666 | 1.146–1.754 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 1.004 | 0.951–1.038 | inconclusive |
| `python_markdown_smart_strong_em_re` | 0.715 | 0.658–0.818 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 6.200 | 5.753–6.616 | Ferroni faster in every run interval |
| `literal_first` | 1.311 | 1.058–1.318 | inconclusive |
| `literal_middle` | 1.139 | 0.891–1.354 | inconclusive |
| `literal_end` | 1.269 | 1.210–1.342 | Ferroni faster in every run interval |
| `literal_absent` | 1.275 | 0.910–2.181 | inconclusive |
| `ferrolink_markup_scan` | 5.948 | 5.796–6.869 | Ferroni faster in every run interval |
| `ferrolink_attribute_split` | 7.710 | 7.604–8.371 | Ferroni faster in every run interval |

## fancy_regex_seek / first_use

Common cases: 23; families: 12. Pair-specific family-weighted ratio: 1.903.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.790 | 0.678–0.903 | comparator faster in every run interval |
| `uuid_v4` | 0.748 | 0.631–0.882 | comparator faster in every run interval |
| `ipv4_validation` | 0.907 | 0.851–0.907 | comparator faster in every run interval |
| `ipv6_validation` | 0.743 | 0.735–0.850 | comparator faster in every run interval |
| `semver_version_parse` | 12.339 | 11.190–12.443 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 8.066 | 6.373–10.576 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.586 | 1.347–1.628 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.786 | 1.599–1.906 | Ferroni faster in every run interval |
| `jinja_float_token` | 0.264 | 0.241–0.279 | comparator faster in every run interval |
| `django_email_domain` | 2.636 | 2.546–2.933 | Ferroni faster in every run interval |
| `django_url_regex` | 2.259 | 2.055–2.466 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.175 | 0.866–1.326 | inconclusive |
| `fluent_bit_nginx` | 1.209 | 1.161–1.652 | Ferroni faster in every run interval |
| `rails_underscore_regex_step` | 1.957 | 1.434–2.125 | Ferroni faster in every run interval |
| `python_markdown_smart_emphasis_re` | 0.491 | 0.476–0.553 | comparator faster in every run interval |
| `python_markdown_smart_strong_em_re` | 0.381 | 0.361–0.383 | comparator faster in every run interval |
| `wordpress_shortcode_captures` | 6.149 | 6.131–7.247 | Ferroni faster in every run interval |
| `literal_first` | 1.375 | 1.135–1.564 | inconclusive |
| `literal_middle` | 1.037 | 0.809–1.222 | inconclusive |
| `literal_end` | 1.313 | 1.154–1.369 | inconclusive |
| `literal_absent` | 1.482 | 1.039–1.674 | inconclusive |
| `ferrolink_markup_scan` | 8.746 | 6.144–8.773 | Ferroni faster in every run interval |
| `ferrolink_attribute_split` | 7.789 | 7.148–9.153 | Ferroni faster in every run interval |

## regex / steady

Common cases: 15; families: 7. Pair-specific family-weighted ratio: 1.304.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.136 | 1.136–1.281 | Ferroni faster in every run interval |
| `uuid_v4` | 1.398 | 1.393–1.666 | Ferroni faster in every run interval |
| `ipv4_validation` | 1.983 | 1.842–2.282 | Ferroni faster in every run interval |
| `ipv6_validation` | 1.244 | 1.129–1.648 | Ferroni faster in every run interval |
| `semver_version_parse` | 1.682 | 1.583–1.970 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 1.289 | 1.101–1.361 | Ferroni faster in every run interval |
| `jinja_string_token` | 0.663 | 0.636–0.725 | comparator faster in every run interval |
| `jinja_integer_token` | 1.092 | 1.041–1.162 | inconclusive |
| `fluent_bit_apache` | 1.293 | 1.015–1.502 | inconclusive |
| `fluent_bit_nginx` | 1.869 | 1.750–1.959 | Ferroni faster in every run interval |
| `literal_first` | 0.998 | 0.934–1.143 | inconclusive |
| `literal_middle` | 1.161 | 0.967–1.227 | inconclusive |
| `literal_end` | 0.966 | 0.850–1.104 | inconclusive |
| `literal_absent` | 1.080 | 1.012–1.095 | inconclusive |
| `ferrolink_attribute_split` | 1.582 | 1.250–1.652 | Ferroni faster in every run interval |

## regex / compile

Common cases: 15; families: 7. Pair-specific family-weighted ratio: 2.251.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 1.182 | 1.027–1.235 | inconclusive |
| `uuid_v4` | 0.899 | 0.816–1.198 | inconclusive |
| `ipv4_validation` | 1.015 | 0.860–1.063 | inconclusive |
| `ipv6_validation` | 1.141 | 0.984–1.259 | inconclusive |
| `semver_version_parse` | 17.664 | 15.481–23.894 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 11.527 | 8.371–13.142 | Ferroni faster in every run interval |
| `jinja_string_token` | 2.851 | 2.507–3.167 | Ferroni faster in every run interval |
| `jinja_integer_token` | 2.079 | 1.858–2.217 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.903 | 1.902–2.221 | Ferroni faster in every run interval |
| `fluent_bit_nginx` | 2.186 | 2.146–2.227 | Ferroni faster in every run interval |
| `literal_first` | 1.161 | 1.059–1.317 | inconclusive |
| `literal_middle` | 1.122 | 1.057–1.421 | inconclusive |
| `literal_end` | 1.367 | 1.252–1.570 | Ferroni faster in every run interval |
| `literal_absent` | 1.178 | 0.921–1.917 | inconclusive |
| `ferrolink_attribute_split` | 3.094 | 2.864–3.187 | Ferroni faster in every run interval |

## regex / first_use

Common cases: 15; families: 7. Pair-specific family-weighted ratio: 1.712.

| Case | Median ratio | Run range | Interpretation |
| --- | ---: | ---: | --- |
| `uuid_shape` | 0.806 | 0.727–0.824 | comparator faster in every run interval |
| `uuid_v4` | 0.683 | 0.655–0.786 | comparator faster in every run interval |
| `ipv4_validation` | 0.720 | 0.689–0.745 | comparator faster in every run interval |
| `ipv6_validation` | 0.725 | 0.648–0.728 | comparator faster in every run interval |
| `semver_version_parse` | 12.688 | 10.548–14.670 | Ferroni faster in every run interval |
| `semver_hyphen_range_captures` | 8.177 | 6.830–9.726 | Ferroni faster in every run interval |
| `jinja_string_token` | 1.526 | 1.475–1.597 | Ferroni faster in every run interval |
| `jinja_integer_token` | 1.760 | 1.676–1.765 | Ferroni faster in every run interval |
| `fluent_bit_apache` | 1.123 | 0.784–1.129 | inconclusive |
| `fluent_bit_nginx` | 1.304 | 1.243–1.342 | Ferroni faster in every run interval |
| `literal_first` | 1.333 | 1.258–1.617 | Ferroni faster in every run interval |
| `literal_middle` | 0.982 | 0.894–1.240 | inconclusive |
| `literal_end` | 1.218 | 1.200–1.387 | Ferroni faster in every run interval |
| `literal_absent` | 1.359 | 1.153–1.583 | Ferroni faster in every run interval |
| `ferrolink_attribute_split` | 3.278 | 3.136–3.845 | Ferroni faster in every run interval |

Raw samples, estimates, confidence intervals, failures, eligibility reasons, corpus snapshot and execution order are retained beside this report.

Memory, where requested, is fresh-process peak RSS including the binary, runtime, parsed catalog, compilation, input/output and allocator. It is not isolated compiled-pattern memory.
