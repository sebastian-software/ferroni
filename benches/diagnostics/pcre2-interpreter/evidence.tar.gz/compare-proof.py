import os, subprocess, json, pathlib, shutil, statistics
root=pathlib.Path('/Users/sebastian/Workspace/.codex/5205/ferroni')
output=pathlib.Path('/private/tmp/ferroni-pcre-profiles')
rows=[]
for rep in range(3):
 for case in ['django_email_domain','django_url_regex','ipv6_validation','tiktoken_o200k_base']:
  versions=['baseline','final'] if rep%2==0 else ['final','baseline']
  for version in versions:
   engine='rust';name=f'pcre-proof-{case}-{version}-{rep}'
   env=dict(os.environ,PRODUCTION_CASE=case,PRODUCTION_ENGINE=engine,PRODUCTION_CORPUS='tokenizer' if case.startswith('tiktoken_') else 'production')
   cmd=[str(output/(version+'-bench')),'--bench','--noplot','--sample-size','30','--measurement-time','2','--warm-up-time','1','--save-baseline',name,'/steady/']
   with (output/(name+'.log')).open('w') as f: subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,check=True,timeout=90)
   source=root/'target/criterion/production_regex'/f'{case}_steady_{engine}'/name
   shutil.copytree(source,output/name)
   estimate=json.loads((source/'estimates.json').read_text())['median']
   row=dict(case=case,version=version,rep=rep,ns=estimate['point_estimate'],interval=estimate['confidence_interval'],command=cmd)
   rows.append(row);print(case,version,rep,round(row['ns']/1000,2),flush=True)
   (output/'proof-comparison.json').write_text(json.dumps(rows,indent=2))
for case in ['django_email_domain','django_url_regex','ipv6_validation','tiktoken_o200k_base']:
 ratios=[]
 for rep in range(3):
  values={r['version']:r['ns'] for r in rows if r['case']==case and r['rep']==rep}
  ratios.append(values['baseline']/values['final'])
 print(case,'speedups',ratios,'median',statistics.median(ratios),flush=True)
