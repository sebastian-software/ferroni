import os,subprocess,json,pathlib,shutil,statistics
root=pathlib.Path('/Users/sebastian/Workspace/.codex/5205/ferroni');output=pathlib.Path('/private/tmp/ferroni-pcre-profiles');rows=[];case='django_email_domain'
for rep in range(3):
 versions=['short-before','short-after','pcre2'] if rep%2==0 else ['pcre2','short-after','short-before']
 for version in versions:
  engine='pcre2' if version=='pcre2' else 'rust';binary='short-before' if version=='pcre2' else version;name=f'pcre-short-{version}-{rep}'
  env=dict(os.environ,PRODUCTION_CASE=case,PRODUCTION_ENGINE=engine)
  cmd=[str(output/(binary+'-bench')),'--bench','--noplot','--sample-size','30','--measurement-time','2','--warm-up-time','1','--save-baseline',name,'/steady/']
  with (output/(name+'.log')).open('w') as f:subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,check=True,timeout=60)
  source=root/'target/criterion/production_regex'/f'{case}_steady_{engine}'/name;shutil.copytree(source,output/name);estimate=json.loads((source/'estimates.json').read_text())['median'];row=dict(case=case,version=version,rep=rep,ns=estimate['point_estimate'],interval=estimate['confidence_interval'],command=cmd);rows.append(row);print(version,rep,round(row['ns']/1000,2),flush=True);(output/'short-comparison.json').write_text(json.dumps(rows,indent=2))
ratios=[]
for rep in range(3):
 v={r['version']:r['ns'] for r in rows if r['rep']==rep};ratios.append(v['short-before']/v['short-after'])
print('Short-domain speedups',ratios,'median',statistics.median(ratios),flush=True)
