from pathlib import Path
import json,subprocess,os,shutil,difflib
root=Path('/Users/sebastian/Workspace/.codex/5205/ferroni');out=Path('/private/tmp/ferroni-pcre-profiles')
base=subprocess.check_output(['git','show','HEAD:src/regexec.rs'],cwd=root,text=True)
base_fixed=base.replace('msa.time_end = Some(Instant::now());','msa.time_end = Some(Instant::now() - std::time::Duration::from_secs(1));')
candidate=(out/'final-regexec.rs').read_text().replace('msa.time_end = Some(Instant::now());','msa.time_end = Some(Instant::now() - std::time::Duration::from_secs(1));')
(out/'candidate.patch').write_text(''.join(difflib.unified_diff(base.splitlines(True),candidate.splitlines(True),fromfile='a/src/regexec.rs',tofile='b/src/regexec.rs')))
catalog=json.loads((root/'benches/production_regex/catalog.json').read_text());case=next(c for c in catalog['cases'] if c['id']=='django_email_domain');case['inputs']=[i for i in case['inputs'] if len(i['text'])<=320];catalog['cases']=[case];(out/'short-catalog.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n')
runner=(root/'benches/production_regex/runner.rs').read_text().replace('include_str!("catalog.json")',f'include_str!("{out}/short-catalog.json")').replace('include_str!("../tokenizer_regex/catalog.json")',f'include_str!("{root}/benches/tokenizer_regex/catalog.json")');(out/'short-runner.rs').write_text(runner)
(out/'short-entry.rs').write_text(f'#[path="{root}/benches/engines.rs"] mod engines;\n#[path="{out}/short-runner.rs"] mod runner;\nfn main() {{ runner::main(); }}\n')
manifest=root/'Cargo.toml';saved_manifest=manifest.read_text();code=root/'src/regexec.rs'
env=dict(os.environ,PCRE2_SYS_STATIC='1',PCRE2_SYS_DEBUG='1',CARGO_PROFILE_RELEASE_DEBUG='1',CARGO_PROFILE_RELEASE_STRIP='none')
try:
 manifest.write_text(saved_manifest+f'\n[[example]]\nname="diagnostic_short_regex"\npath="{out}/short-entry.rs"\nrequired-features=["ffi"]\n')
 for version,source in [('short-before',base_fixed),('short-after',candidate)]:
  code.write_text(source)
  with (out/(version+'-build.jsonl')).open('w') as stdout,(out/(version+'-build.log')).open('w') as stderr:
   subprocess.run(['cargo','build','--locked','--release','--features','ffi','--example','diagnostic_short_regex','--message-format=json'],cwd=root,env=env,stdout=stdout,stderr=stderr,check=True,timeout=90)
  for l in (out/(version+'-build.jsonl')).read_text().splitlines():
   r=json.loads(l)
   if r.get('reason')=='compiler-artifact' and r.get('target',{}).get('name')=='diagnostic_short_regex' and r.get('executable'):shutil.copy2(r['executable'],out/(version+'-bench'))
finally:
 manifest.write_text(saved_manifest);code.write_text(base_fixed)
print('Short fixtures:',len(case['inputs']),flush=True)
