#!/usr/bin/env node
// Standalone codec experiment; it does not change Ferroni's archive format.
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { join } from 'node:path';
import { createHash } from 'node:crypto';
import { performance } from 'node:perf_hooks';
import { brotliCompressSync, brotliDecompressSync, zstdCompressSync, zstdDecompressSync, constants } from 'node:zlib';
const cases = ['cpp','scss','java','json','rust','html','astro','tsx','c','php'];
const codecs = ['brotli11','zstd3','zstd9','zstd19'];
const [command, artifacts, cache, name, repetitionText] = process.argv.slice(2);
const sha = b => createHash('sha256').update(b).digest('hex');
function payload(name) {
  const programs = readFileSync(join(artifacts, `${name}.programs`));
  const groups = readFileSync(join(artifacts, `${name}.portable`));
  const length = Buffer.alloc(4); length.writeUInt32LE(programs.length);
  return Buffer.concat([length,programs,groups]);
}
function decode(codec, bytes) {
  return codec === 'brotli11' ? brotliDecompressSync(bytes) : zstdDecompressSync(bytes);
}
if (command === 'prepare') {
  mkdirSync(cache, { recursive: true });
  const rows = [];
  for (const name of cases) {
    const raw = payload(name);
    for (const codec of codecs) {
      const start = performance.now();
      const encoded = codec === 'brotli11'
        ? brotliCompressSync(raw, {params: {
          [constants.BROTLI_PARAM_QUALITY]:11,
          [constants.BROTLI_PARAM_MODE]:constants.BROTLI_MODE_GENERIC,
        }})
        : zstdCompressSync(raw, {params: {
          [constants.ZSTD_c_compressionLevel]:Number(codec.slice(4)),
          [constants.ZSTD_c_checksumFlag]:1,
        }});
      const compressMs = performance.now()-start;
      if (!decode(codec,encoded).equals(raw)) throw new Error('Round trip differs');
      writeFileSync(join(cache, `${name}.${codec}`),encoded);
      rows.push({corpus:name,codec,rawBytes:raw.length,compressedBytes:encoded.length,
        payloadSha256:sha(raw),compressedSha256:sha(encoded),compressMs,
        versions:process.versions,zstdFrameChecksum:codec !== 'brotli11'});
      writeFileSync(join(cache,'preparation.json'),JSON.stringify(rows,null,2)+'\n');
    }
    process.stdout.write(`Prepared ${name}\n`);
  }
} else if (command === 'measure') {
  const repetition = Number(repetitionText);
  const raw = payload(name);
  const prepared = JSON.parse(readFileSync(join(cache,'preparation.json'),'utf8'));
  const ordered = codecs.slice(repetition%codecs.length).concat(codecs.slice(0,repetition%codecs.length));
  const rows = [];
  for (const codec of ordered) {
    const encoded = readFileSync(join(cache,`${name}.${codec}`));
    const reference = prepared.find(r=>r.corpus===name && r.codec===codec);
    if (sha(raw)!==reference.payloadSha256 || sha(encoded)!==reference.compressedSha256)
      throw new Error('Input hash changed');
    for (let i=0;i<3;i++) if (!decode(codec,encoded).equals(raw)) throw new Error('Warmup differs');
    const samplesMs = [];
    for (let i=0;i<15;i++) {
      const start = performance.now();
      const decoded = decode(codec,encoded);
      const elapsed = performance.now()-start;
      if (!decoded.equals(raw)) throw new Error('Decode differs');
      samplesMs.push(elapsed);
    }
    rows.push({corpus:name,codec,repetition:repetition+1,samplesMs});
  }
  process.stdout.write(JSON.stringify(rows)+'\n');
} else throw new Error('Usage: compare-portable-codecs.mjs prepare|measure ARTIFACTS CACHE [CORPUS REPETITION]');
