from pathlib import Path
import subprocess,json,os,hashlib
root=Path.cwd();cache=root/'.cache/portable-codec-levels-20261024';encoded=cache/'encoded';encoded.mkdir(exist_ok=True);source=root/'scripts/compare-portable-codecs.mjs';source_sha=hashlib.sha256(source.read_bytes()).hexdigest();old=root/'.cache/portable-load-20261023/zstd';art=root/'.cache/portable-load-20261023/final/artifacts';cases=['cpp','scss','java','json','rust','html','astro','tsx','c','php'];codecs=['brotli11','zstd9','zstd16','zstd17','zstd19','zstd21','zstd22'];rows=[]
old_rows={(r['corpus'],r['codec']):r for r in json.loads((old/'preparation.json').read_text())}
for case in cases:
 for codec in codecs:
  env={**os.environ,'PORTABLE_CODEC_REFERENCE':str(old) if codec in ['brotli11','zstd9'] else ''}
  result=subprocess.run(['node',str(source),'prepare-one',str(art),str(encoded),case,codec],capture_output=True,text=True,check=True,timeout=600,env=env)
  row=json.loads(result.stdout);assert row['corpus']==case and row['codec']==codec
  if codec.startswith('zstd'):assert row['zstdFrameChecksum'] is True
  previous=old_rows.get((case,codec))
  if previous:assert row['compressedSha256']==previous['compressedSha256'],(case,codec)
  assert hashlib.sha256(source.read_bytes()).hexdigest()==source_sha
  rows.append(row);(encoded/'preparation.json').write_text(json.dumps(rows,indent=2)+'\n')
  print(case,codec,round(row['compressedBytes']/1048576,3),'MiB',round(row['compressMs']/1000,3),'s encode',('reused' if row.get('reusedFrom') else f"{row['encodeMaxRssKiB']/1024:.1f} MiB peak"),flush=True)
(cache/'source.mjs').write_bytes(source.read_bytes());(cache/'prepare-context.json').write_text(json.dumps({'sourceSha256':source_sha,'cases':cases,'codecs':codecs,'baselineReference':str(old),'reusedEncodings':['brotli11','zstd9'],'encodingScope':'Fresh isolated Node process per new corpus/level; encode wall time is one diagnostic and RSS includes input construction. Frozen baseline encodings copied only after matching runtime versions, payload hash, encoded hash, and full round trip. Level 19 regenerated and verified against its previous encoded hash.'},indent=2)+'\n')
print('Prepared all',len(rows),'corpus/codec pairs',flush=True)
