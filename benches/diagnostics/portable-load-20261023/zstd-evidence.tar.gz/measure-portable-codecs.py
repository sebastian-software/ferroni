from pathlib import Path
import subprocess,json,hashlib,statistics,tarfile,io
root=Path.cwd();c=root/'.cache/portable-load-20261023/zstd';out=root/'benches/diagnostics/portable-load-20261023';art=root/'.cache/portable-load-20261023/final/artifacts';cases=['cpp','scss','java','json','rust','html','astro','tsx','c','php'];rows=[]
prep=json.loads((c/'preparation.json').read_text());main=json.loads((out/'summary.json').read_text());by={(r['corpus'],r['variant']):r for r in main['rows']}
assert len(prep)==40
for r in prep:assert r['payloadSha256']==by[r['corpus'],'portable']['sizes']['payload_sha256']
source=root/'scripts/compare-portable-codecs.mjs';source_sha=hashlib.sha256(source.read_bytes()).hexdigest()
for repetition in range(3):
 for case in cases[repetition:]+cases[:repetition]:
  result=subprocess.run(['node',str(source),'measure',str(art),str(c),case,str(repetition)],capture_output=True,text=True,check=True,timeout=60);rows.extend(json.loads(result.stdout));(c/'samples.json').write_text(json.dumps(rows,indent=2)+'\n')
 print('Completed codec repetition',repetition+1,flush=True)
assert len(rows)==120
summary=[]
for case in cases:
 br_means=[statistics.mean(r['samplesMs']) for r in rows if r['corpus']==case and r['codec']=='brotli11']
 for codec in ['brotli11','zstd3','zstd9','zstd19']:
  prepared=next(r for r in prep if r['corpus']==case and r['codec']==codec);base=next(r for r in prep if r['corpus']==case and r['codec']=='brotli11');selected=[r for r in rows if r['corpus']==case and r['codec']==codec];means=[statistics.mean(r['samplesMs']) for r in selected];changes=[100*(v/b-1) for v,b in zip(means,br_means)]
  summary.append({**prepared,'perProcessMeanMs':means,'medianProcessMeanMs':statistics.median(means),'decodeChangePercent':statistics.median(changes),'decodeChangeRangePercent':[min(changes),max(changes)],'sizeChangePercent':100*(prepared['compressedBytes']/base['compressedBytes']-1)})
context={'classification':'separate in-memory codec diagnostic, not a Rust or CDN benchmark','versions':prep[0]['versions'],'sourceSha256':source_sha,'processRepetitions':3,'warmupDecodes':3,'samplesPerProcess':15,'order':'rotating corpus and codec order, sequential; no compression during decode measurements','input':'Exactly the optimized portable payloads, u32 program length + programs + FPRT002 groups. SHA-256 identity checked against the Rust matrix. Every decode compares all output bytes outside timing.','zstdFrameChecksum':True,'limits':['Local Node builtin native codecs only; does not establish browser or Rust decoding speed.','Time includes output allocation, excludes I/O, bridge, Rust load, and teardown; garbage collection and host activity can affect samples.','Only the ten optimized portable packages were measured; Rust source and payload format are unchanged.']}
(c/'summary.json').write_text(json.dumps({'context':context,'rows':summary},indent=2)+'\n');(out/'zstd.json').write_text((c/'summary.json').read_text())
lines=['# Zstd versus Brotli on the portable packages','', 'Same Node runtime, native builtin codecs, identical payloads: three rotating processes, three warmups and 15 timed decodes per codec/process. Central times are medians of process means. Ranges show all three paired changes versus Brotli-11. Every decoded byte agrees. Zstd frame checksums are enabled at every level. These are local codec diagnostics, excluding Rust load, I/O, transport, bridge costs, and teardown; no browser/CDN speed claim follows.','', '| Corpus | Codec | Compressed KiB | Size vs Brotli | Decode ms | Decode vs Brotli, median [range] |','| --- | --- | ---: | ---: | ---: | ---: |']
for r in summary:
 a,b=r['decodeChangeRangePercent'];lines.append(f"| {r['corpus']} | {r['codec']} | {r['compressedBytes']/1024:.1f} | {r['sizeChangePercent']:+.1f}% | {r['medianProcessMeanMs']:.3f} | {r['decodeChangePercent']:+.1f}% [{a:+.1f}, {b:+.1f}] |")
lines += ['', 'Compression is performed once before any timing process. Its costs are retained in JSON but are single diagnostics, not repeated encode benchmarks. Higher levels trade producer time for package size; decode speed must be measured separately. Dictionaries and custom compression parameters were not used.','', 'Node '+context['versions']['node']+'; Zstd '+context['versions']['zstd']+'; Brotli '+context['versions']['brotli']+'. See [Zstd](https://github.com/facebook/zstd) for the upstream compression-level model.','', 'Reproduce with `scripts/compare-portable-codecs.mjs prepare ARTIFACTS CACHE`, then `measure ARTIFACTS CACHE CORPUS REPETITION` for each corpus and repetitions 0–2. The source, orchestration, raw samples, and source/input/encoded SHA-256 hashes are retained in [zstd-evidence.tar.gz](zstd-evidence.tar.gz).','']
(out/'zstd.md').write_text('\n'.join(lines))
files=[(source,'compare-portable-codecs.mjs'),(Path(__file__),'measure-portable-codecs.py')]+[(c/name,name) for name in ['preparation.json','samples.json','summary.json']];manifest={name:hashlib.sha256(p.read_bytes()).hexdigest() for p,name in files}
with tarfile.open(out/'zstd-evidence.tar.gz','w:gz') as tar:
 for p,name in files:tar.add(p,arcname=name,recursive=False)
 data=(json.dumps(manifest,indent=2)+'\n').encode();info=tarfile.TarInfo('manifest.json');info.size=len(data);tar.addfile(info,io.BytesIO(data))
for r in summary:
 if r['corpus']=='cpp':print(r['codec'],round(r['compressedBytes']/1048576,3),'MiB',round(r['medianProcessMeanMs'],3),'ms decode',flush=True)
for codec in ['zstd3','zstd9','zstd19']:
 selected=[r for r in summary if r['codec']==codec];print(codec,'size range',[round(min(r['sizeChangePercent'] for r in selected),1),round(max(r['sizeChangePercent'] for r in selected),1)],'decode range',[round(min(r['decodeChangePercent'] for r in selected),1),round(max(r['decodeChangePercent'] for r in selected),1)],flush=True)
