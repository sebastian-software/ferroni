from pathlib import Path
import subprocess,json,statistics,hashlib,tarfile
root=Path.cwd();c=root/'.cache/portable-load-20261023';rows=[];variants=['after','fused'];cases=['cpp','scss','java','json','rust','html','astro','tsx','c','php']
for rep in range(3):
 for case in cases[rep:]+cases[:rep]:
  for v in variants[rep%2:]+variants[:rep%2]:
   r=subprocess.run([str(c/f'phases-{v}'),'load-probe',case,str(c/'artifacts'),'portable','25'],capture_output=True,text=True,check=True,timeout=60);row=json.loads(r.stdout);row.update(repetition=rep+1,stage=v);rows.append(row)
  (c/'fused-screen.json').write_text(json.dumps(rows,indent=2)+'\n')
 print('Completed screen repetition',rep+1,flush=True)
for case in cases:
 ratios=[]
 for rep in range(1,4):
  a=next(r for r in rows if r['corpus']==case and r['repetition']==rep and r['stage']=='after');b=next(r for r in rows if r['corpus']==case and r['repetition']==rep and r['stage']=='fused');ratios.append(100*(statistics.mean(b['samples_ns'])/statistics.mean(a['samples_ns'])-1))
 print(case,round(statistics.median(ratios),1),[round(x,1) for x in ratios],flush=True)
