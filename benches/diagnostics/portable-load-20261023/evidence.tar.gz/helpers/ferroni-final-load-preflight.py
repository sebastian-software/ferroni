from pathlib import Path
import json,subprocess,struct,hashlib,shutil,gzip,time,statistics,platform
root=Path.cwd();c=root/'.cache/portable-load-20261023';run=c/'final/run-01';sizes=json.loads((run/'sizes.json').read_text());fresh=json.loads((c/'brotli-fresh.json').read_text());old=json.loads((root/'benches/diagnostics/portable-kernel-20261023/brotli.json').read_text());br=[]
for row in sizes:
 variant=row['variant'];source=next(r for r in (old if variant=='before' else fresh) if r['corpus']==row['corpus'] and r['variant']==({'before':'portable','control':'eager'}.get(variant,variant)));r=dict(source);r['variant']=variant;r['codec_timing_provenance']='historical, reused by payload hash' if variant=='before' else 'fresh standalone Brotli-11 run before main timing';assert r['payloadSha256']==row['payload_sha256'];br.append(r)
(c/'brotli.json').write_text(json.dumps(br,indent=2)+'\n')
# Verify the refreshed final producer deterministically reproduces every image.
verify=c/'verify-export';verify.mkdir(exist_ok=True)
for case in ['cpp','scss','java','json','rust','html','astro','tsx','c','php']:
 subprocess.run([str(c/'final/bin/portable'),'prepare-portable',case,str(verify)],capture_output=True,check=True,timeout=90)
 for ext in ['programs','portable']:assert (verify/f'{case}.{ext}').read_bytes()==(c/f'final/artifacts/{case}.{ext}').read_bytes()
print('Final producer determinism verified for all corpora',flush=True)
shutil.copy2(run/'sizes.json',c/'preparation-sizes.json')
for row in sizes:
 art=root/'.cache/portable-kernel-20261023/artifacts' if row['variant']=='before' else c/'final/artifacts';programs=(art/f"{row['corpus']}.programs").read_bytes();v='portable' if row['variant']=='before' else row['variant'];groups=b'' if v in ['eager','control'] else (art/f"{row['corpus']}.{v}").read_bytes();payload=struct.pack('<I',len(programs))+programs+groups;encoded=gzip.compress(payload,compresslevel=9,mtime=0);assert hashlib.sha256(encoded).hexdigest()==row['gzip_sha256'];times=[]
 for i in range(10):
  start=time.perf_counter_ns();decoded=gzip.decompress(encoded);elapsed=time.perf_counter_ns()-start;assert decoded==payload
  if i:times.append(elapsed)
  del decoded
 row['decompress_ns']=times;row['decompress_median_ns']=statistics.median(times)
(run/'sizes.json').write_text(json.dumps(sizes,indent=2)+'\n')
(c/'codec-preflight.json').write_text(json.dumps({'python':platform.python_version(),'gzip':'All 50 decode lanes resampled serially after Brotli and producer checks, before main timings. Original preparation samples retained separately.','brotli':'Fresh Eager, Snapshot, and optimized Portable; unchanged before size reused only by payload SHA-256. No compilation or compression beside Criterion.'},indent=2)+'\n')
print('All gzip decode diagnostics resampled without other experiment work',flush=True)
