from pathlib import Path
import json,tarfile,subprocess,io,hashlib,struct
root=Path.cwd();c=root/'.cache/portable-load-20261023';run=c/'final/run-01';out=root/'benches/diagnostics/portable-load-20261023'
# Validate both immutable instruction images and all fixture references.
context=json.loads((run/'context.json').read_text());old_context=json.loads((root/'.cache/prepared-eager-20261023/run-01/context.json').read_text());assert context['fixture_sha256']==old_context['fixture_sha256']
identities=[]
for case in context['fixture_sha256']:
 def bodies(path):
  data=path.read_bytes();n=struct.unpack_from('<I',data,13)[0];pos=17;h=hashlib.sha256()
  for _ in range(n):
   size=struct.unpack_from('<I',data,pos)[0];key=data[pos:pos+4+size*4];pos+=4+size*4;size=struct.unpack_from('<I',data,pos+4)[0];pos+=8;h.update(key);h.update(struct.pack('<I',size));h.update(data[pos:pos+size]);pos+=size
  assert pos==len(data);return n,h.hexdigest()
 old=root/f'.cache/portable-kernel-20261023/artifacts/{case}.portable';new=c/f'final/artifacts/{case}.portable';a=bodies(old);b=bodies(new);assert a==b
 identities.append({'corpus':case,'groups':a[0],'ordered_keys_and_record_bodies_sha256':a[1],'before_sha256':hashlib.sha256(old.read_bytes()).hexdigest(),'optimized_sha256':hashlib.sha256(new.read_bytes()).hexdigest()})
(c/'instruction-identity.json').write_text(json.dumps(identities,indent=2)+'\n')
# All captured working-tree overrides must still be exact.
for name,digest in context['source_sha256'].items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
for label,hashes in context['binaries'].items():
 for kind,digest in hashes.items():assert hashlib.sha256((c/'final/bin'/(label+('-bench' if kind=='bench' else ''))).read_bytes()).hexdigest()==digest
entries=[]
for name in ['context.json','validation.json','sizes.json','memory.json']:
 entries.append((run/name,'run/'+name))
for path in (run/'criterion').rglob('*.json'):entries.append((path,'run/'+str(path.relative_to(run))))
for path in run.glob('r*.log'):entries.append((path,'run/'+path.name))
for name in ['phases-before','phases-after','phases-final']:
 for suffix in ['-samples.json','-summary.json','-provenance.json','-source.tar.gz']:
  path=c/(name+suffix)
  if path.exists():entries.append((path,'diagnostics/'+path.name))
for name in ['fused-source.tar.gz','fused-screen.json','fused-screen.log','fused-screen-provenance.json','legacy-validation.json','baseline-head-verification.json','instruction-identity.json','brotli.json','brotli-fresh.json','codec-preflight.json','preparation-sizes.json','artifact-preparation.json','backup-before-matrix.log','preparation.log','preflight.log','matrix.log','phase-final.log','validation-focused.log','clippy-all-features.log','clippy-no-default.log','fmt-check.log','test-counts.log','profile-no-default-test.log','checksum-tests.log']:
 path=c/name
 if path.exists():entries.append((path,'diagnostics/'+name))
for label in ['baseline','final']:
 entries.append((c/label/'build-provenance.json',label+'/build-provenance.json'))
 for path in (c/label/'build-logs').glob('*'):entries.append((path,label+'/build-logs/'+path.name))
entries.append((root/'.cache/prepared-eager-20261023/run-01/context.json','references/snapshot-context.json'))
for name in context['source_sha256']:
 if name.startswith(('src/','scripts/','examples/')) or name in ['Cargo.toml','benches/diagnostics/portable-eager-prototype.md']:
  entries.append((root/name,'source-overrides/'+name))
for name in ['ferroni-profile-load-phases.py','ferroni-profile-load-after.py','ferroni-profile-load-final.py','ferroni-screen-load-fused.py','ferroni-final-load-preflight.py','ferroni-write-load-report.py','ferroni-pack-load-evidence.py']:
 entries.append((Path('/private/tmp')/name,'helpers/'+name))
manifest={arc:hashlib.sha256(path.read_bytes()).hexdigest() for path,arc in entries}
with tarfile.open(out/'evidence.tar.gz','w:gz') as tar:
 for path,arc in entries:tar.add(path,arcname=arc,recursive=False)
 def add(name,data):
  b=data.encode();info=tarfile.TarInfo(name);info.size=len(b);tar.addfile(info,io.BytesIO(b))
 add('manifest.json',json.dumps({'base_commit':context['base_commit'],'files_sha256':manifest},indent=2)+'\n')
 add('README.txt','Base commit: '+context['base_commit']+'\nApply source-overrides on that base to recover the measured implementation. Final and baseline build provenance record all copied build inputs and binary hashes. Baseline input identity was checked against the base commit. Historical Snapshot source is retained in the preceding prepared/portable experiment evidence archives. No dependency fork is used by the current build. All phase builds are separate from final Criterion binaries. Codec diagnostics were completed before main measurement; before Brotli codec times are historical and labeled. The local .cache artifacts and frozen binaries remain intact.\n')
print('Evidence entries:',len(entries),'bytes:',(out/'evidence.tar.gz').stat().st_size)
