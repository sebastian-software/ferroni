from pathlib import Path
import json,statistics
out=Path('benches/diagnostics/portable-load-20261023');s=json.loads((out/'summary.json').read_text());by={(r['corpus'],r['variant']):r for r in s['rows']};pairs={(p['corpus'],p['baseline']):p for p in s['portable_pairs']};cases=['cpp','scss','java','json','rust','html','astro','tsx','c','php'];br={(r['corpus'],r['variant']):r for r in s['brotli']}
def span(base,metric):
 values=[pairs[c,base]['metrics'][metric]['median_percent'] for c in cases];return f'{min(values):+.1f}% to {max(values):+.1f}%'
def regress(base):return ', '.join(c for c in cases if pairs[c,base]['metrics']['search']['all_runs_regress_3_percent']) or 'none'
def gainspan(base):
 a=[-pairs[c,base]['metrics']['load']['median_percent'] for c in cases];return f'{min(a):.1f}–{max(a):.1f}%'
lines=['# Fork-free portable Eager: load-phase optimization','',
 f'The optimized loader takes {gainspan("before")} less time than the frozen merged portable loader and {gainspan("eager")} less than ordinary Eager across ten captured corpora (median paired changes from three processes). Changes versus the frozen Snapshot loader range from {span("prepared","load")}. Every corpus gains at least 3% in each of the three repetitions versus merged Portable. These are in-memory Rust load times, excluding codecs, file I/O, and network transfer.','',
 f'Warm-search changes versus merged Portable range from {span("before","search")}; versus Eager, {span("eager","search")}; versus Snapshot, {span("prepared","search")}. Cases at least 3% slower in every repetition: merged Portable: {regress("before")}; Eager: {regress("eager")}; Snapshot: {regress("prepared")}. This is still an opt-in prototype.','',
 'The [codec diagnostics](codecs.md) show decompression separately. The [complete comparison](comparison.md) retains all absolute times, paired ranges against each reference, Brotli/gzip sizes, peak RSS, and internal counters. [measurements.md](measurements.md) includes the feature control. [phases.md](phases.md) contains the before/after phase breakdown; [summary.json](summary.json) retains every Criterion mean estimate and reference pair. The [evidence archive](evidence.tar.gz) binds source overrides, build provenance, raw samples, validation, diagnostics, and checks.','',
 '## Load across all corpora','',
 'Milliseconds per captured corpus. Negative changes mean less time; the full comparison includes the three-process ranges.','',
 '| Corpus | Eager | Snapshot | Merged Portable | Optimized Portable | vs merged | vs Eager |',
 '| --- | ---: | ---: | ---: | ---: | ---: | ---: |']
for c in cases:
 times=[by[c,v]['timings']['load']['median_mean_ns']/1e6 for v in ['eager','prepared','before','portable']]
 lines.append(f'| {c} | '+' | '.join(f'{t:.3f}' for t in times)+f' | {pairs[c,"before"]["metrics"]["load"]["median_percent"]:+.1f}% | {pairs[c,"eager"]["metrics"]["load"]["median_percent"]:+.1f}% |')
lines+=['','## Cause and implementation','',
 'The initial exclusive phase clocks put C++ group checksums at 5.77 ms (22.7% of load) and SCSS at 3.05 ms (30.3%). The serial word checksum had one dependent multiplication chain. The group format now uses four independent word lanes for both record checks and the binding to its program archive. C++ group checksum time falls to 1.71 ms and SCSS to 0.92 ms in the separate diagnostic runs.','',
 'The portable instruction reader preflights the complete `count × 16` byte span and decodes fixed-size chunks. It avoids four fallible reader calls per instruction and allocation before checking the complete span. C++ instruction decoding falls from 3.10 to 1.90 ms in the diagnostic builds. Full opcode, reference, range, assertion, and byte-class validation still runs. No unsafe code, dependencies, dependency forks, or execution-cache changes were added.','',
 'New exports use `FPRT002` with the new corruption checks; consumers continue to load `FPRT001` using its original checks. The ordinary precompiled program format remains version 2. Program archives and every group identity/instruction body match the merged packages byte-for-byte. Corruption checks are not authentication. Tests cover every single-bit change across lane/tail boundaries, legacy loading, and invalid entry states with a correctly recomputed checksum.','',
 'A fused decode/validation loop was rejected: a rotating three-process load screen made C++ 4.3–6.0% slower and produced mixed changes elsewhere. Its exact intermediate source and raw screen are retained. Diagnostic scopes are behind `scanner-load-profile` and compile out of all final measurement binaries.','',
 '## Size and memory','']
raw_same=all(by[c,'portable']['sizes']['raw_bytes']==by[c,'before']['sizes']['raw_bytes'] for c in cases)
assert raw_same
br_deltas=[100*(br[c,'portable']['brotli11Bytes']/br[c,'before']['brotli11Bytes']-1) for c in cases]
lines += [f'Raw package lengths are identical to merged Portable in every corpus. Brotli-11 changes range from {min(br_deltas):+.2f}% to {max(br_deltas):+.2f}%; the instruction payload is unchanged and only checksum/header bytes differ. Eager, Snapshot, and optimized Portable were freshly compressed and round-trip checked. Before sizes are reused only after payload SHA-256 identity checks; their historical codec times are labeled and are not a new measurement. gzip-9 and decode diagnostics were rerun serially before the main matrix.','']
c='cpp';lines += [f'For C++, optimized Portable is {by[c,"portable"]["sizes"]["raw_bytes"]/1048576:.2f} MiB raw and {br[c,"portable"]["brotli11Bytes"]/1048576:.2f} MiB with Brotli-11. Snapshot is {by[c,"prepared"]["sizes"]["raw_bytes"]/1048576:.2f} MiB raw / {br[c,"prepared"]["brotli11Bytes"]/1048576:.2f} MiB Brotli; Eager is {by[c,"eager"]["sizes"]["raw_bytes"]/1048576:.2f} / {br[c,"eager"]["brotli11Bytes"]/1048576:.2f} MiB.','']
imm_same=all(by[c,'portable']['memory']['immutable_after_search_bytes']==by[c,'before']['memory']['immutable_after_search_bytes'] for c in cases);scratch_same=all(by[c,'portable']['memory']['scratch_after_search_bytes']==by[c,'before']['memory']['scratch_after_search_bytes'] for c in cases)
assert imm_same and scratch_same
lines += [f'Internal immutable and scanner scratch counters are identical to merged Portable across all corpora. Peak RSS retains fixture parsing, source images, decoded programs, scanners, and four document passes. It is a process high-water mark, not an allocation total; see all three process ranges in the JSON and the full comparison. There is no general memory-reduction claim.','',
 '## Method and verification','',
 '- Base and frozen merged baseline: `0953789a0a777163c9497478d39166203e410e6e`. The 198 baseline build inputs match that commit. Old caches, binaries, and reports remain intact.',
 '- Ten captured corpora; all 75,501 calls, winning patterns, and capture arrays agree in all five lanes before timing. New-reader replay of legacy packages also reproduces all calls. Every archived group is consumed without a decode fallback. The refreshed producer deterministically reproduces every new image.',
 '- Five variants × ten corpora × three rotating process repetitions. Criterion: 40 samples, 300 ms warmup, 1 s target, 10,000 bootstrap resamples. Criterion extends the measurement duration where 40 iterations need more time. Ratios pair the same repetition; observed ranges are not confidence intervals.',
 '- Load includes indexing, checksum/structural validation, decoding, helper preparation, and scanner/cache construction. Warm search follows three complete document passes; fresh string identities and teardown stay outside timing. First document includes load plus its first replay.',
 '- Separate phase diagnostics: three rotating processes, 20 fresh loads per process, nested exclusive clocks. Instrumentation adds overhead; these explain causes and do not replace final Criterion timings.',
 '- Local Mac Studio M1 Ultra, 64 GB, macOS arm64, rustc 1.99.0, release/bench ThinLTO. Time Machine was idle before the matrix. No experiment compilation or compression ran beside main timings. Core placement, thermals, and unrelated background activity were not controlled.',
 '- Current producer and consumer resolve registry regex-automata 0.4.18 and aho-corasick 1.1.5. Snapshot is an unchanged historical executable with its old dependency extensions; those are not in the current dependency graph. The feature control runs ordinary Eager through the optimized Portable binary without a group image.',
 '- Local release validation: 580 focused tests pass (one test remains ignored), plus the diagnostic test without default features. Coverage includes portable differential searches with tiny cache resets, malformed/truncated archives, legacy checksums, re-export, captures/order/duplicates, and mode fallback. Formatting passes; Clippy passes with all features and with `precompiled,scanner-load-profile` without defaults. Test counts come from `scripts/count-tests.sh` and are retained separately; no new CI claim is implied.','',
 'Within Rust, the largest remaining costs depend on the corpus: PHP spends about 5.04 ms in ordinary program decoding, SCSS about 2.14 ms in instruction validation, and C++ about 3.24 ms in scanner assembly plus 1.99 ms in group lookup. These are concrete next profiling targets. This comparison does not establish cross-platform behavior, full grammar coverage, authenticated distribution, or Ferriki/CDN startup time.','',
 'Compressed inputs make codec work a larger target now. The fresh C++ standalone Brotli diagnostic takes 46.24 ms, compared with 19.84 ms of optimized Rust load; gzip decoding takes 33.32 ms. These are separate runtimes and boundaries, not a measured end-to-end sum. Format/codec layout and the actual application decode path deserve priority before further small loader changes. See the codec table for every corpus.','',
 '## Reproduction','',
 'Retain the historical caches referenced by the build provenance. Use fresh output directories and omit `scanner-load-profile` from final binaries. Frozen Before reads its original FPRT001 artifact directory; optimized Portable reads FPRT002.','',
 '```sh',
 'python3 scripts/prepare-portable-eager-comparison.py NEW_CACHE --snapshot-cache SNAPSHOT_CACHE --portable-reference-cache MERGED_BASELINE_CACHE',
 '# Export each corpus with NEW_CACHE/bin/portable prepare-portable CORPUS NEW_CACHE/artifacts.',
 'python3 scripts/compare-scanner-group-archives.py NEW_CACHE/run-01 --cache NEW_CACHE --prebuilt --reuse-artifacts --prepare-only --before-artifacts MERGED_ARTIFACTS --variants eager prepared before portable control',
 'node scripts/compress-scanner-group-archives.mjs NEW_CACHE/artifacts BROTLI_JSON eager prepared portable',
 'python3 scripts/compare-scanner-group-archives.py NEW_CACHE/run-01 --cache NEW_CACHE --measure-only --repetitions 3',
 'python3 scripts/report-portable-load.py NEW_CACHE/run-01 COMBINED_BROTLI_JSON REPORT_DIR --phases PHASE_DIR',
 '```','',
 'The evidence includes the helper scripts that combine the verified reference codec rows, capture diagnostic phases, and retain final source overrides. The current tree cannot rebuild the historical Snapshot without its historical sources; its original evidence is retained in the preceding dated reports.','']
codec_lines=['# Separate codec diagnostics','',
 'These are standalone, in-memory decoding diagnostics completed before the main matrix: CPython gzip/zlib and Node Brotli, nine timed decodes after a round-trip/warmup. Rust load is the median of three Criterion process means. The different runtimes and allocation paths do not establish a direct codec ranking or an application/CDN startup time. No file I/O, network, or host-language bridge is included. Historical Before Brotli timings are omitted.','',
 '| Corpus | Variant | Rust load ms | gzip-9 decode ms | Brotli-11 decode ms |',
 '| --- | --- | ---: | ---: | ---: |']
for c in cases:
 for v in ['eager','prepared','portable']:
  r=by[c,v];codec_lines.append(f"| {c} | {v} | {r['timings']['load']['median_mean_ns']/1e6:.3f} | {r['sizes']['decompress_median_ns']/1e6:.3f} | {br[c,v]['decodeMedianMs']:.3f} |")
(out/'codecs.md').write_text('\n'.join(codec_lines)+'\n')
(out/'README.md').write_text('\n'.join(lines))
