from pathlib import Path
import subprocess,json,statistics,hashlib,tarfile
root=Path.cwd();cache=root/'.cache/portable-load-20261023';cases=['cpp','scss','java','json','rust','html','astro','tsx','c','php'];rows=[];stage='before'
files=subprocess.run(['git','ls-files','-m','-o','--exclude-standard'],check=True,capture_output=True,text=True).stdout.splitlines()
files=sorted(set(n for n in files if (root/n).is_file()))
with tarfile.open(cache/f'phases-{stage}-source.tar.gz','w:gz') as tar:
 for name in files:tar.add(root/name,arcname=name,recursive=False)
provenance={'head':subprocess.run(['git','rev-parse','HEAD'],capture_output=True,text=True,check=True).stdout.strip(),'instrumented_binary_sha256':hashlib.sha256((cache/f'phases-{stage}').read_bytes()).hexdigest(),'source_sha256':{n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in files},'features':['portable-eager-prototype','scanner-load-profile'],'scope':'Thread-local exclusive phase clocks; diagnostic only, excluded from final Criterion binaries.'}
(cache/f'phases-{stage}-provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
for rep in range(3):
 for case in cases[rep:]+cases[:rep]:
  variants=['portable','eager'] if rep%2==0 else ['eager','portable']
  for variant in variants:
   p=subprocess.run([str(cache/f'phases-{stage}'),'load-phases',case,str(root/'.cache/portable-kernel-20261023/artifacts'),variant,'20'],capture_output=True,text=True,check=True,timeout=90)
   row=json.loads(p.stdout);row['repetition']=rep+1;rows.append(row)
   for sample in row['samples']:
    total=next(r['inclusive_ns'] for r in sample if r['phase']=='total')
    assert sum(r['exclusive_ns'] for r in sample)==total
   (cache/f'phases-{stage}-samples.json').write_text(json.dumps(rows,indent=2)+'\n')
  print('Profiled',rep+1,case,flush=True)
summary=[]
for case in cases:
 for variant in ['eager','portable']:
  rs=[r for r in rows if r['corpus']==case and r['variant']==variant];names=sorted({s['phase'] for r in rs for sample in r['samples'] for s in sample})
  timings=[]
  for name in names:
   exclusive=[];inclusive=[];calls=[]
   for r in rs:
    data=[s for sample in r['samples'] for s in sample if s['phase']==name]
    exclusive.append(statistics.mean(s['exclusive_ns'] for s in data));inclusive.append(statistics.mean(s['inclusive_ns'] for s in data));calls.append(statistics.mean(s['calls'] for s in data))
   timings.append({'phase':name,'median_process_mean_exclusive_ns':statistics.median(exclusive),'median_process_mean_inclusive_ns':statistics.median(inclusive),'calls_per_load':statistics.median(calls),'exclusive_per_run_ns':exclusive})
  summary.append({'corpus':case,'variant':variant,'phases':timings})
(cache/f'phases-{stage}-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for row in summary:
 if row['variant']=='portable':
  total=next(p['median_process_mean_inclusive_ns'] for p in row['phases'] if p['phase']=='total')
  print(row['corpus'],round(total/1e6,3),[(p['phase'],round(p['median_process_mean_exclusive_ns']/1e6,3),round(100*p['median_process_mean_exclusive_ns']/total,1)) for p in sorted(row['phases'],key=lambda p:p['median_process_mean_exclusive_ns'],reverse=True)[:6]],flush=True)
