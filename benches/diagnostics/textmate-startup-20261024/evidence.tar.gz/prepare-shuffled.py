import json, shutil, subprocess
from pathlib import Path
root = Path(__file__).resolve().parent
frozen = root.parent / 'textmate-source-off-20261024/inputs'
after = root / 'inputs-shuffled'
shutil.copy2('target/release/textmate-source-comparison', root/'bin/profile-shuffled')
shutil.copytree(frozen, after)
records = []
for case in ['cpp','scss','java','json','rust','html','astro','tsx','c','php']:
    result = subprocess.run([str(root/'bin/profile-shuffled'),'prepare',case,str(after),'eager'], capture_output=True,text=True,check=True)
    assert (after/f'{case}.programs').read_bytes() == (frozen/f'{case}.programs').read_bytes()
    assert (after/f'{case}.expected.json').read_bytes() == (frozen/f'{case}.expected.json').read_bytes()
    record = {'producer':json.loads(result.stdout)}
    result = subprocess.run(['node','scripts/portable-eager-package.mjs','pack',str(after),case,str(after)],capture_output=True,text=True,check=True)
    record['package'] = json.loads(result.stdout)
    records.append(record)
    print('Produced',case,record['package']['compressedBytes'],flush=True)
(root/'shuffled-packages.json').write_text(json.dumps(records,indent=2)+'\n')
rows = []
for case in ['cpp','scss','astro']:
    result = subprocess.run([str(root/'bin/profile-shuffled'),'profile',case,str(after),'portable','10'],capture_output=True,text=True,check=True)
    rows.extend(json.loads(line) for line in result.stdout.splitlines())
(root/'profile-shuffled.json').write_text(json.dumps(rows,indent=2)+'\n')
