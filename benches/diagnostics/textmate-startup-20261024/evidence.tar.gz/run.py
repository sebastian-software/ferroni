import hashlib
import json
import os
import platform
import subprocess
import sys
from pathlib import Path

root = Path(__file__).resolve().parent
repository = root.parent.parent
frozen = root.parent / 'textmate-source-off-20261024'
cases = ['cpp', 'scss', 'java', 'json', 'rust', 'html', 'astro', 'tsx', 'c', 'php']
inputs = {'before': frozen / 'inputs', 'after': root / 'inputs-shuffled'}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


paths = [path for path in (repository / 'src').rglob('*.rs')]
paths += [repository / name for name in ['Cargo.toml', 'Cargo.lock']]
paths += [path for directory in ['src', 'textmate', 'benches'] for path in (root / directory).rglob('*')
          if path.is_file() and path.suffix in ['.rs', '.toml']]
paths += [root / 'Cargo.toml', root / 'Cargo.lock', Path(__file__).resolve()]
source_hashes = {str(path.relative_to(repository)): digest(path) for path in paths}
input_hashes = {variant: {p.name: digest(p) for p in directory.iterdir() if p.is_file()}
                for variant, directory in inputs.items()}
base = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
patch = subprocess.check_output(['git', 'diff', '--', 'src', 'benches/diagnostics/portable-eager-prototype.md'])
(root / 'implementation.patch').write_bytes(patch)
context = {
    'base': base,
    'baseline': 'New identical local TextMate harness built against unchanged merged main before source edits',
    'candidate': 'FPRT003 compact byte planes and 16-bit pool; runtime instruction layout and search kernel unchanged',
    'sourceSha256': source_hashes,
    'inputSha256': input_hashes,
    'binarySha256': {p.name: digest(p) for p in (root / 'bin').iterdir() if p.is_file()},
    'patchSha256': hashlib.sha256(patch).hexdigest(),
    'platform': platform.platform(),
    'rustc': subprocess.check_output(['rustc', '-Vv'], text=True),
    'backupStatus': subprocess.check_output(['tmutil', 'status'], text=True),
    'criterion': {'samples': 40, 'warmupSeconds': 0.3, 'targetSeconds': 1, 'bootstrapResamples': 10000},
    'repetitions': 3,
    'boundary': 'first_document: bounded verified Zstd decode, raw TextMate grammar parsing/registration, archive attachment, first-use work and full scope/binary tokenization; warm_search: complete same document after three passes',
    'excludes': ['network transfer', 'input file I/O', 'theme application', 'HTML rendering'],
    'frozenInputContextSha256': digest(frozen / 'context.json'),
}
(root / 'context.json').write_text(json.dumps(context, indent=2) + '\n')
helper = '''import json,resource,subprocess,sys
p=subprocess.run(sys.argv[1:],check=True,text=True,capture_output=True)
v=json.loads(p.stdout)
v['peakRssBytes']=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss
print(json.dumps(v))
'''
validation = []
for corpus in cases:
    for variant in ['before', 'after', 'after-legacy']:
        binary = root / 'bin' / ('driver-before' if variant == 'before' else 'driver-after')
        directory = inputs['after' if variant == 'after' else 'before']
        result = subprocess.run([sys.executable, '-c', helper, str(binary), 'validate', corpus,
                                 str(directory), 'portable'], text=True, capture_output=True,
                                check=True, timeout=90)
        row = json.loads(result.stdout)
        row['build'] = variant
        assert row['stats'][2] == 0
        group_count = int.from_bytes((directory / f'{corpus}.portable').read_bytes()[13:17], 'little')
        assert row['stats'][1] == group_count
        validation.append(row)
        print('Validated', corpus, variant, row['tokens'], row['stats'], flush=True)
(root / 'validation.json').write_text(json.dumps(validation, indent=2) + '\n')
for repetition in range(1, 4):
    ordered = cases[repetition - 1:] + cases[:repetition - 1]
    for corpus in ordered:
        variants = ['before', 'after'] if (repetition + cases.index(corpus)) % 2 else ['after', 'before']
        for variant in variants:
            label = f'r{repetition}-{corpus}-{variant}'
            environment = {**os.environ, 'CORPUS': corpus, 'VARIANT': 'portable',
                           'INPUTS': str(inputs[variant]), 'OUTPUT': str(root / 'criterion' / label)}
            print('Benchmark', label, flush=True)
            result = subprocess.run([str(root / 'bin' / variant), '--bench', '--noplot'],
                                    env=environment, text=True, capture_output=True, check=True,
                                    timeout=180)
            (root / f'{label}.log').write_text(result.stdout + result.stderr)
for name, expected in source_hashes.items():
    assert digest(repository / name) == expected, name
for variant, hashes in input_hashes.items():
    for name, expected in hashes.items():
        assert digest(inputs[variant] / name) == expected, (variant, name)
for name, expected in context['binarySha256'].items():
    assert digest(root / 'bin' / name) == expected, name
(root / 'verified-after-run.json').write_text(json.dumps({
    'sourcesUnchanged': True, 'inputsUnchanged': True, 'binariesUnchanged': True,
    'backupStatus': subprocess.check_output(['tmutil', 'status'], text=True),
}, indent=2) + '\n')
print('Completed all 60 Criterion processes and verified frozen inputs/source/binaries', flush=True)
