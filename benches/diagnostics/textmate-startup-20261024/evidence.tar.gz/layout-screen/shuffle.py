import struct, subprocess, json
from pathlib import Path
root = Path(__file__).resolve().parent
frozen = root.parent.parent / 'textmate-source-off-20261024/inputs'
results = []
for case in ['cpp', 'scss', 'astro']:
    data = (frozen / f'{case}.portable').read_bytes()
    for layout in ['packed-shuffle', 'separate-shuffle', 'separate-columns-pool32']:
        pos = 13
        def u32():
            global pos
            n = struct.unpack_from('<I', data, pos)[0]
            pos += 4
            return n
        def skipvec():
            global pos
            n = u32()
            pos += 4 * n
        def planes(words, width):
            encoded = struct.pack(f'<{len(words)}' + ('I' if width == 4 else 'H'), *words)
            return b''.join(encoded[i::width] for i in range(width))
        count = u32()
        out = bytearray(b'FPRT003\0' + data[8:17])
        for group in range(count):
            start = pos
            skipvec()
            key = data[start:pos]
            checksum = u32()
            size = u32()
            end = pos + size
            tag = data[pos]
            pos += 1
            if tag == 0:
                record = b'\0'
            else:
                assert tag == 5
                start = pos
                for _ in range(3):
                    skipvec()
                u32()
                record = bytearray(b'\6' + data[start:pos])
                for _ in range(2):
                    start = pos
                    pos += 265
                    n = u32()
                    record.extend(data[start:pos])
                    code = list(struct.iter_unpack('<4I', data[pos:pos+n*16]))
                    pos += n * 16
                    if layout == 'packed-shuffle':
                        record.extend(planes([a << 3 | op for op,a,b,r in code], 4))
                    elif layout == 'separate-shuffle':
                        record.extend(bytes(op for op,a,b,r in code))
                        record.extend(planes([a for op,a,b,r in code], 4))
                    else:
                        record.extend(bytes(op for op,a,b,r in code))
                        record.extend(struct.pack(f'<{n}I', *(a for op,a,b,r in code)))
                    if layout.endswith('shuffle'):
                        record.extend(planes([b for op,a,b,r in code], 4))
                    else:
                        record.extend(struct.pack(f'<{n}I', *(b for op,a,b,r in code)))
                    m = u32()
                    record.extend(struct.pack('<I', m))
                    pool = struct.unpack_from(f'<{m}I', data, pos)
                    pos += m * 4
                    if layout.endswith('shuffle'):
                        record.extend(planes(pool, 2))
                    else:
                        record.extend(struct.pack(f'<{m}I', *pool))
                assert pos == end
            out.extend(key)
            # Compression-only screening. The old record checksum is retained;
            # these diagnostic images are not sent to the runtime decoder.
            out.extend(struct.pack('<II', checksum, len(record)))
            out.extend(record)
        assert pos == len(data)
        name = f'{case}-{layout}'
        (root / f'{name}.portable').write_bytes(out)
        (root / f'{name}.programs').write_bytes((frozen / f'{case}.programs').read_bytes())
        result = subprocess.run(['node', 'scripts/portable-eager-package.mjs', 'pack', str(root), name, str(root)], text=True, capture_output=True, check=True)
        results.append(json.loads(result.stdout))
(root / 'shuffle-results.json').write_text(json.dumps(results, indent=2))
print(json.dumps([{k:r[k] for k in ['name','payloadBytes','compressedBytes']} for r in results], indent=2))
