use criterion::{BatchSize, Criterion, criterion_group, criterion_main};
use std::{hint::black_box, path::PathBuf, time::Duration};
use textmate_source_comparison::Inputs;
fn bench(c: &mut Criterion) {
    let corpus = std::env::var("CORPUS").unwrap();
    let variant = std::env::var("VARIANT").unwrap();
    let directory = PathBuf::from(std::env::var_os("INPUTS").unwrap());
    let input = Inputs::read(&directory, &corpus, &variant);
    {
        let loaded = input.load();
        let result = input.tokenize(&loaded);
        let actual: Vec<_> = result.iter().map(|(tokens,binary)| serde_json::json!({
            "tokens":tokens.iter().map(|t|serde_json::json!([t.start_index,t.end_index,t.scopes])).collect::<Vec<_>>(),
            "binary":binary,
        })).collect();
        let expected: serde_json::Value = serde_json::from_slice(
            &std::fs::read(directory.join(format!("{corpus}.expected.json"))).unwrap(),
        )
        .unwrap();
        assert_eq!(serde_json::to_value(actual).unwrap(), expected);
        assert_eq!(loaded.registry.diagnostic_stats().2, 0);
    }
    let mut group = c.benchmark_group(format!("{corpus}/{variant}"));
    group
        .sample_size(40)
        .warm_up_time(Duration::from_millis(300))
        .measurement_time(Duration::from_secs(1))
        .nresamples(10_000);
    group.bench_function("construct", |b| {
        b.iter_batched(|| (), |()| black_box(input.load()), BatchSize::PerIteration)
    });
    group.bench_function("first_document", |b| {
        b.iter_batched(
            || (),
            |()| {
                let loaded = input.load();
                let result = input.tokenize(&loaded);
                black_box((loaded, result))
            },
            BatchSize::PerIteration,
        )
    });
    let loaded = input.load();
    for _ in 0..3 {
        black_box(input.tokenize(&loaded));
    }
    group.bench_function("warm_search", |b| {
        b.iter(|| black_box(input.tokenize(&loaded)))
    });
    group.finish();
}
fn config() -> Criterion {
    Criterion::default().output_directory(&PathBuf::from(std::env::var_os("OUTPUT").unwrap()))
}
criterion_group! {name=benches; config=config(); targets=bench}
criterion_main!(benches);
