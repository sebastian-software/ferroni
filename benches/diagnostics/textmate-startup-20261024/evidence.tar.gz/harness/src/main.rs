use serde_json::json;
use std::{hint::black_box, path::Path, time::Instant};
use textmate_source_comparison::Inputs;
fn main() {
    let args: Vec<_> = std::env::args().collect();
    let command = &args[1];
    let corpus = &args[2];
    let directory = Path::new(&args[3]);
    let variant = args.get(4).map_or("eager", String::as_str);
    let input = Inputs::read(directory, corpus, variant);
    #[cfg(feature = "profile")]
    if command == "profile" {
        let iterations = args.get(5).map_or(10, |x| x.parse::<usize>().unwrap());
        let expected: serde_json::Value = serde_json::from_slice(&std::fs::read(directory.join(format!("{corpus}.expected.json"))).unwrap()).unwrap();
        for repetition in 0..iterations {
            textmate_source_comparison::take_timings();
            let ((loaded, output), phases) = ferroni::scanner::load_profile::measure(|| {
                let loaded = input.load();
                let output = input.tokenize(&loaded);
                (loaded, output)
            });
            let actual: Vec<_> = output.iter().map(|(tokens, binary)| json!({
                "tokens": tokens.iter().map(|t| json!([t.start_index,t.end_index,t.scopes])).collect::<Vec<_>>(),
                "binary":binary,
            })).collect();
            assert_eq!(serde_json::to_value(actual).unwrap(), expected);
            assert_eq!(loaded.registry.diagnostic_stats().2, 0);
            println!("{}", json!({"corpus":corpus,"variant":variant,"repetition":repetition,
                "phases":phases.iter().map(|p|json!({"name":p.phase,"calls":p.calls,"inclusive_ns":p.inclusive_ns,"exclusive_ns":p.exclusive_ns})).collect::<Vec<_>>(),
                "transport_and_grammar":textmate_source_comparison::take_timings(),"stats":loaded.registry.diagnostic_stats()}));
        }
        return;
    }
    let start = Instant::now();
    let loaded = input.load();
    let load_ns = start.elapsed().as_nanos();
    let start = Instant::now();
    let output = input.tokenize(&loaded);
    let first_ns = start.elapsed().as_nanos();
    if command == "prepare" {
        // Exercise the fixed document repeatedly before exporting static scanner groups.
        for _ in 0..2 {
            assert_eq!(input.tokenize(&loaded), output);
        }
        let (programs, groups) = loaded.registry.diagnostic_export();
        std::fs::write(directory.join(format!("{corpus}.programs")), &programs).unwrap();
        std::fs::write(directory.join(format!("{corpus}.portable")), &groups).unwrap();
        let expected: Vec<_> = output.iter().map(|(tokens, binary)| json!({
            "tokens": tokens.iter().map(|t| json!([t.start_index,t.end_index,t.scopes])).collect::<Vec<_>>(),
            "binary":binary,
        })).collect();
        std::fs::write(
            directory.join(format!("{corpus}.expected.json")),
            serde_json::to_vec(&expected).unwrap(),
        )
        .unwrap();
        println!(
            "{}",
            json!({"corpus":corpus,"programBytes":programs.len(),"groupBytes":groups.len(),
            "stats":loaded.registry.diagnostic_stats(),"lines":output.len()})
        );
    } else {
        let expected: serde_json::Value = serde_json::from_slice(
            &std::fs::read(directory.join(format!("{corpus}.expected.json"))).unwrap(),
        )
        .unwrap();
        let actual: Vec<_> = output.iter().map(|(tokens, binary)| json!({
            "tokens": tokens.iter().map(|t| json!([t.start_index,t.end_index,t.scopes])).collect::<Vec<_>>(),
            "binary":binary,
        })).collect();
        assert_eq!(
            serde_json::to_value(actual).unwrap(),
            expected,
            "complete TextMate tokens differ"
        );
        for _ in 0..3 {
            assert_eq!(input.tokenize(&loaded), output);
        }
        println!(
            "{}",
            json!({"corpus":corpus,"variant":variant,"load_ns":load_ns,"first_search_ns":first_ns,
            "stats":loaded.registry.diagnostic_stats(),"lines":output.len(),"tokens":output.iter().map(|x| x.0.len()).sum::<usize>()})
        );
        black_box(loaded);
    }
}
