use ferriki_textmate::{
    Grammar, GrammarConfiguration, StateStack, SyncRegistry, Token, parse_raw_grammar,
};
use ferroni::AccelerationMode;
use serde_json::Value;
use sha2::{Digest, Sha256};
use std::{path::Path, rc::Rc, sync::Arc};

pub struct Asset {
    encoded: Vec<u8>,
    decoded_bytes: usize,
    encoded_hash: [u8; 32],
    decoded_hash: [u8; 32],
}
fn hash(value: &str) -> [u8; 32] {
    std::array::from_fn(|i| u8::from_str_radix(&value[i * 2..i * 2 + 2], 16).unwrap())
}
impl Asset {
    fn read(path: &Path, value: &Value, production: bool) -> Self {
        Self {
            encoded: std::fs::read(path).unwrap(),
            decoded_bytes: value[if production {
                "payloadBytes"
            } else {
                "decodedBytes"
            }]
            .as_u64()
            .unwrap() as usize,
            encoded_hash: hash(
                value[if production {
                    "compressedSha256"
                } else {
                    "encodedSha256"
                }]
                .as_str()
                .unwrap(),
            ),
            decoded_hash: hash(
                value[if production {
                    "payloadSha256"
                } else {
                    "decodedSha256"
                }]
                .as_str()
                .unwrap(),
            ),
        }
    }
    fn decode(&self) -> Vec<u8> {
        assert_eq!(
            timed("transport_encoded_hash", || <[u8; 32]>::from(Sha256::digest(&self.encoded))),
            self.encoded_hash
        );
        assert!(self.decoded_bytes <= 256 * 1024 * 1024);
        let mut decoder = zstd::bulk::Decompressor::new().unwrap();
        decoder
            .set_parameter(zstd::zstd_safe::DParameter::WindowLogMax(23))
            .unwrap();
        let decoded = timed("transport_decompress", || decoder.decompress(&self.encoded, self.decoded_bytes).unwrap());
        assert_eq!(decoded.len(), self.decoded_bytes);
        assert_eq!(
            timed("transport_decoded_hash", || <[u8; 32]>::from(Sha256::digest(&decoded))),
            self.decoded_hash
        );
        decoded
    }
}
pub struct Inputs {
    pub root: String,
    pub grammars: Vec<Asset>,
    pub injections: Vec<Vec<String>>,
    pub document: String,
    pub sidecar: Option<(Asset, usize)>,
    pub variant: String,
}
pub struct Loaded {
    pub registry: SyncRegistry,
    pub grammar: Rc<Grammar>,
}
pub type Output = Vec<(Vec<Token>, Vec<u32>)>;
impl Inputs {
    pub fn read(directory: &Path, corpus: &str, variant: &str) -> Self {
        let manifest: Value = serde_json::from_slice(
            &std::fs::read(directory.join(format!("{corpus}.json"))).unwrap(),
        )
        .unwrap();
        let prepared = variant == "portable";
        Self {
            root: manifest["rootScope"].as_str().unwrap().to_owned(),
            grammars: manifest["grammars"]
                .as_array()
                .unwrap()
                .iter()
                .map(|x| {
                    Asset::read(
                        &directory.join(format!("{}.zst", x["file"].as_str().unwrap())),
                        &x["transport"],
                        false,
                    )
                })
                .collect(),
            injections: manifest["grammars"]
                .as_array()
                .unwrap()
                .iter()
                .map(|x| {
                    x["injections"]
                        .as_array()
                        .unwrap()
                        .iter()
                        .map(|v| v.as_str().unwrap().to_owned())
                        .collect()
                })
                .collect(),
            document: std::fs::read_to_string(directory.join(format!("{corpus}.txt"))).unwrap(),
            sidecar: prepared.then(|| {
                let value: Value = serde_json::from_slice(
                    &std::fs::read(directory.join(format!("{corpus}.eager.json"))).unwrap(),
                )
                .unwrap();
                (
                    Asset::read(&directory.join(format!("{corpus}.eager.zst")), &value, true),
                    value["programBytes"].as_u64().unwrap() as usize,
                )
            }),
            variant: variant.to_owned(),
        }
    }
    pub fn load(&self) -> Loaded {
        let mut registry = timed("registry_new", || SyncRegistry::new(None, None).unwrap());
        let mode = if self.variant == "off" {
            AccelerationMode::Off
        } else {
            AccelerationMode::Eager
        };
        let (programs, groups) = if let Some((asset, program_bytes)) = &self.sidecar {
            let decoded = asset.decode();
            assert_eq!(
                u32::from_le_bytes(decoded[..4].try_into().unwrap()) as usize,
                *program_bytes
            );
            (
                Some(timed("program_copy", || Arc::<[u8]>::from(&decoded[4..4 + program_bytes]))),
                Some(timed("group_copy", || Arc::<[u8]>::from(&decoded[4 + program_bytes..]))),
            )
        } else {
            (None, None)
        };
        timed("archive_attach", || registry.diagnostic_cache(mode, programs, groups));
        for (source, injections) in self.grammars.iter().zip(&self.injections) {
            let decoded = source.decode();
            let raw =
                timed("grammar_parse", || parse_raw_grammar(std::str::from_utf8(&decoded).unwrap(), Some("grammar.json")).unwrap());
            timed("grammar_register", || registry.add_grammar(raw, injections.clone()));
        }
        let grammar = timed("grammar_construct", || registry
            .grammar_for_scope_name(
                &self.root,
                GrammarConfiguration::default().with_regex_prefilter(mode != AccelerationMode::Off),
            )
            .unwrap()
            .unwrap());
        Loaded { registry, grammar }
    }
    pub fn tokenize(&self, loaded: &Loaded) -> Output {
        let mut state: Option<Arc<StateStack>> = None;
        self.document
            .lines()
            .map(|line| {
                let result = loaded
                    .grammar
                    .tokenize_line_with_scopes(line, state.take(), 0)
                    .unwrap();
                assert!(!result.stopped_early);
                state = Some(result.rule_stack);
                (result.tokens, result.binary_tokens)
            })
            .collect()
    }
}

#[cfg(feature = "profile")]
thread_local! {
    static TIMINGS: std::cell::RefCell<std::collections::BTreeMap<&'static str, (u64,u128)>> = const { std::cell::RefCell::new(std::collections::BTreeMap::new()) };
}
fn timed<T>(_name: &'static str, run: impl FnOnce() -> T) -> T {
    #[cfg(feature = "profile")]
    let start = std::time::Instant::now();
    let result = run();
    #[cfg(feature = "profile")]
    TIMINGS.with_borrow_mut(|all| {
        let item = all.entry(_name).or_default();
        item.0 += 1;
        item.1 += start.elapsed().as_nanos();
    });
    result
}
#[cfg(feature = "profile")]
pub fn take_timings() -> std::collections::BTreeMap<&'static str, (u64,u128)> {
    TIMINGS.with_borrow_mut(std::mem::take)
}
