/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/

//! TextMate regular-expression sources compiled onto ferroni's Scanner API.

use std::array;
use std::collections::HashMap;
use std::fmt;
use std::sync::{Arc, Mutex, OnceLock};

use crate::RegexError;
use ferroni::backtrack_lint::BacktrackWarning as FerroniBacktrackWarning;
use ferroni::oniguruma::ONIG_OPTION_CAPTURE_GROUP;
pub(crate) use ferroni::scanner::{OnigString, ScannerFindOptions};
use ferroni::scanner::{
    Scanner, ScannerConfig, ScannerPatternCache as FerroniScannerPatternCache, ScannerSyntax,
};

/// Shared compiled patterns for the grammars owned by one registry.
///
/// Scanners holding an end or while pattern resolved from begin captures
/// intentionally bypass this cache: Ferroni keeps strong references until
/// `clear`, while vscode-textmate rebuilds and drops those scanners when
/// captured end or while patterns change. Static patterns that merely contain
/// a backreference to their own groups have fixed text and share the cache.
#[derive(Clone)]
pub(crate) struct ScannerPatternCache(
    Arc<Mutex<FerroniScannerPatternCache>>,
    ferroni::AccelerationMode,
);

impl Default for ScannerPatternCache {
    fn default() -> Self {
        Self::new()
    }
}

impl ScannerPatternCache {
    pub(crate) fn new() -> Self {
        Self(
            Arc::new(Mutex::new(FerroniScannerPatternCache::new())),
            ferroni::AccelerationMode::Auto,
        )
    }

    pub(crate) fn diagnostic(
        mode: ferroni::AccelerationMode,
        programs: Option<Arc<[u8]>>,
        groups: Option<Arc<[u8]>>,
    ) -> Self {
        let mut cache = FerroniScannerPatternCache::new();
        if let Some(bytes) = programs {
            cache.add_precompiled(ferroni::PrecompiledPatterns::from_bytes(bytes).unwrap());
        }
        if let Some(bytes) = groups {
            cache.add_group_prototype(bytes).unwrap();
        }
        Self(Arc::new(Mutex::new(cache)), mode)
    }
    pub(crate) fn diagnostic_export(&self) -> (Vec<u8>, Vec<u8>) {
        let cache = self.0.lock().unwrap();
        (
            cache.export_precompiled().unwrap(),
            cache
                .export_group_prototype(ferroni::scanner::group_prototype::GroupKind::Portable)
                .unwrap(),
        )
    }
    pub(crate) fn diagnostic_stats(&self) -> (usize, usize, usize) {
        let cache = self.0.lock().unwrap();
        let (loaded, fallback) = cache.group_prototype_load_stats();
        (cache.len(), loaded, fallback)
    }
    pub(crate) fn clear(&self) {
        self.0
            .lock()
            .expect("scanner pattern cache lock poisoned")
            .clear();
    }

    fn compile(
        &self,
        patterns: &[&str],
        config: &ScannerConfig,
        share_patterns: bool,
    ) -> Result<Scanner, ferroni::error::RegexError> {
        let config = config.clone().acceleration(self.1);
        if share_patterns {
            Scanner::with_pattern_cache(
                patterns,
                &config,
                &mut self.0.lock().expect("scanner pattern cache lock poisoned"),
            )
        } else {
            Scanner::with_config(patterns, &config)
        }
    }

    #[cfg(test)]
    pub(crate) fn len(&self) -> usize {
        self.0
            .lock()
            .expect("scanner pattern cache lock poisoned")
            .len()
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct CaptureIndex {
    pub(crate) start: usize,
    pub(crate) end: usize,
    pub(crate) length: usize,
}

#[cfg(test)]
std::thread_local! {
    // Count actual regex searches, including injections and capture retokenization.
    pub(crate) static SCANNER_CALL_COUNT: std::cell::Cell<usize> = const { std::cell::Cell::new(0) };
}

#[derive(Clone, Debug)]
struct AnchorCache {
    a0_g0: String,
    a0_g1: String,
    a1_g0: String,
    a1_g1: String,
}

#[derive(Clone, Debug)]
pub(crate) struct RegExpSource<T> {
    pub source: String,
    pub original_source: String,
    pub rule_id: T,
    pub has_anchor: bool,
    pub has_back_references: bool,
    anchor_cache: Option<AnchorCache>,
}

impl<T> RegExpSource<T> {
    #[must_use]
    pub(crate) fn new(reg_exp_source: impl Into<String>, rule_id: T) -> Self {
        let original_source = reg_exp_source.into();
        let (source, has_anchor) = rewrite_end_anchor(&original_source);
        let anchor_cache = has_anchor.then(|| build_anchor_cache(&source));
        let has_back_references = has_back_references(&source);
        Self {
            source,
            original_source,
            rule_id,
            has_anchor,
            has_back_references,
            anchor_cache,
        }
    }

    pub(crate) fn set_source(&mut self, new_source: impl Into<String>) {
        let new_source = new_source.into();
        if self.source == new_source {
            return;
        }
        self.source = new_source;
        if self.has_anchor {
            self.anchor_cache = Some(build_anchor_cache(&self.source));
        }
    }

    #[must_use]
    pub(crate) fn resolve_back_references(
        &self,
        line_text: &str,
        capture_indices: &[CaptureIndex],
    ) -> String {
        replace_numeric_back_references(&self.source, line_text, capture_indices)
    }

    /// Checks that a serialized dynamic pattern could only have been produced
    /// by replacing this source's numeric backreferences with escaped captures.
    ///
    /// Grammar-state snapshots are untrusted input. Accepting an arbitrary
    /// replacement here would let a caller supply executable regex syntax in
    /// place of the captured text, so matching is bounded by a fixed work
    /// budget and validates the exact escaping performed by the tokenizer.
    pub(crate) fn is_valid_back_reference_expansion(
        &self,
        candidate: &str,
        work: &mut usize,
    ) -> bool {
        let parts = split_back_reference_source(&self.source);
        let reference_count = parts
            .iter()
            .filter(|part| matches!(part, BackReferencePart::Capture))
            .count();
        if reference_count == 0 || reference_count > MAX_VALIDATION_BACKREFERENCES {
            return false;
        }
        let mut memo = HashMap::new();
        matches_back_reference_parts(&parts, candidate, 0, 0, &mut memo, work)
    }

    #[must_use]
    pub(crate) fn resolve_anchors(&self, allow_a: bool, allow_g: bool) -> &str {
        let Some(cache) = self.anchor_cache.as_ref() else {
            return &self.source;
        };
        match (allow_a, allow_g) {
            (false, false) => &cache.a0_g0,
            (false, true) => &cache.a0_g1,
            (true, false) => &cache.a1_g0,
            (true, true) => &cache.a1_g1,
        }
    }
}

const MAX_VALIDATION_BACKREFERENCES: usize = 256;
const MAX_BACK_REFERENCE_VALIDATION_WORK: usize = 100_000;

enum BackReferencePart<'a> {
    Literal(&'a str),
    Capture,
}

fn split_back_reference_source(source: &str) -> Vec<BackReferencePart<'_>> {
    let bytes = source.as_bytes();
    let mut parts = Vec::new();
    let mut position = 0;
    let mut last_pushed_position = 0;
    while position < bytes.len() {
        if bytes[position] == b'\\' && bytes.get(position + 1).is_some_and(u8::is_ascii_digit) {
            let mut digit_end = position + 2;
            while bytes.get(digit_end).is_some_and(u8::is_ascii_digit) {
                digit_end += 1;
            }
            parts.push(BackReferencePart::Literal(
                &source[last_pushed_position..position],
            ));
            parts.push(BackReferencePart::Capture);
            last_pushed_position = digit_end;
            position = digit_end;
        } else {
            position += 1;
        }
    }
    parts.push(BackReferencePart::Literal(&source[last_pushed_position..]));
    parts
}

fn matches_back_reference_parts(
    parts: &[BackReferencePart<'_>],
    candidate: &str,
    part_index: usize,
    byte_position: usize,
    memo: &mut HashMap<(usize, usize), bool>,
    work: &mut usize,
) -> bool {
    *work += 1;
    if *work > MAX_BACK_REFERENCE_VALIDATION_WORK {
        return false;
    }
    if let Some(result) = memo.get(&(part_index, byte_position)) {
        return *result;
    }
    let result = match parts.get(part_index) {
        None => byte_position == candidate.len(),
        Some(BackReferencePart::Literal(literal)) => {
            candidate
                .get(byte_position..)
                .is_some_and(|suffix| suffix.starts_with(literal))
                && matches_back_reference_parts(
                    parts,
                    candidate,
                    part_index + 1,
                    byte_position + literal.len(),
                    memo,
                    work,
                )
        }
        Some(BackReferencePart::Capture) => {
            let mut end = byte_position;
            loop {
                if matches_back_reference_parts(parts, candidate, part_index + 1, end, memo, work) {
                    break true;
                }
                let Some(next_end) = escaped_capture_character_end(candidate, end) else {
                    break false;
                };
                end = next_end;
                *work += 1;
                if *work > MAX_BACK_REFERENCE_VALIDATION_WORK {
                    break false;
                }
            }
        }
    };
    memo.insert((part_index, byte_position), result);
    result
}

fn escaped_capture_character_end(value: &str, byte_position: usize) -> Option<usize> {
    let character = value.get(byte_position..)?.chars().next()?;
    if character == '\\' {
        let next_position = byte_position + character.len_utf8();
        let escaped_character = value.get(next_position..)?.chars().next()?;
        return requires_regex_literal_escape(escaped_character)
            .then_some(next_position + escaped_character.len_utf8());
    }
    (!requires_regex_literal_escape(character)).then_some(byte_position + character.len_utf8())
}

fn requires_regex_literal_escape(character: char) -> bool {
    matches!(
        character,
        '-' | '\\'
            | '{'
            | '}'
            | '*'
            | '+'
            | '?'
            | '|'
            | '^'
            | '$'
            | '.'
            | ','
            | '['
            | ']'
            | '('
            | ')'
            | '#'
    ) || character.is_whitespace()
}

fn rewrite_end_anchor(source: &str) -> (String, bool) {
    let bytes = source.as_bytes();
    let mut position = 0;
    let mut last_pushed_position = 0;
    let mut output = String::new();
    let mut has_anchor = false;

    while position < bytes.len() {
        if bytes[position] == b'\\' && position + 1 < bytes.len() {
            let next = source[position + 1..]
                .chars()
                .next()
                .expect("backslash must have a following character");
            match next {
                'z' => {
                    output.push_str(&source[last_pushed_position..position]);
                    output.push_str("$(?!\\n)(?<!\\n)");
                    last_pushed_position = position + 1 + next.len_utf8();
                }
                'A' | 'G' => has_anchor = true,
                _ => {}
            }
            position += 1 + next.len_utf8();
        } else {
            position += source[position..]
                .chars()
                .next()
                .expect("position must be within source")
                .len_utf8();
        }
    }

    if last_pushed_position == 0 {
        (source.to_owned(), has_anchor)
    } else {
        output.push_str(&source[last_pushed_position..]);
        (output, has_anchor)
    }
}

fn build_anchor_cache(source: &str) -> AnchorCache {
    let mut variants = array::from_fn::<_, 4, _>(|_| String::with_capacity(source.len()));
    let bytes = source.as_bytes();
    let mut position = 0;

    while position < bytes.len() {
        if bytes[position] == b'\\' && position + 1 < bytes.len() {
            let next = source[position + 1..]
                .chars()
                .next()
                .expect("backslash must have a following character");
            for variant in &mut variants {
                variant.push('\\');
            }
            match next {
                'A' => {
                    variants[0].push('\u{ffff}');
                    variants[1].push('\u{ffff}');
                    variants[2].push('A');
                    variants[3].push('A');
                }
                'G' => {
                    variants[0].push('\u{ffff}');
                    variants[1].push('G');
                    variants[2].push('\u{ffff}');
                    variants[3].push('G');
                }
                _ => {
                    for variant in &mut variants {
                        variant.push(next);
                    }
                }
            }
            position += 1 + next.len_utf8();
            continue;
        }

        let remainder = &source[position..];
        let character = remainder
            .chars()
            .next()
            .expect("position must be within source");
        for variant in &mut variants {
            variant.push(character);
        }
        position += character.len_utf8();
    }

    let [a0_g0, a0_g1, a1_g0, a1_g1] = variants;
    AnchorCache {
        a0_g0,
        a0_g1,
        a1_g0,
        a1_g1,
    }
}

fn has_back_references(source: &str) -> bool {
    let bytes = source.as_bytes();
    bytes
        .windows(2)
        .any(|pair| pair[0] == b'\\' && pair[1].is_ascii_digit())
}

fn replace_numeric_back_references(
    source: &str,
    line_text: &str,
    capture_indices: &[CaptureIndex],
) -> String {
    let bytes = source.as_bytes();
    let mut result = String::with_capacity(source.len());
    let mut position = 0;
    let mut last_pushed_position = 0;

    while position < bytes.len() {
        if bytes[position] != b'\\'
            || bytes
                .get(position + 1)
                .is_none_or(|byte| !byte.is_ascii_digit())
        {
            position += 1;
            continue;
        }

        let digit_start = position + 1;
        let mut digit_end = digit_start + 1;
        while bytes.get(digit_end).is_some_and(u8::is_ascii_digit) {
            digit_end += 1;
        }
        let capture_index = source[digit_start..digit_end]
            .parse::<usize>()
            .expect("ASCII digits must parse as an index");
        let captured_value = capture_indices.get(capture_index).map_or("", |capture| {
            substring_utf16(line_text, capture.start, capture.end)
        });

        result.push_str(&source[last_pushed_position..position]);
        result.push_str(&escape_reg_exp_characters(captured_value));
        last_pushed_position = digit_end;
        position = digit_end;
    }
    result.push_str(&source[last_pushed_position..]);
    result
}

fn substring_utf16(value: &str, start: usize, end: usize) -> &str {
    let start = utf16_offset_to_utf8(value, start);
    let end = utf16_offset_to_utf8(value, end);
    &value[start.min(end)..end]
}

fn utf16_offset_to_utf8(value: &str, offset: usize) -> usize {
    let mut utf16_position = 0;
    for (byte_position, character) in value.char_indices() {
        if utf16_position >= offset {
            return byte_position;
        }
        utf16_position += character.len_utf16();
        if utf16_position > offset {
            return byte_position + character.len_utf8();
        }
    }
    value.len()
}

fn escape_reg_exp_characters(value: &str) -> String {
    let mut escaped = String::with_capacity(value.len());
    for character in value.chars() {
        if requires_regex_literal_escape(character) {
            escaped.push('\\');
        }
        escaped.push(character);
    }
    escaped
}

#[must_use]
pub(crate) fn has_captures(regex_source: Option<&str>) -> bool {
    let Some(source) = regex_source else {
        return false;
    };
    find_capture_placeholder(source, 0).is_some()
}

#[must_use]
pub(crate) fn replace_captures(
    regex_source: &str,
    capture_source: &str,
    capture_indices: &[CaptureIndex],
) -> String {
    let mut result = String::with_capacity(regex_source.len());
    let mut position = 0;
    while let Some(placeholder) = find_capture_placeholder(regex_source, position) {
        result.push_str(&regex_source[position..placeholder.start]);
        let Some(capture) = capture_indices.get(placeholder.index) else {
            result.push_str(&regex_source[placeholder.start..placeholder.end]);
            position = placeholder.end;
            continue;
        };

        let captured =
            substring_utf16(capture_source, capture.start, capture.end).trim_start_matches('.');
        match placeholder.command {
            Some(CaptureCommand::Downcase) => result.push_str(&captured.to_lowercase()),
            Some(CaptureCommand::Upcase) => result.push_str(&captured.to_uppercase()),
            None => result.push_str(captured),
        }
        position = placeholder.end;
    }
    result.push_str(&regex_source[position..]);
    result
}

#[derive(Clone, Copy)]
enum CaptureCommand {
    Downcase,
    Upcase,
}

struct CapturePlaceholder {
    start: usize,
    end: usize,
    index: usize,
    command: Option<CaptureCommand>,
}

fn find_capture_placeholder(source: &str, from: usize) -> Option<CapturePlaceholder> {
    let bytes = source.as_bytes();
    let mut position = from;
    while position < bytes.len() {
        if bytes[position] != b'$' {
            position += 1;
            continue;
        }

        if bytes.get(position + 1).is_some_and(u8::is_ascii_digit) {
            let digit_start = position + 1;
            let mut end = digit_start + 1;
            while bytes.get(end).is_some_and(u8::is_ascii_digit) {
                end += 1;
            }
            return Some(CapturePlaceholder {
                start: position,
                end,
                index: source[digit_start..end].parse().ok()?,
                command: None,
            });
        }

        if bytes.get(position + 1) == Some(&b'{') {
            let digit_start = position + 2;
            let mut digit_end = digit_start;
            while bytes.get(digit_end).is_some_and(u8::is_ascii_digit) {
                digit_end += 1;
            }
            if digit_end == digit_start || source.get(digit_end..digit_end + 2) != Some(":/") {
                position += 1;
                continue;
            }

            let command_start = digit_end + 2;
            let (command, command_length) =
                if source.get(command_start..command_start + 8) == Some("downcase") {
                    (CaptureCommand::Downcase, 8)
                } else if source.get(command_start..command_start + 6) == Some("upcase") {
                    (CaptureCommand::Upcase, 6)
                } else {
                    position += 1;
                    continue;
                };
            let end = command_start + command_length + 1;
            if bytes.get(end - 1) != Some(&b'}') {
                position += 1;
                continue;
            }
            return Some(CapturePlaceholder {
                start: position,
                end,
                index: source[digit_start..digit_end].parse().ok()?,
                command: Some(command),
            });
        }
        position += 1;
    }
    None
}

pub(crate) struct RegExpSourceList<T> {
    items: Vec<RegExpSource<T>>,
    has_anchors: bool,
    cached: Option<Arc<CompiledRule<T>>>,
    anchor_cache: [Option<Arc<CompiledRule<T>>>; 4],
    regex_prefilter: bool,
    scanner_pattern_cache: ScannerPatternCache,
    /// Set once a source was replaced at runtime. Only resolved end and while
    /// patterns are replaced, so the list's text is no longer static.
    has_resolved_sources: bool,
}

impl<T> Default for RegExpSourceList<T> {
    fn default() -> Self {
        Self::new()
    }
}

impl<T> RegExpSourceList<T> {
    #[must_use]
    pub(crate) fn new() -> Self {
        Self::with_regex_prefilter(true)
    }

    pub(crate) fn with_regex_prefilter(regex_prefilter: bool) -> Self {
        Self::with_pattern_cache(regex_prefilter, ScannerPatternCache::new())
    }

    pub(crate) fn with_pattern_cache(
        regex_prefilter: bool,
        scanner_pattern_cache: ScannerPatternCache,
    ) -> Self {
        Self {
            items: Vec::new(),
            has_anchors: false,
            cached: None,
            anchor_cache: array::from_fn(|_| None),
            regex_prefilter,
            scanner_pattern_cache,
            has_resolved_sources: false,
        }
    }

    #[allow(
        dead_code,
        reason = "part of the vscode-textmate port, kept for upstream parity"
    )]
    pub(crate) fn dispose(&mut self) {
        self.dispose_caches();
    }

    fn dispose_caches(&mut self) {
        self.cached = None;
        self.anchor_cache = array::from_fn(|_| None);
    }

    pub(crate) fn push(&mut self, item: RegExpSource<T>) {
        self.has_anchors |= item.has_anchor;
        self.items.push(item);
    }

    pub(crate) fn unshift(&mut self, item: RegExpSource<T>) {
        self.has_anchors |= item.has_anchor;
        self.items.insert(0, item);
    }

    #[must_use]
    pub(crate) fn len(&self) -> usize {
        self.items.len()
    }

    #[must_use]
    #[allow(
        dead_code,
        reason = "part of the vscode-textmate port, kept for upstream parity"
    )]
    pub(crate) fn is_empty(&self) -> bool {
        self.items.is_empty()
    }

    pub(crate) fn set_source(&mut self, index: usize, new_source: impl Into<String>) {
        let new_source = new_source.into();
        self.has_resolved_sources = true;
        if self.items[index].source != new_source {
            self.dispose_caches();
            self.items[index].set_source(new_source);
        }
    }
}

impl<T: Copy> RegExpSourceList<T> {
    pub(crate) fn compile(&mut self) -> Result<Arc<CompiledRule<T>>, RegexError> {
        if let Some(cached) = self.cached.as_ref() {
            return Ok(Arc::clone(cached));
        }
        let compiled = Arc::new(CompiledRule::new(
            self.items.iter().map(|item| item.source.clone()).collect(),
            self.items
                .iter()
                .map(|item| item.original_source.as_str())
                .collect::<Vec<_>>(),
            self.items.iter().map(|item| item.rule_id).collect(),
            self.regex_prefilter,
            &self.scanner_pattern_cache,
            !self.has_resolved_sources,
        )?);
        self.cached = Some(Arc::clone(&compiled));
        Ok(compiled)
    }

    pub(crate) fn compile_ag(
        &mut self,
        allow_a: bool,
        allow_g: bool,
    ) -> Result<Arc<CompiledRule<T>>, RegexError> {
        if !self.has_anchors {
            return self.compile();
        }

        let cache_index = usize::from(allow_a) * 2 + usize::from(allow_g);
        if let Some(cached) = self.anchor_cache[cache_index].as_ref() {
            return Ok(Arc::clone(cached));
        }
        let compiled = Arc::new(CompiledRule::new(
            self.items
                .iter()
                .map(|item| item.resolve_anchors(allow_a, allow_g).to_owned())
                .collect(),
            self.items
                .iter()
                .map(|item| item.original_source.as_str())
                .collect(),
            self.items.iter().map(|item| item.rule_id).collect(),
            self.regex_prefilter,
            &self.scanner_pattern_cache,
            !self.has_resolved_sources,
        )?);
        self.anchor_cache[cache_index] = Some(Arc::clone(&compiled));
        Ok(compiled)
    }
}

pub(crate) struct CompiledRule<T> {
    scanner: Mutex<Scanner>,
    reg_exps: Vec<String>,
    rules: Vec<T>,
    backtracking_warnings: Vec<CompiledBacktrackingWarning<T>>,
    backtracking_warnings_recorded: OnceLock<()>,
}

struct CompiledBacktrackingWarning<T> {
    rule: T,
    pattern: String,
    warning: FerroniBacktrackWarning,
}

impl<T: Copy> CompiledRule<T> {
    fn new(
        reg_exps: Vec<String>,
        original_patterns: Vec<&str>,
        rules: Vec<T>,
        regex_prefilter: bool,
        pattern_cache: &ScannerPatternCache,
        share_patterns: bool,
    ) -> Result<Self, RegexError> {
        let compiled_reg_exps: Vec<_> = reg_exps
            .iter()
            .map(|pattern| normalize_ferroni_pattern(pattern))
            .collect();
        let scanner_reg_exps: Vec<_> = compiled_reg_exps.iter().map(String::as_str).collect();
        // vscode-oniguruma compiles scanner patterns with CAPTURE_GROUP by
        // default, so unnamed groups keep capturing next to named ones and
        // numbered backreferences stay valid in patterns with named groups.
        let config = ScannerConfig::default()
            .options(ONIG_OPTION_CAPTURE_GROUP)
            .syntax(ScannerSyntax::Oniguruma)
            .prefilter(regex_prefilter);
        let scanner = pattern_cache
            .compile(&scanner_reg_exps, &config, share_patterns)
            .map_err(RegexError::new)?;
        let mut backtracking_warnings = Vec::new();
        for (index, warnings) in scanner.warnings().iter().enumerate() {
            for warning in warnings {
                backtracking_warnings.push(CompiledBacktrackingWarning {
                    rule: rules[index],
                    pattern: original_patterns[index].to_owned(),
                    warning: warning.clone(),
                });
            }
        }
        Ok(Self {
            scanner: Mutex::new(scanner),
            reg_exps,
            rules,
            backtracking_warnings,
            backtracking_warnings_recorded: OnceLock::new(),
        })
    }

    pub(crate) fn record_backtracking_warnings_once(
        &self,
        mut visit: impl FnMut(T, &str, &FerroniBacktrackWarning),
    ) {
        if self.backtracking_warnings.is_empty() {
            return;
        }
        self.backtracking_warnings_recorded.get_or_init(|| {
            for finding in &self.backtracking_warnings {
                visit(finding.rule, &finding.pattern, &finding.warning);
            }
        });
    }

    #[must_use]
    pub(crate) fn find_next_match(
        &self,
        string: &OnigString,
        start_position: usize,
        options: ScannerFindOptions,
    ) -> Option<FindNextMatchResult<T>> {
        #[cfg(test)]
        SCANNER_CALL_COUNT.with(|count| count.set(count.get() + 1));
        let matched = self
            .scanner
            .lock()
            .expect("compiled scanner lock poisoned")
            .find_next_match_utf16(string, start_position, options)?;

        // Ferroni reports line-guard matches at the synthetic end position
        // used by TextMate's line scanner. These guards are valid at the
        // logical line start, but not after the line terminator. Keep the
        // TextMate distinction here rather than weakening shared Scanner
        // semantics for regular expression consumers.
        let pattern = self.reg_exps[matched.index].trim();
        if matched.captures()[0].start == string.utf16_len()
            && (pattern == "^$"
                || (start_position < string.utf16_len() && rejects_artificial_end(pattern)))
        {
            return None;
        }

        Some(FindNextMatchResult {
            rule_id: self.rules[matched.index],
            capture_indices: matched
                .into_captures()
                .into_iter()
                .map(|capture| CaptureIndex {
                    start: capture.start,
                    end: capture.end,
                    length: capture.length,
                })
                .collect(),
        })
    }
}

fn normalize_ferroni_pattern(pattern: &str) -> String {
    let mut result = String::with_capacity(pattern.len());
    let bytes = pattern.as_bytes();
    let mut position = 0;
    let mut in_character_class = false;

    while position < bytes.len() {
        if bytes[position] == b'\\' {
            result.push('\\');
            position += 1;
            if let Some(character) = pattern[position..].chars().next() {
                result.push(character);
                position += character.len_utf8();
            }
            continue;
        }
        match bytes[position] {
            b'[' => in_character_class = true,
            b']' => in_character_class = false,
            b'{' if !in_character_class
                && !starts_valid_interval(&pattern[position..])
                && !starts_special_brace_expression(pattern, position) =>
            {
                result.push('\\');
            }
            _ => {}
        }
        let character = pattern[position..]
            .chars()
            .next()
            .expect("pattern position must be on a character boundary");
        result.push(character);
        position += character.len_utf8();
    }
    result
}

fn rejects_artificial_end(pattern: &str) -> bool {
    pattern == "$"
        || pattern.starts_with("^\\s*")
        || pattern.starts_with("^(?!")
        || pattern.starts_with("(^|\\G)(?!")
}

fn starts_valid_interval(value: &str) -> bool {
    let bytes = value.as_bytes();
    let mut position = 1;
    let first_digits = take_ascii_digits(bytes, &mut position);
    if bytes.get(position) == Some(&b'}') {
        return first_digits;
    }
    if bytes.get(position) != Some(&b',') {
        return false;
    }
    position += 1;
    let second_digits = take_ascii_digits(bytes, &mut position);
    bytes.get(position) == Some(&b'}') && (first_digits || second_digits)
}

fn take_ascii_digits(bytes: &[u8], position: &mut usize) -> bool {
    let start = *position;
    while bytes.get(*position).is_some_and(u8::is_ascii_digit) {
        *position += 1;
    }
    *position != start
}

fn starts_special_brace_expression(pattern: &str, position: usize) -> bool {
    pattern.get(..position).is_some_and(|prefix| {
        ["\\p", "\\P", "\\x", "\\o", "(?"]
            .iter()
            .any(|marker| prefix.ends_with(marker))
    })
}

impl<T: fmt::Debug> fmt::Display for CompiledRule<T> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        for (index, (rule, source)) in self.rules.iter().zip(&self.reg_exps).enumerate() {
            if index != 0 {
                formatter.write_str("\n")?;
            }
            write!(formatter, "   - {rule:?}: {source}")?;
        }
        Ok(())
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub(crate) struct FindNextMatchResult<T> {
    pub rule_id: T,
    pub capture_indices: Vec<CaptureIndex>,
}

#[cfg(test)]
mod tests {
    use std::sync::Arc;

    use super::{
        CaptureIndex, OnigString, RegExpSource, RegExpSourceList, ScannerFindOptions,
        ScannerPatternCache, has_captures, normalize_ferroni_pattern, replace_captures,
    };

    #[test]
    fn rewrites_end_anchor_and_resolves_a_and_g_anchors() {
        let source = RegExpSource::new(r"\Afoo\Gbar\z", 1_u32);

        assert_eq!(source.source, "\\Afoo\\Gbar$(?!\\n)(?<!\\n)");
        assert!(source.has_anchor);
        assert_eq!(
            source.resolve_anchors(false, false),
            "\\\u{ffff}foo\\\u{ffff}bar$(?!\\n)(?<!\\n)"
        );
        assert_eq!(
            source.resolve_anchors(false, true),
            "\\\u{ffff}foo\\Gbar$(?!\\n)(?<!\\n)"
        );
        assert_eq!(
            source.resolve_anchors(true, false),
            "\\Afoo\\\u{ffff}bar$(?!\\n)(?<!\\n)"
        );
        assert_eq!(
            source.resolve_anchors(true, true),
            "\\Afoo\\Gbar$(?!\\n)(?<!\\n)"
        );

        let unicode_escape = RegExpSource::new("\\é\\A", 2_u32);
        assert_eq!(unicode_escape.resolve_anchors(true, false), "\\é\\A");
    }

    #[test]
    fn shared_pattern_cache_keeps_anchor_variants_distinct_and_reuses_them() {
        let cache = ScannerPatternCache::new();
        for _ in 0..2 {
            for (allow_a, allow_g) in [(false, false), (false, true), (true, false), (true, true)] {
                let mut sources = RegExpSourceList::with_pattern_cache(true, cache.clone());
                sources.push(RegExpSource::new(r"\Afoo\Gbar", 1_u32));
                sources.compile_ag(allow_a, allow_g).unwrap();
            }
        }

        assert_eq!(cache.len(), 4);
    }

    #[test]
    fn resolves_and_escapes_numeric_back_references() {
        let source = RegExpSource::new(r"end-\1-\12", 1_u32);
        let line = "💻 a.b";
        let captures = vec![
            CaptureIndex {
                start: 0,
                end: 6,
                length: 6,
            },
            CaptureIndex {
                start: 3,
                end: 6,
                length: 3,
            },
        ];

        assert!(source.has_back_references);
        assert_eq!(
            source.resolve_back_references(line, &captures),
            r"end-a\.b-"
        );
        let mut work = 0;
        assert!(source.is_valid_back_reference_expansion(r"end-a\.b-", &mut work));
        let mut work = 0;
        assert!(!source.is_valid_back_reference_expansion(r"end-a.*-", &mut work));
        let mut work = 0;
        assert!(!source.is_valid_back_reference_expansion(r"end-a\q-", &mut work));
    }

    #[test]
    fn validates_only_bounded_escaped_backreference_expansions() {
        let source = RegExpSource::new(r"begin-\1-middle-\2-end", 1_u32);
        let mut work = 0;
        assert!(source.is_valid_back_reference_expansion(r"begin-a\.b-middle-x\*y-end", &mut work));
        let mut work = 0;
        assert!(!source.is_valid_back_reference_expansion(r"begin-a.*-middle-x-end", &mut work));

        let too_many_backreferences = RegExpSource::new(r"\1".repeat(257), 2_u32);
        let mut work = 0;
        assert!(!too_many_backreferences.is_valid_back_reference_expansion("", &mut work));
    }

    #[test]
    fn enforces_backreference_validation_budget_across_frames() {
        let source = RegExpSource::new(r"\1", 1_u32);
        let pattern = "a".repeat(15_000);
        let mut work = 0;
        assert!(source.is_valid_back_reference_expansion(&pattern, &mut work));
        assert!(source.is_valid_back_reference_expansion(&pattern, &mut work));
        assert!(!source.is_valid_back_reference_expansion(&pattern, &mut work));
    }

    #[test]
    fn replaces_name_capture_placeholders() {
        let capture = CaptureIndex {
            start: 0,
            end: 8,
            length: 8,
        };
        assert!(has_captures(Some("entity.${0:/downcase}.$0.${0:/upcase}")));
        assert!(!has_captures(Some("entity.name")));
        assert_eq!(
            replace_captures(
                "entity.${0:/downcase}.$0.${0:/upcase}",
                ".Foo.Bar",
                &[capture]
            ),
            "entity.foo.bar.Foo.Bar.FOO.BAR"
        );
    }

    #[test]
    fn compiles_scanner_patterns_with_utf16_offsets_and_rule_priority() {
        let mut sources = RegExpSourceList::new();
        sources.push(RegExpSource::new("Y", 10_u32));
        sources.push(RegExpSource::new("X", 20_u32));
        let compiled = sources.compile().unwrap();
        let line = OnigString::new("a💻bYX");

        let result = compiled
            .find_next_match(&line, 0, ScannerFindOptions::NONE)
            .unwrap();
        assert_eq!(result.rule_id, 10);
        assert_eq!(result.capture_indices[0].start, 4);
        assert_eq!(result.capture_indices[0].end, 5);
    }

    #[test]
    fn preserves_unmatched_alternative_capture_groups() {
        let line = OnigString::new(r#"<h1 v-if="condition">"#);
        let pattern = r"(?:(v-for)|(v-(?:if|else-if|else)))(?=[)/=>\s])";

        let mut sources = RegExpSourceList::new();
        sources.push(RegExpSource::new(r"(?=/>)|(>)", 0_u32));
        sources.push(RegExpSource::new(pattern, 1_u32));
        sources.push(RegExpSource::new(r"[^>\s]+", 2_u32));
        let compiled = sources.compile().unwrap();

        let result = compiled
            .find_next_match(&line, 3, ScannerFindOptions::NONE)
            .unwrap();

        assert_eq!(result.rule_id, 1);
        assert_eq!(
            result.capture_indices,
            [
                CaptureIndex {
                    start: 4,
                    end: 8,
                    length: 4,
                },
                CaptureIndex {
                    start: 0,
                    end: 0,
                    length: 0,
                },
                CaptureIndex {
                    start: 4,
                    end: 8,
                    length: 4,
                },
            ]
        );
    }

    #[test]
    fn scanner_finds_later_anchored_patterns_after_earlier_misses() {
        let line = OnigString::new(" ok, cool\n");
        for pattern in [
            r"^ ",
            r"^[ \t]*",
            r"^[ \t]*(?=\S)",
            r"^([ \t]*)",
            r"^([ \t]*)(?=\S)",
        ] {
            let mut single_source = RegExpSourceList::new();
            single_source.push(RegExpSource::new(pattern, 2_u32));
            let single_scanner = single_source.compile().unwrap();
            assert!(
                single_scanner
                    .find_next_match(&line, 0, ScannerFindOptions::NONE)
                    .is_some(),
                "pattern {pattern:?} should match"
            );
        }

        let mut sources = RegExpSourceList::new();
        sources.push(RegExpSource::new(r"^\s*(•).*$\n?", 1_u32));
        sources.push(RegExpSource::new(r"^([ \t]*)(?=\S)", 2_u32));
        let scanner = sources.compile().unwrap();

        let result = scanner
            .find_next_match(&line, 0, ScannerFindOptions::NONE)
            .unwrap();

        assert_eq!(result.rule_id, 2);
        assert_eq!(result.capture_indices[0].start, 0);
        assert_eq!(result.capture_indices[0].end, 1);
    }

    #[test]
    fn preserves_captures_in_extended_patterns_with_look_behind() {
        let pattern = r"(?x)
            ( (https?|s?ftp|ftps|file|smb|afp|nfs|(x-)?man(-page)?|gopher|txmt|issue)://|mailto:)
            [-:@a-zA-Z0-9_.,~%+/?=&#;]+(?<![-.,?:#;])
        ";
        let mut sources = RegExpSourceList::new();
        sources.push(RegExpSource::new(pattern, 1_u32));
        let scanner = sources.compile().unwrap();

        let result = scanner
            .find_next_match(
                &OnigString::new("https://github.com\n"),
                0,
                ScannerFindOptions::NONE,
            )
            .unwrap();

        assert_eq!(result.capture_indices[2].start, 0);
        assert_eq!(result.capture_indices[2].end, 5);
    }

    #[test]
    fn preserves_captures_after_named_recursive_groups() {
        let pattern = r"(?x)
            (?<ft>
                map\s*<\s*\g<ft>\s*,\s*\g<ft>\s*> |
                set\s*<\s*\g<ft>\s*> |
                list\s*<\s*\g<ft>\s*>\s*(cpp_type(?!\S))? |
                [a-zA-Z_][\w.]*
            )[ \t]*
            (?:([a-zA-Z_][\w.]*)[ \t]*)?
        ";
        let mut sources = RegExpSourceList::new();
        sources.push(RegExpSource::new(pattern, 1_u32));
        let scanner = sources.compile().unwrap();

        let result = scanner
            .find_next_match(
                &OnigString::new("string message\n"),
                0,
                ScannerFindOptions::NONE,
            )
            .unwrap();

        assert_eq!(result.capture_indices[1].start, 0);
        assert_eq!(result.capture_indices[1].end, 6);
        assert_eq!(result.capture_indices[3].start, 7);
        assert_eq!(result.capture_indices[3].end, 14);
    }

    #[test]
    fn keeps_unnamed_groups_capturing_next_to_named_groups() {
        // Go's function-call rule: without CAPTURE_GROUP the unnamed
        // alternatives stop capturing and `Println` loses its scope.
        let pattern = r"(?:((?<=\.)\b\w+)|\b(\w+))(?<brackets>\[(?:[^]\[]|\g<brackets>)*])?(?=\()";
        let mut sources = RegExpSourceList::new();
        sources.push(RegExpSource::new(pattern, 1_u32));
        let scanner = sources.compile().unwrap();

        let result = scanner
            .find_next_match(
                &OnigString::new("\tfmt.Println(\"Hello\")\n"),
                5,
                ScannerFindOptions::NONE,
            )
            .unwrap();

        assert_eq!(result.capture_indices.len(), 4);
        assert_eq!(result.capture_indices[0].start, 5);
        assert_eq!(result.capture_indices[0].end, 12);
        assert_eq!(result.capture_indices[1].start, 5);
        assert_eq!(result.capture_indices[1].end, 12);
    }

    #[test]
    fn matches_any_char_star_from_a_mid_line_position() {
        // Svelte retokenizes captures on a line prefix and resumes mid-line;
        // a leading `.*` must still match at the resume position.
        let mut sources = RegExpSourceList::new();
        sources.push(RegExpSource::new("--.*", 1_u32));
        sources.push(RegExpSource::new(".*", 2_u32));
        let scanner = sources.compile().unwrap();

        let result = scanner
            .find_next_match(&OnigString::new("<div class"), 5, ScannerFindOptions::NONE)
            .unwrap();

        assert_eq!(result.rule_id, 2);
        assert_eq!(result.capture_indices[0].start, 5);
        assert_eq!(result.capture_indices[0].end, 10);
    }

    #[test]
    fn supports_numbered_backrefs_alongside_named_groups() {
        let pattern = r"(?<word>a)(b)\2";
        assert!(ferroni::api::Regex::new(pattern).is_err());
        let mut sources = RegExpSourceList::new();
        sources.push(RegExpSource::new(pattern, 1_u32));
        let scanner = sources.compile().unwrap();

        let result = scanner
            .find_next_match(&OnigString::new("abb\n"), 0, ScannerFindOptions::NONE)
            .unwrap();

        assert_eq!(result.capture_indices[0].start, 0);
        assert_eq!(result.capture_indices[0].end, 3);
        assert_eq!(result.capture_indices[2].start, 1);
        assert_eq!(result.capture_indices[2].end, 2);
    }

    #[test]
    fn distinguishes_end_anchor_from_empty_line_anchor_at_artificial_eol() {
        let line = OnigString::new("\n");
        let mut end_sources = RegExpSourceList::new();
        end_sources.push(RegExpSource::new("$", 1_u32));
        assert!(
            end_sources
                .compile()
                .unwrap()
                .find_next_match(&line, 1, ScannerFindOptions::NONE)
                .is_some()
        );

        let mut empty_line_sources = RegExpSourceList::new();
        empty_line_sources.push(RegExpSource::new("^$", 1_u32));
        assert!(
            empty_line_sources
                .compile()
                .unwrap()
                .find_next_match(&line, 1, ScannerFindOptions::NONE)
                .is_none()
        );
    }

    #[test]
    fn escapes_invalid_interval_braces_for_ferroni() {
        assert_eq!(
            normalize_ferroni_pattern(r"(:)\s*(?!(\s*{))"),
            r"(:)\s*(?!(\s*\{))"
        );
        for pattern in [
            r"a{1}",
            r"a{1,}",
            r"a{1,3}",
            r"a{,3}",
            r"\p{Greek}",
            r"\x{20}",
            r"[{}]",
            r"(?{callout})",
        ] {
            assert_eq!(normalize_ferroni_pattern(pattern), pattern);
        }
    }

    #[test]
    fn disabling_prefilter_preserves_captures_after_warmup_and_anchor_compilation() {
        for anchors in [None, Some((true, true)), Some((true, false))] {
            let make_scanner = |enabled| {
                let mut sources = RegExpSourceList::with_regex_prefilter(enabled);
                for index in 0..32_u32 {
                    sources.push(RegExpSource::new(
                        format!(r"\A(keyword{index})_[a-z]+"),
                        index,
                    ));
                }
                match anchors {
                    None => sources.compile(),
                    Some((allow_a, allow_g)) => sources.compile_ag(allow_a, allow_g),
                }
                .unwrap()
            };
            let enabled = make_scanner(true);
            let disabled = make_scanner(false);
            let line = OnigString::new("keyword19_value");
            for _ in 0..64 {
                let expected = enabled
                    .find_next_match(&line, 0, ScannerFindOptions::NONE)
                    .unwrap();
                let actual = disabled
                    .find_next_match(&line, 0, ScannerFindOptions::NONE)
                    .unwrap();
                assert_eq!(actual.rule_id, expected.rule_id);
                assert_eq!(actual.capture_indices, expected.capture_indices);
            }
            assert!(enabled.scanner.lock().unwrap().prefilter_stats().built);
            let stats = disabled.scanner.lock().unwrap().prefilter_stats();
            assert!(!stats.built);
            assert_eq!(stats.covered, 0);
        }
    }

    #[test]
    fn invalidates_compiled_scanner_when_a_source_changes() {
        let mut sources = RegExpSourceList::new();
        sources.push(RegExpSource::new("a", 1_u32));
        let first = sources.compile().unwrap();
        assert!(Arc::ptr_eq(&first, &sources.compile().unwrap()));

        sources.set_source(0, "b");
        let second = sources.compile().unwrap();
        assert!(!Arc::ptr_eq(&first, &second));
        let line = OnigString::new("b");
        assert_eq!(
            second
                .find_next_match(&line, 0, ScannerFindOptions::NONE)
                .unwrap()
                .rule_id,
            1
        );
    }

    #[test]
    fn forwards_find_options_and_supports_anchor_rewriting_fallback() {
        let line = OnigString::new("foo");
        let mut sources = RegExpSourceList::new();
        sources.push(RegExpSource::new(r"\Afoo", 1_u32));

        let compiled = sources.compile().unwrap();
        assert!(
            compiled
                .find_next_match(&line, 0, ScannerFindOptions::NONE)
                .is_some()
        );
        assert!(
            compiled
                .find_next_match(&line, 0, ScannerFindOptions::NOT_BEGIN_STRING)
                .is_none()
        );

        assert!(
            sources
                .compile_ag(false, false)
                .unwrap()
                .find_next_match(&line, 0, ScannerFindOptions::NONE)
                .is_none()
        );
        assert!(
            sources
                .compile_ag(true, false)
                .unwrap()
                .find_next_match(&line, 0, ScannerFindOptions::NONE)
                .is_some()
        );
    }
}
