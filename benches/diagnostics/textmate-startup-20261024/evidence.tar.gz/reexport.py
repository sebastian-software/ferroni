import json, shutil, subprocess
from pathlib import Path
root=Path(__file__).resolve().parent
source=root/'inputs-shuffled'
output=root/'reexport'
shutil.copytree(source,output)
records=[]
for case in ['cpp','scss','java','json','rust','html','astro','tsx','c','php']:
    result=subprocess.run([str(root/'bin/driver-after'),'prepare',case,str(output),'portable'],capture_output=True,text=True,check=True)
    row={'corpus':case,'result':json.loads(result.stdout),'identical':{suffix:(output/f'{case}.{suffix}').read_bytes()==(source/f'{case}.{suffix}').read_bytes() for suffix in ['programs','portable','expected.json']}}
    records.append(row)
    print(case,row['identical'],flush=True)
(root/'reexport-validation.json').write_text(json.dumps(records,indent=2)+'\n')
assert all(all(row['identical'].values()) for row in records)
