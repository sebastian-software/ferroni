import json
import statistics
from pathlib import Path

root = Path(__file__).resolve().parent
frozen = root.parent / 'textmate-source-off-20261024'
cases = ['cpp', 'scss', 'java', 'json', 'rust', 'html', 'astro', 'tsx', 'c', 'php']
labels = dict(zip(cases, ['C++', 'SCSS', 'Java', 'JSON', 'Rust', 'HTML', 'Astro', 'TSX', 'C', 'PHP']))
validation = json.loads((root / 'validation.json').read_text())
assert len(validation) == 30
assert all(row['stats'][2] == 0 for row in validation)
verified = json.loads((root / 'verified-after-run.json').read_text())
assert all(verified[k] for k in ['sourcesUnchanged', 'inputsUnchanged', 'binariesUnchanged'])

rows = []
for case in cases:
    row = {'corpus': case, 'label': labels[case], 'metrics': {}}
    for metric in ['construct', 'first_document', 'warm_search']:
        result = {}
        for variant in ['before', 'after']:
            estimates = []
            for repetition in range(1, 4):
                path = root / 'criterion' / f'r{repetition}-{case}-{variant}' / f'{case}_portable' / metric / 'new/estimates.json'
                estimates.append(json.loads(path.read_text())['mean']['point_estimate'] / 1_000_000)
            result[variant] = {'medianProcessMeanMs': statistics.median(estimates), 'processMeansMs': estimates}
        paired = [100 * (after / before - 1) for before, after in zip(result['before']['processMeansMs'], result['after']['processMeansMs'])]
        result['pairedPercentChange'] = paired
        result['medianPairedPercentChange'] = statistics.median(paired)
        result['medianTimePercentChange'] = 100 * (result['after']['medianProcessMeanMs'] / result['before']['medianProcessMeanMs'] - 1)
        result['allRunsAtLeastThreePercentFaster'] = all(change <= -3 for change in paired)
        row['metrics'][metric] = result
    row['packages'] = {}
    for variant, directory in [('before', frozen / 'inputs'), ('after', root / 'inputs-shuffled')]:
        manifest = json.loads((directory / f'{case}.eager.json').read_text())
        workload = json.loads((directory / f'{case}.json').read_text())
        grammar_bytes = sum(asset['transport']['encodedBytes'] for asset in workload['grammars'])
        row['packages'][variant] = {
            'payloadBytes': manifest['payloadBytes'],
            'preparedZstdBytes': manifest['compressedBytes'],
            'grammarZstdBytes': grammar_bytes,
            'totalDownloadBytes': grammar_bytes + manifest['compressedBytes'],
        }
    row['peakRssBytes'] = {variant: next(v['peakRssBytes'] for v in validation if v['corpus'] == case and v['build'] == variant)
                           for variant in ['before', 'after']}
    rows.append(row)

summary = {
    'baseline': 'Merged main ae9d1c155c5f39347ae46409094f83234539a260, FPRT002 archives',
    'candidate': 'Same TextMate harness with FPRT003 compact byte-plane archives',
    'boundary': 'Verified bounded in-memory package decode, raw grammar parsing, first-use work, and complete first-document highlighting; network transfer and file I/O excluded',
    'method': 'Three rotating fresh processes per variant/corpus, 40 Criterion samples, 300 ms warmup, 1 s target, 10,000 bootstrap resamples; cells are medians of process mean estimates',
    'correctness': {variant: {
        'cases': sum(v['build'] == variant for v in validation),
        'tokens': sum(v['tokens'] for v in validation if v['build'] == variant),
        'lines': sum(v['lines'] for v in validation if v['build'] == variant),
        'groupFallbacks': sum(v['stats'][2] for v in validation if v['build'] == variant),
    } for variant in ['before', 'after', 'after-legacy']},
    'rows': rows,
    'astroWarmFollowup': json.loads((root / 'astro-warm-check.json').read_text()),
    'reexport': json.loads((root / 'reexport-validation.json').read_text()),
}
(root / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')


def timing_table(metric):
    lines = ['| Language | Before ms | After ms | Paired change | Process range | Every run gains ≥3% |', '|---|---:|---:|---:|---:|---|']
    for row in rows:
        result = row['metrics'][metric]
        paired = result['pairedPercentChange']
        lines.append(f"| {row['label']} | {result['before']['medianProcessMeanMs']:.3f} | {result['after']['medianProcessMeanMs']:.3f} | {result['medianPairedPercentChange']:+.1f}% | {min(paired):+.1f}% to {max(paired):+.1f}% | {'yes' if result['allRunsAtLeastThreePercentFaster'] else 'no'} |")
    return '\n'.join(lines)


sizes = ['| Language | Decoded payload MiB, before → after | Prepared Zstd KiB, before → after | Total download change |', '|---|---:|---:|---:|']
for row in rows:
    b, a = row['packages']['before'], row['packages']['after']
    sizes.append(f"| {row['label']} | {b['payloadBytes']/2**20:.2f} → {a['payloadBytes']/2**20:.2f} | {b['preparedZstdBytes']/1024:.1f} → {a['preparedZstdBytes']/1024:.1f} | {100*(a['totalDownloadBytes']/b['totalDownloadBytes']-1):+.1f}% |")

text = '''# TextMate startup: compact portable byte planes

The target is the remaining startup gap between source Off and prepared Eager
for C++, SCSS, and Astro. The implementation reduces transport, verification,
and instruction decoding work without changing the execution kernel or adding
dependency forks. The same ten full TextMate workloads are measured again.

## Change

The existing runtime instructions have four 32-bit words, one reserved. The
new FPRT003 wire image packs the opcode into a bounded operand and writes two
words per instruction. The branch/range pool uses 16-bit words under the
existing 65,536-state bound. Equal byte positions are stored together in byte
planes so Zstd can compress repeated high bytes. The loader widens directly
into the same runtime arrays, then runs the existing structural validator.

The ordinary compiled-program format stays at version 2. FPRT001/FPRT002 remain
readable, integrity checks remain enabled, and Auto/Off behavior is unchanged.
The outer package retains Zstd level 19 and its existing limits and SHA-256
checks. Packages need regeneration to obtain the new representation.

## Startup including the first highlighted document

''' + timing_table('first_document') + '''

## Execution after three warm document passes

''' + timing_table('warm_search') + '''

Astro's initial warm-search median is +3.3%, with a +0.4% to +7.9% process
range. A targeted follow-up selects only `warm_search` in five fresh alternating
pairs using the same frozen binaries and inputs, retaining initialization and
correctness checks. Its median paired change is +0.8%, range -1.1% to +2.5%.
That follow-up does not reproduce a consistent slowdown of at least 3%; the
initial result remains in the table rather than being replaced. Search uses
the same runtime instructions, pool word types, and execution kernel.

## Package sizes

Total download includes the unchanged compressed TextMate grammar dependency
closure plus the prepared sidecar. Times above exclude actual CDN transfer.

''' + '\n'.join(sizes) + '''

## Diagnosis and rejected layouts

The initial instrumented runs identified verified decompression and decoded
SHA-256 as the largest avoidable startup costs. A variable-length opcode layout
reduced bytes but increased instruction decoding work. Fixed packed records and
a narrower pool improved startup but enlarged the SCSS Zstd asset. Compression
screens compared column layouts and byte planes; the selected byte planes
reduce both decoded size and compressed transport size. Compression-only screen
images retain placeholder old record checksums and are never used as runtime
validation evidence. Final images are exported and checked by the Rust producer.

`profile-before.json`, `profile-compact.json`, `profile-packed.json`, and
`profile-shuffled.json` retain the diagnostic phase clocks. Their instrumentation
overhead is not part of the final Criterion comparison. Final benchmarks use
ordinary release builds with phase clocks compiled out. The search kernel and
runtime instruction/pool layouts are unchanged.

## Method and validation

The baseline and candidate use the same isolated TextMate harness and lockfile,
release ThinLTO profile, hardware SHA-256, libzstd, source grammar definitions,
dependency closures, documents, and expected scope/binary tokens. Each matrix
cell has three fresh Criterion processes; corpus and variant order rotate.
Each process uses 40 samples, a 300 ms warmup, a one-second target, and 10,000
bootstrap resamples. Absolute cells are medians of process mean estimates;
percentage changes are computed within each repetition before aggregation.
There are 60 process runs and 180 metric series. Pure grammar construction is
retained separately as `construct` but excludes deferred scanner work.

Before timing, both versions and the new consumer with all ten old FPRT002
archives check complete scope/binary output over four document passes. Every
prepared group is consumed, with zero group fallbacks. Every benchmark process
also independently checks its first document. All three validation lanes
produce the same 58,103 tokens across 5,984 lines. The new ordinary program
archives and expected output JSON match the old producer byte-for-byte.
All ten new program/group images and expected output files also re-export
byte-for-byte after loading and executing the prepared representation.

Source, input, and executable SHA-256 hashes are recorded before timing and
rechecked afterward. No build, compression, or test task runs during final
timing. Time Machine is checked before and after the matrix. Hardware is the
same local Apple M1 Ultra with 64 GB RAM. Network, file I/O, theme application,
and HTML rendering are outside timing. Prepared groups cover the encountered
static scanners; dynamic patterns and unseen grammar paths retain fallback.
`peakRssBytes` in the JSON is a single fresh validation-process high-water mark,
including inputs, transport buffers, allocator retention, and repeated document
passes. It is not an isolated live-heap measurement or a timing series.

Local validation includes the portable-feature library suite, precompiled and
scanner-group integration suites, the NFA-only group suite, formatting, and
all-target/all-feature Clippy. `validation.json`, raw Criterion samples and
estimates, build/test logs, source patch, and diagnostic scripts are retained
in `evidence.tar.gz`, together with the frozen input/harness evidence.
'''
(root / 'README.md').write_text(text)
print(text)
