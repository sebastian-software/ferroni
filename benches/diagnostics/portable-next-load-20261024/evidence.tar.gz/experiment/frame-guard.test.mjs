import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { test } from "node:test";
import { constants, zstdCompressSync, zstdDecompressSync } from "node:zlib";
import { createPackage, decodePackage } from "./guarded.mjs";

const programs = Buffer.from("program bytes");
const groups = Buffer.from("group bytes");
const { encoded, manifest } = createPackage(programs, groups);
const sha = (bytes) => createHash("sha256").update(bytes).digest("hex");
const changed = (bytes) => ({ ...manifest, compressedBytes: bytes.length, compressedSha256: sha(bytes) });
assert.equal(encoded[4], 0x24); // Single segment, one-byte content size, checksum.

test("equivalent 4- and 8-byte content-size fields decode correctly", () => {
  for (const width of [4, 8]) {
    const header = Buffer.alloc(5 + width);
    encoded.copy(header, 0, 0, 5);
    header[4] = (width === 4 ? 0x80 : 0xc0) | 0x24;
    if (width === 4) header.writeUInt32LE(manifest.payloadBytes, 5);
    else header.writeBigUInt64LE(BigInt(manifest.payloadBytes), 5);
    const frame = Buffer.concat([header, encoded.subarray(6)]);
    assert.deepEqual(decodePackage(frame, changed(frame)), { programs, groups });
  }
});

test("the guard rejects a large window even when the one-shot decoder accepts it", () => {
  const header = Buffer.alloc(10);
  encoded.copy(header, 0, 0, 4);
  header[4] = 0x84; // Four-byte content size, separate window, checksum.
  header[5] = 14 << 3; // A 16 MiB window, even though the content is tiny.
  header.writeUInt32LE(manifest.payloadBytes, 6);
  const frame = Buffer.concat([header, encoded.subarray(6)]);
  assert.equal(zstdDecompressSync(frame, {
    chunkSize: manifest.payloadBytes + 64,
    params: { [constants.ZSTD_d_windowLogMax]: 23 },
  }).length, manifest.payloadBytes);
  assert.throws(() => decodePackage(frame, changed(frame)), /window exceeds/);
});

test("truncation, trailing data, concatenated and skippable frames are rejected", () => {
  const empty = zstdCompressSync(Buffer.alloc(0));
  for (const frame of [encoded.subarray(0, 4), encoded.subarray(0, encoded.length - 1)]) {
    assert.throws(() => decodePackage(frame, changed(frame)), /Truncated/);
  }
  for (const tail of [Buffer.from([0]), empty]) {
    const frame = Buffer.concat([encoded, tail]);
    assert.throws(() => decodePackage(frame, changed(frame)), /exactly one frame/);
  }
  const skippable = Buffer.alloc(8);
  skippable.writeUInt32LE(0x184d2a50);
  assert.throws(() => decodePackage(skippable, changed(skippable)), /frame magic/);
});
