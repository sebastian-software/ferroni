import { readFileSync } from "node:fs";
import { join } from "node:path";
import { performance } from "node:perf_hooks";

const [packages, raw, corpus, variant, repetition] = process.argv.slice(2);
const { decodePackage } = await import(new URL(`./${variant}/portable-eager-package.mjs`, import.meta.url));
const manifest = JSON.parse(readFileSync(join(packages, `${corpus}.eager.json`), "utf8"));
const encoded = readFileSync(join(packages, `${corpus}.eager.zst`));
const programs = readFileSync(join(raw, `${corpus}.programs`));
const groups = readFileSync(join(raw, `${corpus}.portable`));
function validate(result) {
  if (!result.programs.equals(programs) || !result.groups.equals(groups)) {
    throw new Error("Decoded archives differ");
  }
}
for (let i = 0; i < 3; i++) validate(decodePackage(encoded, manifest));
const samplesMs = [];
for (let i = 0; i < 15; i++) {
  const start = performance.now();
  const result = decodePackage(encoded, manifest);
  samplesMs.push(performance.now() - start);
  validate(result);
}
process.stdout.write(JSON.stringify({
  corpus, variant, repetition: Number(repetition), samplesMs,
  maxRssKiB: process.resourceUsage().maxRSS,
  payloadBytes: manifest.payloadBytes, compressedBytes: manifest.compressedBytes,
  compressedSha256: manifest.compressedSha256, payloadSha256: manifest.payloadSha256,
  versions: process.versions,
}) + "\n");
