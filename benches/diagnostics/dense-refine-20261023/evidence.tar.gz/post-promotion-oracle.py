"""Check every fixture repeatedly through promotion, after all timing phases."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,subprocess
r=Path(__file__).resolve().parent;repo=r.parents[1]
assert (r/'final6-reuse-previous/analysis.json').exists(), 'timing queue must finish first'
assert json.loads((r/'active-phase.json').read_text())['phase']=='complete'
manifest=json.loads((r/'binaries.json').read_text());binary=r/'bin/bits0006';assert hashlib.sha256(binary.read_bytes()).hexdigest()==manifest['bits0006']['sha256']
d=r/'post-promotion-oracles';d.mkdir(exist_ok=False);cases=[]
for corpus in ['production','tokenizer']:
 env=dict(os.environ,PRODUCTION_ENGINE='rust',PRODUCTION_CORPUS=corpus)
 for key in ['PRODUCTION_CASE','PRODUCTION_REUSE_COUNTS','PRODUCTION_LANE_BUDGETS']:env.pop(key,None)
 p=d/(corpus+'.jsonl')
 with p.open('w') as f, (d/(corpus+'.stderr.log')).open('w') as log:subprocess.run([str(binary),'--reuse-trace','8192'],cwd=repo,env=env,stdout=f,stderr=log,check=True)
 eligible={x['case'] for x in map(json.loads,(r/('bits0006-'+corpus+'-validation.jsonl')).read_text().splitlines()) if x['status']=='eligible'}
 observed=set()
 for line in p.read_text().splitlines():
  if line.startswith('ELIGIBILITY '):continue
  row=json.loads(line);assert row['engine']=='rust' and row['case'] in eligible;observed.add(row['case'])
  ops=row['operations'];assert len(ops)==8192 and [x['operation'] for x in ops]==list(range(1,8193))
  cases.append({'case':row['case'],'corpus':corpus,'checked_operations':len(ops)})
 assert observed==eligible
result={'utc':datetime.now(timezone.utc).isoformat(),'binary_sha256':manifest['bits0006']['sha256'],'all_checks_passed':True,'cases':cases,'checked_operations':sum(c['checked_operations'] for c in cases),'timing_scope':'Individual operation durations include timer/harness overhead. Used only for repeated oracle-fixture assertions through promotion, not performance acceptance.'}
(d/'audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='cases'},indent=2))
