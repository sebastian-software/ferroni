"""Run an explicit, manifest-checked candidate; never infer it from a label."""
from pathlib import Path
import hashlib,json,subprocess,sys
r=Path(__file__).resolve().parent
name,binary=sys.argv[1:];assert name not in ['screen-bitset','screen-inline','screen-exact']
manifest=json.loads((r/'binaries.json').read_text());candidate=r/'bin'/binary
assert hashlib.sha256(candidate.read_bytes()).hexdigest()==manifest[binary]['sha256']
cases='django_email_local_part,uuid_v4,jinja_string_token,jinja_integer_token,semver_version_parse,ferrolink_markup_scan,fluent_bit_apache'
cmd=[sys.executable,str(r/'compare.py'),str(r/'bin/base0002'),str(candidate),str(r/name),'--cases',cases,'--repetitions','8','--alignment-offsets','0,16,32,48','--warmup','.25','--measure','.75','--samples','20','--environment-base','7168','--seed','20261023']
(r/'active-phase.json').write_text(json.dumps({'phase':name,'candidate':binary,'expected_sha256':manifest[binary]['sha256'],'command':cmd},indent=2)+'\n')
with (r/(name+'.log')).open('w') as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
c=json.loads((r/name/'context.json').read_text());assert c['binaries'][1]['sha256']==manifest[binary]['sha256'];assert c['args']['candidate']==str(candidate)
subprocess.run([sys.executable,str(r/'summarize.py'),name],check=True)
(r/'active-phase.json').write_text('{"phase":"complete"}\n')
