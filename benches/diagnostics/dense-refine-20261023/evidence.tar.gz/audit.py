#!/usr/bin/env python3
"""Audit retained comparison phases, including compile and first-use lanes."""
import argparse
from datetime import datetime
import hashlib
import json
from pathlib import Path


def audit(directory, binaries):
    context = json.loads((directory / 'context.json').read_text())
    rows = json.loads((directory / 'measurements.json').read_text())
    status = json.loads((directory / 'phase-status.json').read_text()) if (directory / 'phase-status.json').exists() else {'status': 'complete'}
    complete = status['status'] == 'complete'
    assert complete or status['status'] == 'superseded'
    summaries = json.loads((directory / 'analysis.json').read_text()) if complete else []
    args = context['args']
    cases = set(args['cases'].split(','))
    if cases == {'all'}:
        validation = [json.loads(line) for name in ['production', 'tokenizer']
                      for line in (directory.parent / f'base0001-{name}-validation.jsonl').read_text().splitlines()]
        cases = {row['case'] for row in validation if row['status'] == 'eligible'}
    lanes = set(args['lanes'].split(','))
    assert args['engines'] == 'rust'
    if complete:
        assert {(row['case'], row['lane']) for row in summaries} == {(case, lane) for case in cases for lane in lanes}
    reps = args['repetitions']
    offsets = [int(value) for value in args['alignment_offsets'].split(',')]
    assert reps == 2 * len(offsets)
    assert context['environment_sizes'] == [context['environment_base_bytes'] + offsets[n % len(offsets)] for n in range(reps if complete else len(context['environment_sizes']))]
    assert len(rows) == len(context['order'])
    assert len(rows) == len(cases) * reps * 2 if complete else len(rows) == status['complete_processes'] < len(cases) * reps * 2
    assert len(rows) % 2 == 0
    for binary in context['binaries']:
        assert binary['sha256'] == binaries[Path(binary['path']).name]['sha256']
    assert len(args['baseline']) == len(args['candidate'])
    assert context['binaries'][0]['path'] == args['baseline']
    assert context['binaries'][1]['path'] == args['candidate']
    seen, orders = set(), {}
    previous_end = None
    sample_count = 0
    for expected, row in zip(context['order'], rows):
        key = row['repetition'], row['case'], row['variant']
        assert key not in seen
        seen.add(key)
        assert row['engine'] == 'rust' and row['variant'] in [0, 1]
        assert expected['command'][0] == context['binaries'][row['variant']]['path']
        assert set(row['lanes']) == lanes
        for field in ['repetition', 'case', 'engine', 'variant', 'alignment_offset']:
            assert expected[field] == row[field]
        assert row['alignment_offset'] == offsets[row['repetition'] % len(offsets)]
        start, end = (datetime.fromisoformat(row[field]) for field in ['started_utc', 'finished_utc'])
        assert start <= end and (previous_end is None or previous_end <= start)
        previous_end = end
        orders.setdefault((row['case'], row['repetition']), []).append(row['variant'])
        raw = directory / f"raw/{row['repetition']:02d}/{row['case']}/rust/{row['variant']}"
        assert (raw / 'process.log').is_file()
        for estimate in row['lanes'].values():
            samples = json.loads((raw / estimate['raw_directory'] / 'sample.json').read_text())
            assert len(samples['times']) == args['samples'] == len(samples['iters'])
            assert min(samples['times']) > 0 and min(samples['iters']) > 0 and estimate['ns'] > 0
            sample_count += len(samples['times'])
    for n in range(0, len(rows), 2):
        a, b = rows[n:n + 2]
        assert (a['case'], a['repetition']) == (b['case'], b['repetition'])
        assert {a['variant'], b['variant']} == {0, 1}
    for case in cases if complete else []:
        for rep in range(reps):
            assert sorted(orders[case, rep]) == [0, 1]
        for index in range(len(offsets)):
            assert orders[case, index] == list(reversed(orders[case, index + len(offsets)]))
    return {'phase': directory.name, 'cases': len(cases), 'lanes': sorted(lanes),
            'pairs': len(rows) // 2, 'processes': len(rows), 'criterion_samples': sample_count,
            'complete': complete, 'status': status['status'], 'started_utc': rows[0]['started_utc'], 'finished_utc': rows[-1]['finished_utc'],
            'load_average_1m_range': [min(row['load_average'][0] for row in rows), max(row['load_average'][0] for row in rows)]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('root', type=Path)
    args = parser.parse_args()
    binaries = json.loads((args.root / 'binaries.json').read_text())
    for name, expected in binaries.items():
        assert hashlib.sha256((args.root / 'bin' / name).read_bytes()).hexdigest() == expected['sha256']
    phases = [audit(path, binaries) for path in args.root.iterdir() if path.is_dir() and (path / 'measurements.json').exists()]
    phases.sort(key=lambda row: row['started_utc'])
    for before, after in zip(phases, phases[1:]):
        assert before['finished_utc'] <= after['started_utc']
    result = {'phases': phases, 'total_processes': sum(row['processes'] for row in phases),
              'total_pairs': sum(row['pairs'] for row in phases), 'total_criterion_samples': sum(row['criterion_samples'] for row in phases),
              'all_phases_serial': True, 'all_final6_phases_complete': all(row['complete'] for row in phases if row['phase'].startswith('final6-')), 'incomplete_superseded_phases': [row['phase'] for row in phases if not row['complete']], 'all_frozen_binary_hashes_verified': True}
    (args.root / 'audit.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
