"""Create the durable report only after all selected comparisons finish."""
from pathlib import Path
import csv,json
r=Path(__file__).resolve().parent;repo=r.parents[1];out=repo/'benches/diagnostics/dense-refine-20261023'
audit=json.loads((r/'audit.json').read_text());assert audit['all_phases_serial'] and audit['all_final6_phases_complete']
names=['final6-focus-confirm','final6-broad-confirm','final6-previous-confirm','final6-startup-confirm','final6-reuse-confirm','final6-reuse-previous','final6-capture-aa-long','final6-capture-long']
data={n:json.loads((r/n/'analysis.json').read_text()) for n in names}
by={n:{(x['case'],x['lane']):x for x in rows} for n,rows in data.items()}
pct=lambda n:f'{n:+.2f}%'
def interval(x):return f"{pct(x['interval_95_percent'][0])} to {pct(x['interval_95_percent'][1])}"
def cycles(x):return ' / '.join(pct(v) for v in x['cycle_medians_percent'])
focus=data[names[0]];broad=data[names[1]]
strict_faster=lambda x:x['median_change_percent']<=-3 and all(v<=-3 for v in x['cycle_medians_percent']) and x['interval_95_percent'][1]<0
strict_slower=lambda x:x['median_change_percent']>=3 and all(v>=3 for v in x['cycle_medians_percent']) and x['interval_95_percent'][0]>0
decision={'runtime_commit':'c5fa681dfb649d81bfe3e4070673bc9b15b26887','candidate':'bits0006','metric':'Paired change of process mean elapsed time; negative is faster. No controls subtracted, no phases pooled, no pair/sample removed.','strict_rule':'Median and both cycle medians exceed 3% in the same direction; descriptive interval excludes zero. This is a local descriptive rule, not a multiplicity-adjusted test.','broad_target_gains':[x['case'] for x in broad if strict_faster(x)],'broad_target_costs':[x['case'] for x in broad if strict_slower(x)],'broad_positive_medians':[{'case':x['case'],'median':x['median_change_percent'],'interval':x['interval_95_percent'],'cycles':x['cycle_medians_percent']} for x in broad if x['median_change_percent']>0],'source_scope':'Frozen 9b85954 baseline and 37d406c previous adaptive prototype; not exact current main.'}
decision['target_confirmation']={}
for cid,phase in [('django_email_local_part',names[0]),('uuid_v4',names[0]),('jinja_integer_token',names[0]),('semver_version_parse',names[7]),('jinja_string_token',names[7])]:
 x=by[phase][cid,'steady'];changes=[p['change_percent'] for p in x['pairs']]
 decision['target_confirmation'][cid]={'phase':phase,'median':x['median_change_percent'],'interval':x['interval_95_percent'],'cycles':x['cycle_medians_percent'],'range':[min(changes),max(changes)],'pairs_at_least_3_percent_slower':sum(v>=3 for v in changes)}
decision['warm_local_uuid_gains_preserved']=all(strict_faster(by[names[0]][c,'steady']) for c in ['django_email_local_part','uuid_v4'])
decision['target_capture_intervals_below_3_percent']=all(decision['target_confirmation'][c]['interval'][1]<3 for c in ['jinja_integer_token','jinja_string_token','semver_version_parse'])
decision['fresh_16_batch_cost_lower_than_previous']={c:(lambda x: x['median_change_percent']<0 and max(x['cycle_medians_percent'])<0 and x['interval_95_percent'][1]<0)(by[names[5]][c,'reuse_16']) for c in ['django_email_local_part','uuid_v4']}
(out/'decision.json').write_text(json.dumps(decision,indent=2)+'\n')
with (out/'results.csv').open('w',newline='') as f:
 w=csv.writer(f,lineterminator="\n");w.writerow(['phase','case','lane','median_change_percent','interval_low','interval_high','cycle_1','cycle_2','baseline_median_ns','candidate_median_ns','pairs','min_pair_change_percent','max_pair_change_percent','pairs_at_least_3_percent_faster','pairs_at_least_3_percent_slower'])
 for name,rows in data.items():
  for x in rows:w.writerow([name,x['case'],x['lane'],x['median_change_percent'],*x['interval_95_percent'],*x['cycle_medians_percent'],x['baseline_median_ns'],x['candidate_median_ns'],len(x['pairs']),min(p['change_percent'] for p in x['pairs']),max(p['change_percent'] for p in x['pairs']),sum(p['change_percent']<=-3 for p in x['pairs']),sum(p['change_percent']>=3 for p in x['pairs'])])
text=[]
def add(s=''):text.append(s)
add('# Bounded adaptive single-regex DFA refinement\n')
add('The refined implementation replaces the general dense builder with a bounded\nbitset construction, preserves the hybrid route for capture/find calls, and\nkeeps optional promotion metadata outside the hybrid search object.\n')
for cid,label in [('django_email_local_part','Local-Part'),('uuid_v4','UUID v4'),('jinja_integer_token','Jinja Integer'),('jinja_string_token','Jinja String'),('semver_version_parse','Semver')]:
 phase=names[7] if cid in ['jinja_string_token','semver_version_parse'] else names[0]
 label_phase='longer 16-pair capture comparison' if phase==names[7] else 'independent 16-pair focus comparison'
 x=by[phase][cid,'steady'];add(f"- {label}: {pct(x['median_change_percent'])} in the {label_phase} ({interval(x)}).")
add('\nThese are local elapsed-time changes against the frozen runtime baseline,\nnot end-to-end application throughput. The full warm matrix, construction\nlanes, direct comparison with the previous adaptive prototype, and all smaller\ncosts are reported below. No arithmetic average is used to hide case costs.\n')
for c,label in [('django_email_local_part','Local-Part'),('uuid_v4','UUID')]:
 baseline=by[names[4]][c,'reuse_16'];previous=by[names[5]][c,'reuse_16']
 add(f"For a fresh {label} regex with only 16 whole fixture batches, the change is {pct(baseline['median_change_percent'])} versus baseline and {pct(previous['median_change_percent'])} versus the previous adaptive prototype. The setup cost is reduced, not eliminated for every short lifetime.\n")
ipv6=by[names[1]]['ipv6_validation','steady'];add(f"Smaller warm costs remain outside the main targets, including IPv6 at {pct(ipv6['median_change_percent'])}; the complete matrix follows.\n")
add('## Implementation and scope\n')
add('The runtime baseline is `9b85954dba9a37d58f93d5b62870b8788c8e521b` (2.4.0),\nand the previous small adaptive prototype is\n`37d406c75565408671c8192327b2630c4403114e`. The selected source is\n`c5fa681dfb649d81bfe3e4070673bc9b15b26887`, following bitset construction at\n`e61b25b` and reject-only dispatch at `50f8e6f`. This is not an exact-current-main\ncomparison. Main was `817d2b3` when initially checked; subsequent scanner and\narchive changes are outside this frozen experiment.\n')
add('- Build Boolean subsets of the existing public Thompson NFA with a `u64`;\n  no new dependency, `unsafe`, or regex-automata `dfa-build` feature.\n- Admit at most 64 actual NFA states, byte-mode empty-match semantics, and\n  absolute text-start/text-end assertions. The separate 512-state HIR estimate\n  is only an admission precheck. Unsupported NFAs stay hybrid.\n- Preserve the original inline hybrid DFA and per-thread cache pool. Promote\n  after 64 actual consultations of each eligible seek or accept DFA.\n- Use dense seeks for complete Boolean decisions. Capture/find calls use the\n  legacy hybrid search body without dense dispatch, counting, or promotion;\n  positive results still go through the matcher for captures and positions.\n- Publish one immutable table with the existing atomics/`OnceLock` policy.\n  Release the cache guard before construction; concurrent readers can keep\n  using hybrid. Memoize normal rejection and prevent retries after a panic.\n- Bound table storage, including compaction headroom, by 64 KiB and subset\n  workspace by 32 KiB. The budgets count data storage, excluding allocator\n  bookkeeping; hybrid NFAs/caches and promotion metadata are additional.\n')
add('Optional seek/accept promotion metadata lives in one boxed pair. Ineligible\nNFAs allocate no pair and return directly to hybrid. A layout diagnostic on\nthis toolchain measured 1472 bytes for the baseline-shaped search object,\n1600 with inline promotion fields, and 1488 with the boxed pair. The cache-pool\noffset returns from 1584 to 1456, matching the baseline shape. An eligible pair\nuses 128 additional heap bytes and one allocation. These are layout observations,\nnot Rust layout guarantees or proof that the offset alone caused a timing cost.\nThe 1029-state IPv6 NFA has no adaptive state.\n')
add('The prior [feature-only control](../dense-policy-20261022/README.md#controls-and-attribution)\nwas slower for Jinja Integer and Semver even without a dense runtime change.\nFeature selection and generated-code placement therefore remain attribution\nuncertainties. This refinement removes that feature and unnecessary adaptive\nwork from capture/find calls; it does not assign the entire former regression\nto one branch or allocation.\n')
add('## Warm independent focus\n')
add('Sixteen pairs use eight environment-size offsets, revisited with the opposite\nbinary order. Negative values mean less elapsed time. Intervals are descriptive\n95% cluster-bootstrap intervals, retaining both order pairs at each offset;\nthey are not corrected for multiple comparisons or host activity.\n')
add('| Case | Median | Descriptive 95% interval | Cycle 1 / cycle 2 |\n| --- | ---: | --- | --- |')
for x in focus:add(f"| `{x['case']}` | {pct(x['median_change_percent'])} | {interval(x)} | {cycles(x)} |")
add('\nThe Semver focus interval reached +3.25% and the independent broad Jinja\nString interval reached +3.32%. The same frozen binaries therefore received\nseparately planned longer confirmation for both capture cases (16 pairs/eight\noffsets, 1 s warm-up, 3 s measurement, 40 samples), plus an identical-binary\ncontrol. No phase is pooled or subtracted.\n')
add('| Longer capture phase | Case | Median | Descriptive 95% interval | Cycle 1 / cycle 2 |\n| --- | --- | ---: | --- | --- |')
for n,label in [(names[6],'Identical binary A/A'),(names[7],'Refined vs baseline')]:
 for x in data[n]:add(f"| {label} | `{x['case']}` | {pct(x['median_change_percent'])} | {interval(x)} | {cycles(x)} |")
add('\nThe CSV and decision details also retain pair ranges and the count of pairs\nslower by at least 3%. A near-zero median is not a claim that every process\nlayout or individual pair is unchanged.\n')
add('\n## All executable warm cases\n')
add('This independent matrix has eight pairs per case over four offsets and their\nopposite orders. It includes all 27 executable production cases and both\ntokenizer cases. The two catalog entries without executable fixtures remain\npending and are not timed.\n')
add('| Case | Median | Descriptive 95% interval | Cycle 1 / cycle 2 |\n| --- | ---: | --- | --- |')
for x in sorted(broad,key=lambda x:x['case']):add(f"| `{x['case']}` | {pct(x['median_change_percent'])} | {interval(x)} | {cycles(x)} |")
add(f"\nThe strict local rule finds {len(decision['broad_target_gains'])} case gains and\n{len(decision['broad_target_costs'])} case costs of at least 3% in both cycles,\nwith the interval excluding zero. [decision.json](decision.json) records every\npositive median as well; a smaller cost or an interval reaching 3% is not proof\nof no regression.\n")
add('## Previous small adaptive prototype\n')
add('These are fresh direct comparisons with `37d406c`, not ratios reconstructed\nfrom separate baseline phases. Each row has eight pairs/four offsets.\n')
add('| Case | Median | Descriptive 95% interval | Cycle 1 / cycle 2 |\n| --- | ---: | --- | --- |')
for x in data[names[2]]:add(f"| `{x['case']}` | {pct(x['median_change_percent'])} | {interval(x)} | {cycles(x)} |")
add('\n## Construction and reuse\n')
add('Each lane starts with a fresh compiled regex. `compile` measures compilation\nand required engine context; lazy `SingleSeek` construction happens later.\n`first_use` adds execution on the first fixture input. Reuse lanes add N full\nfixture batches, not N individual searches. Local-Part has 58 inputs per batch;\nUUID has 11. Regex destruction is outside the measured region in all these\nlanes, matching the diagnostic harness. Each row has eight counterbalanced pairs.\n')
add('| Case | Compile | First use | 1 batch | 16 batches | 256 batches | 1024 batches |\n| --- | ---: | ---: | ---: | ---: | ---: | ---: |')
cold=list(dict.fromkeys(x['case'] for x in data[names[3]]))
for case in cold:
 vals=[by[names[3]][case,lane]['median_change_percent'] for lane in ['compile','first_use']]
 vals += [by[names[4]][case,f'reuse_{n}']['median_change_percent'] for n in [1,16,256,1024]]
 add('| `'+case+'` | '+' | '.join(pct(v) for v in vals)+' |')
add('\nDirect fresh-regex reuse comparison with the previous adaptive prototype:\n')
add('| Case | Batches | Median | Descriptive 95% interval | Cycle 1 / cycle 2 |\n| --- | ---: | ---: | --- | --- |')
for x in data[names[5]]:add(f"| `{x['case']}` | {x['lane'].split('_')[1]} | {pct(x['median_change_percent'])} | {interval(x)} | {cycles(x)} |")
add('\n[results.csv](results.csv) includes every construction/reuse interval, cycle,\npaired count, and absolute process-median duration, including the other cold\ncases. Warm results alone do not establish a win for short-lived regexes.\n')
add('The motivating in-process builder probe measured the first bitset version at\nabout 6.38 µs for Local-Part and 9.92 µs for UUID, versus 47.13 and 35.08 µs for\nthe generic dense builder (128 builds each). That diagnostic predates final\ncompaction/integration and is not substituted for the fresh-regex evidence.\nChanging generic-builder start kinds or acceleration was insufficient. Direct\nhybrid-cache state export was rejected because retained IDs violate its public\nAPI contract; replaying paths to respect that contract removed the advantage.\n')
add('## Correctness and controls\n')
add('Formatting and all-target/all-feature Clippy with `-D warnings` passed. The\nbroad feature-enabled library/API/compatibility/scanner suites, matcher/C\ncatalog oracles, and the full parallel library suite without default features\npassed for the bitset implementation. After each API/layout follow-up, the\nfocused promotion/differential tests, reject-only policy test, 314 API tests,\nall six matcher/C catalog tests, Clippy, and the no-default-features all-target\ncheck passed again. The gates and their exact logs are retained.\n')
post=json.loads((r/'post-promotion-oracles/audit.json').read_text());assert post['all_checks_passed']
add(f"After timing finished, the selected immutable binary also passed {post['checked_operations']} repeated oracle-fixture assertions: 8192 public operations for each of all 29 executable cases. This covers repeated use through promotion. Those individual trace durations include timer/harness overhead and are not performance acceptance evidence.\n")
add('The extra parallel library run exposed an existing test race: a counted-loop\ntest observed another test\'s temporary global match-stack limit (`-15`).\nCommit `700d6eb` adds the existing `shared_limits` read guard to that test.\nThe full parallel rerun passed 513 tests. This changes no production code.\n')
add('Bitset tests cover all 256 predecessor bytes, empty input, Unicode bytes,\nnonzero starts, EOI-delayed anchors, the 64/65-state boundary, unsupported\nassertions, bounded rejection, panic fallback, and concurrent promotion. The\nreject-only test checks no counting or promotion before and after Boolean calls\npromote the same automaton. No archive/wire format changes are made.\n')
add('All immutable binaries were built at the same canonical package path with\nRust 1.99.0 / LLVM 23.1.1, optimized bench profile with ThinLTO, default features\nplus `ffi`, locked dependencies, and one common diagnostic harness. Both catalogs\nand all executable oracle-validation records agree byte-for-byte. The baseline\nand previous prototype were rebuilt after the test-only guard; their retained\nbenchmark hashes are unchanged.\n')
aa=json.loads((r/'control-aa/analysis.json').read_text());add(f"The identical-binary A/A medians range from {pct(min(x['median_change_percent'] for x in aa))}\nto {pct(max(x['median_change_percent'] for x in aa))} across seven cases; some descriptive\nintervals remain wider than 3%. No control result is subtracted.\n")
add('## Host conditions and retained exploration\n')
add('This is an interactive M1 Ultra host (20 logical CPUs, 64 GiB), not an isolated\nbenchmark machine. Before each selected pair, the runner requires one-minute\nload at most 10 and at least 20 seconds since the last observed value above\nthat threshold. Both processes then run consecutively. Every wait, process\nload, order, and environment offset is retained. The gate cannot prevent a new\nbackground burst inside a pair; CPU affinity and frequency were not controlled.\nNo task-owned builds, tests, or profiling overlap selected timings. External\nprocesses were never stopped for this work.\n')
add('The first bitset screen remains diagnostic. Two later screen labels\naccidentally reused that first executable; hashes and an attribution correction\nare retained, and those phases provide no evidence for their intended source\nchanges. The first correctly attributed `bits0004` screen was strongly loaded\nand is excluded from selection. Its broad run (114 complete pairs) was\nsuperseded by the reject-only API fix.\n')
add('The complete `bits0005` focus had Local-Part -41.29%, UUID -13.72%, Jinja\nInteger +0.19%, and Semver +0.07%. Its partial broad run (101 complete pairs)\nsuggested an IPv6 cost, prompting the compact metadata change. Neither partial\nbroad phase is presented as a completed eight-pair matrix. Both were stopped\nduring existing capacity waits at complete-pair boundaries, with no timed\nCriterion child interrupted. All rows and raw samples remain in the archive.\n')
add(f"The integrity audit verifies {audit['total_processes']} completed Criterion\nprocesses, {audit['total_pairs']} complete pairs, and\n{audit['total_criterion_samples']} raw sample records across selected and retained\nexploratory phases. All selected phases are complete; the two superseded broad\nphases are explicitly incomplete. Frozen binary identities and all archived\nfile hashes are checked.\n")
add('## Evidence\n')
add('- [Raw evidence archive](evidence.tar.gz) and [SHA-256](evidence.sha256).\n- [All selected results](results.csv) and [decision details](decision.json).\n- The archive includes source snapshots, manifests, build/oracle/gate logs,\n  runners, dependent analysis tools, contexts, phase status, all raw Criterion\n  samples and estimates, and integrity audits. Frozen executable bytes and\n  redundant build targets are excluded; their hashes are retained.\n')
(out/'README.md').write_text('\n'.join(text))
print('WROTE REPORT',len(broad),'broad rows',len(focus),'focus rows')
