
    #[test]
    #[ignore = "local construction diagnosis"]
    fn dense_refine_construction_diagnostic() {
        
        use std::time::Instant;
        let catalog: serde_json::Value = serde_json::from_str(include_str!("../benches/production_regex/catalog.json")).unwrap();
        let selected = ["django_email_local_part", "uuid_v4", "jinja_string_token", "jinja_integer_token", "semver_version_parse"];
        for case in catalog["cases"].as_array().unwrap() {
            let name = case["id"].as_str().unwrap();
            if !selected.contains(&name) { continue; }
            let flags = &case["flags"];
            let mut options = ONIG_OPTION_CAPTURE_GROUP.union(crate::oniguruma::ONIG_OPTION_SINGLELINE);
            for (flag, value) in [
                ("ignore_case", ONIG_OPTION_IGNORECASE),
                ("extended", crate::oniguruma::ONIG_OPTION_EXTEND),
                ("dotall", crate::oniguruma::ONIG_OPTION_MULTILINE),
            ] { if flags[flag] == true { options = options.union(value); } }
            let (_, seek, accept) = onig_new_for_single_seek(case["pattern"].as_str().unwrap().as_bytes(), options, &ONIG_ENCODING_UTF8, &OnigSyntaxOniguruma, false, true).unwrap();
            let Some(Seek::Pattern(code)) = seek else { eprintln!("{name}: no pattern seek"); continue; };
            let mut hirs=vec![("seek",code.decode())];
            if let Some(a)=accept { hirs.push(("accept",a.code.decode())); }
            for (kind,hir) in hirs {
                let Some((nfa,eligible))=single_nfa(&hir) else { eprintln!("{name} {kind}: NFA over limit"); continue; };
                eprintln!("{name} {kind} exact={} nfa={} eligible={eligible} look={:?}",code.exact(),nfa.states().len(),nfa.look_set_any());
                if !eligible { continue; }

                let dfa=build_single_hybrid(nfa.clone()).unwrap();
                let mut times=vec![]; let mut memory=0; let mut built=0;
                for _ in 0..128 {
                    let mut cache=dfa.create_cache();
                    let inputs=case["inputs"].as_array().unwrap();
                    for operation in 0..64 {
                        let input=&inputs[operation%inputs.len()];
                        let text=input["text"].as_str().unwrap();
                        let start=input["start"].as_u64().unwrap_or(0) as usize;
                        let _=dfa.try_search_fwd(&mut cache,&Input::new(text).span(start..text.len()).earliest(true)).unwrap();
                    }
                    let now=Instant::now();
                    let table=std::hint::black_box(SingleTable::build(std::hint::black_box(&dfa),&mut cache,PREFERRED_SINGLE_DENSE_LIMITS));
                    times.push(now.elapsed().as_nanos());
                    if let Some(table)=table { built+=1; memory=table.memory_usage()+std::mem::size_of::<SingleTable>(); }
                }
                times.sort(); eprintln!("{name} {kind}: median={}ns memory={memory} built={built}",times[64]);

            }
        }
    }
