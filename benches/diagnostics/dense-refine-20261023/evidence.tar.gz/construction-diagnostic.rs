
    #[test]
    #[ignore = "local construction diagnosis"]
    fn dense_refine_construction_diagnostic() {
        use regex_automata::dfa::StartKind;
        use std::time::Instant;
        let catalog: serde_json::Value = serde_json::from_str(include_str!("../benches/production_regex/catalog.json")).unwrap();
        let selected = ["django_email_local_part", "uuid_v4", "jinja_string_token", "jinja_integer_token", "semver_version_parse"];
        for case in catalog["cases"].as_array().unwrap() {
            let name = case["id"].as_str().unwrap();
            if !selected.contains(&name) { continue; }
            let flags = &case["flags"];
            let mut options = ONIG_OPTION_CAPTURE_GROUP.union(crate::oniguruma::ONIG_OPTION_SINGLELINE);
            for (flag, value) in [
                ("ignore_case", ONIG_OPTION_IGNORECASE),
                ("extended", crate::oniguruma::ONIG_OPTION_EXTEND),
                ("dotall", crate::oniguruma::ONIG_OPTION_MULTILINE),
            ] { if flags[flag] == true { options = options.union(value); } }
            let (_, seek, accept) = onig_new_for_single_seek(case["pattern"].as_str().unwrap().as_bytes(), options, &ONIG_ENCODING_UTF8, &OnigSyntaxOniguruma, false, true).unwrap();
            let Some(Seek::Pattern(code)) = seek else { eprintln!("{name}: no pattern seek"); continue; };
            let mut hirs=vec![("seek",code.decode())];
            if let Some(a)=accept { hirs.push(("accept",a.code.decode())); }
            for (kind,hir) in hirs {
                let Some((nfa,eligible))=single_nfa(&hir) else { eprintln!("{name} {kind}: NFA over limit"); continue; };
                eprintln!("{name} {kind} exact={} nfa={} eligible={eligible} look={:?}",code.exact(),nfa.states().len(),nfa.look_set_any());
                if !eligible { continue; }
                for (label,unanchored,accelerate) in [("original",false,true),("unanchored",true,true),("noaccel",false,false),("lean",true,false)] {
                    let mut times=vec![]; let mut memory=0;
                    for _ in 0..128 {
                        let config=dense::Config::new().match_kind(MatchKind::LeftmostFirst).start_kind(if unanchored { StartKind::Unanchored } else { StartKind::Both }).accelerate(accelerate).dfa_size_limit(Some(SINGLE_DENSE_DFA_SIZE_LIMIT)).determinize_size_limit(Some(SINGLE_DENSE_DETERMINIZE_SIZE_LIMIT));
                        let now=Instant::now();
                        let dfa=std::hint::black_box(dense::Builder::new().configure(config).build_from_nfa(std::hint::black_box(&nfa)));
                        times.push(now.elapsed().as_nanos());
                        if let Ok(dfa)=dfa { memory=dfa.memory_usage(); }
                    }
                    times.sort(); eprintln!("{name} {kind} {label}: median={}ns memory={memory}",times[64]);
                }
            }
        }
    }
