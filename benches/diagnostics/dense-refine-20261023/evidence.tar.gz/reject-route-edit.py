from pathlib import Path
p=Path('src/dfa_prefilter.rs');s=p.read_text()
a=s.index('        let input = Input::new(text).span(start..text.len()).earliest(true);',s.index('    pub(crate) fn search(&self, text: &[u8], start: usize)'))
b=s.index('        if let Some(adaptive) = &self.dense',a)
s=s[:a]+'''        let result = self.search_hybrid(text, start);
'''+s[b:]
a=s.index('    pub(crate) fn exact(&self) -> bool {',a)
s=s[:a]+'''    /// Reject-only callers still need the matcher after every positive seek.
    /// Keep their original hybrid path without dense dispatch or promotion.
    pub(crate) fn search_hybrid(&self, text: &[u8], start: usize) -> Option<bool> {
        let input = Input::new(text).span(start..text.len()).earliest(true);
        let mut caches = self.caches.get();
        self.dfa.try_search_fwd(&mut caches.seek, &input)
            .ok().map(|found| found.is_some())
    }

'''+s[a:]
a=s.rfind('\n}')
s=s[:a]+r'''
    /// Reject-only consultation does not pay promotion costs, even when the
    /// same automaton later serves complete boolean decisions.
    #[test]
    fn reject_only_search_keeps_the_hybrid_path_before_and_after_promotion() {
        let seek=adaptive_single_seek_with(r"\A(?:ab|cd)[0-9]{1,3}\z",ONIG_OPTION_CAPTURE_GROUP,Some(PREFERRED_SINGLE_DENSE_LIMITS),2).unwrap();
        for _ in 0..128 {
            assert_eq!(seek.search_hybrid(b"ab1",0),Some(true));
            assert_eq!(seek.search_hybrid(b"xx",0),Some(false));
        }
        assert_eq!(seek.adaptive_consultations(),(Some(0),None));
        assert_eq!(seek.backend_names().0,"hybrid");
        assert_eq!(seek.search(b"ab1",0),Some(true));
        assert_eq!(seek.search(b"xx",0),Some(false));
        assert_eq!(seek.backend_names().0,"dense");
        for _ in 0..128 {
            assert_eq!(seek.search_hybrid(b"ab1",0),Some(true));
            assert_eq!(seek.search_hybrid(b"xx",0),Some(false));
        }
        assert_eq!(seek.adaptive_consultations(),(Some(2),None));
    }
'''+s[a:]
p.write_text(s)
p=Path('src/api.rs');s=p.read_text();old='''        let found = seek.search(text, start)?;''';new='''        let found = if accept {
            seek.search(text, start)?
        } else {
            seek.search_hybrid(text, start)?
        };''';assert s.count(old)==1;s=s.replace(old,new);p.write_text(s)
