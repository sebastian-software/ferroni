"""Frozen, serialized confirmation; no builds/tests/profiling during timings."""
from datetime import datetime,timezone
from pathlib import Path
import hashlib,json,os,random,shutil,subprocess,sys
r=Path(__file__).resolve().parent;repo=r.parents[1]
freeze=json.loads((r/'freeze-bits0005.json').read_text());assert freeze['all_builds_and_tests_stopped']
final_binary=freeze['candidate']
manifest=json.loads((r/'binaries.json').read_text())
for binary in ['base0002','small002','same0001',final_binary]:
 assert hashlib.sha256((r/'bin'/binary).read_bytes()).hexdigest()==manifest[binary]['sha256']
focus=['django_email_local_part','uuid_v4','jinja_string_token','jinja_integer_token','semver_version_parse','ferrolink_markup_scan','fluent_bit_apache']
cold=['django_email_local_part','uuid_v4','jinja_string_token','jinja_integer_token','semver_version_parse','django_email_domain','django_url_regex']
phases=[
 ('final5-focus-confirm','base0002',final_binary,','.join(focus),'steady',16,'0,8,16,24,32,40,48,56'),
 ('final5-broad-confirm','base0002',final_binary,'all','steady',8,'0,16,32,48'),
 ('final5-previous-confirm','small002',final_binary,','.join(focus),'steady',8,'0,16,32,48'),
 ('final5-startup-confirm','base0002',final_binary,','.join(cold),'compile,first_use',8,'0,16,32,48'),
 ('final5-reuse-confirm','base0002',final_binary,','.join(cold),'reuse_1,reuse_16,reuse_256,reuse_1024',8,'0,16,32,48'),
 ('final5-reuse-previous','small002',final_binary,'django_email_local_part,uuid_v4','reuse_1,reuse_16,reuse_256,reuse_1024',8,'0,16,32,48'),
]
(r/'confirmation-plan-bits0005.json').write_text(json.dumps({'created_utc':datetime.now(timezone.utc).isoformat(),'phases':phases,'focus_warmup_seconds':.5,'focus_measure_seconds':1.5,'focus_samples':30,'other_warmup_seconds':.35,'other_measure_seconds':1.,'other_samples':25,'environment_base':7168,'seed':20261023,'availability_policy':'Before each pair, require load_1m <=10 and at least20 seconds since the last observed above-threshold value. Retain all waits and process loads; no interruption inside a pair.','acceptance':'Targets >=3% faster; inspect medians, both cycle medians, descriptive 95% cluster intervals. No pooling across phases, no outlier deletion. New regressions trigger investigation, not subtraction of AA/control effects.'},indent=2)+'\n')
for name,old,new,cases,lanes,reps,offsets in phases:
 env=dict(os.environ);env.pop('PRODUCTION_REUSE_COUNTS',None)
 if lanes.startswith('reuse_'):env['PRODUCTION_REUSE_COUNTS']='1,16,256,1024'
 warm,measure,samples=(.5,1.5,30) if name=='final5-focus-confirm' else (.35,1.,25)
 cmd=[sys.executable,str(r/'compare-quiet.py'),str(r/'bin'/old),str(r/'bin'/new),str(r/name),'--cases',cases,'--lanes',lanes,'--repetitions',str(reps),'--alignment-offsets',offsets,'--warmup',str(warm),'--measure',str(measure),'--samples',str(samples),'--environment-base','7168','--seed','20261023']
 (r/'active-phase.json').write_text(json.dumps({'phase':name,'command':cmd},indent=2)+'\n')
 print('START',name,flush=True)
 with (r/(name+'.log')).open('w') as f:subprocess.run(cmd,cwd=repo,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
 context=json.loads((r/name/'context.json').read_text())
 assert context['binaries'][0]['sha256']==manifest[old]['sha256']
 assert context['binaries'][1]['sha256']==manifest[new]['sha256']
 subprocess.run([sys.executable,str(r/'summarize.py'),name],cwd=repo,check=True)
 print('DONE',name,flush=True)
(r/'active-phase.json').write_text('{"phase":"complete"}\n')
