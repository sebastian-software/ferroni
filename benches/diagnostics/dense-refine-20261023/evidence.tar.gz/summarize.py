"""Summarize independent paired phases without pooling or dropping samples."""
import importlib.util
import json
from pathlib import Path
import statistics
import sys

root = Path(__file__).resolve().parent
repo = root.parents[1]
spec = importlib.util.spec_from_file_location(
    "prior_analysis", repo / "benches/diagnostics/possessive-negated-fix-20261022/analyze.py"
)
analysis = importlib.util.module_from_spec(spec)
spec.loader.exec_module(analysis)
for name in sys.argv[1:]:
    phase = root / name
    context = json.loads((phase / "context.json").read_text())
    records = json.loads((phase / "measurements.json").read_text())
    repetitions = context["args"]["repetitions"]
    cases = context["args"]["cases"].split(",")
    if cases == ["all"]:
        cases = sorted({record["case"] for record in records})
    lanes = context["args"]["lanes"].split(",")
    engines = context["args"]["engines"].split(",")
    assert len(records) == len(cases) * len(engines) * repetitions * 2
    output = []
    for case in cases:
        for engine in engines:
            for lane in lanes:
                pairs = []
                for rep in range(repetitions):
                    rows = [r for r in records if r["case"] == case
                            and r["engine"] == engine and r["repetition"] == rep]
                    assert sorted(row["variant"] for row in rows) == [0, 1]
                    old, new = sorted(rows, key=lambda row: row["variant"])
                    pairs.append({"repetition": rep, "offset": old["alignment_offset"],
                                  "baseline_ns": old["lanes"][lane]["ns"],
                                  "candidate_ns": new["lanes"][lane]["ns"],
                                  "first_variant": rows[0]["variant"],
                                  "change_percent": 100 * (new["lanes"][lane]["ns"]
                                                         / old["lanes"][lane]["ns"] - 1)})
                offsets = sorted({pair["offset"] for pair in pairs})
                clusters = [[p["change_percent"] for p in pairs if p["offset"] == offset]
                            for offset in offsets]
                if repetitions == 2 * len(offsets):
                    for offset in offsets:
                        assert sorted(p["first_variant"] for p in pairs
                                      if p["offset"] == offset) == [0, 1]
                changes = [p["change_percent"] for p in pairs]
                median = statistics.median(changes)
                cycles = [statistics.median(changes[i:i + len(offsets)])
                          for i in range(0, repetitions, len(offsets))]
                interval = analysis.median_interval(clusters, 20261022 + cases.index(case))
                output.append({"case": case, "engine": engine, "lane": lane,
                               "pairs": pairs, "median_change_percent": median,
                               "interval_95_percent": interval, "cycle_medians_percent": cycles,
                               "baseline_median_ns": statistics.median(p["baseline_ns"] for p in pairs),
                               "candidate_median_ns": statistics.median(p["candidate_ns"] for p in pairs),
                               "pairs_faster": sum(v < 0 for v in changes)})
                print(name, case, lane, f"{median:+.2f}%",
                      "interval", [round(v, 2) for v in interval],
                      "cycles", [round(v, 2) for v in cycles])
    (phase / "analysis.json").write_text(json.dumps(output, indent=2) + "\n")

