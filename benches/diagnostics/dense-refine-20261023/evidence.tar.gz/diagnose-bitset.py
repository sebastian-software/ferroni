from pathlib import Path
import os,subprocess
r=Path(__file__).resolve().parent;repo=r.parents[1];p=repo/'src/dfa_prefilter.rs';before=p.read_bytes()
s=before.decode();i=s.rfind('\n}');s=s[:i]+(r/'bitset-diagnostic.rs').read_text()+s[i:];p.write_text(s)
try:
 with (r/'construction-bitset.log').open('w') as f:
  subprocess.run(['cargo','test','--release','--offline','--locked','--lib','dense_refine_construction_diagnostic','--','--ignored','--nocapture'],cwd=repo,env=dict(os.environ,CARGO_BUILD_JOBS='4',PCRE2_SYS_STATIC='1'),stdout=f,stderr=subprocess.STDOUT,check=True)
finally:p.write_bytes(before)
