from pathlib import Path
p=Path('src/dfa_prefilter.rs');s=p.read_text()
s=s.replace('    dense: Option<AdaptiveDfa>,\n    accept_dense: Option<AdaptiveDfa>,\n}', '''    adaptive: Option<Box<SingleAdaptive>>,
}

/// Keep optional promotion state out of the hybrid DFA's hot object. NFAs
/// outside the small-table policy allocate no adaptive metadata.
struct SingleAdaptive {
    seek: Option<AdaptiveDfa>,
    accept: Option<AdaptiveDfa>,
}''',1)
s=s.replace('            dense,\n            accept_dense,\n        })', '''            adaptive: (dense.is_some() || accept_dense.is_some()).then(|| {
                Box::new(SingleAdaptive {
                    seek: dense,
                    accept: accept_dense,
                })
            }),
        })''',1)
a='''        if let Some(table) = self.dense.as_ref().and_then(AdaptiveDfa::dense) {
            return Some(table.search(text, start));
        }
        let result = self.search_hybrid(text, start);
        if let Some(adaptive) = &self.dense {
            adaptive.record_hybrid_consultation(self.dfa.get_nfa());
        }
        result'''
b='''        let Some(adaptive) = self.adaptive_seek() else {
            return self.search_hybrid(text, start);
        };
        if let Some(table) = adaptive.dense() {
            return Some(table.search(text, start));
        }
        let result = self.search_hybrid(text, start);
        adaptive.record_hybrid_consultation(self.dfa.get_nfa());
        result'''
assert a in s;s=s.replace(a,b,1)
# All remaining field users are diagnostics, acceptance, or test helpers.
s=s.replace('self.dense.as_ref()', 'self.adaptive_seek()')
s=s.replace('self.accept_dense.as_ref()', 'self.adaptive_accept()')
s=s.replace('self\n                    .accept_dense\n                    .as_ref()', 'self.adaptive_accept()')
s=s.replace('self.accept_dense\n                    .as_ref()', 'self.adaptive_accept()')
s=s.replace('&self.accept_dense', 'self.adaptive_accept()')
s=s.replace('adaptive.dense.as_ref()', 'adaptive.adaptive_seek()')
needle='    pub(crate) fn exact(&self) -> bool {'
assert needle in s
s=s.replace(needle,'''    fn adaptive_seek(&self) -> Option<&AdaptiveDfa> {
        self.adaptive.as_deref()?.seek.as_ref()
    }

    fn adaptive_accept(&self) -> Option<&AdaptiveDfa> {
        self.adaptive.as_deref()?.accept.as_ref()
    }

'''+needle,1)
s=s.replace('            + table_bytes(self.adaptive_seek())', '''            + self
                .adaptive
                .as_deref()
                .map_or(0, std::mem::size_of_val)
            + table_bytes(self.adaptive_seek())''',1)
assert '.accept_dense' not in s
assert 'self.dense.as_ref()' not in s
p.write_text(s)
