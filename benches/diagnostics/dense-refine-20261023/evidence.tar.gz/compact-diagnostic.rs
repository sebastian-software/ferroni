    #[test]
    #[ignore = "local layout and eligibility diagnosis"]
    fn compact_metadata_diagnostic() {
        #[allow(dead_code)]
        struct BaselineShape {
            dfa: hybrid::DFA,
            accept: Option<(hybrid::DFA, accept::AcceptRejects)>,
            caches: Pool<SingleCaches, CacheMaker>,
            exact: bool,
        }
        #[allow(dead_code)]
        struct InlineShape {
            dfa: hybrid::DFA,
            accept: Option<(hybrid::DFA, accept::AcceptRejects)>,
            caches: Pool<SingleCaches, CacheMaker>,
            exact: bool,
            dense: Option<AdaptiveDfa>,
            accept_dense: Option<AdaptiveDfa>,
        }
        eprintln!("shape bytes baseline={} inline={} compact={} pair={}", std::mem::size_of::<BaselineShape>(), std::mem::size_of::<InlineShape>(), std::mem::size_of::<SingleSeek>(), std::mem::size_of::<SingleAdaptive>());
        eprintln!("dfa/cache offsets baseline={}/{} inline={}/{} compact={}/{}", std::mem::offset_of!(BaselineShape,dfa),std::mem::offset_of!(BaselineShape,caches),std::mem::offset_of!(InlineShape,dfa),std::mem::offset_of!(InlineShape,caches),std::mem::offset_of!(SingleSeek,dfa),std::mem::offset_of!(SingleSeek,caches));
        let catalog: serde_json::Value = serde_json::from_str(include_str!("../benches/production_regex/catalog.json")).unwrap();
        for case in catalog["cases"].as_array().unwrap() {
            let name=case["id"].as_str().unwrap();
            if !["ipv6_validation","django_email_local_part","uuid_v4","jinja_string_token","jinja_integer_token","semver_version_parse"].contains(&name) { continue; }
            let mut options = ONIG_OPTION_CAPTURE_GROUP.union(crate::oniguruma::ONIG_OPTION_SINGLELINE);
            if case["flags"]["ignore_case"]==true {options=options.union(ONIG_OPTION_IGNORECASE);}
            if case["flags"]["extended"]==true {options=options.union(crate::oniguruma::ONIG_OPTION_EXTEND);}
            if case["flags"]["dotall"]==true {options=options.union(crate::oniguruma::ONIG_OPTION_MULTILINE);}
            let seek=production_single_seek(case["pattern"].as_str().unwrap(),options).unwrap();
            eprintln!("{name}: exact={} nfa={} adaptive={:?} accept_nfa={:?}",seek.exact(),seek.dfa.get_nfa().states().len(),seek.adaptive_consultations(),seek.accept.as_ref().map(|(dfa,_)|dfa.get_nfa().states().len()));
        }
    }
