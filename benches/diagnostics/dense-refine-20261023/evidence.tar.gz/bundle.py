#!/usr/bin/env python3
"""Bundle all completed experimental phases and verify every retained hash."""
import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('root', type=Path)
    parser.add_argument('destination', type=Path)
    args = parser.parse_args()
    audit = json.loads((args.root / 'audit.json').read_text())
    assert audit['all_phases_serial'] and audit['all_final6_phases_complete']
    expected = {'final6-focus-confirm', 'final6-broad-confirm', 'final6-previous-confirm', 'final6-startup-confirm', 'final6-reuse-confirm', 'final6-reuse-previous', 'final6-capture-aa-long', 'final6-capture-long'}
    assert {row['phase'] for row in audit['phases'] if row['phase'].startswith('final6-')} == expected
    names = [row['phase'] for row in audit['phases']] + ['sources', 'tool-dependencies', 'gate-logs', 'post-promotion-oracles']
    files = [path for path in args.root.iterdir() if path.is_file()
             and path.suffix in {'.json', '.log', '.txt', '.patch', '.py', '.md', '.jsonl', '.rs'}
             and path.name != 'archive-audit.json']
    for name in names:
        directory = args.root / name
        assert directory.is_dir(), directory
        for path in directory.rglob('*'):
            assert not path.is_symlink(), path
            if path.is_file():
                files.append(path)
    files.sort(key=lambda path: path.relative_to(args.root).as_posix())
    assert len(set(files)) == len(files)
    manifest = {path.relative_to(args.root).as_posix():
                {'sha256': sha(path.read_bytes()), 'bytes': path.stat().st_size} for path in files}
    encoded = (json.dumps(manifest, indent=2) + '\n').encode()
    output = args.destination / 'evidence.tar.gz'
    with output.open('wb') as raw:
        with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode='w') as archive:
                for path in files:
                    info = archive.gettarinfo(str(path), path.relative_to(args.root).as_posix())
                    info.uid = info.gid = info.mtime = 0
                    info.uname = info.gname = ''
                    info.mode = 0o644
                    with path.open('rb') as source:
                        archive.addfile(info, source)
                info = tarfile.TarInfo('MANIFEST.json')
                info.size = len(encoded)
                info.mode = 0o644
                archive.addfile(info, io.BytesIO(encoded))
    with tarfile.open(output, 'r:gz') as archive:
        assert set(archive.getnames()) == set(manifest) | {'MANIFEST.json'}
        assert json.load(archive.extractfile('MANIFEST.json')) == manifest
        for name, expected in manifest.items():
            data = archive.extractfile(name).read()
            assert len(data) == expected['bytes'] and sha(data) == expected['sha256'], name
    digest = sha(output.read_bytes())
    (args.destination / 'evidence.sha256').write_text(digest + '  evidence.tar.gz\n')
    result = {'files': len(files), 'all_archived_hashes_verified': True, 'incomplete_diagnostics_retained': audit['incomplete_superseded_phases'],
              'archive_bytes': output.stat().st_size, 'archive_sha256': digest,
              'excluded': ['frozen executable bytes (hashes retained)', 'redundant build targets']}
    (args.root / 'archive-audit.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
