"""Run relevant correctness/lint gates serially before freezing timings."""
from datetime import datetime,timezone
from pathlib import Path
import hashlib,json,os,subprocess
r=Path(__file__).resolve().parent;repo=r.parents[1];d=r/'gate-logs';d.mkdir(exist_ok=False)
env=dict(os.environ,PCRE2_SYS_STATIC='1',CARGO_BUILD_JOBS='4',RUST_MIN_STACK='268435456',FERRONI_ONIGURUMA_DIR=str(repo/'.cache/upstream/oniguruma-orig'),FERRONI_ONIGMO_DIR=str(repo/'.cache/upstream/onigmo-ruby'))
commands=[
 ('fmt',['cargo','fmt','--all','--check']),
 ('parity',['cargo','test','--offline','--locked','--features','ffi,prefilter-self-check','--lib','--test','api_test','--test','compat_utf8','--test','compat_back','--test','compat_syntax','--test','compat_options','--test','compat_regset','--test','compat_prefilter_differential','--test','scanner_prefilter_regressions','--test','single_regex_reject','--','--test-threads=1']),
 ('no-default',['cargo','test','--offline','--locked','--no-default-features','--lib']),
 ('clippy',['cargo','clippy','--workspace','--all-targets','--all-features','--offline','--locked','--','-D','warnings']),
]
records=[]
for name,cmd in commands:
 print('START',name,flush=True)
 start=datetime.now(timezone.utc).isoformat()
 with (d/(name+'.log')).open('w') as f:p=subprocess.run(cmd,cwd=repo,env=env,stdout=f,stderr=subprocess.STDOUT)
 records.append({'gate':name,'command':cmd,'started_utc':start,'finished_utc':datetime.now(timezone.utc).isoformat(),'returncode':p.returncode})
 (d/'summary.json').write_text(json.dumps(records,indent=2)+'\n')
 print('DONE',name,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
