from pathlib import Path
p=Path('src/dfa_prefilter.rs');s=p.read_text()
s=s.replace('''        let max_rows =
            max_rows.min(limits.determinize_bytes / std::mem::size_of::<LazyStateID>());''','''        let max_rows = max_rows.min(limits.determinize_bytes / (std::mem::size_of::<TableNode>() + 1));''')
# rustfmt may leave a single-line expression.
s=s.replace('''        let max_rows = max_rows.min(limits.determinize_bytes / std::mem::size_of::<LazyStateID>());''','''        let max_rows = max_rows.min(limits.determinize_bytes / (std::mem::size_of::<TableNode>() + 1));''')
a=s.index('        // IDs 0 and 1 terminate a search.');b=s.index('        let mut starts',a)
s=s[:a]+'''        // IDs 0 and 1 terminate a search. Other IDs are row offsets plus 2.
        fn intern(node: TableNode, states: &mut Vec<TableNode>, stride: usize, max_rows: usize) -> Option<u32> {
            let id = node.id;
            if id.is_quit() || id.is_unknown() { return None; }
            if id.is_match() { return Some(1); }
            if id.is_dead() { return Some(0); }
            let index = match states.iter().position(|known| known.id == id) {
                Some(index) => index,
                None if states.len() < max_rows => { states.push(node); states.len() - 1 }
                None => return None,
            };
            u32::try_from(index * stride + 2).ok()
        }
'''+s[b:]
s=s.replace('''            *slot = intern(id, &mut states, stride, max_rows)?;''','''            *slot = intern(TableNode { id, parent: u32::MAX, byte: 0, context: index as u16 }, &mut states, stride, max_rows)?;''')
a=s.index('        let mut row = 0;',s.index('impl SingleTable'));b=s.index('        let mut map',a)
s=s[:a]+'''        let mut row = 0;
        let mut path = Vec::with_capacity(max_rows);
        let mut steps = 257usize;
        while row < states.len() {
            path.clear();
            let mut ancestor = row;
            while states[ancestor].parent != u32::MAX {
                path.push(states[ancestor].byte);
                ancestor = states[ancestor].parent as usize;
            }
            let context = states[row].context;
            let previous = if context == 256 { None } else { Some(context as u8) };
            for unit in classes.representatives(..) {
                // Public hybrid IDs are only valid for the next transition.
                // Replay this state's path before each outgoing edge rather
                // than using a saved ID as an input to the library.
                steps = steps.checked_add(path.len() + 2)?;
                if steps > 32768 { return None; }
                let mut id = dfa.start_state(cache, &regex_automata::util::start::Config::new().look_behind(previous)).ok()?;
                if cache.clear_count() != generation { return None; }
                for &byte in path.iter().rev() {
                    id = dfa.next_state(cache, id, byte).ok()?;
                    if cache.clear_count() != generation { return None; }
                }
                if id != states[row].id { return None; }
                let next = match unit.as_u8() {
                    Some(byte) => dfa.next_state(cache, id, byte),
                    None => dfa.next_eoi_state(cache, id),
                }.ok()?;
                if cache.clear_count() != generation { return None; }
                let next_id = if let Some(byte) = unit.as_u8() {
                    intern(TableNode { id: next, parent: row as u32, byte, context }, &mut states, stride, max_rows)?
                } else {
                    if next.is_quit() || next.is_unknown() { return None; }
                    u32::from(next.is_match())
                };
                transitions.push(next_id);
            }
            row += 1;
        }
'''+s[b:]
a=s.index('impl SingleTable {')
s=s[:a]+'''/// A shortest byte path recreates a state using only the public hybrid API.
/// Stored IDs are used for equality, never as transition inputs.
struct TableNode {
    id: LazyStateID,
    parent: u32,
    byte: u8,
    context: u16,
}

'''+s[a:]
p.write_text(s)
