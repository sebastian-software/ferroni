from pathlib import Path
import subprocess,sys,json
r=Path(__file__).resolve().parent
cases='django_email_local_part,uuid_v4,jinja_string_token,jinja_integer_token,semver_version_parse,ferrolink_markup_scan,fluent_bit_apache'
phase='screen-exact'
cmd=[sys.executable,str(r/'compare.py'),str(r/'bin/base0001'),str(r/'bin/bits0001'),str(r/phase),'--cases',cases,'--repetitions','8','--alignment-offsets','0,16,32,48','--warmup','.25','--measure','.75','--samples','20','--environment-base','7168','--seed','20261023']
(r/'active-phase.json').write_text(json.dumps({'phase':phase,'command':cmd},indent=2)+'\n')
with (r/(phase+'.log')).open('w') as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
subprocess.run([sys.executable,str(r/'summarize.py'),phase],check=True)
(r/'active-phase.json').write_text('{"phase":"complete"}\n')
