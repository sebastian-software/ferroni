"""Independent longer Semver pair and identical-binary control; no adjustment."""
from datetime import datetime,timezone
from pathlib import Path
import hashlib,json,os,subprocess,sys
r=Path(__file__).resolve().parent;repo=r.parents[1]
manifest=json.loads((r/'binaries.json').read_text());freeze=json.loads((r/'freeze-bits0006.json').read_text());assert freeze['all_builds_and_tests_stopped']
plan={'created_utc':datetime.now(timezone.utc).isoformat(),'reason':'Completed final6 focus Semver median +0.83%, descriptive interval [-0.07,+3.25] leaves a target-sized cost unresolved. Independent longer single-case phases add an identical-binary control without pooling or subtraction.','phases':[['final6-semver-aa-long','base0002','same0001'],['final6-semver-long','base0002','bits0006']],'repetitions':16,'offsets':'0,8,16,24,32,40,48,56','warmup_seconds':1,'measure_seconds':3,'samples':40}
p=r/'semver-confirm-plan.json'
if p.exists():assert json.loads(p.read_text())['phases']==plan['phases']
else:p.write_text(json.dumps(plan,indent=2)+'\n')
# --plan records the decision now; execute only after the full matrix finishes.
if '--plan' in sys.argv:sys.exit(0)
for name,old,new in plan['phases']:
 for b in [old,new]:assert hashlib.sha256((r/'bin'/b).read_bytes()).hexdigest()==manifest[b]['sha256']
 cmd=[sys.executable,str(r/'compare-quiet.py'),str(r/'bin'/old),str(r/'bin'/new),str(r/name),'--cases','semver_version_parse','--lanes','steady','--repetitions','16','--alignment-offsets',plan['offsets'],'--warmup','1','--measure','3','--samples','40','--environment-base','7168','--seed','20261023']
 (r/'active-phase.json').write_text(json.dumps({'phase':name,'command':cmd},indent=2)+'\n');print('START',name,flush=True)
 with (r/(name+'.log')).open('w') as f:subprocess.run(cmd,cwd=repo,stdout=f,stderr=subprocess.STDOUT,check=True)
 c=json.loads((r/name/'context.json').read_text());assert [b['sha256'] for b in c['binaries']]==[manifest[b]['sha256'] for b in [old,new]]
 subprocess.run([sys.executable,str(r/'summarize.py'),name],cwd=repo,check=True);print('DONE',name,flush=True)
(r/'active-phase.json').write_text('{"phase":"complete"}\n')
