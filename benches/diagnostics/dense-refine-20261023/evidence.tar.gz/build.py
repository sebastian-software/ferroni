"""Build retained source snapshots at one canonical package path."""
import hashlib,json,os,re,shutil,subprocess,sys
from pathlib import Path
r=Path(__file__).resolve().parent;repo=r.parents[1]
paths=['Cargo.toml','src/dfa_prefilter.rs','src/api.rs']
original={p:(repo/p).read_bytes() for p in paths}
sha=lambda b:hashlib.sha256(b).hexdigest()
assert subprocess.check_output(['git','branch','--show-current'],cwd=repo,text=True).strip()=='codex/perf-dense-adaptive-refine'
assert sha((repo/'benches/production_regex/runner.rs').read_bytes())==json.loads((r/'context.json').read_text())['harness_sha256']
try:
 for name in sys.argv[1:]:
  target=r/'bin'/name;assert not target.exists()
  sources={p:((r/'sources'/name/Path(p).name).read_bytes() if (r/'sources'/name/Path(p).name).exists() else subprocess.check_output(['git','show','9b85954:'+p],cwd=repo)) for p in paths}
  for p,b in sources.items():(repo/p).write_bytes(b)
  with (r/('build-'+name+'.log')).open('w') as f:
   subprocess.run(['cargo','bench','--locked','--offline','--features','ffi','--bench','production_regex_bench','--no-run'],cwd=repo,env=dict(os.environ,PCRE2_SYS_STATIC='1',CARGO_BUILD_JOBS='4'),stdout=f,stderr=subprocess.STDOUT,check=True)
  log=(r/('build-'+name+'.log')).read_text();assert 'Compiling ferroni v2.4.0' in log
  artifact=re.search(r'Executable benches/production_regex_bench.rs \(([^)]+)\)',log).group(1)
  shutil.copyfile(repo/artifact,target);target.chmod(0o755)
  meta=json.loads((r/'binaries.json').read_text());meta[name]={'sha256':sha(target.read_bytes()),'sources':{p:sha(b) for p,b in sources.items()},'common_regcomp_sha256':sha((repo/'src/regcomp.rs').read_bytes())}
  (r/'binaries.json').write_text(json.dumps(meta,indent=2)+'\n')
  for corpus in ['production','tokenizer']:
   with (r/(name+'-'+corpus+'-validation.jsonl')).open('w') as f:
    subprocess.run([str(target),'--validate'],cwd=repo,env=dict(os.environ,PRODUCTION_ENGINE='rust',PRODUCTION_CORPUS=corpus),stdout=f,check=True)
   rows=(r/(name+'-'+corpus+'-validation.jsonl')).read_text()
   if name!='base0001':assert rows==(r/('base0001-'+corpus+'-validation.jsonl')).read_text()
  print('BUILT AND VALIDATED',name,meta[name]['sha256'],flush=True)
finally:
 for p,b in original.items():(repo/p).write_bytes(b)
