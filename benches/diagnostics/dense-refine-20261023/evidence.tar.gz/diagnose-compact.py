from pathlib import Path
import subprocess,os
r=Path(__file__).resolve().parent;p=Path('src/dfa_prefilter.rs');before=p.read_bytes()
s=before.decode();i=s.rfind('\n}');p.write_text(s[:i]+(r/'compact-diagnostic.rs').read_text()+s[i:])
try:
 with (r/'compact-diagnostic.log').open('w') as f:
  subprocess.run(['cargo','test','--offline','--locked','--lib','compact_metadata_diagnostic','--','--ignored','--nocapture'],env=dict(os.environ,RUST_MIN_STACK='268435456',CARGO_BUILD_JOBS='4'),stdout=f,stderr=subprocess.STDOUT,check=True)
finally:p.write_bytes(before)
