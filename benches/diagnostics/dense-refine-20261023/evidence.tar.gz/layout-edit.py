from pathlib import Path
import subprocess
p=Path('src/dfa_prefilter.rs');s=p.read_text();Path('.cache/perf-dense-refine-20261023/bitset-boxed-source.rs').write_text(s)
base=subprocess.check_output(['git','show','9b85954:src/dfa_prefilter.rs'],text=True)
a=s.index('pub(crate) struct SingleSeek {');b=s.index('/// A bounded boolean DFA',a)
s=s[:a]+'''pub(crate) struct SingleSeek {
    dfa: hybrid::DFA,
    accept: Option<(hybrid::DFA, accept::AcceptRejects)>,
    caches: Pool<SingleCaches, CacheMaker>,
    exact: bool,
    dense: Option<AdaptiveDfa>,
    accept_dense: Option<AdaptiveDfa>,
}

'''+s[b:]
a=s.index('/// An immutable dense DFA,');b=s.index('/// The hybrid automaton remains',a);s=s[:a]+s[b:]
s=s.replace('    hybrid: Box<hybrid::DFA>,\n','').replace('fn new(hybrid: hybrid::DFA, limits: SingleDenseLimits, threshold: usize)', 'fn new(limits: SingleDenseLimits, threshold: usize)').replace('            hybrid: Box::new(hybrid),\n','')
s=s.replace('fn record_hybrid_consultation(&self)', 'fn record_hybrid_consultation(&self, nfa: &thompson::NFA)').replace('SingleTable::build(self.hybrid.get_nfa(), self.limits)','SingleTable::build(nfa, self.limits)')
a=s.index('impl SingleDfa {');b=s.index('#[derive(Clone, Copy)]\nstruct SingleDenseLimits',a);s=s[:a]+s[b:]
s=s.replace('    seek: Option<hybrid::Cache>,','    seek: hybrid::Cache,')
a=s.index('impl SingleSeek {');b=s.index('/// Compile the bounded Thompson NFA',a)
methods=r'''impl SingleSeek {
    pub(crate) fn build(seek: &Seek, accept: Option<&AcceptCode>) -> Option<Self> {
        Self::build_with_adaptive_policy(seek,accept,Some(PREFERRED_SINGLE_DENSE_LIMITS),SINGLE_DENSE_PROMOTION_THRESHOLD)
    }

    fn build_with_adaptive_policy(seek: &Seek, accept: Option<&AcceptCode>, limits: Option<SingleDenseLimits>, threshold: usize) -> Option<Self> {
        Self::assemble(seek,accept,limits,limits,threshold,false)
    }

    #[cfg(test)]
    fn build_with_dense_limits(seek: &Seek, accept: Option<&AcceptCode>, limits: Option<SingleDenseLimits>) -> Option<Self> {
        Self::build_with_separate_dense_limits(seek,accept,limits,limits)
    }

    #[cfg(test)]
    fn build_with_separate_dense_limits(seek: &Seek, accept: Option<&AcceptCode>, seek_limits: Option<SingleDenseLimits>, accept_limits: Option<SingleDenseLimits>) -> Option<Self> {
        Self::assemble(seek,accept,seek_limits,accept_limits,0,true)
    }

    fn assemble(seek: &Seek, accept: Option<&AcceptCode>, seek_limits: Option<SingleDenseLimits>, accept_limits: Option<SingleDenseLimits>, threshold: usize, eager: bool) -> Option<Self> {
        let Seek::Pattern(code)=seek else { return None; };
        let (dfa,dense)=single_dfa_adaptive(&code.decode(),seek_limits,threshold,eager)?;
        let accept=accept.and_then(|accept| {
            let (dfa,dense)=single_dfa_adaptive(&accept.code.decode(),accept_limits,threshold,eager)?;
            Some((dfa,accept.rejects.clone(),dense))
        });
        let (accept,accept_dense)=match accept {
            Some((dfa,rejects,dense))=>(Some((dfa,rejects)),dense),
            None=>(None,None),
        };
        let make_seek=dfa.clone();
        let make_accept=accept.as_ref().map(|(dfa,_)|dfa.clone());
        let caches=Pool::new(Box::new(move||SingleCaches {
            seek:make_seek.create_cache(),
            accept:make_accept.as_ref().map(hybrid::DFA::create_cache),
        }) as CacheMaker);
        Some(Self {dfa,accept,caches,exact:code.exact(),dense,accept_dense})
    }

    /// Boolean search over the complete suffix, with the original hybrid
    /// representation and cache path retained beside the optional table.
    pub(crate) fn search(&self,text:&[u8],start:usize)->Option<bool> {
        if let Some(table)=self.dense.as_ref().and_then(AdaptiveDfa::dense) {
            return Some(table.search(text,start));
        }
        let input=Input::new(text).span(start..text.len()).earliest(true);
        let result={
            let mut caches=self.caches.get();
            self.dfa.try_search_fwd(&mut caches.seek,&input).ok().map(|found|found.is_some())
        };
        if let Some(adaptive)=&self.dense { adaptive.record_hybrid_consultation(self.dfa.get_nfa()); }
        result
    }

    pub(crate) fn exact(&self)->bool {self.exact}
    pub(crate) fn has_accept(&self)->bool {self.accept.is_some()}

    pub(crate) fn accept_answer(&self,text:&[u8],start:usize)->Option<bool> {
        let (dfa,rejects)=self.accept.as_ref()?;
        let found=if let Some(table)=self.accept_dense.as_ref().and_then(AdaptiveDfa::dense) {
            table.search(text,start)
        } else {
            let input=Input::new(text).span(start..text.len()).earliest(true);
            let result={
                let mut caches=self.caches.get();
                dfa.try_search_fwd(caches.accept.as_mut()?,&input).ok().map(|found|found.is_some())
            };
            if let Some(adaptive)=&self.accept_dense { adaptive.record_hybrid_consultation(dfa.get_nfa()); }
            result?
        };
        if found { return Some(true); }
        match rejects {
            accept::AcceptRejects::Unless(triggers)=>(!triggers.occur_in(&text[start..])).then_some(false),
            accept::AcceptRejects::Never=>None,
        }
    }

    #[cfg(test)]
    pub(crate) fn memory_usage(&self)->usize {self.automata_memory_usage()+self.cache_memory_usage()}
    #[cfg(test)]
    fn uses_dense_dfas(&self)->bool {
        self.dense.as_ref().and_then(AdaptiveDfa::dense).is_some()
            && (self.accept.is_none() || self.accept_dense.as_ref().and_then(AdaptiveDfa::dense).is_some())
    }
    #[cfg(test)]
    fn has_cache_pool(&self)->bool {true}
    #[cfg(test)]
    fn backend_names(&self)->(&'static str,Option<&'static str>) {
        (if self.dense.as_ref().and_then(AdaptiveDfa::dense).is_some() {"dense"} else {"hybrid"},
         self.accept.as_ref().map(|_|if self.accept_dense.as_ref().and_then(AdaptiveDfa::dense).is_some(){"dense"}else{"hybrid"}))
    }
    #[cfg(test)]
    fn automata_memory_usage(&self)->usize {
        fn table_bytes(adaptive:Option<&AdaptiveDfa>)->usize {
            adaptive.and_then(AdaptiveDfa::dense).map_or(0,|table|table.memory_usage()+std::mem::size_of_val(table))
        }
        self.dfa.get_nfa().memory_usage()+std::mem::size_of_val(&self.dfa)
            +self.accept.as_ref().map_or(0,|(dfa,_)|dfa.get_nfa().memory_usage()+std::mem::size_of_val(dfa))
            +table_bytes(self.dense.as_ref())+table_bytes(self.accept_dense.as_ref())
    }
    #[cfg(test)]
    fn cache_memory_usage(&self)->usize {
        let caches=self.caches.get();
        caches.seek.memory_usage()+caches.accept.as_ref().map_or(0,hybrid::Cache::memory_usage)
    }
}

'''
s=s[:a]+methods+s[b:]
a=s.index('/// Build a fully precomputed DFA');b=s.index('fn build_single_hybrid',a);s=s[:a]+s[b:]
a=s.index('/// The DFA of a single regex');b=s.index('#[cfg(test)]\nmod tests',a)
s=s[:a]+r'''/// Keep the original hybrid DFA inline. The additional state is present only
/// when this NFA meets the bitset and assertion guards.
fn single_dfa_adaptive(hir:&Hir,limits:Option<SingleDenseLimits>,threshold:usize,eager:bool)->Option<(hybrid::DFA,Option<AdaptiveDfa>)> {
    let (nfa,eligible)=single_nfa(hir)?;
    let dense=if let Some(limits)=limits && eligible && SingleTable::supports(&nfa) {
        let adaptive=AdaptiveDfa::new(limits,threshold);
        if eager { adaptive.initialize_dense_with(||SingleTable::build(&nfa,limits).map(Box::new)); }
        Some(adaptive)
    } else {None};
    Some((build_single_hybrid(nfa)?,dense))
}

'''+s[b:]
s=s.replace('self.dfa.adaptive().map(AdaptiveDfa::consultation_count)','self.dense.as_ref().map(AdaptiveDfa::consultation_count)')
s=s.replace('''self.accept
                    .as_ref()
                    .and_then(|(dfa, _)| dfa.adaptive())''','''self.accept_dense.as_ref()''')
s=s.replace('assert!(!dense.has_cache_pool());','assert!(dense.has_cache_pool(), "the original hybrid pool stays available");')
s=s.replace('assert!(forced.dfa.is_hybrid());','assert_eq!(forced.backend_names().0, "hybrid");')
s=s.replace('adaptive.dfa.adaptive().expect("seek is adaptive")','adaptive.dense.as_ref().expect("seek is adaptive")')
s=s.replace('let enum_bytes = std::mem::size_of::<SingleDfa>();','let adaptive_bytes = std::mem::size_of::<AdaptiveDfa>();').replace('enum={enum_bytes} B','adaptive={adaptive_bytes} B')
p.write_text(s)
