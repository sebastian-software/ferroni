from pathlib import Path
import subprocess,os,sys,shutil,json,hashlib
root=Path.cwd(); cache=root/'.cache/portable-kernel-20261023'; source=cache/'registry-source';stage=cache/'ablations'/sys.argv[1];stage.mkdir(exist_ok=False)
for name in ['src/dfa_prefilter/portable.rs','src/dfa_prefilter.rs','examples/scanner_group_archive.rs']:
    shutil.copy2(root/name,source/name)
shutil.copy2(source/'src/dfa_prefilter/portable.rs',stage/'portable.rs')
shutil.copy2(source/'src/dfa_prefilter.rs',stage/'dfa_prefilter.rs')
env={**os.environ,'CARGO_TARGET_DIR':str(root/'.cache/portable-eager-20261023/registry-source/target')}
p=subprocess.run(['cargo','build','--offline','--locked','--release','--features','portable-eager-prototype','--example','scanner_group_archive','--message-format=json'],cwd=source,env=env,capture_output=True,text=True)
(stage/'build.log').write_text(p.stdout+p.stderr);assert p.returncode==0
records=[json.loads(line) for line in p.stdout.splitlines() if line.startswith('{')]
exe=next(r['executable'] for r in reversed(records) if r.get('reason')=='compiler-artifact' and r.get('executable') and r['target']['name']=='scanner_group_archive')
shutil.copy2(exe,stage/'driver')
(stage/'source-sha256.json').write_text(json.dumps({name:hashlib.sha256((source/name).read_bytes()).hexdigest() for name in ['src/dfa_prefilter/portable.rs','src/dfa_prefilter.rs','examples/scanner_group_archive.rs','Cargo.toml','Cargo.lock']},indent=2)+'\n')
print('Built',sys.argv[1])
