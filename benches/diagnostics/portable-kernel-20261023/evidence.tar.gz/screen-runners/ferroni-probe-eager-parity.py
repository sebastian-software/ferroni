from pathlib import Path
import subprocess,json,statistics
root=Path.cwd();cache=root/'.cache/portable-kernel-20261023';art=root/'.cache/portable-eager-20261023/artifacts';stages=['eager','walk','control'];cases=['cpp','scss','java','json','rust','html','astro','tsx','c','php'];rows=[]
for rep in range(3):
    for case in cases[rep:]+cases[:rep]:
        for stage in stages[rep:]+stages[:rep]:
            p=subprocess.run([str(cache/'bin/eager') if stage == 'eager' else str(cache/'ablations/walk/driver'),'search-probe',case,str(art),('eager' if stage == 'eager' else 'control' if stage == 'control' else 'portable'),'40'],check=True,capture_output=True,text=True,timeout=60)
            row=json.loads(p.stdout);row.update(stage=stage,repetition=rep+1);rows.append(row)
            (cache/'parity-probe-samples.json').write_text(json.dumps(rows,indent=2)+'\n')
    print('Completed probe repetition',rep+1,flush=True)
summary=[]
for case in cases:
    med={stage:statistics.median(statistics.mean(x['samples_ns']) for x in rows if x['corpus']==case and x['stage']==stage) for stage in stages}
    summary.append({'corpus':case,'median_process_mean_ns':med,'sequential_change_percent':{b:(med[b]/med[a]-1)*100 for a,b in zip(stages,stages[1:])}})
(cache/'parity-probe-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
