from pathlib import Path
import subprocess,os,time
root=Path('/Users/sebastian/Workspace/.codex/226e/ferroni');old=root/'.cache/portable-eager-20261023';out=root/'.cache/portable-kernel-20261023/profile-before'
for case in ['tsx','html']:
    env={**os.environ,'GROUP_ARCHIVE_CORPUS':case,'GROUP_ARCHIVE_VARIANT':'portable','GROUP_ARCHIVE_DIR':str(old/'artifacts'),'GROUP_ARCHIVE_OUTPUT':str(out/'criterion'/case)}
    with (out/f'{case}-host.log').open('w') as log:
        p=subprocess.Popen([str(old/'bin/portable-bench'),'--bench','search','--profile-time','8','--noplot'],cwd=root,env=env,stdout=log,stderr=log)
        time.sleep(1)
        result=subprocess.run(['sample',str(p.pid),'5','1','-file',str(out/f'{case}-host.sample.txt')],capture_output=True,text=True)
        (out/f'{case}-host.sample.log').write_text(result.stdout+result.stderr)
        print(case,'sample exit',result.returncode,flush=True)
        assert p.wait(timeout=40)==0
