#![cfg(feature = "scanner-group-nfa-prototype")]
//! Ordered scanner-group archive round trips and bounded decoder failures.
use ferroni::scanner::group_prototype::GroupKind;
use ferroni::{AccelerationMode, Scanner, ScannerConfig, ScannerFindOptions, ScannerPatternCache};

#[test]
fn group_archives_preserve_order_duplicates_captures_and_fallback() {
    let config = ScannerConfig::default().acceleration(AccelerationMode::Eager);
    let sets = [
        vec![r"\b[a-z]+\b", r"([0-9]+)", r"^end$", r"(?<=x)y", r"(a)\1"],
        vec![r"([0-9]+)", r"\b[a-z]+\b", r"([0-9]+)"],
        vec![r"\A\z"],
        vec![r"(?<=x)y"],
    ];
    let mut build = ScannerPatternCache::new();
    for set in &sets {
        Scanner::with_pattern_cache(set, &config, &mut build).unwrap();
    }
    let programs = build.export_precompiled().unwrap();
    for kind in kinds() {
        let groups = build.export_group_prototype(kind).unwrap();
        let mut loaded = ScannerPatternCache::new();
        loaded.add_precompiled(ferroni::PrecompiledPatterns::from_bytes(programs.clone()).unwrap());
        let stats = loaded.add_group_prototype(groups).unwrap();
        assert!(stats.nfa + stats.dfa + stats.prepared + stats.portable > 0);
        if kind == GroupKind::Dfa {
            assert!(stats.dfa > 0);
        }
        for mode in [AccelerationMode::Auto, AccelerationMode::Off] {
            let mut cache = ScannerPatternCache::new();
            cache.add_precompiled(
                ferroni::PrecompiledPatterns::from_bytes(programs.clone()).unwrap(),
            );
            cache
                .add_group_prototype(build.export_group_prototype(kind).unwrap())
                .unwrap();
            Scanner::with_pattern_cache(&sets[0], &config.clone().acceleration(mode), &mut cache)
                .unwrap();
            assert_eq!(cache.group_prototype_load_stats(), (0, 0));
        }
        for set in sets
            .iter()
            .chain(std::iter::once(&vec!["missing", "[a-z]+extra"]))
        {
            let mut reference = Scanner::with_config(set, &config).unwrap();
            let mut actual = Scanner::with_pattern_cache(set, &config, &mut loaded).unwrap();
            for subject in ["", "a", "aa xy 12 end", "é 007 word", "end\n", "xx\ny"] {
                for (start, _) in subject
                    .char_indices()
                    .chain(std::iter::once((subject.len(), '\0')))
                {
                    for options in [ScannerFindOptions::NONE, ScannerFindOptions::from_bits(7)] {
                        assert_eq!(
                            actual.find_next_match(subject, start, options),
                            reference.find_next_match(subject, start, options),
                            "{kind:?} {set:?} {subject:?} {start}"
                        );
                    }
                }
            }
        }
    }
}

#[test]
fn damaged_group_archive_rejects_or_falls_back() {
    let config = ScannerConfig::default().acceleration(AccelerationMode::Eager);
    let patterns = ["foo", "[0-9]+"];
    let mut build = ScannerPatternCache::new();
    Scanner::with_pattern_cache(&patterns, &config, &mut build).unwrap();
    let programs = build.export_precompiled().unwrap();
    for kind in kinds() {
        let groups = build.export_group_prototype(kind).unwrap();
        let mut damaged = groups.clone();
        *damaged.last_mut().unwrap() ^= 0xFF;
        let mut cache = ScannerPatternCache::new();
        cache.add_precompiled(ferroni::PrecompiledPatterns::from_bytes(programs.clone()).unwrap());
        cache.add_group_prototype(damaged).unwrap();
        let mut scanner = Scanner::with_pattern_cache(&patterns, &config, &mut cache).unwrap();
        assert_eq!(
            scanner
                .find_next_match("foo", 0, ScannerFindOptions::NONE)
                .unwrap()
                .index,
            0
        );
        assert_eq!(cache.group_prototype_load_stats(), (0, 1));
        for end in [0, 8, groups.len() / 2, groups.len() - 1] {
            let mut cache = ScannerPatternCache::new();
            cache.add_precompiled(
                ferroni::PrecompiledPatterns::from_bytes(programs.clone()).unwrap(),
            );
            assert!(cache.add_group_prototype(groups[..end].to_vec()).is_err());
            let mut scanner = Scanner::with_pattern_cache(&patterns, &config, &mut cache).unwrap();
            assert_eq!(
                scanner
                    .find_next_match("foo", 0, ScannerFindOptions::NONE)
                    .unwrap()
                    .index,
                0
            );
        }
    }
}

fn kinds() -> Vec<GroupKind> {
    #[allow(unused_mut)]
    let mut kinds = vec![GroupKind::Nfa];
    #[cfg(feature = "scanner-group-prototype")]
    kinds.push(GroupKind::Dfa);
    #[cfg(feature = "prepared-eager-prototype")]
    kinds.push(GroupKind::PreparedEager);
    #[cfg(feature = "portable-eager-prototype")]
    kinds.push(GroupKind::Portable);
    kinds
}

#[cfg(feature = "portable-eager-prototype")]
#[test]
fn portable_images_can_be_shared_and_exported_again_after_execution() {
    let config = ScannerConfig::default().acceleration(AccelerationMode::Eager);
    let patterns = [r"\b[a-z]+\b", r"(\d+)", r"(?<=prefix:)suffix", r"^end$"];
    let mut producer = ScannerPatternCache::new();
    Scanner::with_pattern_cache(&patterns, &config, &mut producer).unwrap();
    let programs = producer.export_precompiled().unwrap();
    let image = producer
        .export_group_prototype(GroupKind::Portable)
        .unwrap();
    let mut consumer = ScannerPatternCache::new();
    consumer.add_precompiled(ferroni::PrecompiledPatterns::from_bytes(programs).unwrap());
    let stats = consumer.add_group_prototype(image.clone()).unwrap();
    assert_eq!(stats.portable, 1);
    let mut loaded = Scanner::with_pattern_cache(&patterns, &config, &mut consumer).unwrap();
    let mut ordinary = Scanner::with_config(&patterns, &config).unwrap();
    for subject in ["word 123", "prefix:suffix", "é end\n", "", "unseen input"] {
        for start in subject
            .char_indices()
            .map(|(at, _)| at)
            .chain([subject.len()])
        {
            assert_eq!(
                loaded.find_next_match(subject, start, ScannerFindOptions::NONE),
                ordinary.find_next_match(subject, start, ScannerFindOptions::NONE)
            );
        }
    }
    assert_eq!(consumer.group_prototype_load_stats(), (1, 0));
    assert_eq!(
        consumer
            .export_group_prototype(GroupKind::Portable)
            .unwrap(),
        image
    );
    // A different experimental representation must not accidentally serialize
    // the unused compatibility handles instead of the actual loaded image.
    assert!(consumer.export_group_prototype(GroupKind::Nfa).is_err());
}

#[cfg(feature = "prepared-eager-prototype")]
#[test]
fn exact_eager_snapshot_survives_loading_and_search_without_rebuilding() {
    let config = ScannerConfig::default().acceleration(AccelerationMode::Eager);
    let sets = [
        vec![
            r"(?:alpha|beta|gamma|delta)",
            r"[a-z]+@example\.com",
            r"(?<=prefix:)suffix",
            r"\b[A-Z]\w*",
        ],
        vec![
            r".*(?:rare-one|rare-two|rare-three)",
            r"[a-z]++:end",
            r"^anchor",
            r"(?i)(?:foo|bar|baz)",
        ],
    ];
    let mut producer = ScannerPatternCache::new();
    for patterns in &sets {
        Scanner::with_pattern_cache(patterns, &config, &mut producer).unwrap();
    }
    let programs = producer.export_precompiled().unwrap();
    let snapshot = producer
        .export_group_prototype(GroupKind::PreparedEager)
        .unwrap();
    let mut ordinary = ScannerPatternCache::new();
    ordinary.add_precompiled(ferroni::PrecompiledPatterns::from_bytes(programs.clone()).unwrap());
    for patterns in &sets {
        Scanner::with_pattern_cache(patterns, &config, &mut ordinary).unwrap();
    }
    // The ordinary v2 loader also fills an unused ASCII map cache for
    // non-Map optimizers. Compare its observable behavior below; exact byte
    // preservation is checked against the producer snapshot after searching.
    let mut consumer = ScannerPatternCache::new();
    consumer.add_precompiled(ferroni::PrecompiledPatterns::from_bytes(programs).unwrap());
    let stats = consumer.add_group_prototype(snapshot.clone()).unwrap();
    for patterns in &sets {
        let mut loaded = Scanner::with_pattern_cache(patterns, &config, &mut consumer).unwrap();
        let mut reference = Scanner::with_pattern_cache(patterns, &config, &mut ordinary).unwrap();
        for subject in [
            "alpha beta PREFIX:foo",
            "rare-two name@example.com",
            "ABC foo:endsuffix",
            "anchor",
            "é ☃",
        ] {
            for (at, _) in subject.char_indices() {
                assert_eq!(
                    loaded.find_next_match(subject, at, ScannerFindOptions::NONE),
                    reference.find_next_match(subject, at, ScannerFindOptions::NONE)
                );
            }
        }
    }
    assert_eq!(
        consumer.prepared_program_load_stats(),
        (stats.prepared_programs, 0)
    );
    assert_eq!(consumer.group_prototype_load_stats(), (sets.len(), 0));
    // The original exact state variants, metadata, plans, and literal tables
    // survive a fresh process-style load, including after mutable caches warm.
    assert_eq!(
        consumer
            .export_group_prototype(GroupKind::PreparedEager)
            .unwrap(),
        snapshot
    );
    consumer.clear_precompiled();
    assert_eq!(consumer.group_prototype_load_stats(), (0, 0));
}

#[cfg(feature = "prepared-eager-prototype")]
#[test]
fn dependency_snapshots_preserve_literal_representations_and_reject_truncation() {
    use aho_corasick::{AhoCorasick, AhoCorasickKind, MatchKind};
    for kind in [AhoCorasickKind::DFA, AhoCorasickKind::ContiguousNFA] {
        let ac = AhoCorasick::builder()
            .kind(Some(kind))
            .match_kind(MatchKind::LeftmostFirst)
            .build(["alpha", "alphabet", "beta", "gamma"])
            .unwrap();
        let bytes = ac.ferroni_snapshot().unwrap();
        let loaded =
            AhoCorasick::from_ferroni_snapshot(&bytes).unwrap_or_else(|| panic!("failed {kind:?}"));
        assert_eq!(loaded.kind(), kind);
        assert_eq!(loaded.ferroni_snapshot().unwrap(), bytes);
        for text in ["alphabet beta", "gamma", "xalpha", "no matches", ""] {
            assert_eq!(ac.find(text), loaded.find(text));
        }
        for end in 0..bytes.len() {
            assert!(AhoCorasick::from_ferroni_snapshot(&bytes[..end]).is_none());
        }
    }
    use regex_automata::nfa::thompson::{self, NFA};
    let nfa = NFA::compiler()
        .configure(
            thompson::Config::new()
                .utf8(false)
                .which_captures(thompson::WhichCaptures::None),
        )
        .build_many(&[r"\bfoo|bar", r"[a-z]+[0-9]"])
        .unwrap();
    let bytes = nfa.ferroni_snapshot().unwrap();
    assert_eq!(
        NFA::from_ferroni_snapshot(&bytes)
            .unwrap()
            .ferroni_snapshot()
            .unwrap(),
        bytes
    );
    for end in 0..bytes.len() {
        assert!(NFA::from_ferroni_snapshot(&bytes[..end]).is_none());
    }
}
