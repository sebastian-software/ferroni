//! Exact immutable program helpers for the local Eager archive experiment.
use crate::regint::{MapAsciiRanges, OptimizeType, RegexType};
use crate::scanner::{
    PrecompiledError,
    precompiled::wire::{Reader, Wire},
};
type Result<T> = std::result::Result<T, PrecompiledError>;

pub(crate) fn write_ac(ac: &Option<aho_corasick::AhoCorasick>, out: &mut Vec<u8>) -> Result<()> {
    ac.is_some().write(out)?;
    if let Some(ac) = ac {
        ac.ferroni_snapshot()
            .ok_or(PrecompiledError::NonportablePattern)?
            .write(out)?;
    }
    Ok(())
}
pub(crate) fn read_ac(input: &mut Reader<'_>) -> Result<Option<aho_corasick::AhoCorasick>> {
    if !bool::read(input)? {
        return Ok(None);
    }
    let bytes = Vec::<u8>::read(input)?;
    let ac = aho_corasick::AhoCorasick::from_ferroni_snapshot(&bytes);
    ac.map(Some).ok_or(PrecompiledError::InvalidData)
}
pub(crate) fn export_program_helpers(reg: &RegexType) -> Result<Vec<u8>> {
    super::prepare_program(reg);
    let mut out = Vec::new();
    reg.pure_literal.write(&mut out)?;
    reg.skip_repeated_empty_search.write(&mut out)?;
    reg.map_ascii_ranges.write_prepared(&mut out)?;
    reg.ac_alt_has_capture.write(&mut out)?;
    write_ac(&reg.ac_alt, &mut out)?;
    crate::leading_run::write_prepared(reg, &mut out)?;
    if let Some(literals) = &reg.required_literals {
        literals.write_prepared(&mut out)?;
    }
    Ok(out)
}
pub(crate) fn load_program_helpers(reg: &mut RegexType, bytes: &[u8]) -> Result<()> {
    let mut input = Reader::new(bytes);
    reg.pure_literal = Wire::read(&mut input)?;
    reg.skip_repeated_empty_search = Wire::read(&mut input)?;
    reg.map_ascii_ranges = MapAsciiRanges::read_prepared(&mut input)?;
    reg.ac_alt_has_capture = Wire::read(&mut input)?;
    reg.ac_alt = read_ac(&mut input)?;
    crate::leading_run::load_prepared(reg, &mut input)?;
    if let Some(literals) = &mut reg.required_literals {
        literals.load_prepared(&mut input)?;
    }
    // A memmem finder contains target CPU dispatch. Bind that cheap handle
    // locally; bytecode analysis and literal-automaton compilation are skipped.
    reg.exact_finder = (reg.optimize == OptimizeType::StrFast && reg.exact.len() > 1)
        .then(|| Box::new(memchr::memmem::Finder::new(&reg.exact).into_owned()));
    input.done()
}
