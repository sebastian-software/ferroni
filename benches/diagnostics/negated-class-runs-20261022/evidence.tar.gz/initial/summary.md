# Production regex comparison

Host: macOS-27.0.1-arm64-arm-64bit; arm64.

Diagnostic evidence; no publication claim.

Ratios are comparator / Ferroni. Compile and first-use times concern one pattern; steady times concern the complete fixture batch.

Each comparison below uses only its explicitly listed common tasks. Families have equal aggregate weight; architectures are never combined.

## Eligibility

| Case | Engine | Status |
| --- | --- | --- |
| `uuid_shape` | rust | eligible |
| `uuid_v4` | rust | eligible |
| `ipv4_validation` | rust | eligible |
| `ipv6_validation` | rust | eligible |
| `semver_version_parse` | rust | eligible |
| `semver_hyphen_range_captures` | rust | eligible |
| `jinja_string_token` | rust | eligible |
| `jinja_integer_token` | rust | eligible |
| `jinja_float_token` | rust | eligible |
| `django_email_local_part` | rust | eligible |
| `django_email_domain` | rust | eligible |
| `django_url_regex` | rust | eligible |
| `fluent_bit_apache` | rust | eligible |
| `fluent_bit_nginx` | rust | eligible |
| `rails_underscore_regex_step` | rust | eligible |
| `mastodon_hashtag_regex_step` | rust | eligible |
| `python_markdown_smart_emphasis_re` | rust | eligible |
| `python_markdown_smart_strong_em_re` | rust | eligible |
| `wordpress_shortcode_captures` | rust | eligible |
| `symfony_grapheme_chunks_1` | rust | eligible |
| `symfony_grapheme_chunks_2` | rust | eligible |
| `literal_first` | rust | eligible |
| `literal_middle` | rust | eligible |
| `literal_end` | rust | eligible |
| `literal_absent` | rust | eligible |
| `linkify_http_tail` | rust | pending |
| `php_cs_fixer_recursive_types` | rust | pending |
| `ferrolink_markup_scan` | rust | eligible |
| `ferrolink_attribute_split` | rust | eligible |

Raw samples, estimates, confidence intervals, failures, eligibility reasons, corpus snapshot and execution order are retained beside this report.

Memory, where requested, is fresh-process peak RSS including the binary, runtime, parsed catalog, compilation, input/output and allocator. It is not isolated compiled-pattern memory.
