"""Local paired Criterion diagnostic using the repository's environment padding."""
import argparse, hashlib, importlib.util, json, os, platform, random, statistics, subprocess
from pathlib import Path
ROOT=Path.cwd()
spec=importlib.util.spec_from_file_location('comparison',ROOT/'scripts/compare-production.py')
comparison=importlib.util.module_from_spec(spec); spec.loader.exec_module(comparison)
p=argparse.ArgumentParser()
p.add_argument('baseline',type=Path);p.add_argument('candidate',type=Path);p.add_argument('output',type=Path)
p.add_argument('--cases',default='ferrolink_markup_scan,ferrolink_attribute_split,wordpress_shortcode_captures,jinja_string_token,tiktoken_cl100k_base,tiktoken_o200k_base')
p.add_argument('--repetitions',type=int,default=3);p.add_argument('--warmup',type=float,default=.3);p.add_argument('--measure',type=float,default=1);p.add_argument('--samples',type=int,default=20)
p.add_argument('--lanes',default='steady');p.add_argument('--engines',default='rust')
a=p.parse_args();comparison.LANES=a.lanes.split(',');out=a.output.resolve();out.mkdir(parents=True,exist_ok=False)
binaries=[a.baseline.resolve(),a.candidate.resolve()]
assert len(os.fsencode(binaries[0]))==len(os.fsencode(binaries[1])), 'binary path lengths must agree'
catalogs={k:json.loads((ROOT/f'benches/{v}/catalog.json').read_text()) for k,v in [('production','production_regex'),('tokenizer','tokenizer_regex')]}
case_corpus={c['id']:k for k,d in catalogs.items() for c in d['cases'] if c.get('inputs')}
cases=list(case_corpus) if a.cases=='all' else a.cases.split(',')
rows=[]
ctx=dict(diagnostic=True,baseline_commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),rustc=subprocess.check_output(['rustc','-Vv'],text=True),platform=platform.platform(),args=vars(a).copy(),binaries=[dict(path=str(b),sha256=hashlib.sha256(b.read_bytes()).hexdigest()) for b in binaries],environment_sizes=[],order=[])
ctx['args']={k:str(v) if isinstance(v,Path) else v for k,v in ctx['args'].items()}
for rep in range(a.repetitions):
 pairs=[(c,e) for c in cases for e in a.engines.split(',')]
 random.Random(20261022+rep).shuffle(pairs)
 jobs=[]
 for ci,(case,engine) in enumerate(pairs):
  for which in ([0,1] if (rep+ci)%2==0 else [1,0]):
   raw=out/f'raw/{rep}/{case}/{engine}/{which}'
   env=dict(os.environ,PRODUCTION_CASE=case,PRODUCTION_ENGINE=engine,PRODUCTION_CORPUS=case_corpus[case],CRITERION_HOME=str(raw))
   env.pop('PRODUCTION_LANE_BUDGETS',None)
   jobs.append((case,engine,which,raw,env))
 size=comparison.aligned_size([job[-1] for job in jobs],rep);ctx['environment_sizes'].append(size)
 for case,engine,which,raw,env in jobs:
  raw.mkdir(parents=True)
  filt=f'/({a.lanes.replace(",","|")})/{engine}$'
  cmd=[str(binaries[which]),'--bench','--noplot','--sample-size',str(a.samples),'--nresamples','10000','--warm-up-time',str(a.warmup),'--measurement-time',str(a.measure),filt]
  ctx['order'].append(dict(repetition=rep,case=case,engine=engine,variant=which,command=cmd))
  (out/'context.json').write_text(json.dumps(ctx,indent=2)+'\n')
  with (raw/'process.log').open('w') as log:
   subprocess.run(cmd,env=comparison.aligned_environment(env,size),stdout=log,stderr=subprocess.STDOUT,check=True,timeout=90)
  lanes=comparison.estimates(raw,case,engine)
  if not lanes: raise RuntimeError(f'no measurements: {case} {engine}')
  rows.append(dict(repetition=rep,case=case,engine=engine,variant=which,lanes=lanes))
  (out/'measurements.json').write_text(json.dumps(rows,indent=2)+'\n')
  print(rep+1,case,engine,which,' '.join(f'{k}={v["ns"]:.1f}ns' for k,v in lanes.items()),flush=True)
summary=[]
for case in cases:
 for engine in a.engines.split(','):
  for lane in a.lanes.split(','):
   base=[r['lanes'][lane]['ns'] for r in rows if r['case']==case and r['engine']==engine and r['variant']==0]
   cand=[r['lanes'][lane]['ns'] for r in rows if r['case']==case and r['engine']==engine and r['variant']==1]
   changes=[100*(c/b-1) for b,c in zip(base,cand)]
   summary.append(dict(case=case,engine=engine,lane=lane,baseline_ns=statistics.median(base),candidate_ns=statistics.median(cand),changes_percent=changes,median_change_percent=statistics.median(changes)))
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for r in summary: print(r['case'],r['engine'],r['lane'],f'{r["median_change_percent"]:+.2f}%',r['changes_percent'])
