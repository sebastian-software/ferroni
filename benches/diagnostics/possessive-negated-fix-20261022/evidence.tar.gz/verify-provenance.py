"""Verify the selected source and every retained timing's frozen binary."""
import hashlib
import json
from pathlib import Path
import subprocess


root = Path(__file__).resolve().parent
report = Path('benches/diagnostics/possessive-negated-fix-20261022')
context = json.loads((root / 'context.json').read_text())
phases = json.loads((root / 'audit.json').read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == context['baseline_commit']
assert sha('src/regexec.rs') == context['source_sha256'] == sha(root / 'helper02.rs')
assert sha('Cargo.lock') == context['lock_sha256']
for path, expected in context['corpus_sha256'].items():
    assert sha(path) == expected, path
assert subprocess.check_output(['rustc', '-Vv'], text=True) == context['rustc']
validation = json.loads((root / 'validation.json').read_text())
assert validation['source_sha256'] == context['source_sha256']
assert validation['full_test_exit_code'] == 0
assert sha('target/release/deps/production_regex_bench-d0e46610545d739f') == sha(root / 'helper02')

runners = {sha(path): path.name for path in [root / 'compare-original.py', root / 'compare-fixed-base.py']}
assert sha(report / 'compare.py') in runners
binaries = {}
verified = []
for phase in phases:
    run = json.loads((root / phase['directory'] / 'context.json').read_text())
    assert run['checkout_commit'] == context['baseline_commit']
    assert run['runner_sha256'] in runners
    assert run['rustc'] == context['rustc']
    for binary in run['binaries']:
        path = Path(binary['path'])
        assert path.parent == root
        if path.name not in binaries:
            binaries[path.name] = sha(path)
        assert binary['sha256'] == binaries[path.name], (phase['directory'], path.name)
    assert run['binaries'][0]['sha256'] == context['binaries']['baseline']
    verified.append({'phase': phase['directory'], 'runner': runners[run['runner_sha256']],
                     'binary_names': [Path(x['path']).name for x in run['binaries']]})

result = {'source_matches_full_test_validation': True,
          'selected_build_is_byte_identical_to_frozen_binary': True,
          'head_lockfile_and_corpora_unchanged': True,
          'all_recorded_binary_and_runner_hashes_verified': True,
          'source_sha256': context['source_sha256'],
          'binaries': binaries, 'phases': verified}
(root / 'provenance-audit.json').write_text(json.dumps(result, indent=2) + '\n')
print(len(verified), 'phases; frozen binaries, runners, source, lockfile, and corpora verified')
