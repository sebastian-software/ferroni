import json,statistics
from pathlib import Path
root=Path(__file__).resolve().parent
for name in ['control-aa','broad']:
 p=root/name/'measurements.json'
 if not p.exists(): continue
 rows=json.loads(p.read_text());print(name,len(rows),'process records')
 for case in ['semver_hyphen_range_captures','semver_version_parse','ferrolink_markup_scan','jinja_string_token']:
  selected=[r for r in rows if r['case']==case];pairs={}
  for r in selected:pairs.setdefault(r['repetition'],{})[r['variant']]=r['lanes']['steady']['ns']
  changes=[100*(p[1]/p[0]-1) for p in pairs.values() if len(p)==2]
  if changes:print(case,len(changes),'pairs',round(statistics.median(changes),2),'percent')
