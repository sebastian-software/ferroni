    #[test]
    fn diagnostic_semver_opcode_census() {
        let catalog: serde_json::Value = serde_json::from_str(include_str!("../benches/production_regex/catalog.json")).unwrap();
        for case in catalog["cases"].as_array().unwrap().iter().filter(|c| c["id"].as_str().unwrap().starts_with("semver_")) {
            let reg = compile_full(case["pattern"].as_str().unwrap().as_bytes());
            let mut counts = std::collections::BTreeMap::new();
            for op in &reg.ops { *counts.entry(format!("{:?}", op.opcode)).or_insert(0) += 1; }
            println!("{}: {:?}", case["id"], counts);
            assert!(!reg.ops.iter().any(|op| op.opcode == OpCode::CClassNotStar));
        }
    }

