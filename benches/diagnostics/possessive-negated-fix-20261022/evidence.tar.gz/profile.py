import os, subprocess, time, sys
from pathlib import Path
root=Path(__file__).resolve().parent
case='semver_hyphen_range_captures'
for variant in sys.argv[1:]:
    env=dict(os.environ,PRODUCTION_CASE=case,PRODUCTION_ENGINE='rust',PRODUCTION_CORPUS='production')
    process=subprocess.Popen([str(root/variant),'--steady','100000000'],env=env,stdout=subprocess.DEVNULL)
    try:
        time.sleep(1)
        subprocess.run(['/usr/bin/sample',str(process.pid),'5','1','-file',str(root/(variant+'.sample.txt'))],check=True)
    finally:
        process.terminate()
        process.wait()
