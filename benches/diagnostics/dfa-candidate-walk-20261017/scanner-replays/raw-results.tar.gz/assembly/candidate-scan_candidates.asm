
/private/tmp/ferroni-dfa-replay-20261017/binaries/candidate/cpp_scanner_bench:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100203b00 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates>:
100203b00: d10543ff    	sub	sp, sp, #0x150
100203b04: a90f6ffc    	stp	x28, x27, [sp, #0xf0]
100203b08: a91067fa    	stp	x26, x25, [sp, #0x100]
100203b0c: a9115ff8    	stp	x24, x23, [sp, #0x110]
100203b10: a91257f6    	stp	x22, x21, [sp, #0x120]
100203b14: a9134ff4    	stp	x20, x19, [sp, #0x130]
100203b18: a9147bfd    	stp	x29, x30, [sp, #0x140]
100203b1c: 910503fd    	add	x29, sp, #0x140
100203b20: aa0203f5    	mov	x21, x2
100203b24: f944080f    	ldr	x15, [x0, #0x810]
100203b28: f9440c0e    	ldr	x14, [x0, #0x818]
100203b2c: f9442017    	ldr	x23, [x0, #0x840]
100203b30: f944240c    	ldr	x12, [x0, #0x848]
100203b34: f9445018    	ldr	x24, [x0, #0x8a0]
100203b38: 3962d01a    	ldrb	w26, [x0, #0x8b4]
100203b3c: f9442c09    	ldr	x9, [x0, #0x858]
100203b40: f9443008    	ldr	x8, [x0, #0x860]
100203b44: a909a3e9    	stp	x9, x8, [sp, #0x98]
100203b48: f944380d    	ldr	x13, [x0, #0x870]
100203b4c: f9443c1b    	ldr	x27, [x0, #0x878]
100203b50: f94010b0    	ldr	x16, [x5, #0x20]
100203b54: 91000448    	add	x8, x2, #0x1
100203b58: a9368ba3    	stp	x3, x2, [x29, #-0x98]
100203b5c: eb08007f    	cmp	x3, x8
100203b60: 540036c8    	b.hi	0x100204238 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x738>
100203b64: aa0303f9    	mov	x25, x3
100203b68: aa0103f6    	mov	x22, x1
100203b6c: aa0003f3    	mov	x19, x0
100203b70: b40005c3    	cbz	x3, 0x100203c28 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x128>
100203b74: d1000728    	sub	x8, x25, #0x1
100203b78: eb15011f    	cmp	x8, x21
100203b7c: 54000562    	b.hs	0x100203c28 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x128>
100203b80: 38686adc    	ldrb	w28, [x22, x8]
100203b84: f9414a68    	ldr	x8, [x19, #0x290]
100203b88: f9414e69    	ldr	x9, [x19, #0x298]
100203b8c: f941526a    	ldr	x10, [x19, #0x2a0]
100203b90: f941566b    	ldr	x11, [x19, #0x2a8]
100203b94: aa090108    	orr	x8, x8, x9
100203b98: aa0b0149    	orr	x9, x10, x11
100203b9c: aa090108    	orr	x8, x8, x9
100203ba0: b4001128    	cbz	x8, 0x100203dc4 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x2c4>
100203ba4: 910a4268    	add	x8, x19, #0x290
100203ba8: 53077f89    	lsr	w9, w28, #7
100203bac: 8b295108    	add	x8, x8, w9, uxtw #4
100203bb0: a9402109    	ldp	x9, x8, [x8]
100203bb4: 92401b8a    	and	x10, x28, #0x7f
100203bb8: 2a3c03eb    	mvn	w11, w28
100203bbc: aa0c03f1    	mov	x17, x12
100203bc0: d37ff90c    	lsl	x12, x8, #1
100203bc4: 9acb218b    	lsl	x11, x12, x11
100203bc8: aa1103ec    	mov	x12, x17
100203bcc: 9adc2529    	lsr	x9, x9, x28
100203bd0: aa090169    	orr	x9, x11, x9
100203bd4: 9adc2508    	lsr	x8, x8, x28
100203bd8: f27a015f    	tst	x10, #0x40
100203bdc: 9a891108    	csel	x8, x8, x9, ne
100203be0: 36000f28    	tbz	w8, #0x0, 0x100203dc4 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x2c4>
100203be4: 52800094    	mov	w20, #0x4               ; =4
100203be8: 51000e88    	sub	w8, w20, #0x3
100203bec: 52800049    	mov	w9, #0x2                ; =2
100203bf0: 71000a9f    	cmp	w20, #0x2
100203bf4: 1a898108    	csel	w8, w8, w9, hi
100203bf8: 340013a8    	cbz	w8, 0x100203e6c <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x36c>
100203bfc: 7100051f    	cmp	w8, #0x1
100203c00: 54001441    	b.ne	0x100203e88 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x388>
100203c04: b4003a59    	cbz	x25, 0x10020434c <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x84c>
100203c08: 52800200    	mov	w0, #0x10               ; =16
100203c0c: 94058d9d    	bl	0x100367280 <dyld_stub_binder+0x100367280>
100203c10: b4003700    	cbz	x0, 0x1002042f0 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x7f0>
100203c14: d1000728    	sub	x8, x25, #0x1
100203c18: 3900001f    	strb	wzr, [x0]
100203c1c: 3900041c    	strb	w28, [x0, #0x1]
100203c20: f9000408    	str	x8, [x0, #0x8]
100203c24: 1400009f    	b	0x100203ea0 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x3a0>
100203c28: a9063ff0    	stp	x16, x15, [sp, #0x60]
100203c2c: a90713ee    	stp	x14, x4, [sp, #0x70]
100203c30: f90043ed    	str	x13, [sp, #0x80]
100203c34: 52800043    	mov	w3, #0x2                ; =2
100203c38: 11001860    	add	w0, w3, #0x6
100203c3c: f942ea61    	ldr	x1, [x19, #0x5d0]
100203c40: eb00003f    	cmp	x1, x0
100203c44: 54000d29    	b.ls	0x100203de8 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x2e8>
100203c48: f942e668    	ldr	x8, [x19, #0x5c8]
100203c4c: b860791c    	ldr	w28, [x8, x0, lsl #2]
100203c50: 37f8339c    	tbnz	w28, #0x1f, 0x1002042c0 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x7c0>
100203c54: 91040328    	add	x8, x25, #0x100
100203c58: eb15011f    	cmp	x8, x21
100203c5c: 9a953109    	csel	x9, x8, x21, lo
100203c60: 37f00abc    	tbnz	w28, #0x1e, 0x100203db4 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x2b4>
100203c64: a904efec    	stp	x12, x27, [sp, #0x48]
100203c68: d2800000    	mov	x0, #0x0                ; =0
100203c6c: 52800808    	mov	w8, #0x40               ; =64
100203c70: f101031f    	cmp	x24, #0x40
100203c74: 9a888308    	csel	x8, x24, x8, hi
100203c78: 7100035f    	cmp	w26, #0x0
100203c7c: 9a881308    	csel	x8, x24, x8, ne
100203c80: ab080328    	adds	x8, x25, x8
100203c84: da9f3108    	csinv	x8, x8, xzr, lo
100203c88: eb09011f    	cmp	x8, x9
100203c8c: f9002fe9    	str	x9, [sp, #0x58]
100203c90: 9a893108    	csel	x8, x8, x9, lo
100203c94: f9415a6a    	ldr	x10, [x19, #0x2b0]
100203c98: f9415e69    	ldr	x9, [x19, #0x2b8]
100203c9c: a908abe9    	stp	x9, x10, [sp, #0x88]
100203ca0: 9106426b    	add	x11, x19, #0x190
100203ca4: eb08033f    	cmp	x25, x8
100203ca8: 9a88833a    	csel	x26, x25, x8, hi
100203cac: aa1903f4    	mov	x20, x25
100203cb0: aa1c03fb    	mov	x27, x28
100203cb4: 37e80d5c    	tbnz	w28, #0x1d, 0x100203e5c <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x35c>
100203cb8: 36d8013c    	tbz	w28, #0x1b, 0x100203cdc <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x1dc>
100203cbc: 6b1b019f    	cmp	w12, w27
100203cc0: 1a9f17e8    	cset	w8, eq
100203cc4: 0a080008    	and	w8, w0, w8
100203cc8: f943727c    	ldr	x28, [x19, #0x6e0]
100203ccc: eb1c031f    	cmp	x24, x28
100203cd0: 1a8813e8    	csel	w8, wzr, w8, ne
100203cd4: 360002a8    	tbz	w8, #0x0, 0x100203d28 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x228>
100203cd8: 52800020    	mov	w0, #0x1                ; =1
100203cdc: eb14035f    	cmp	x26, x20
100203ce0: 540008a0    	b.eq	0x100203df4 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x2f4>
100203ce4: 38746ac9    	ldrb	w9, [x22, x20]
100203ce8: 38696968    	ldrb	w8, [x11, x9]
100203cec: 12006b6a    	and	w10, w27, #0x7ffffff
100203cf0: f942de61    	ldr	x1, [x19, #0x5b8]
100203cf4: 8b0a0108    	add	x8, x8, x10
100203cf8: eb01011f    	cmp	x8, x1
100203cfc: 54003342    	b.hs	0x100204364 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x864>
100203d00: f942da6a    	ldr	x10, [x19, #0x5b0]
100203d04: b868794a    	ldr	w10, [x10, x8, lsl #2]
100203d08: 37f8032a    	tbnz	w10, #0x1f, 0x100203d6c <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x26c>
100203d0c: 52800008    	mov	w8, #0x0                ; =0
100203d10: aa0a03fb    	mov	x27, x10
100203d14: 37000488    	tbnz	w8, #0x0, 0x100203da4 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x2a4>
100203d18: 91000694    	add	x20, x20, #0x1
100203d1c: 2a1b03fc    	mov	w28, w27
100203d20: 36f7fcbc    	tbz	w28, #0x1e, 0x100203cb4 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x1b4>
100203d24: 14000047    	b	0x100203e40 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x340>
100203d28: f942f262    	ldr	x2, [x19, #0x5e0]
100203d2c: f942f663    	ldr	x3, [x19, #0x5e8]
100203d30: 911dc264    	add	x4, x19, #0x770
100203d34: a94883e1    	ldp	x1, x0, [sp, #0x88]
100203d38: aa1b03e5    	mov	x5, x27
100203d3c: 94000a12    	bl	0x100206584 <__RNvNtCswl2masnNbE_7ferroni13dfa_prefilter12record_match>
100203d40: f943c268    	ldr	x8, [x19, #0x780]
100203d44: f943c669    	ldr	x9, [x19, #0x788]
100203d48: 52800020    	mov	w0, #0x1                ; =1
100203d4c: eb09011f    	cmp	x8, x9
100203d50: 54000d80    	b.eq	0x100203f00 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x400>
100203d54: aa1b03ec    	mov	x12, x27
100203d58: aa1c03f8    	mov	x24, x28
100203d5c: 9106426b    	add	x11, x19, #0x190
100203d60: eb14035f    	cmp	x26, x20
100203d64: 54fffc01    	b.ne	0x100203ce4 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x1e4>
100203d68: 14000023    	b	0x100203df4 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x2f4>
100203d6c: 53185d22    	lsl	w2, w9, #8
100203d70: 91164268    	add	x8, x19, #0x590
100203d74: a93823b3    	stp	x19, x8, [x29, #-0x80]
100203d78: aa0003fc    	mov	x28, x0
100203d7c: d10203a0    	sub	x0, x29, #0x80
100203d80: aa1b03e1    	mov	x1, x27
100203d84: aa0c03fb    	mov	x27, x12
100203d88: 94056c41    	bl	0x10035ee8c <__RNvMs3_NtNtCs2npzAA8bySG_14regex_automata6hybrid3dfaNtB5_4Lazy16cache_next_state>
100203d8c: aa1b03ec    	mov	x12, x27
100203d90: 9106426b    	add	x11, x19, #0x190
100203d94: aa0003e8    	mov	x8, x0
100203d98: aa1c03e0    	mov	x0, x28
100203d9c: aa0103fb    	mov	x27, x1
100203da0: 3607fbc8    	tbz	w8, #0x0, 0x100203d18 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x218>
100203da4: 52800001    	mov	w1, #0x0                ; =0
100203da8: 52800060    	mov	w0, #0x3                ; =3
100203dac: 52800037    	mov	w23, #0x1               ; =1
100203db0: 14000041    	b	0x100203eb4 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x3b4>
100203db4: 52800001    	mov	w1, #0x0                ; =0
100203db8: 52800017    	mov	w23, #0x0               ; =0
100203dbc: 52800000    	mov	w0, #0x0                ; =0
100203dc0: 1400003c    	b	0x100203eb0 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x3b0>
100203dc4: a9063ff0    	stp	x16, x15, [sp, #0x60]
100203dc8: a90713ee    	stp	x14, x4, [sp, #0x70]
100203dcc: f90043ed    	str	x13, [sp, #0x80]
100203dd0: 8b1c0268    	add	x8, x19, x28
100203dd4: 39424103    	ldrb	w3, [x8, #0x90]
100203dd8: 11001860    	add	w0, w3, #0x6
100203ddc: f942ea61    	ldr	x1, [x19, #0x5d0]
100203de0: eb00003f    	cmp	x1, x0
100203de4: 54fff328    	b.hi	0x100203c48 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x148>
100203de8: 900029a2    	adrp	x2, 0x100737000 <_anon.af190ef596d93b7202cb9b72c851791c.6+0x10>
100203dec: 91068042    	add	x2, x2, #0x1a0
100203df0: 9405085b    	bl	0x100345f5c <__RNvNtCsjIpoRzUjyHQ_4core9panicking18panic_bounds_check>
100203df4: eb15035f    	cmp	x26, x21
100203df8: 540002c1    	b.ne	0x100203e50 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x350>
100203dfc: 394a3e68    	ldrb	w8, [x19, #0x28f]
100203e00: 91000500    	add	x0, x8, #0x1
100203e04: 12006b68    	and	w8, w27, #0x7ffffff
100203e08: f942de61    	ldr	x1, [x19, #0x5b8]
100203e0c: 0b000108    	add	w8, w8, w0
100203e10: eb08003f    	cmp	x1, x8
100203e14: 54002cc9    	b.ls	0x1002043ac <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x8ac>
100203e18: f942da69    	ldr	x9, [x19, #0x5b0]
100203e1c: b8687925    	ldr	w5, [x9, x8, lsl #2]
100203e20: 37f826e5    	tbnz	w5, #0x1f, 0x1002042fc <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x7fc>
100203e24: 52800000    	mov	w0, #0x0                ; =0
100203e28: 360027c0    	tbz	w0, #0x0, 0x100204320 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x820>
100203e2c: 52800001    	mov	w1, #0x0                ; =0
100203e30: 52800060    	mov	w0, #0x3                ; =3
100203e34: 52800037    	mov	w23, #0x1               ; =1
100203e38: aa1503f4    	mov	x20, x21
100203e3c: 1400001e    	b	0x100203eb4 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x3b4>
100203e40: 52800001    	mov	w1, #0x0                ; =0
100203e44: 52800017    	mov	w23, #0x0               ; =0
100203e48: 52800000    	mov	w0, #0x0                ; =0
100203e4c: 1400001a    	b	0x100203eb4 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x3b4>
100203e50: f9402ff4    	ldr	x20, [sp, #0x58]
100203e54: eb14035f    	cmp	x26, x20
100203e58: 540005a1    	b.ne	0x100203f0c <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x40c>
100203e5c: 52800001    	mov	w1, #0x0                ; =0
100203e60: 52800017    	mov	w23, #0x0               ; =0
100203e64: 52800040    	mov	w0, #0x2                ; =2
100203e68: 14000013    	b	0x100203eb4 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x3b4>
100203e6c: 52800200    	mov	w0, #0x10               ; =16
100203e70: 94058d04    	bl	0x100367280 <dyld_stub_binder+0x100367280>
100203e74: b40023e0    	cbz	x0, 0x1002042f0 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x7f0>
100203e78: 52800028    	mov	w8, #0x1                ; =1
100203e7c: 39000008    	strb	w8, [x0]
100203e80: f9000419    	str	x25, [x0, #0x8]
100203e84: 14000007    	b	0x100203ea0 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x3a0>
100203e88: 52800200    	mov	w0, #0x10               ; =16
100203e8c: 94058cfd    	bl	0x100367280 <dyld_stub_binder+0x100367280>
100203e90: b4002300    	cbz	x0, 0x1002042f0 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x7f0>
100203e94: 52800068    	mov	w8, #0x3                ; =3
100203e98: 39000008    	strb	w8, [x0]
100203e9c: 2900f014    	stp	w20, w28, [x0, #0x4]
100203ea0: 94058cd1    	bl	0x1003671e4 <dyld_stub_binder+0x1003671e4>
100203ea4: 52800001    	mov	w1, #0x0                ; =0
100203ea8: 52800060    	mov	w0, #0x3                ; =3
100203eac: 52800037    	mov	w23, #0x1               ; =1
100203eb0: aa1903f4    	mov	x20, x25
100203eb4: f9445668    	ldr	x8, [x19, #0x8a8]
100203eb8: cb190289    	sub	x9, x20, x25
100203ebc: 8b090108    	add	x8, x8, x9
100203ec0: f9045668    	str	x8, [x19, #0x8a8]
100203ec4: f942ca69    	ldr	x9, [x19, #0x590]
100203ec8: b4001f09    	cbz	x9, 0x1002042a8 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x7a8>
100203ecc: f902d268    	str	x8, [x19, #0x5a0]
100203ed0: 36000097    	tbz	w23, #0x0, 0x100203ee0 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x3e0>
100203ed4: 52800028    	mov	w8, #0x1                ; =1
100203ed8: 3922d668    	strb	w8, [x19, #0x8b5]
100203edc: 52800040    	mov	w0, #0x2                ; =2
100203ee0: a9547bfd    	ldp	x29, x30, [sp, #0x140]
100203ee4: a9534ff4    	ldp	x20, x19, [sp, #0x130]
100203ee8: a95257f6    	ldp	x22, x21, [sp, #0x120]
100203eec: a9515ff8    	ldp	x24, x23, [sp, #0x110]
100203ef0: a95067fa    	ldp	x26, x25, [sp, #0x100]
100203ef4: a94f6ffc    	ldp	x28, x27, [sp, #0xf0]
100203ef8: 910543ff    	add	sp, sp, #0x150
100203efc: d65f03c0    	ret
100203f00: 52800001    	mov	w1, #0x0                ; =0
100203f04: 52800017    	mov	w23, #0x0               ; =0
100203f08: 17ffffeb    	b	0x100203eb4 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x3b4>
100203f0c: b948b268    	ldr	w8, [x19, #0x8b0]
100203f10: 3100050d    	adds	w13, w8, #0x1
100203f14: b908b26d    	str	w13, [x19, #0x8b0]
100203f18: 54000183    	b.lo	0x100203f48 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x448>
100203f1c: f9402be8    	ldr	x8, [sp, #0x50]
100203f20: d37ef501    	lsl	x1, x8, #2
100203f24: aa0003f4    	mov	x20, x0
100203f28: f94043e0    	ldr	x0, [sp, #0x80]
100203f2c: aa0c03fc    	mov	x28, x12
100203f30: 94058c5c    	bl	0x1003670a0 <dyld_stub_binder+0x1003670a0>
100203f34: aa1c03ec    	mov	x12, x28
100203f38: 9106426b    	add	x11, x19, #0x190
100203f3c: aa1403e0    	mov	x0, x20
100203f40: 5280002d    	mov	w13, #0x1               ; =1
100203f44: b908b26d    	str	w13, [x19, #0x8b0]
100203f48: eb15033f    	cmp	x25, x21
100203f4c: 54002382    	b.hs	0x1002043bc <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x8bc>
100203f50: f94027e8    	ldr	x8, [sp, #0x48]
100203f54: b40013c8    	cbz	x8, 0x1002041cc <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x6cc>
100203f58: d280000e    	mov	x14, #0x0               ; =0
100203f5c: 8b0806ea    	add	x10, x23, x8, lsl #1
100203f60: 38796ac8    	ldrb	w8, [x22, x25]
100203f64: f943c674    	ldr	x20, [x19, #0x788]
100203f68: f943be61    	ldr	x1, [x19, #0x778]
100203f6c: f943ba6f    	ldr	x15, [x19, #0x770]
100203f70: d346fd10    	lsr	x16, x8, #6
100203f74: 52800029    	mov	w9, #0x1                ; =1
100203f78: 9ac82131    	lsl	x17, x9, x8
100203f7c: d10203a2    	sub	x2, x29, #0x80
100203f80: aa1703e9    	mov	x9, x23
100203f84: 14000007    	b	0x100203fa0 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x4a0>
100203f88: f8707848    	ldr	x8, [x2, x16, lsl #3]
100203f8c: ea11011f    	tst	x8, x17
100203f90: 540002e1    	b.ne	0x100203fec <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x4ec>
100203f94: aa0903f7    	mov	x23, x9
100203f98: eb0a013f    	cmp	x9, x10
100203f9c: 540006e0    	b.eq	0x100204078 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x578>
100203fa0: 7840253c    	ldrh	w28, [x9], #0x2
100203fa4: f94053e8    	ldr	x8, [sp, #0xa0]
100203fa8: eb1c011f    	cmp	x8, x28
100203fac: 54001e49    	b.ls	0x100204374 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x874>
100203fb0: f9404fe8    	ldr	x8, [sp, #0x98]
100203fb4: 8b1c1508    	add	x8, x8, x28, lsl #5
100203fb8: 3dc00100    	ldr	q0, [x8]
100203fbc: 3c9803a0    	stur	q0, [x29, #-0x80]
100203fc0: 3dc00500    	ldr	q0, [x8, #0x10]
100203fc4: 3c9903a0    	stur	q0, [x29, #-0x70]
100203fc8: eb1c029f    	cmp	x20, x28
100203fcc: 54fffde9    	b.ls	0x100203f88 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x488>
100203fd0: d346ff88    	lsr	x8, x28, #6
100203fd4: eb01011f    	cmp	x8, x1
100203fd8: 54001d82    	b.hs	0x100204388 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x888>
100203fdc: f86879e8    	ldr	x8, [x15, x8, lsl #3]
100203fe0: 9adc2508    	lsr	x8, x8, x28
100203fe4: 3707fd88    	tbnz	w8, #0x0, 0x100203f94 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x494>
100203fe8: 17ffffe8    	b	0x100203f88 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x488>
100203fec: a90143f1    	stp	x17, x16, [sp, #0x10]
100203ff0: a90207ef    	stp	x15, x1, [sp, #0x20]
100203ff4: a9033bea    	stp	x10, x14, [sp, #0x30]
100203ff8: 290833ed    	stp	w13, w12, [sp, #0x40]
100203ffc: f90027e0    	str	x0, [sp, #0x48]
100204000: f9403be8    	ldr	x8, [sp, #0x70]
100204004: eb1c011f    	cmp	x8, x28
100204008: 54001e49    	b.ls	0x1002043d0 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x8d0>
10020400c: a94627e8    	ldp	x8, x9, [sp, #0x60]
100204010: 787c7921    	ldrh	w1, [x9, x28, lsl #1]
100204014: f9403fe0    	ldr	x0, [sp, #0x78]
100204018: aa1903e2    	mov	x2, x25
10020401c: d63f0100    	blr	x8
100204020: 36000160    	tbz	w0, #0x0, 0x10020404c <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x54c>
100204024: a944a3e0    	ldp	x0, x8, [sp, #0x48]
100204028: eb1c011f    	cmp	x8, x28
10020402c: 9106426b    	add	x11, x19, #0x190
100204030: 294833ed    	ldp	w13, w12, [sp, #0x40]
100204034: a9433bea    	ldp	x10, x14, [sp, #0x30]
100204038: 54001d69    	b.ls	0x1002043e4 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x8e4>
10020403c: f94043e8    	ldr	x8, [sp, #0x80]
100204040: b83c790d    	str	w13, [x8, x28, lsl #2]
100204044: 910005ce    	add	x14, x14, #0x1
100204048: 14000005    	b	0x10020405c <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x55c>
10020404c: f94027e0    	ldr	x0, [sp, #0x48]
100204050: 9106426b    	add	x11, x19, #0x190
100204054: 294833ed    	ldp	w13, w12, [sp, #0x40]
100204058: a9433bea    	ldp	x10, x14, [sp, #0x30]
10020405c: f94017e1    	ldr	x1, [sp, #0x28]
100204060: a941bff0    	ldp	x16, x15, [sp, #0x18]
100204064: f9400bf1    	ldr	x17, [sp, #0x10]
100204068: d10203a2    	sub	x2, x29, #0x80
10020406c: 91000af7    	add	x23, x23, #0x2
100204070: eb0a02ff    	cmp	x23, x10
100204074: 54fff861    	b.ne	0x100203f80 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x480>
100204078: b4000aae    	cbz	x14, 0x1002041cc <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x6cc>
10020407c: eb15035f    	cmp	x26, x21
100204080: 9a95834f    	csel	x15, x26, x21, hi
100204084: f9402ff4    	ldr	x20, [sp, #0x58]
100204088: f90053ef    	str	x15, [sp, #0xa0]
10020408c: 14000005    	b	0x1002040a0 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x5a0>
100204090: 52800020    	mov	w0, #0x1                ; =1
100204094: f9402ff4    	ldr	x20, [sp, #0x58]
100204098: eb1a029f    	cmp	x20, x26
10020409c: 54000ae0    	b.eq	0x1002041f8 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x6f8>
1002040a0: eb1a01ff    	cmp	x15, x26
1002040a4: 540017a0    	b.eq	0x100204398 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x898>
1002040a8: 387a6ac9    	ldrb	w9, [x22, x26]
1002040ac: 38696968    	ldrb	w8, [x11, x9]
1002040b0: 12006b6a    	and	w10, w27, #0x7ffffff
1002040b4: f942de61    	ldr	x1, [x19, #0x5b8]
1002040b8: 8b0a0108    	add	x8, x8, x10
1002040bc: eb01011f    	cmp	x8, x1
1002040c0: 54001522    	b.hs	0x100204364 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x864>
1002040c4: f942da6a    	ldr	x10, [x19, #0x5b0]
1002040c8: b8687948    	ldr	w8, [x10, x8, lsl #2]
1002040cc: 37f80528    	tbnz	w8, #0x1f, 0x100204170 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x670>
1002040d0: 52800017    	mov	w23, #0x0               ; =0
1002040d4: aa0803fb    	mov	x27, x8
1002040d8: 37000777    	tbnz	w23, #0x0, 0x1002041c4 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x6c4>
1002040dc: 9100075a    	add	x26, x26, #0x1
1002040e0: 2a1b03e8    	mov	w8, w27
1002040e4: 37f007e8    	tbnz	w8, #0x1e, 0x1002041e0 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x6e0>
1002040e8: 37e80808    	tbnz	w8, #0x1d, 0x1002041e8 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x6e8>
1002040ec: 36dffd68    	tbz	w8, #0x1b, 0x100204098 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x598>
1002040f0: 6b1b019f    	cmp	w12, w27
1002040f4: 1a9f17e8    	cset	w8, eq
1002040f8: 0a080008    	and	w8, w0, w8
1002040fc: f9437274    	ldr	x20, [x19, #0x6e0]
100204100: eb14031f    	cmp	x24, x20
100204104: 1a8813e8    	csel	w8, wzr, w8, ne
100204108: 3707fc48    	tbnz	w8, #0x0, 0x100204090 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x590>
10020410c: f942f262    	ldr	x2, [x19, #0x5e0]
100204110: f942f663    	ldr	x3, [x19, #0x5e8]
100204114: aa0d03fc    	mov	x28, x13
100204118: b90003ed    	str	w13, [sp]
10020411c: 911dc264    	add	x4, x19, #0x770
100204120: a94883e1    	ldp	x1, x0, [sp, #0x88]
100204124: aa1b03e5    	mov	x5, x27
100204128: f94043e6    	ldr	x6, [sp, #0x80]
10020412c: f9402be7    	ldr	x7, [sp, #0x50]
100204130: aa0e03f8    	mov	x24, x14
100204134: 94000a4a    	bl	0x100206a5c <__RNvNtCswl2masnNbE_7ferroni13dfa_prefilter13record_needed>
100204138: eb00030e    	subs	x14, x24, x0
10020413c: 540009c0    	b.eq	0x100204274 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x774>
100204140: f943c268    	ldr	x8, [x19, #0x780]
100204144: f943c669    	ldr	x9, [x19, #0x788]
100204148: 52800020    	mov	w0, #0x1                ; =1
10020414c: eb09011f    	cmp	x8, x9
100204150: 9106426b    	add	x11, x19, #0x190
100204154: 540004c0    	b.eq	0x1002041ec <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x6ec>
100204158: aa1b03ec    	mov	x12, x27
10020415c: aa1403f8    	mov	x24, x20
100204160: f9402ff4    	ldr	x20, [sp, #0x58]
100204164: aa1c03ed    	mov	x13, x28
100204168: f94053ef    	ldr	x15, [sp, #0xa0]
10020416c: 17ffffcb    	b	0x100204098 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x598>
100204170: 53185d22    	lsl	w2, w9, #8
100204174: 91164268    	add	x8, x19, #0x590
100204178: a93823b3    	stp	x19, x8, [x29, #-0x80]
10020417c: f90027e0    	str	x0, [sp, #0x48]
100204180: d10203a0    	sub	x0, x29, #0x80
100204184: aa1b03e1    	mov	x1, x27
100204188: aa0c03f7    	mov	x23, x12
10020418c: aa0d03fb    	mov	x27, x13
100204190: aa0f03f4    	mov	x20, x15
100204194: aa0e03fc    	mov	x28, x14
100204198: 94056b3d    	bl	0x10035ee8c <__RNvMs3_NtNtCs2npzAA8bySG_14regex_automata6hybrid3dfaNtB5_4Lazy16cache_next_state>
10020419c: aa1c03ee    	mov	x14, x28
1002041a0: aa1403ef    	mov	x15, x20
1002041a4: aa1b03ed    	mov	x13, x27
1002041a8: aa1703ec    	mov	x12, x23
1002041ac: 9106426b    	add	x11, x19, #0x190
1002041b0: aa0003f7    	mov	x23, x0
1002041b4: f94027e0    	ldr	x0, [sp, #0x48]
1002041b8: f9402ff4    	ldr	x20, [sp, #0x58]
1002041bc: aa0103fb    	mov	x27, x1
1002041c0: 3607f8f7    	tbz	w23, #0x0, 0x1002040dc <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x5dc>
1002041c4: 52800060    	mov	w0, #0x3                ; =3
1002041c8: 14000009    	b	0x1002041ec <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x6ec>
1002041cc: 52800017    	mov	w23, #0x0               ; =0
1002041d0: 52800021    	mov	w1, #0x1                ; =1
1002041d4: aa1a03f4    	mov	x20, x26
1002041d8: 52800020    	mov	w0, #0x1                ; =1
1002041dc: 17ffff36    	b	0x100203eb4 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x3b4>
1002041e0: 52800000    	mov	w0, #0x0                ; =0
1002041e4: 14000002    	b	0x1002041ec <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x6ec>
1002041e8: 52800040    	mov	w0, #0x2                ; =2
1002041ec: 52800021    	mov	w1, #0x1                ; =1
1002041f0: aa1a03f4    	mov	x20, x26
1002041f4: 17ffff30    	b	0x100203eb4 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x3b4>
1002041f8: 91040328    	add	x8, x25, #0x100
1002041fc: eb0802bf    	cmp	x21, x8
100204200: 540000a9    	b.ls	0x100204214 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x714>
100204204: 52800017    	mov	w23, #0x0               ; =0
100204208: 52800040    	mov	w0, #0x2                ; =2
10020420c: 52800021    	mov	w1, #0x1                ; =1
100204210: 17ffff29    	b	0x100203eb4 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x3b4>
100204214: 91164261    	add	x1, x19, #0x590
100204218: aa1303e0    	mov	x0, x19
10020421c: aa1b03e2    	mov	x2, x27
100204220: 97fff49a    	bl	0x100201488 <__RNvMs0_NtNtCs2npzAA8bySG_14regex_automata6hybrid3dfaNtB5_3DFA14next_eoi_state>
100204224: 360002c0    	tbz	w0, #0x0, 0x10020427c <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x77c>
100204228: 52800060    	mov	w0, #0x3                ; =3
10020422c: 52800021    	mov	w1, #0x1                ; =1
100204230: 52800037    	mov	w23, #0x1               ; =1
100204234: 17ffff20    	b	0x100203eb4 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x3b4>
100204238: f81783b5    	stur	x21, [x29, #-0x88]
10020423c: d10263a8    	sub	x8, x29, #0x98
100204240: 90000469    	adrp	x9, 0x100290000 <__RNvXs1g_NtCsjIpoRzUjyHQ_4core3fmtRyNtB6_5Debug3fmtCs2npzAA8bySG_14regex_automata+0x150>
100204244: 910b1129    	add	x9, x9, #0x2c4
100204248: a93827a8    	stp	x8, x9, [x29, #-0x80]
10020424c: d10223a8    	sub	x8, x29, #0x88
100204250: b0fff2e9    	adrp	x9, 0x100061000 <__RNvXs_NtNtCsjIpoRzUjyHQ_4core3ops5rangeINtB4_5RangejENtNtB8_3fmt5Debug3fmtB8_+0x3c>
100204254: 91054129    	add	x9, x9, #0x150
100204258: a93927a8    	stp	x8, x9, [x29, #-0x70]
10020425c: d0000b20    	adrp	x0, 0x10036a000 <_anon.64882c1eabbe1c9d1b1908eaf6c4d615.206+0xb7>
100204260: 910b5c00    	add	x0, x0, #0x2d7
100204264: d0002982    	adrp	x2, 0x100736000 <_anon.75a3cae221075a9c115f769f974ea0a5.77+0x1f0>
100204268: 913f6042    	add	x2, x2, #0xfd8
10020426c: d10203a1    	sub	x1, x29, #0x80
100204270: 94050797    	bl	0x1003460cc <__RNvNtCsjIpoRzUjyHQ_4core9panicking9panic_fmt>
100204274: 52800020    	mov	w0, #0x1                ; =1
100204278: 17ffffdd    	b	0x1002041ec <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x6ec>
10020427c: aa0103e5    	mov	x5, x1
100204280: 36d800c1    	tbz	w1, #0x1b, 0x100204298 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x798>
100204284: f942f262    	ldr	x2, [x19, #0x5e0]
100204288: f942f663    	ldr	x3, [x19, #0x5e8]
10020428c: 911dc264    	add	x4, x19, #0x770
100204290: a94883e1    	ldp	x1, x0, [sp, #0x88]
100204294: 940008bc    	bl	0x100206584 <__RNvNtCswl2masnNbE_7ferroni13dfa_prefilter12record_match>
100204298: 52800017    	mov	w23, #0x0               ; =0
10020429c: 52800000    	mov	w0, #0x0                ; =0
1002042a0: 52800021    	mov	w1, #0x1                ; =1
1002042a4: 17ffff04    	b	0x100203eb4 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x3b4>
1002042a8: b0001e80    	adrp	x0, 0x1005d5000 <_anon.4dd95af7101c294943ba620810b52dc3.3+0x1f5>
1002042ac: 91196400    	add	x0, x0, #0x659
1002042b0: f0002982    	adrp	x2, 0x100737000 <_anon.af190ef596d93b7202cb9b72c851791c.6+0x10>
1002042b4: 9106e042    	add	x2, x2, #0x1b8
1002042b8: 528003e1    	mov	w1, #0x1f               ; =31
1002042bc: 940506f5    	bl	0x100345e90 <__RNvNtCsjIpoRzUjyHQ_4core6option13expect_failed>
1002042c0: 91164268    	add	x8, x19, #0x590
1002042c4: a93823b3    	stp	x19, x8, [x29, #-0x80]
1002042c8: d10203a0    	sub	x0, x29, #0x80
1002042cc: 52800021    	mov	w1, #0x1                ; =1
1002042d0: aa0c03f4    	mov	x20, x12
1002042d4: 94056d1b    	bl	0x10035f740 <__RNvMs3_NtNtCs2npzAA8bySG_14regex_automata6hybrid3dfaNtB5_4Lazy17cache_start_group>
1002042d8: aa1403ec    	mov	x12, x20
1002042dc: aa0003f4    	mov	x20, x0
1002042e0: d360fc1c    	lsr	x28, x0, #32
1002042e4: 3100069f    	cmn	w20, #0x1
1002042e8: 54ffc801    	b.ne	0x100203be8 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0xe8>
1002042ec: 17fffe5a    	b	0x100203c54 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x154>
1002042f0: 52800100    	mov	w0, #0x8                ; =8
1002042f4: 52800201    	mov	w1, #0x10               ; =16
1002042f8: 94050444    	bl	0x100345408 <__RNvNtCs6zY7rJBZy9D_5alloc5alloc18handle_alloc_error>
1002042fc: 94026aba    	bl	0x10029ede4 <__RNvMNtNtCs2npzAA8bySG_14regex_automata4util8alphabetNtB2_4Unit3eoi>
100204300: aa0003e2    	mov	x2, x0
100204304: 91164268    	add	x8, x19, #0x590
100204308: a93823b3    	stp	x19, x8, [x29, #-0x80]
10020430c: d10203a0    	sub	x0, x29, #0x80
100204310: aa1b03e1    	mov	x1, x27
100204314: 94056ade    	bl	0x10035ee8c <__RNvMs3_NtNtCs2npzAA8bySG_14regex_automata6hybrid3dfaNtB5_4Lazy16cache_next_state>
100204318: aa0103e5    	mov	x5, x1
10020431c: 3707d880    	tbnz	w0, #0x0, 0x100203e2c <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x32c>
100204320: 36d800c5    	tbz	w5, #0x1b, 0x100204338 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x838>
100204324: f942f262    	ldr	x2, [x19, #0x5e0]
100204328: f942f663    	ldr	x3, [x19, #0x5e8]
10020432c: 911dc264    	add	x4, x19, #0x770
100204330: a94883e1    	ldp	x1, x0, [sp, #0x88]
100204334: 94000894    	bl	0x100206584 <__RNvNtCswl2masnNbE_7ferroni13dfa_prefilter12record_match>
100204338: 52800001    	mov	w1, #0x0                ; =0
10020433c: 52800017    	mov	w23, #0x0               ; =0
100204340: 52800000    	mov	w0, #0x0                ; =0
100204344: aa1503f4    	mov	x20, x21
100204348: 17fffedb    	b	0x100203eb4 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x3b4>
10020434c: b0001e80    	adrp	x0, 0x1005d5000 <_anon.4dd95af7101c294943ba620810b52dc3.3+0x1f5>
100204350: 91179800    	add	x0, x0, #0x5e6
100204354: f0002982    	adrp	x2, 0x100737000 <_anon.af190ef596d93b7202cb9b72c851791c.6+0x10>
100204358: 91008042    	add	x2, x2, #0x20
10020435c: 52800481    	mov	w1, #0x24               ; =36
100204360: 940506cc    	bl	0x100345e90 <__RNvNtCsjIpoRzUjyHQ_4core6option13expect_failed>
100204364: f0002982    	adrp	x2, 0x100737000 <_anon.af190ef596d93b7202cb9b72c851791c.6+0x10>
100204368: 91026042    	add	x2, x2, #0x98
10020436c: aa0803e0    	mov	x0, x8
100204370: 940506fb    	bl	0x100345f5c <__RNvNtCsjIpoRzUjyHQ_4core9panicking18panic_bounds_check>
100204374: f0002982    	adrp	x2, 0x100737000 <_anon.af190ef596d93b7202cb9b72c851791c.6+0x10>
100204378: 9107a042    	add	x2, x2, #0x1e8
10020437c: aa1c03e0    	mov	x0, x28
100204380: f94053e1    	ldr	x1, [sp, #0xa0]
100204384: 940506f6    	bl	0x100345f5c <__RNvNtCsjIpoRzUjyHQ_4core9panicking18panic_bounds_check>
100204388: f0002982    	adrp	x2, 0x100737000 <_anon.af190ef596d93b7202cb9b72c851791c.6+0x10>
10020438c: 91014042    	add	x2, x2, #0x50
100204390: aa0803e0    	mov	x0, x8
100204394: 940506f2    	bl	0x100345f5c <__RNvNtCsjIpoRzUjyHQ_4core9panicking18panic_bounds_check>
100204398: f0002982    	adrp	x2, 0x100737000 <_anon.af190ef596d93b7202cb9b72c851791c.6+0x10>
10020439c: 9108c042    	add	x2, x2, #0x230
1002043a0: aa0f03e0    	mov	x0, x15
1002043a4: aa1503e1    	mov	x1, x21
1002043a8: 940506ed    	bl	0x100345f5c <__RNvNtCsjIpoRzUjyHQ_4core9panicking18panic_bounds_check>
1002043ac: f0002982    	adrp	x2, 0x100737000 <_anon.af190ef596d93b7202cb9b72c851791c.6+0x10>
1002043b0: 91032042    	add	x2, x2, #0xc8
1002043b4: aa0803e0    	mov	x0, x8
1002043b8: 940506e9    	bl	0x100345f5c <__RNvNtCsjIpoRzUjyHQ_4core9panicking18panic_bounds_check>
1002043bc: f0002982    	adrp	x2, 0x100737000 <_anon.af190ef596d93b7202cb9b72c851791c.6+0x10>
1002043c0: 91074042    	add	x2, x2, #0x1d0
1002043c4: aa1903e0    	mov	x0, x25
1002043c8: aa1503e1    	mov	x1, x21
1002043cc: 940506e4    	bl	0x100345f5c <__RNvNtCsjIpoRzUjyHQ_4core9panicking18panic_bounds_check>
1002043d0: f0002982    	adrp	x2, 0x100737000 <_anon.af190ef596d93b7202cb9b72c851791c.6+0x10>
1002043d4: 91080042    	add	x2, x2, #0x200
1002043d8: aa1c03e0    	mov	x0, x28
1002043dc: f9403be1    	ldr	x1, [sp, #0x70]
1002043e0: 940506df    	bl	0x100345f5c <__RNvNtCsjIpoRzUjyHQ_4core9panicking18panic_bounds_check>
1002043e4: f0002982    	adrp	x2, 0x100737000 <_anon.af190ef596d93b7202cb9b72c851791c.6+0x10>
1002043e8: 91086042    	add	x2, x2, #0x218
1002043ec: aa1c03e0    	mov	x0, x28
1002043f0: f9402be1    	ldr	x1, [sp, #0x50]
1002043f4: 940506da    	bl	0x100345f5c <__RNvNtCsjIpoRzUjyHQ_4core9panicking18panic_bounds_check>
