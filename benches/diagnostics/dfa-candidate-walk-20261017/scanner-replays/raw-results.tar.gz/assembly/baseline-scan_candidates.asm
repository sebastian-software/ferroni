
/private/tmp/ferroni-dfa-replay-20261017/binaries/baseline/cpp_scanner_bench:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100203b00 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates>:
100203b00: d10543ff    	sub	sp, sp, #0x150
100203b04: a90f6ffc    	stp	x28, x27, [sp, #0xf0]
100203b08: a91067fa    	stp	x26, x25, [sp, #0x100]
100203b0c: a9115ff8    	stp	x24, x23, [sp, #0x110]
100203b10: a91257f6    	stp	x22, x21, [sp, #0x120]
100203b14: a9134ff4    	stp	x20, x19, [sp, #0x130]
100203b18: a9147bfd    	stp	x29, x30, [sp, #0x140]
100203b1c: 910503fd    	add	x29, sp, #0x140
100203b20: aa0203f5    	mov	x21, x2
100203b24: aa0003f3    	mov	x19, x0
100203b28: f9440811    	ldr	x17, [x0, #0x810]
100203b2c: f9440c10    	ldr	x16, [x0, #0x818]
100203b30: f9442000    	ldr	x0, [x0, #0x840]
100203b34: f9442667    	ldr	x7, [x19, #0x848]
100203b38: f9445278    	ldr	x24, [x19, #0x8a0]
100203b3c: 3962d27a    	ldrb	w26, [x19, #0x8b4]
100203b40: f9442e62    	ldr	x2, [x19, #0x858]
100203b44: f9443266    	ldr	x6, [x19, #0x860]
100203b48: f9443a6f    	ldr	x15, [x19, #0x870]
100203b4c: f9443e6e    	ldr	x14, [x19, #0x878]
100203b50: f94010a5    	ldr	x5, [x5, #0x20]
100203b54: 910006a8    	add	x8, x21, #0x1
100203b58: a936d7a3    	stp	x3, x21, [x29, #-0x98]
100203b5c: eb08007f    	cmp	x3, x8
100203b60: 54004248    	b.hi	0x1002043a8 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x8a8>
100203b64: aa0303f4    	mov	x20, x3
100203b68: aa0103ed    	mov	x13, x1
100203b6c: b4000583    	cbz	x3, 0x100203c1c <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x11c>
100203b70: d1000688    	sub	x8, x20, #0x1
100203b74: eb15011f    	cmp	x8, x21
100203b78: 54000522    	b.hs	0x100203c1c <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x11c>
100203b7c: 386869bc    	ldrb	w28, [x13, x8]
100203b80: f9414a68    	ldr	x8, [x19, #0x290]
100203b84: f9414e69    	ldr	x9, [x19, #0x298]
100203b88: f941526a    	ldr	x10, [x19, #0x2a0]
100203b8c: f941566b    	ldr	x11, [x19, #0x2a8]
100203b90: aa090108    	orr	x8, x8, x9
100203b94: aa0b0149    	orr	x9, x10, x11
100203b98: aa090108    	orr	x8, x8, x9
100203b9c: b40014a8    	cbz	x8, 0x100203e30 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x330>
100203ba0: 910a4268    	add	x8, x19, #0x290
100203ba4: 53077f89    	lsr	w9, w28, #7
100203ba8: 8b295108    	add	x8, x8, w9, uxtw #4
100203bac: a9402109    	ldp	x9, x8, [x8]
100203bb0: 92401b8a    	and	x10, x28, #0x7f
100203bb4: 2a3c03eb    	mvn	w11, w28
100203bb8: d37ff90c    	lsl	x12, x8, #1
100203bbc: 9acb218b    	lsl	x11, x12, x11
100203bc0: 9adc2529    	lsr	x9, x9, x28
100203bc4: aa090169    	orr	x9, x11, x9
100203bc8: 9adc2508    	lsr	x8, x8, x28
100203bcc: f27a015f    	tst	x10, #0x40
100203bd0: 9a891108    	csel	x8, x8, x9, ne
100203bd4: 360012e8    	tbz	w8, #0x0, 0x100203e30 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x330>
100203bd8: 52800099    	mov	w25, #0x4               ; =4
100203bdc: 51000f28    	sub	w8, w25, #0x3
100203be0: 52800049    	mov	w9, #0x2                ; =2
100203be4: 71000b3f    	cmp	w25, #0x2
100203be8: 1a898108    	csel	w8, w8, w9, hi
100203bec: 34003468    	cbz	w8, 0x100204278 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x778>
100203bf0: 7100051f    	cmp	w8, #0x1
100203bf4: 54003501    	b.ne	0x100204294 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x794>
100203bf8: b4004694    	cbz	x20, 0x1002044c8 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x9c8>
100203bfc: 52800200    	mov	w0, #0x10               ; =16
100203c00: 94058e00    	bl	0x100367400 <dyld_stub_binder+0x100367400>
100203c04: b4004320    	cbz	x0, 0x100204468 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x968>
100203c08: d1000688    	sub	x8, x20, #0x1
100203c0c: 3900001f    	strb	wzr, [x0]
100203c10: 3900041c    	strb	w28, [x0, #0x1]
100203c14: f9000408    	str	x8, [x0, #0x8]
100203c18: 140001a5    	b	0x1002042ac <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x7ac>
100203c1c: f90043e0    	str	x0, [sp, #0x80]
100203c20: 52800043    	mov	w3, #0x2                ; =2
100203c24: 11001860    	add	w0, w3, #0x6
100203c28: f942ea61    	ldr	x1, [x19, #0x5d0]
100203c2c: eb00003f    	cmp	x1, x0
100203c30: 540010e9    	b.ls	0x100203e4c <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x34c>
100203c34: 91164269    	add	x9, x19, #0x590
100203c38: f942e668    	ldr	x8, [x19, #0x5c8]
100203c3c: b860791c    	ldr	w28, [x8, x0, lsl #2]
100203c40: 37f83dfc    	tbnz	w28, #0x1f, 0x1002043fc <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x8fc>
100203c44: 91040288    	add	x8, x20, #0x100
100203c48: eb15011f    	cmp	x8, x21
100203c4c: 9a95310b    	csel	x11, x8, x21, lo
100203c50: 37f00e7c    	tbnz	w28, #0x1e, 0x100203e1c <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x31c>
100203c54: a9061ff0    	stp	x16, x7, [sp, #0x60]
100203c58: a904c7e5    	stp	x5, x17, [sp, #0x48]
100203c5c: f9002fe4    	str	x4, [sp, #0x58]
100203c60: a9073bef    	stp	x15, x14, [sp, #0x70]
100203c64: d280000f    	mov	x15, #0x0               ; =0
100203c68: 52800808    	mov	w8, #0x40               ; =64
100203c6c: f101031f    	cmp	x24, #0x40
100203c70: 9a888308    	csel	x8, x24, x8, hi
100203c74: 7100035f    	cmp	w26, #0x0
100203c78: 9a881308    	csel	x8, x24, x8, ne
100203c7c: ab080288    	adds	x8, x20, x8
100203c80: da9f310c    	csinv	x12, x8, xzr, lo
100203c84: f9415a69    	ldr	x9, [x19, #0x2b0]
100203c88: f9415e68    	ldr	x8, [x19, #0x2b8]
100203c8c: a909a7e8    	stp	x8, x9, [sp, #0x98]
100203c90: 9106426e    	add	x14, x19, #0x190
100203c94: eb15029f    	cmp	x20, x21
100203c98: 9a958299    	csel	x25, x20, x21, hi
100203c9c: a908b3f4    	stp	x20, x12, [sp, #0x88]
100203ca0: aa1403fa    	mov	x26, x20
100203ca4: aa1c03fb    	mov	x27, x28
100203ca8: 37e80d9c    	tbnz	w28, #0x1d, 0x100203e58 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x358>
100203cac: 36d8013c    	tbz	w28, #0x1b, 0x100203cd0 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x1d0>
100203cb0: 6b1b021f    	cmp	w16, w27
100203cb4: 1a9f17e8    	cset	w8, eq
100203cb8: 0a0801e8    	and	w8, w15, w8
100203cbc: f9437278    	ldr	x24, [x19, #0x6e0]
100203cc0: eb18023f    	cmp	x17, x24
100203cc4: 1a8813e8    	csel	w8, wzr, w8, ne
100203cc8: 36000368    	tbz	w8, #0x0, 0x100203d34 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x234>
100203ccc: 5280002f    	mov	w15, #0x1               ; =1
100203cd0: eb1a02bf    	cmp	x21, x26
100203cd4: 54000ca0    	b.eq	0x100203e68 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x368>
100203cd8: eb1a017f    	cmp	x11, x26
100203cdc: 54000ea0    	b.eq	0x100203eb0 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x3b0>
100203ce0: eb1a019f    	cmp	x12, x26
100203ce4: 54000f00    	b.eq	0x100203ec4 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x3c4>
100203ce8: eb1a033f    	cmp	x25, x26
100203cec: 54004000    	b.eq	0x1002044ec <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x9ec>
100203cf0: 387a69a8    	ldrb	w8, [x13, x26]
100203cf4: 386869c9    	ldrb	w9, [x14, x8]
100203cf8: 12006b6a    	and	w10, w27, #0x7ffffff
100203cfc: f942de61    	ldr	x1, [x19, #0x5b8]
100203d00: 8b0a0120    	add	x0, x9, x10
100203d04: eb01001f    	cmp	x0, x1
100203d08: 54003ec2    	b.hs	0x1002044e0 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x9e0>
100203d0c: f942da69    	ldr	x9, [x19, #0x5b0]
100203d10: b8607929    	ldr	w9, [x9, x0, lsl #2]
100203d14: 37f80489    	tbnz	w9, #0x1f, 0x100203da4 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x2a4>
100203d18: 52800000    	mov	w0, #0x0                ; =0
100203d1c: aa0903fb    	mov	x27, x9
100203d20: 37000760    	tbnz	w0, #0x0, 0x100203e0c <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x30c>
100203d24: 9100075a    	add	x26, x26, #0x1
100203d28: 2a1b03fc    	mov	w28, w27
100203d2c: 36f7fbfc    	tbz	w28, #0x1e, 0x100203ca8 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x1a8>
100203d30: 1400014a    	b	0x100204258 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x758>
100203d34: aa1503f7    	mov	x23, x21
100203d38: aa0203f5    	mov	x21, x2
100203d3c: aa0603f6    	mov	x22, x6
100203d40: aa0b03f4    	mov	x20, x11
100203d44: aa0d03fc    	mov	x28, x13
100203d48: f942f262    	ldr	x2, [x19, #0x5e0]
100203d4c: f942f663    	ldr	x3, [x19, #0x5e8]
100203d50: 911dc264    	add	x4, x19, #0x770
100203d54: a94983e1    	ldp	x1, x0, [sp, #0x98]
100203d58: aa1b03e5    	mov	x5, x27
100203d5c: 94000a6a    	bl	0x100206704 <__RNvNtCswl2masnNbE_7ferroni13dfa_prefilter12record_match>
100203d60: f943c268    	ldr	x8, [x19, #0x780]
100203d64: f943c669    	ldr	x9, [x19, #0x788]
100203d68: 5280002f    	mov	w15, #0x1               ; =1
100203d6c: eb09011f    	cmp	x8, x9
100203d70: 54002aa0    	b.eq	0x1002042c4 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x7c4>
100203d74: aa1b03f0    	mov	x16, x27
100203d78: aa1803f1    	mov	x17, x24
100203d7c: aa1c03ed    	mov	x13, x28
100203d80: aa1403eb    	mov	x11, x20
100203d84: f9404bec    	ldr	x12, [sp, #0x90]
100203d88: 9106426e    	add	x14, x19, #0x190
100203d8c: aa1603e6    	mov	x6, x22
100203d90: aa1503e2    	mov	x2, x21
100203d94: aa1703f5    	mov	x21, x23
100203d98: eb1a02ff    	cmp	x23, x26
100203d9c: 54fff9e1    	b.ne	0x100203cd8 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x1d8>
100203da0: 14000032    	b	0x100203e68 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x368>
100203da4: f90023f5    	str	x21, [sp, #0x40]
100203da8: aa0203f5    	mov	x21, x2
100203dac: 53185d02    	lsl	w2, w8, #8
100203db0: 91164268    	add	x8, x19, #0x590
100203db4: a93823b3    	stp	x19, x8, [x29, #-0x80]
100203db8: d10203a0    	sub	x0, x29, #0x80
100203dbc: aa1b03e1    	mov	x1, x27
100203dc0: aa0d03f8    	mov	x24, x13
100203dc4: aa0b03f4    	mov	x20, x11
100203dc8: aa0603f6    	mov	x22, x6
100203dcc: aa0f03fb    	mov	x27, x15
100203dd0: aa1003fc    	mov	x28, x16
100203dd4: aa1103f7    	mov	x23, x17
100203dd8: 94056c8d    	bl	0x10035f00c <__RNvMs3_NtNtCs2npzAA8bySG_14regex_automata6hybrid3dfaNtB5_4Lazy16cache_next_state>
100203ddc: aa1703f1    	mov	x17, x23
100203de0: aa1c03f0    	mov	x16, x28
100203de4: aa1b03ef    	mov	x15, x27
100203de8: aa1503e2    	mov	x2, x21
100203dec: f94023f5    	ldr	x21, [sp, #0x40]
100203df0: aa1603e6    	mov	x6, x22
100203df4: 9106426e    	add	x14, x19, #0x190
100203df8: f9404bec    	ldr	x12, [sp, #0x90]
100203dfc: aa1403eb    	mov	x11, x20
100203e00: aa1803ed    	mov	x13, x24
100203e04: aa0103fb    	mov	x27, x1
100203e08: 3607f8e0    	tbz	w0, #0x0, 0x100203d24 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x224>
100203e0c: 52800001    	mov	w1, #0x0                ; =0
100203e10: 52800060    	mov	w0, #0x3                ; =3
100203e14: 52800037    	mov	w23, #0x1               ; =1
100203e18: 1400012e    	b	0x1002042d0 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x7d0>
100203e1c: 52800001    	mov	w1, #0x0                ; =0
100203e20: 52800017    	mov	w23, #0x0               ; =0
100203e24: 52800000    	mov	w0, #0x0                ; =0
100203e28: aa1403fa    	mov	x26, x20
100203e2c: 1400012a    	b	0x1002042d4 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x7d4>
100203e30: f90043e0    	str	x0, [sp, #0x80]
100203e34: 8b1c0268    	add	x8, x19, x28
100203e38: 39424103    	ldrb	w3, [x8, #0x90]
100203e3c: 11001860    	add	w0, w3, #0x6
100203e40: f942ea61    	ldr	x1, [x19, #0x5d0]
100203e44: eb00003f    	cmp	x1, x0
100203e48: 54ffef68    	b.hi	0x100203c34 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x134>
100203e4c: 900029a2    	adrp	x2, 0x100737000 <_anon.af190ef596d93b7202cb9b72c851791c.6+0x10>
100203e50: 91068042    	add	x2, x2, #0x1a0
100203e54: 940508a2    	bl	0x1003460dc <__RNvNtCsjIpoRzUjyHQ_4core9panicking18panic_bounds_check>
100203e58: 52800001    	mov	w1, #0x0                ; =0
100203e5c: 52800017    	mov	w23, #0x0               ; =0
100203e60: 52800040    	mov	w0, #0x2                ; =2
100203e64: 1400011b    	b	0x1002042d0 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x7d0>
100203e68: 394a3e68    	ldrb	w8, [x19, #0x28f]
100203e6c: 91000500    	add	x0, x8, #0x1
100203e70: 12006b68    	and	w8, w27, #0x7ffffff
100203e74: f942de61    	ldr	x1, [x19, #0x5b8]
100203e78: 0b000108    	add	w8, w8, w0
100203e7c: eb08003f    	cmp	x1, x8
100203e80: 540035a9    	b.ls	0x100204534 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0xa34>
100203e84: f942da69    	ldr	x9, [x19, #0x5b0]
100203e88: b8687925    	ldr	w5, [x9, x8, lsl #2]
100203e8c: 37f82f45    	tbnz	w5, #0x1f, 0x100204474 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x974>
100203e90: 52800000    	mov	w0, #0x0                ; =0
100203e94: f94047f4    	ldr	x20, [sp, #0x88]
100203e98: 36003020    	tbz	w0, #0x0, 0x10020449c <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x99c>
100203e9c: 52800001    	mov	w1, #0x0                ; =0
100203ea0: 52800060    	mov	w0, #0x3                ; =3
100203ea4: 52800037    	mov	w23, #0x1               ; =1
100203ea8: aa1503fa    	mov	x26, x21
100203eac: 1400010a    	b	0x1002042d4 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x7d4>
100203eb0: 52800001    	mov	w1, #0x0                ; =0
100203eb4: 52800017    	mov	w23, #0x0               ; =0
100203eb8: 52800040    	mov	w0, #0x2                ; =2
100203ebc: aa0b03fa    	mov	x26, x11
100203ec0: 14000104    	b	0x1002042d0 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x7d0>
100203ec4: b948b268    	ldr	w8, [x19, #0x8b0]
100203ec8: 31000504    	adds	w4, w8, #0x1
100203ecc: b908b264    	str	w4, [x19, #0x8b0]
100203ed0: 54000303    	b.lo	0x100203f30 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x430>
100203ed4: a94723e0    	ldp	x0, x8, [sp, #0x70]
100203ed8: d37ef501    	lsl	x1, x8, #2
100203edc: aa0d03f8    	mov	x24, x13
100203ee0: aa0b03f4    	mov	x20, x11
100203ee4: aa0603f6    	mov	x22, x6
100203ee8: aa1503f7    	mov	x23, x21
100203eec: aa0203f5    	mov	x21, x2
100203ef0: aa0f03f9    	mov	x25, x15
100203ef4: aa1003fa    	mov	x26, x16
100203ef8: aa1103fc    	mov	x28, x17
100203efc: 94058cc9    	bl	0x100367220 <dyld_stub_binder+0x100367220>
100203f00: aa1c03f1    	mov	x17, x28
100203f04: aa1a03f0    	mov	x16, x26
100203f08: aa1903ef    	mov	x15, x25
100203f0c: aa1503e2    	mov	x2, x21
100203f10: aa1703f5    	mov	x21, x23
100203f14: aa1603e6    	mov	x6, x22
100203f18: 9106426e    	add	x14, x19, #0x190
100203f1c: f9404bec    	ldr	x12, [sp, #0x90]
100203f20: aa1403eb    	mov	x11, x20
100203f24: aa1803ed    	mov	x13, x24
100203f28: 52800024    	mov	w4, #0x1                ; =1
100203f2c: b908b264    	str	w4, [x19, #0x8b0]
100203f30: a94823ea    	ldp	x10, x8, [sp, #0x80]
100203f34: eb15011f    	cmp	x8, x21
100203f38: 54003062    	b.hs	0x100204544 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0xa44>
100203f3c: f94037e8    	ldr	x8, [sp, #0x68]
100203f40: b4001948    	cbz	x8, 0x100204268 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x768>
100203f44: d2800003    	mov	x3, #0x0                ; =0
100203f48: 8b08055c    	add	x28, x10, x8, lsl #1
100203f4c: f94047e8    	ldr	x8, [sp, #0x88]
100203f50: 386869a8    	ldrb	w8, [x13, x8]
100203f54: f943c679    	ldr	x25, [x19, #0x788]
100203f58: f943be61    	ldr	x1, [x19, #0x778]
100203f5c: f943ba65    	ldr	x5, [x19, #0x770]
100203f60: d346fd07    	lsr	x7, x8, #6
100203f64: 52800029    	mov	w9, #0x1                ; =1
100203f68: 9ac82138    	lsl	x24, x9, x8
100203f6c: d10203b4    	sub	x20, x29, #0x80
100203f70: aa0a03e8    	mov	x8, x10
100203f74: 14000007    	b	0x100203f90 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x490>
100203f78: f8677a89    	ldr	x9, [x20, x7, lsl #3]
100203f7c: ea18013f    	tst	x9, x24
100203f80: 540002a1    	b.ne	0x100203fd4 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x4d4>
100203f84: aa0803ea    	mov	x10, x8
100203f88: eb1c011f    	cmp	x8, x28
100203f8c: 54000960    	b.eq	0x1002040b8 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x5b8>
100203f90: 7840251a    	ldrh	w26, [x8], #0x2
100203f94: eb1a00df    	cmp	x6, x26
100203f98: 54002b49    	b.ls	0x100204500 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0xa00>
100203f9c: 8b1a1449    	add	x9, x2, x26, lsl #5
100203fa0: 3dc00120    	ldr	q0, [x9]
100203fa4: 3c9803a0    	stur	q0, [x29, #-0x80]
100203fa8: 3dc00520    	ldr	q0, [x9, #0x10]
100203fac: 3c9903a0    	stur	q0, [x29, #-0x70]
100203fb0: eb1a033f    	cmp	x25, x26
100203fb4: 54fffe29    	b.ls	0x100203f78 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x478>
100203fb8: d346ff40    	lsr	x0, x26, #6
100203fbc: eb01001f    	cmp	x0, x1
100203fc0: 54002aa2    	b.hs	0x100204514 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0xa14>
100203fc4: f86078a9    	ldr	x9, [x5, x0, lsl #3]
100203fc8: 9ada2529    	lsr	x9, x9, x26
100203fcc: 3707fdc9    	tbnz	w9, #0x0, 0x100203f84 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x484>
100203fd0: 17ffffea    	b	0x100203f78 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x478>
100203fd4: a90097e7    	stp	x7, x5, [sp, #0x8]
100203fd8: f9000fe1    	str	x1, [sp, #0x18]
100203fdc: f90043e3    	str	x3, [sp, #0x80]
100203fe0: b90027e4    	str	w4, [sp, #0x24]
100203fe4: a902c7e2    	stp	x2, x17, [sp, #0x28]
100203fe8: b9003ff0    	str	w16, [sp, #0x3c]
100203fec: f90023f5    	str	x21, [sp, #0x40]
100203ff0: f90037ed    	str	x13, [sp, #0x68]
100203ff4: f94033e8    	ldr	x8, [sp, #0x60]
100203ff8: eb1a011f    	cmp	x8, x26
100203ffc: 54002ae9    	b.ls	0x100204558 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0xa58>
100204000: aa0f03f6    	mov	x22, x15
100204004: aa0a03f7    	mov	x23, x10
100204008: aa0603f5    	mov	x21, x6
10020400c: aa0b03f4    	mov	x20, x11
100204010: a94503e8    	ldp	x8, x0, [sp, #0x50]
100204014: 787a7901    	ldrh	w1, [x8, x26, lsl #1]
100204018: f94047e2    	ldr	x2, [sp, #0x88]
10020401c: f94027e8    	ldr	x8, [sp, #0x48]
100204020: d63f0100    	blr	x8
100204024: 36000260    	tbz	w0, #0x0, 0x100204070 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x570>
100204028: a9478fe8    	ldp	x8, x3, [sp, #0x78]
10020402c: eb1a011f    	cmp	x8, x26
100204030: f94037ed    	ldr	x13, [sp, #0x68]
100204034: f9404bec    	ldr	x12, [sp, #0x90]
100204038: 9106426e    	add	x14, x19, #0x190
10020403c: b9403ff0    	ldr	w16, [sp, #0x3c]
100204040: f9401bf1    	ldr	x17, [sp, #0x30]
100204044: 54002949    	b.ls	0x10020456c <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0xa6c>
100204048: aa1403eb    	mov	x11, x20
10020404c: aa1703ea    	mov	x10, x23
100204050: aa1603ef    	mov	x15, x22
100204054: f9403be8    	ldr	x8, [sp, #0x70]
100204058: b94027e4    	ldr	w4, [sp, #0x24]
10020405c: b83a7904    	str	w4, [x8, x26, lsl #2]
100204060: 91000463    	add	x3, x3, #0x1
100204064: aa1503e6    	mov	x6, x21
100204068: f94017e2    	ldr	x2, [sp, #0x28]
10020406c: 1400000c    	b	0x10020409c <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x59c>
100204070: f94037ed    	ldr	x13, [sp, #0x68]
100204074: aa1403eb    	mov	x11, x20
100204078: f9404bec    	ldr	x12, [sp, #0x90]
10020407c: 9106426e    	add	x14, x19, #0x190
100204080: aa1503e6    	mov	x6, x21
100204084: a942c7e2    	ldp	x2, x17, [sp, #0x28]
100204088: aa1703ea    	mov	x10, x23
10020408c: aa1603ef    	mov	x15, x22
100204090: b9403ff0    	ldr	w16, [sp, #0x3c]
100204094: b94027e4    	ldr	w4, [sp, #0x24]
100204098: f94043e3    	ldr	x3, [sp, #0x80]
10020409c: a94107e5    	ldp	x5, x1, [sp, #0x10]
1002040a0: f94007e7    	ldr	x7, [sp, #0x8]
1002040a4: d10203b4    	sub	x20, x29, #0x80
1002040a8: 9100094a    	add	x10, x10, #0x2
1002040ac: eb1c015f    	cmp	x10, x28
1002040b0: f94023f5    	ldr	x21, [sp, #0x40]
1002040b4: 54fff5e1    	b.ne	0x100203f70 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x470>
1002040b8: b4000d83    	cbz	x3, 0x100204268 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x768>
1002040bc: eb15019f    	cmp	x12, x21
1002040c0: 9a958185    	csel	x5, x12, x21, hi
1002040c4: d10006a2    	sub	x2, x21, #0x1
1002040c8: f9004be5    	str	x5, [sp, #0x90]
1002040cc: eb0c00bf    	cmp	x5, x12
1002040d0: 54002280    	b.eq	0x100204520 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0xa20>
1002040d4: 386c69a8    	ldrb	w8, [x13, x12]
1002040d8: 386869c9    	ldrb	w9, [x14, x8]
1002040dc: 12006b6a    	and	w10, w27, #0x7ffffff
1002040e0: f942de61    	ldr	x1, [x19, #0x5b8]
1002040e4: 8b0a0120    	add	x0, x9, x10
1002040e8: eb01001f    	cmp	x0, x1
1002040ec: 54001fa2    	b.hs	0x1002044e0 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x9e0>
1002040f0: f942da69    	ldr	x9, [x19, #0x5b0]
1002040f4: b8607929    	ldr	w9, [x9, x0, lsl #2]
1002040f8: 37f80709    	tbnz	w9, #0x1f, 0x1002041d8 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x6d8>
1002040fc: 52800017    	mov	w23, #0x0               ; =0
100204100: aa0903fb    	mov	x27, x9
100204104: 37000a37    	tbnz	w23, #0x0, 0x100204248 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x748>
100204108: 9100059a    	add	x26, x12, #0x1
10020410c: 2a1b03e8    	mov	w8, w27
100204110: 37f01088    	tbnz	w8, #0x1e, 0x100204320 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x820>
100204114: 37e810c8    	tbnz	w8, #0x1d, 0x10020432c <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x82c>
100204118: 36d80508    	tbz	w8, #0x1b, 0x1002041b8 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x6b8>
10020411c: 6b1b021f    	cmp	w16, w27
100204120: 1a9f17e8    	cset	w8, eq
100204124: 0a0801e8    	and	w8, w15, w8
100204128: f9437278    	ldr	x24, [x19, #0x6e0]
10020412c: eb18023f    	cmp	x17, x24
100204130: 1a8813e8    	csel	w8, wzr, w8, ne
100204134: 36000068    	tbz	w8, #0x0, 0x100204140 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x640>
100204138: 5280002f    	mov	w15, #0x1               ; =1
10020413c: 1400001f    	b	0x1002041b8 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x6b8>
100204140: aa0c03f4    	mov	x20, x12
100204144: aa0b03f9    	mov	x25, x11
100204148: aa0d03fc    	mov	x28, x13
10020414c: f942f262    	ldr	x2, [x19, #0x5e0]
100204150: f90043e3    	str	x3, [sp, #0x80]
100204154: f942f663    	ldr	x3, [x19, #0x5e8]
100204158: aa0403f6    	mov	x22, x4
10020415c: b90003e4    	str	w4, [sp]
100204160: 911dc264    	add	x4, x19, #0x770
100204164: a94983e1    	ldp	x1, x0, [sp, #0x98]
100204168: aa1b03e5    	mov	x5, x27
10020416c: a9471fe6    	ldp	x6, x7, [sp, #0x70]
100204170: 94000a9b    	bl	0x100206bdc <__RNvNtCswl2masnNbE_7ferroni13dfa_prefilter13record_needed>
100204174: f94043e3    	ldr	x3, [sp, #0x80]
100204178: eb000063    	subs	x3, x3, x0
10020417c: 54001100    	b.eq	0x10020439c <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x89c>
100204180: f943c268    	ldr	x8, [x19, #0x780]
100204184: f943c669    	ldr	x9, [x19, #0x788]
100204188: 5280002f    	mov	w15, #0x1               ; =1
10020418c: eb09011f    	cmp	x8, x9
100204190: 9106426e    	add	x14, x19, #0x190
100204194: 54001060    	b.eq	0x1002043a0 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x8a0>
100204198: aa1c03ed    	mov	x13, x28
10020419c: aa1903eb    	mov	x11, x25
1002041a0: aa1403ec    	mov	x12, x20
1002041a4: aa1b03f0    	mov	x16, x27
1002041a8: aa1803f1    	mov	x17, x24
1002041ac: aa1603e4    	mov	x4, x22
1002041b0: f9404be5    	ldr	x5, [sp, #0x90]
1002041b4: d10006a2    	sub	x2, x21, #0x1
1002041b8: eb0c005f    	cmp	x2, x12
1002041bc: 54000be0    	b.eq	0x100204338 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x838>
1002041c0: 52800040    	mov	w0, #0x2                ; =2
1002041c4: 52800021    	mov	w1, #0x1                ; =1
1002041c8: aa1a03ec    	mov	x12, x26
1002041cc: eb1a017f    	cmp	x11, x26
1002041d0: 54fff7e1    	b.ne	0x1002040cc <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x5cc>
1002041d4: 14000063    	b	0x100204360 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x860>
1002041d8: 53185d02    	lsl	w2, w8, #8
1002041dc: 91164268    	add	x8, x19, #0x590
1002041e0: a93823b3    	stp	x19, x8, [x29, #-0x80]
1002041e4: d10203a0    	sub	x0, x29, #0x80
1002041e8: aa1b03e1    	mov	x1, x27
1002041ec: aa0d03f7    	mov	x23, x13
1002041f0: aa0b03f4    	mov	x20, x11
1002041f4: aa0c03f8    	mov	x24, x12
1002041f8: aa0403fb    	mov	x27, x4
1002041fc: aa0f03f6    	mov	x22, x15
100204200: aa1003f9    	mov	x25, x16
100204204: aa1103fa    	mov	x26, x17
100204208: aa0303fc    	mov	x28, x3
10020420c: 94056b80    	bl	0x10035f00c <__RNvMs3_NtNtCs2npzAA8bySG_14regex_automata6hybrid3dfaNtB5_4Lazy16cache_next_state>
100204210: aa1c03e3    	mov	x3, x28
100204214: aa1a03f1    	mov	x17, x26
100204218: aa1903f0    	mov	x16, x25
10020421c: aa1603ef    	mov	x15, x22
100204220: aa1b03e4    	mov	x4, x27
100204224: 9106426e    	add	x14, x19, #0x190
100204228: aa1803ec    	mov	x12, x24
10020422c: aa1403eb    	mov	x11, x20
100204230: d10006a2    	sub	x2, x21, #0x1
100204234: f9404be5    	ldr	x5, [sp, #0x90]
100204238: aa1703ed    	mov	x13, x23
10020423c: aa0003f7    	mov	x23, x0
100204240: aa0103fb    	mov	x27, x1
100204244: 3607f637    	tbz	w23, #0x0, 0x100204108 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x608>
100204248: 52800060    	mov	w0, #0x3                ; =3
10020424c: 52800021    	mov	w1, #0x1                ; =1
100204250: aa0c03fa    	mov	x26, x12
100204254: 1400001f    	b	0x1002042d0 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x7d0>
100204258: 52800001    	mov	w1, #0x0                ; =0
10020425c: 52800017    	mov	w23, #0x0               ; =0
100204260: 52800000    	mov	w0, #0x0                ; =0
100204264: 1400001b    	b	0x1002042d0 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x7d0>
100204268: 52800017    	mov	w23, #0x0               ; =0
10020426c: 52800021    	mov	w1, #0x1                ; =1
100204270: aa0c03fa    	mov	x26, x12
100204274: 14000016    	b	0x1002042cc <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x7cc>
100204278: 52800200    	mov	w0, #0x10               ; =16
10020427c: 94058c61    	bl	0x100367400 <dyld_stub_binder+0x100367400>
100204280: b4000f40    	cbz	x0, 0x100204468 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x968>
100204284: 52800028    	mov	w8, #0x1                ; =1
100204288: 39000008    	strb	w8, [x0]
10020428c: f9000414    	str	x20, [x0, #0x8]
100204290: 14000007    	b	0x1002042ac <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x7ac>
100204294: 52800200    	mov	w0, #0x10               ; =16
100204298: 94058c5a    	bl	0x100367400 <dyld_stub_binder+0x100367400>
10020429c: b4000e60    	cbz	x0, 0x100204468 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x968>
1002042a0: 52800068    	mov	w8, #0x3                ; =3
1002042a4: 39000008    	strb	w8, [x0]
1002042a8: 2900f019    	stp	w25, w28, [x0, #0x4]
1002042ac: 94058c2e    	bl	0x100367364 <dyld_stub_binder+0x100367364>
1002042b0: 52800001    	mov	w1, #0x0                ; =0
1002042b4: 52800060    	mov	w0, #0x3                ; =3
1002042b8: 52800037    	mov	w23, #0x1               ; =1
1002042bc: aa1403fa    	mov	x26, x20
1002042c0: 14000005    	b	0x1002042d4 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x7d4>
1002042c4: 52800001    	mov	w1, #0x0                ; =0
1002042c8: 52800017    	mov	w23, #0x0               ; =0
1002042cc: 52800020    	mov	w0, #0x1                ; =1
1002042d0: f94047f4    	ldr	x20, [sp, #0x88]
1002042d4: f9445668    	ldr	x8, [x19, #0x8a8]
1002042d8: cb140349    	sub	x9, x26, x20
1002042dc: 8b090108    	add	x8, x8, x9
1002042e0: f9045668    	str	x8, [x19, #0x8a8]
1002042e4: f942ca69    	ldr	x9, [x19, #0x590]
1002042e8: b40007e9    	cbz	x9, 0x1002043e4 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x8e4>
1002042ec: f902d268    	str	x8, [x19, #0x5a0]
1002042f0: 36000097    	tbz	w23, #0x0, 0x100204300 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x800>
1002042f4: 52800028    	mov	w8, #0x1                ; =1
1002042f8: 3922d668    	strb	w8, [x19, #0x8b5]
1002042fc: 52800040    	mov	w0, #0x2                ; =2
100204300: a9547bfd    	ldp	x29, x30, [sp, #0x140]
100204304: a9534ff4    	ldp	x20, x19, [sp, #0x130]
100204308: a95257f6    	ldp	x22, x21, [sp, #0x120]
10020430c: a9515ff8    	ldp	x24, x23, [sp, #0x110]
100204310: a95067fa    	ldp	x26, x25, [sp, #0x100]
100204314: a94f6ffc    	ldp	x28, x27, [sp, #0xf0]
100204318: 910543ff    	add	sp, sp, #0x150
10020431c: d65f03c0    	ret
100204320: 52800000    	mov	w0, #0x0                ; =0
100204324: 52800021    	mov	w1, #0x1                ; =1
100204328: 17ffffea    	b	0x1002042d0 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x7d0>
10020432c: 52800040    	mov	w0, #0x2                ; =2
100204330: 52800021    	mov	w1, #0x1                ; =1
100204334: 17ffffe7    	b	0x1002042d0 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x7d0>
100204338: 91164261    	add	x1, x19, #0x590
10020433c: aa1303e0    	mov	x0, x19
100204340: aa1b03e2    	mov	x2, x27
100204344: 97fff451    	bl	0x100201488 <__RNvMs0_NtNtCs2npzAA8bySG_14regex_automata6hybrid3dfaNtB5_3DFA14next_eoi_state>
100204348: 36000100    	tbz	w0, #0x0, 0x100204368 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x868>
10020434c: 52800060    	mov	w0, #0x3                ; =3
100204350: 52800021    	mov	w1, #0x1                ; =1
100204354: aa1503fa    	mov	x26, x21
100204358: 52800037    	mov	w23, #0x1               ; =1
10020435c: 17ffffdd    	b	0x1002042d0 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x7d0>
100204360: aa0b03fa    	mov	x26, x11
100204364: 17ffffdb    	b	0x1002042d0 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x7d0>
100204368: aa0103e5    	mov	x5, x1
10020436c: f94047f4    	ldr	x20, [sp, #0x88]
100204370: 36d800c1    	tbz	w1, #0x1b, 0x100204388 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x888>
100204374: f942f262    	ldr	x2, [x19, #0x5e0]
100204378: f942f663    	ldr	x3, [x19, #0x5e8]
10020437c: 911dc264    	add	x4, x19, #0x770
100204380: a94983e1    	ldp	x1, x0, [sp, #0x98]
100204384: 940008e0    	bl	0x100206704 <__RNvNtCswl2masnNbE_7ferroni13dfa_prefilter12record_match>
100204388: 52800017    	mov	w23, #0x0               ; =0
10020438c: 52800000    	mov	w0, #0x0                ; =0
100204390: 52800021    	mov	w1, #0x1                ; =1
100204394: aa1503fa    	mov	x26, x21
100204398: 17ffffcf    	b	0x1002042d4 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x7d4>
10020439c: 9100069a    	add	x26, x20, #0x1
1002043a0: 52800021    	mov	w1, #0x1                ; =1
1002043a4: 17ffffca    	b	0x1002042cc <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x7cc>
1002043a8: f81783b5    	stur	x21, [x29, #-0x88]
1002043ac: d10263a8    	sub	x8, x29, #0x98
1002043b0: 90000469    	adrp	x9, 0x100290000 <__RNvXs1g_NtCsjIpoRzUjyHQ_4core3fmtRhNtB6_5Debug3fmtCs2npzAA8bySG_14regex_automata+0x124>
1002043b4: 91111129    	add	x9, x9, #0x444
1002043b8: a93827a8    	stp	x8, x9, [x29, #-0x80]
1002043bc: d10223a8    	sub	x8, x29, #0x88
1002043c0: b0fff2e9    	adrp	x9, 0x100061000 <__RNvXs_NtNtCsjIpoRzUjyHQ_4core3ops5rangeINtB4_5RangejENtNtB8_3fmt5Debug3fmtB8_+0x3c>
1002043c4: 91054129    	add	x9, x9, #0x150
1002043c8: a93927a8    	stp	x8, x9, [x29, #-0x70]
1002043cc: d0000b20    	adrp	x0, 0x10036a000 <_anon.64882c1eabbe1c9d1b1908eaf6c4d615.102+0x259>
1002043d0: 91115c00    	add	x0, x0, #0x457
1002043d4: d0002982    	adrp	x2, 0x100736000 <_anon.75a3cae221075a9c115f769f974ea0a5.77+0x1f0>
1002043d8: 913f6042    	add	x2, x2, #0xfd8
1002043dc: d10203a1    	sub	x1, x29, #0x80
1002043e0: 9405079b    	bl	0x10034624c <__RNvNtCsjIpoRzUjyHQ_4core9panicking9panic_fmt>
1002043e4: b0001e80    	adrp	x0, 0x1005d5000 <_anon.4dd95af7101c294943ba620810b52dc3.3+0x75>
1002043e8: 911f6400    	add	x0, x0, #0x7d9
1002043ec: f0002982    	adrp	x2, 0x100737000 <_anon.af190ef596d93b7202cb9b72c851791c.6+0x10>
1002043f0: 9106e042    	add	x2, x2, #0x1b8
1002043f4: 528003e1    	mov	w1, #0x1f               ; =31
1002043f8: 94050706    	bl	0x100346010 <__RNvNtCsjIpoRzUjyHQ_4core6option13expect_failed>
1002043fc: a93827b3    	stp	x19, x9, [x29, #-0x80]
100204400: d10203a0    	sub	x0, x29, #0x80
100204404: aa1503f7    	mov	x23, x21
100204408: aa0203f5    	mov	x21, x2
10020440c: 52800021    	mov	w1, #0x1                ; =1
100204410: aa0e03f9    	mov	x25, x14
100204414: a904c7e5    	stp	x5, x17, [sp, #0x48]
100204418: a9061ff0    	stp	x16, x7, [sp, #0x60]
10020441c: aa0f03fb    	mov	x27, x15
100204420: f9002fe4    	str	x4, [sp, #0x58]
100204424: aa0d03f6    	mov	x22, x13
100204428: aa0603fc    	mov	x28, x6
10020442c: 94056d25    	bl	0x10035f8c0 <__RNvMs3_NtNtCs2npzAA8bySG_14regex_automata6hybrid3dfaNtB5_4Lazy17cache_start_group>
100204430: aa1503e2    	mov	x2, x21
100204434: aa1703f5    	mov	x21, x23
100204438: aa1c03e6    	mov	x6, x28
10020443c: aa1603ed    	mov	x13, x22
100204440: a94513f1    	ldp	x17, x4, [sp, #0x50]
100204444: a9461ff0    	ldp	x16, x7, [sp, #0x60]
100204448: aa1b03ef    	mov	x15, x27
10020444c: f94027e5    	ldr	x5, [sp, #0x48]
100204450: aa1903ee    	mov	x14, x25
100204454: aa0003f9    	mov	x25, x0
100204458: d360fc1c    	lsr	x28, x0, #32
10020445c: 3100073f    	cmn	w25, #0x1
100204460: 54ffbbe1    	b.ne	0x100203bdc <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0xdc>
100204464: 17fffdf8    	b	0x100203c44 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x144>
100204468: 52800100    	mov	w0, #0x8                ; =8
10020446c: 52800201    	mov	w1, #0x10               ; =16
100204470: 94050446    	bl	0x100345588 <__RNvNtCs6zY7rJBZy9D_5alloc5alloc18handle_alloc_error>
100204474: 94026abc    	bl	0x10029ef64 <__RNvMNtNtCs2npzAA8bySG_14regex_automata4util8alphabetNtB2_4Unit3eoi>
100204478: aa0003e2    	mov	x2, x0
10020447c: 91164268    	add	x8, x19, #0x590
100204480: a93823b3    	stp	x19, x8, [x29, #-0x80]
100204484: d10203a0    	sub	x0, x29, #0x80
100204488: aa1b03e1    	mov	x1, x27
10020448c: 94056ae0    	bl	0x10035f00c <__RNvMs3_NtNtCs2npzAA8bySG_14regex_automata6hybrid3dfaNtB5_4Lazy16cache_next_state>
100204490: aa0103e5    	mov	x5, x1
100204494: f94047f4    	ldr	x20, [sp, #0x88]
100204498: 3707d020    	tbnz	w0, #0x0, 0x100203e9c <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x39c>
10020449c: 36d800c5    	tbz	w5, #0x1b, 0x1002044b4 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x9b4>
1002044a0: f942f262    	ldr	x2, [x19, #0x5e0]
1002044a4: f942f663    	ldr	x3, [x19, #0x5e8]
1002044a8: 911dc264    	add	x4, x19, #0x770
1002044ac: a94983e1    	ldp	x1, x0, [sp, #0x98]
1002044b0: 94000895    	bl	0x100206704 <__RNvNtCswl2masnNbE_7ferroni13dfa_prefilter12record_match>
1002044b4: 52800001    	mov	w1, #0x0                ; =0
1002044b8: 52800017    	mov	w23, #0x0               ; =0
1002044bc: 52800000    	mov	w0, #0x0                ; =0
1002044c0: aa1503fa    	mov	x26, x21
1002044c4: 17ffff84    	b	0x1002042d4 <__RNvMs7_NtCswl2masnNbE_7ferroni13dfa_prefilterNtB5_12SetPrefilter15scan_candidates+0x7d4>
1002044c8: b0001e80    	adrp	x0, 0x1005d5000 <_anon.4dd95af7101c294943ba620810b52dc3.3+0x75>
1002044cc: 911d9800    	add	x0, x0, #0x766
1002044d0: f0002982    	adrp	x2, 0x100737000 <_anon.af190ef596d93b7202cb9b72c851791c.6+0x10>
1002044d4: 91008042    	add	x2, x2, #0x20
1002044d8: 52800481    	mov	w1, #0x24               ; =36
1002044dc: 940506cd    	bl	0x100346010 <__RNvNtCsjIpoRzUjyHQ_4core6option13expect_failed>
1002044e0: f0002982    	adrp	x2, 0x100737000 <_anon.af190ef596d93b7202cb9b72c851791c.6+0x10>
1002044e4: 91026042    	add	x2, x2, #0x98
1002044e8: 940506fd    	bl	0x1003460dc <__RNvNtCsjIpoRzUjyHQ_4core9panicking18panic_bounds_check>
1002044ec: f0002982    	adrp	x2, 0x100737000 <_anon.af190ef596d93b7202cb9b72c851791c.6+0x10>
1002044f0: 91074042    	add	x2, x2, #0x1d0
1002044f4: aa1903e0    	mov	x0, x25
1002044f8: aa1503e1    	mov	x1, x21
1002044fc: 940506f8    	bl	0x1003460dc <__RNvNtCsjIpoRzUjyHQ_4core9panicking18panic_bounds_check>
100204500: f0002982    	adrp	x2, 0x100737000 <_anon.af190ef596d93b7202cb9b72c851791c.6+0x10>
100204504: 91080042    	add	x2, x2, #0x200
100204508: aa1a03e0    	mov	x0, x26
10020450c: aa0603e1    	mov	x1, x6
100204510: 940506f3    	bl	0x1003460dc <__RNvNtCsjIpoRzUjyHQ_4core9panicking18panic_bounds_check>
100204514: f0002982    	adrp	x2, 0x100737000 <_anon.af190ef596d93b7202cb9b72c851791c.6+0x10>
100204518: 91014042    	add	x2, x2, #0x50
10020451c: 940506f0    	bl	0x1003460dc <__RNvNtCsjIpoRzUjyHQ_4core9panicking18panic_bounds_check>
100204520: f0002982    	adrp	x2, 0x100737000 <_anon.af190ef596d93b7202cb9b72c851791c.6+0x10>
100204524: 91092042    	add	x2, x2, #0x248
100204528: aa0503e0    	mov	x0, x5
10020452c: aa1503e1    	mov	x1, x21
100204530: 940506eb    	bl	0x1003460dc <__RNvNtCsjIpoRzUjyHQ_4core9panicking18panic_bounds_check>
100204534: f0002982    	adrp	x2, 0x100737000 <_anon.af190ef596d93b7202cb9b72c851791c.6+0x10>
100204538: 91032042    	add	x2, x2, #0xc8
10020453c: aa0803e0    	mov	x0, x8
100204540: 940506e7    	bl	0x1003460dc <__RNvNtCsjIpoRzUjyHQ_4core9panicking18panic_bounds_check>
100204544: f0002982    	adrp	x2, 0x100737000 <_anon.af190ef596d93b7202cb9b72c851791c.6+0x10>
100204548: 9107a042    	add	x2, x2, #0x1e8
10020454c: f94047e0    	ldr	x0, [sp, #0x88]
100204550: aa1503e1    	mov	x1, x21
100204554: 940506e2    	bl	0x1003460dc <__RNvNtCsjIpoRzUjyHQ_4core9panicking18panic_bounds_check>
100204558: f0002982    	adrp	x2, 0x100737000 <_anon.af190ef596d93b7202cb9b72c851791c.6+0x10>
10020455c: 91086042    	add	x2, x2, #0x218
100204560: aa1a03e0    	mov	x0, x26
100204564: f94033e1    	ldr	x1, [sp, #0x60]
100204568: 940506dd    	bl	0x1003460dc <__RNvNtCsjIpoRzUjyHQ_4core9panicking18panic_bounds_check>
10020456c: f0002982    	adrp	x2, 0x100737000 <_anon.af190ef596d93b7202cb9b72c851791c.6+0x10>
100204570: 9108c042    	add	x2, x2, #0x230
100204574: aa1a03e0    	mov	x0, x26
100204578: f9403fe1    	ldr	x1, [sp, #0x78]
10020457c: 940506d8    	bl	0x1003460dc <__RNvNtCsjIpoRzUjyHQ_4core9panicking18panic_bounds_check>
