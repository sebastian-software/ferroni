import copy
import json
import pathlib
import statistics
import subprocess

base = pathlib.Path('/private/tmp/ferriki-independent-perf-20261017')
unit = base / 'multi'
cwd = '/Users/sebastian/Workspace/.codex/dfa-consumer-bench/ferriki/node'
args = ['node', 'scripts/bench-independent-paired.mjs',
        '--engine', f'baseline={unit}/baseline', '--engine', f'candidate={unit}/candidate',
        '--corpus-root', '/private/tmp/ferriki-style-ascii-20261017/published-corpus',
        '--processes', '8', '--rounds', '60', '--cold-runs', '0',
        '--write', str(unit / 'homepage-extension.json')]
with (unit / 'homepage-extension.log').open('w') as log:
    subprocess.run(args, cwd=cwd, stdout=log, stderr=subprocess.STDOUT, check=True)

original = json.loads((unit / 'homepage-confirmation.json').read_text())
extension = json.loads((unit / 'homepage-extension.json').read_text())
for key in ['engines', 'harnessSha256', 'machine', 'node']:
    assert original[key] == extension[key], key
for key in ['rounds', 'warmups', 'corpus-root']:
    assert original['options'][key] == extension['options'][key], key
report = copy.deepcopy(original)
report['runs'] = [dict(run, cohort=cohort) for cohort, source in enumerate([original, extension]) for run in source['runs']]
report['cohorts'] = ['homepage-confirmation.json', 'homepage-extension.json']
report['options']['processes'] = str(len(report['runs']))

def interval(ratios):
    state = 20261017
    estimates = []
    for _ in range(10000):
        sample = []
        for _ in ratios:
            state = (state * 1664525 + 1013904223) & 0xffffffff
            sample.append(ratios[int((state / 2**32) * len(ratios))])
        estimates.append(statistics.median(sample) - 1)
    estimates.sort()
    return [estimates[249], estimates[9749]]

rows = []
for i, case in enumerate(report['runs'][0]['cases']):
    ratios = []
    for run in report['runs']:
        current = run['cases'][i]
        for key in ['path', 'sha256', 'outputSha256']:
            assert current[key] == case[key], key
        ratios.append(statistics.median(current['samplesMs']['candidate']) / statistics.median(current['samplesMs']['baseline']))
    rows.append({'path': case['path'], 'change': statistics.median(ratios) - 1, 'interval95': interval(ratios), 'ratios': ratios})
totals = [{name: sum(statistics.median(case['samplesMs'][name]) for case in run['cases']) for name in ['baseline', 'candidate']} for run in report['runs']]
summary = report['summary']['candidate']
summary.update(rows=rows, totals=totals, totalChange=statistics.median(t['candidate'] / t['baseline'] for t in totals) - 1)
assert len(report['cold']) == 40 and not extension['cold']
(unit / 'homepage-pooled.json').write_text(json.dumps(report) + '\n')
print(json.dumps({'totalChange': summary['totalChange'], 'largestWarmUpper': max(row['interval95'][1] for row in rows), 'coldInterval95': summary['coldInterval95'], 'rows': rows}, indent=2), flush=True)
