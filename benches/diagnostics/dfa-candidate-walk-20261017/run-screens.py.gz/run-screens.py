import subprocess, pathlib, time
root=pathlib.Path('/private/tmp/ferriki-independent-perf-20261017')
cwd='/Users/sebastian/Workspace/.codex/dfa-consumer-bench/ferriki/node'
corpus='/private/tmp/ferriki-style-ascii-20261017/published-corpus'
for unit in ['selector','ferroni','multi']:
    jobs=[]
    if unit!='multi':
        jobs.append(('curated-screen', ['scripts/bench-native-boundary-paired.mjs','--engine',f'baseline={root/unit}/baseline.node','--engine',f'candidate={root/unit}/candidate.node','--processes','3','--rounds','25','--warmups','12','--themes','html','--corpora','curated']))
    if unit=='multi':
        jobs.append(('multi-screen', ['scripts/bench-independent-paired.mjs','--multi']))
    jobs.append(('homepage-screen', ['scripts/bench-independent-paired.mjs']))
    for label,args in jobs:
        if 'scripts/bench-independent-paired.mjs' in args:
            args+=['--engine',f'baseline={root/unit}/baseline','--engine',f'candidate={root/unit}/candidate','--corpus-root',corpus,'--processes','3','--rounds','40','--cold-runs','0']
            if unit=='ferroni': args+=['--ferroni-source-comparison']
        args+=['--write',str(root/unit/(label+'.json'))]
        print(f'START {unit}/{label}',flush=True)
        with (root/unit/(label+'.log')).open('w') as log:
            r=subprocess.run(['node',*args],cwd=cwd,stdout=log,stderr=subprocess.STDOUT)
        print(f'END {unit}/{label} exit={r.returncode}',flush=True)
        if r.returncode: print((root/unit/(label+'.log')).read_text()[-6000:],flush=True);raise SystemExit(r.returncode)
