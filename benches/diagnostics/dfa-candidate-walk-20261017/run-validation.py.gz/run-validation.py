import subprocess, pathlib, concurrent.futures, os, json, time
base=pathlib.Path('/private/tmp/ferriki-independent-perf-20261017')
pnpm='/Users/sebastian/Library/pnpm/.tools/pnpm/10.28.2/bin/pnpm'
roots={'selector':'/Users/sebastian/Workspace/.codex/selector-matcher/ferriki','multi':'/Users/sebastian/Workspace/.codex/native-multi-theme/ferriki','consumer':'/Users/sebastian/Workspace/.codex/dfa-consumer-bench/ferriki','ferroni':'/private/tmp/ferroni-dfa-candidate-walk-20261017'}
results={}
def check(unit,label,args,node=False,env=None):
    root=roots[unit]
    path=base/('ferroni' if unit=='consumer' else unit)/(label+'.log')
    with path.open('w') as log:
        r=subprocess.run(args,cwd=root+('/node' if node else ''),env=env,stdout=log,stderr=subprocess.STDOUT)
    results[unit+'/'+label]=r.returncode
    print(unit,label,'PASS' if r.returncode==0 else 'FAIL',flush=True)
    (base/'validation-status.json').write_text(json.dumps(results,indent=2)+'\n')
    if r.returncode: print(path.read_text()[-5000:],flush=True)
    return r.returncode

def ferriki(unit):
    if unit!='consumer':
        check(unit,'fmt',['cargo','fmt','--all','--check'])
        check(unit,'clippy',['cargo','clippy','--workspace','--all-targets','--all-features','--locked','--','-D','warnings'])
        check(unit,'workspace-tests',['cargo','test','--workspace','--all-features','--locked'])
        check(unit,'adrs',['node','scripts/check-adrs.mjs'])
    if unit=='multi':
        check(unit,'eslint',[pnpm,'exec','eslint','ferriki/src/index.mjs','scripts/check-ferriki-multitheme.mjs'],True)
        check(unit,'js-format',[pnpm,'exec','oxfmt','--check','ferriki/src/index.mjs','scripts/check-ferriki-multitheme.mjs','ferriki/native-binding.d.ts',roots[unit]+'/adr/0017-node-html-output-priority.md'],True)
        check(unit,'typecheck',[pnpm,'run','typecheck'],True)
    check(unit,'core-compat',[pnpm,'run','test:ferriki-compat:core'],True)
    check(unit,'curated-parity',[pnpm,'run','check:bench-curated'],True)
    check(unit,'tiobe-parity',[pnpm,'run','check:bench-tiobe'],True)

def ferroni():
    env=os.environ.copy();env['FERRONI_ONIGURUMA_DIR']='/Users/sebastian/Workspace/ferroni/.cache/upstream/oniguruma-orig'
    check('ferroni','fmt',['cargo','fmt','--all','--check'])
    check('ferroni','onigmo-prepare',['./scripts/prepare-onigmo-sources.sh'])
    check('ferroni','clippy',['cargo','clippy','--all-targets','--all-features','--locked','--','-D','warnings'],env=env)
    check('ferroni','workspace-tests',['cargo','test','--locked'],env=env)
    check('ferroni','self-check',['cargo','test','--locked','--features','prefilter-self-check','--lib','--test','api_test','--test','compat_prefilter_differential','--test','scanner_prefilter_regressions'],env=env)
    check('ferroni','feature-matrix',['cargo','test','--all-features','--locked','--test','regex_feature_matrix'],env=env)
    check('ferroni','docs',['cargo','doc','--no-deps','--locked'],env={**env,'RUSTDOCFLAGS':'-D warnings'})
    check('ferroni','deny',['cargo','deny','--all-features','--locked','check'],env=env)
    check('ferroni','workflow-pins',['./scripts/check-workflow-pins.sh'])
    check('ferroni','readme-family',['./scripts/readme-family.sh','check'])
    check('ferroni','readme-figures',['./scripts/check-readme-figures.sh'])
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    pending=[pool.submit(ferriki,'selector'),pool.submit(ferriki,'multi'),pool.submit(ferroni)]
    for f in concurrent.futures.as_completed(pending): f.result()
ferriki('consumer')
print('VALIDATION COMPLETE',json.dumps(results),flush=True)
