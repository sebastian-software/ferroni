import subprocess, pathlib
root=pathlib.Path('/private/tmp/ferriki-independent-perf-20261017')
cwd='/Users/sebastian/Workspace/.codex/dfa-consumer-bench/ferriki/node'
corpus='/private/tmp/ferriki-style-ascii-20261017/published-corpus'
jobs=[]
for unit,language in [('selector','cpp'),('ferroni','mdx')]:
    jobs.append((unit,'selected-confirmation',['scripts/bench-native-boundary-paired.mjs','--engine',f'baseline={root/unit}/baseline.node','--engine',f'candidate={root/unit}/candidate.node','--processes','8','--rounds','60','--warmups','12','--themes','html','--corpora','curated','--languages',language]))
for unit in ['selector','ferroni','multi']:
    args=['scripts/bench-independent-paired.mjs','--engine',f'baseline={root/unit}/baseline','--engine',f'candidate={root/unit}/candidate','--corpus-root',corpus,'--processes','8','--rounds','60','--cold-runs','40']
    if unit=='ferroni':args+=['--ferroni-source-comparison']
    jobs.append((unit,'homepage-confirmation',args))
args=['scripts/bench-independent-paired.mjs','--engine',f'baseline={root}/multi/baseline','--engine',f'candidate={root}/multi/candidate','--corpus-root',corpus,'--processes','6','--rounds','40','--cold-runs','30','--multi']
jobs.append(('multi','multi-confirmation',args))
for unit,label,args in jobs:
    print('START',unit,label,flush=True)
    with (root/unit/(label+'.log')).open('w') as log:
        r=subprocess.run(['node',*args,'--write',str(root/unit/(label+'.json'))],cwd=cwd,stdout=log,stderr=subprocess.STDOUT)
    print('END',unit,label,'exit='+str(r.returncode),flush=True)
    if r.returncode:print((root/unit/(label+'.log')).read_text()[-5000:],flush=True);raise SystemExit(r.returncode)
