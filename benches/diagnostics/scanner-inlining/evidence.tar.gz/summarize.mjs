import { readFileSync, writeFileSync } from "node:fs";
import { gunzipSync } from "node:zlib";
import { quantile } from "../../../../scripts/tiobe-benchmark.mjs";

const median = (values) => quantile(values, 0.5);
const geomean = (values) =>
  Math.exp(values.reduce((sum, value) => sum + Math.log(value), 0) / values.length);
function summarize(file, baseline, candidate) {
  const report = JSON.parse(gunzipSync(readFileSync(new URL(file, import.meta.url))));
  const cases = report.runs[0].cases.map((entry, index) => {
    const samples = report.runs.map((run) => run.cases[index].samplesMs);
    const ratios = samples.map((sample) => median(sample[candidate]) / median(sample[baseline]));
    return {
      id: entry.id,
      baselineMedianMs: median(samples.flatMap((sample) => sample[baseline])),
      candidateMedianMs: median(samples.flatMap((sample) => sample[candidate])),
      medianChange: median(ratios) - 1,
      minChange: Math.min(...ratios) - 1,
      maxChange: Math.max(...ratios) - 1,
    };
  });
  const groups = Object.fromEntries(
    ["all", "example", "large"].map((size) => {
      const selected = report.runs[0].cases.flatMap((entry, index) =>
        size === "all" || entry.id.includes(`/${size}/`) ? [index] : [],
      );
      const changes = report.runs.map(
        (run) =>
          geomean(
            selected.map((index) => {
              const sample = run.cases[index].samplesMs;
              return median(sample[candidate]) / median(sample[baseline]);
            }),
          ) - 1,
      );
      return [
        size,
        {
          cases: selected.length,
          medianChange: median(changes),
          minChange: Math.min(...changes),
          maxChange: Math.max(...changes),
        },
      ];
    }),
  );
  return { baseline, candidate, groups, cases };
}

writeFileSync(
  new URL("summary.json", import.meta.url),
  `${JSON.stringify(
    {
      trial: summarize("noinline-trial.json.gz", "local-control", "noinline-insert"),
      broad: summarize("noinline-broad.json.gz", "local-control", "noinline-insert"),
      broadVersusOld: summarize("noinline-broad.json.gz", "registry-2.1.0", "noinline-insert"),
    },
    null,
    2,
  )}\n`,
);
