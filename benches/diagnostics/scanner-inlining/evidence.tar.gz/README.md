# Ferroni 2.2.1 regression profiling

This local follow-up to [update PR #268](https://github.com/sebastian-software/ferriki/pull/268)
was measured on October 16, 2026, on the same Apple M1 Ultra/macOS arm64,
Node 24.21.0 and rustc 1.99.0 as the [initial comparison](../ferroni-2.2.1/README.md).
The update PR is unchanged. This directory retains an experimental Ferroni
patch and its evidence; Ferriki's final runtime uses ordinary registry 2.2.1.

## Finding

The TypeScript/TSX regressions are locally recoverable with a one-attribute
change in Ferroni: prevent `PatternBits::insert` from being inlined into the
large DFA candidate walk. The [patch](noinline-insert.patch) preserves the
bitset representation, matching logic, candidate ordering, cache-clear fix,
and automatic DFA warmup.

Four native profiles use the existing `profile-tiobe.mjs` harness, the curated
large TypeScript/TSX fixtures, `github-dark`, and 15 seconds of warmed HTML
work each. The harness checks exact Shiki HTML agreement before profiling.
Samply 0.13.1 records release builds with line tables and symbols retained.
The summaries discard the first two seconds of each process, after setup and
warmup in all four captures.

| Self CPU samples in `SetPrefilter::candidates_at` | 2.1.0 | 2.2.1 |
| --- | ---: | ---: |
| TypeScript | 27.02% | 34.04% |
| TSX | 26.07% | 33.05% |

The extra share is concentrated in the candidate walk. Renderer and host-boundary
work do not explain the regression. In the retained [2.2.1 hot-loop assembly](hot-loop-2.2.1.txt),
the state ID is stored to and loaded from a stack slot on each byte, while the
[2.1.0 loop](hot-loop-2.1.0.txt) keeps it in a register. The new inline bitset
insertion and the additional cache-clear tracking increase the state the
compiler must keep live. Preventing insertion from being inlined is a measured
way to improve this code generation. This is not a commit-level bisect proving
which upstream change introduced every part of the slowdown.

## Ordinary release measurements

Profiling builds and profiled timings are not used for the speed comparisons.
The experiment and control are ordinary stripped release builds using the
same temporary Ferroni source path, compiler, flags and dependencies. The
control matches the registry 2.2.1 source. This controls for differences in
Cargo source identity as well as the source change itself.

A first four-engine trial compares registry 2.1.0, registry 2.2.1, the local
unmodified 2.2.1 control, and the patch: TypeScript and TSX, both sizes, three
fresh workers, 12 warmups and 30 timed rounds. Registry and local 2.2.1 show
essentially the same regression; the patch recovers it.

A separate broad run compares registry 2.1.0, the local 2.2.1 control and the
patch across all 20 curated languages and both sizes: 40 cases, three fresh
workers, 12 warmups and 20 timed rounds. Engine order rotates within each
round. All output hashes match within and across workers.

The patch reduces elapsed time against unchanged 2.2.1 by **2.77%** in the
median per-worker geometric mean of case-median ratios (range -3.31% to
-2.33%). Against 2.1.0, its aggregate change is -2.68%. Selected large cases:

| Language | Unchanged 2.2.1, ms | Patched 2.2.1, ms | Median worker change |
| --- | ---: | ---: | ---: |
| TypeScript | 15.687 | 14.085 | -10.57% |
| TSX | 19.531 | 17.571 | -9.69% |
| Astro | 21.022 | 19.916 | -5.90% |
| Svelte | 23.487 | 21.728 | -6.32% |
| Vue | 11.200 | 10.590 | -5.22% |
| CSS | 5.677 | 5.674 | -0.01% |
| Ruby | 3.637 | 3.641 | +0.19% |
| YAML | 31.797 | 32.074 | +0.73% |

The time columns pool samples; changes use the median of per-worker ratios.
Patched large TypeScript is 2.14% below 2.1.0; TSX is 1.12% below it, with one
worker 0.72% above it. The original regressions are recovered on this machine.
Not every cell improves: small MDX and C++ have central changes around +3%,
with worker ranges crossing zero. The full ranges are in [summary.json](summary.json).

## Adoption boundary

The fix belongs in Ferroni. Ferriki should continue to consume a released
engine rather than vendor a scanner implementation or add grammar-specific
prefilter settings. The patch is a concrete upstream candidate, not a released
dependency or an applied Ferriki change.

Before adopting it upstream, repeat representative scanner/HTML and general
regex cases on Linux x86-64 and another supported target. Inlining and register
allocation are compiler/architecture-sensitive. No Linux, Windows, cold-start,
allocation or memory improvement is established by this investigation.

## Evidence and reproduction

- [Context](context.json), symbolic [baseline](baseline-build.json) and
  [candidate](candidate-build.json) receipts, ordinary [control](local-control-build.json)
  and [patch](noinline-build.json) receipts.
- `base-{typescript,tsx}` and `candidate-{typescript,tsx}` retain profile JSON,
  diagnostic workload reports, logs, symbol sidecars and filtered summaries.
  Symbol sidecars are gzip-compressed for storage. Temporary binaries are not
  committed.
- [Four-engine trial](noinline-trial.json.gz), [broad run](noinline-broad.json.gz),
  and [summary](summary.json). Regenerate with `node summarize.mjs` here.

Run the profiles from `node/`, after building each registry version with
`CARGO_PROFILE_RELEASE_DEBUG=line-tables-only CARGO_PROFILE_RELEASE_STRIP=none`:

```sh
samply record --save-only --unstable-presymbolicate -o /tmp/typescript.json.gz \
  node scripts/profile-tiobe.mjs --corpus curated --language typescript \
  --size large --boundary native --seconds 15
```

Set `FERRIKI_CACHE_DIR` to the checkout's `node/.cache/ferriki-assets` and
`FERRIKI_ASSETS_REMOTE=0`. Repeat with `--language tsx`. Use the existing
`summarize-samply-profile.mjs` with `--since <profile.meta.startTime + 2000>`
and `--focus candidates_at` after decompressing the matching symbol sidecar.

For ordinary measurements, copy registry Ferroni 2.2.1 to a temporary source
directory, build with `FERRIKI_FERRONI_PATH` pointing there, and save the addon
and receipt. Apply the one-line patch in that same directory and build again.
Do not carry the profiling overrides into these builds. Use
`bench-native-boundary-paired.mjs` with the engines and options retained in the
raw reports. Builds, tests and profiling never overlap the timed comparisons.

## Validation

The [validation record](validation/checks.json) and compressed logs retain:

- The complete Ferriki core compatibility gate with the patch: passed,
  including native grammar coverage and existing HTML/API/consumer checks.
  Its optional Phiki smoke test retains the existing missing-PHP skip.
- Ferroni's library suite with `prefilter-self-check`, in release mode and
  with one test thread: 527 passed.
- Ferroni's API, prefilter differential and scanner regression integration
  suites with `prefilter-self-check`: passed, with the intentional fuzz-seed
  writer ignored.
- Lint for the summary script and rebuilding the ordinary registry 2.2.1
  addon after restoring the temporary manifests: passed.

The first core attempt stopped at a Cargo lockfile/override mismatch in the
dependency-boundary check. A temporary workspace patch entry made the same
local engine visible to every Cargo subprocess, and the complete retry passed.
Both the manifest and lockfile were then restored.

The packaged Ferroni source excludes benchmark fixtures that its library
tests read. Matching grammar/trace inputs were restored from tag `v2.2.1`
for these tests. An initial parallel library run also hit a single-Regex
accept assertion. That test passes on the unmodified control in isolation,
and all 527 patched library tests pass serially; this is not evidence of a
patch-induced matching change or a clean parallel run. The original failure
log is retained. No matching logic was changed or assertion suppressed.
