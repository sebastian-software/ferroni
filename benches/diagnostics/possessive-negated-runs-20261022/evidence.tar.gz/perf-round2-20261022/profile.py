import os, subprocess, time, sys
from pathlib import Path
root=Path(__file__).resolve().parent
case=sys.argv[1]
corpus='tokenizer' if case.startswith('tiktoken_') else 'production'
env=dict(os.environ,PRODUCTION_CASE=case,PRODUCTION_ENGINE='rust',PRODUCTION_CORPUS=corpus)
p=subprocess.Popen([str(root/'baseline'),'--steady','100000000'],env=env,stdout=subprocess.DEVNULL)
try:
 time.sleep(1)
 subprocess.run(['/usr/bin/sample',str(p.pid),'5','1','-file',str(root/(case+'.sample.txt'))],check=True)
finally:
 p.terminate()
 p.wait()
